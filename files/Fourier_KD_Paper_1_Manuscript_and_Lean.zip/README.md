# Polytopes and mixed extreme points of finite Fourier Kirkwood–Dirac state spaces

Public research manuscript by hys-ops. The central statement is Theorem 1.1. The article treats finite abelian groups with their full normalized Fourier basis. The first page credits the full prior pure-hull classification in the 23 November 2026 revision of the Bruneton-led note. Sections 2–4 address finite generation, the size and topology of the mixed extreme locus, and the explicit two-qubit family. Section 5 supplies a uniform separating construction. Appendix A maps the results to proof declarations and describes the formal route to an embedded interval.

## Read or rebuild the article

Open Fourier_KD_Polytopes.pdf. The full editable text, including the references, is in one UTF-8 file, Fourier_KD_Polytopes.tex. From a normal TeX Live or MiKTeX installation with Latin Modern, AMS packages, geometry, booktabs, array, xcolor and hyperref, run these commands in the unpacked directory.

    pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error Fourier_KD_Polytopes.tex
    pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error Fourier_KD_Polytopes.tex

## Reproduce the mathematical formalization

Extract Fourier_KD_Paper_1_Lean_Complete.zip, enter its FiniteFourierKD directory and run the following command.

    python3 replay.py

Use Python 3, Git and elan/Lake. The first clean replay fetches the pinned dependencies. The project uses Lean 4.34.1 and mathlib d13f23b723b8a846827a245b89c10fc7d3f11612.

This public copy preserves the Lean project and kernel logs; only README wording and machine-specific workspace prefixes in saved run manifests were changed. Its SHA-256 is 6dd51e82b9a9b3b4c38356b5301430ac3e579df47158816e748f1d793c8e40ca. The recorded run in verification/run.json reports success. verification/logs/kernel.log lists the 60 individually rechecked modules, and verification/logs/endpoint-axioms.log records the types and transitive axioms for the 13 endpoints. Its README.md and README.ko.md give further detail.

hys-ops directed the research into whether reusable tests from earlier work could transfer to a different problem. ChatGPT and Codex contributed to developing the mathematical arguments, drafting the manuscript, and writing the Lean formalization. No independent human review is recorded.
