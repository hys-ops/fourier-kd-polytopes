# Infinite-rank extreme states for Fourier Kirkwood–Dirac positivity
Public research manuscript by hys-ops · 24 November 2026

The PDF and the standalone .tex file are the same English manuscript. Compile twice with pdflatex from this directory. No separate bibliography files are needed. KD_Paper_2_Audit_KO.md gives the evidence and prior-art comparison in Korean.

## The principal result

For second-countable locally compact Hausdorff abelian G, the full set of normal trace-one Fourier KD-positive states on L²(G) admits an infinite-rank extreme point precisely when finite relative indices of nested compact open subgroups are unbounded and some pair of compact open subgroups is incomparable. Quantification over extreme decompositions is in the full physical state set. Theorem 1.1 includes the chain and bounded-index obstructions.

## Principal reproducibility archive

Fourier_KD_LCA_Lean_Extension.zip is the byte-for-byte original Lean release. It has its own README, version manifest and saved kernel logs. Lean 4.33.1, mathlib 0df444a360eaa60ab8c11dca51a86af692955474. Inspect src/KDGeneralAbelianFinal.lean, logs/LCAExtensionAudit-types-and-axioms.txt, logs/module-status.tsv. Run this quick audit from the outer directory to cross-check stored receipts and all project-source hashes with no recompile:

    python3 audit_receipts.py Fourier_KD_LCA_Lean_Extension.zip

To run the original checker from a clean installation:

    unzip Fourier_KD_LCA_Lean_Extension.zip
    cd Fourier_KD_LCA_Lean_Extension
    sha256sum -c SHA256SUMS
    lake update
    python3 replay.py --fetch

With the correct Lean toolchain, mathlib cache access and sufficient disk, the final command builds and kernel-checks all 266 local modules. The archived run used hash-matched previous receipts where available. The paper-2 audit rechecked the hashes, recorded build results, kernel logs and declarations; it did not claim a new 266-module build.

## Two supplemental Lean checks

The supplements have separate instructions, source files and receipts. Both use Lean 4.34.1 with mathlib d13f23b723b8a846827a245b89c10fc7d3f11612. Their object files are not interchangeable with those of the principal 4.33.1 archive. The finite-section supplement embeds Fourier_KD_Paper_1_Lean_Complete.zip as its pinned finite-state dependency.

* The discrete modulation supplement checks the stabilizer and the exact cardinality of a countable discrete kernel's modulation orbit with infinite active displacement subgroup. On actual ℓ² the supplement also verifies finite rank for a positive operator with finite occupied diagonal and the infinite active-subgroup inference under the zero-cross-block partition condition. The condition for KD extreme operators is supplied by the original ChainLimit.extreme_partition. The group action uses the inverse character parameter relative to the paper. The two parameterizations have identical orbits.
* The finite-section supplement checks a concrete (A+B)/(A∩B) and the almost-everywhere symbol sign on the ambient phase space. Its mixed extreme set and arc live in the finite matrix section. The full LCA mixed-state classification and the trace-norm closed-hull corollary remain written deductions.

The exact cardinality of the set of infinite-rank extreme **states on the original arbitrary LCA group** has a written proof in the manuscript. The discrete kernel orbit theorem checks one step. No global cardinality endpoint was found in the 266-module archive. These scope distinctions also apply to the comparisons with Spriet. His equation (11), concerning a real Hilbert–Schmidt span, is a separate question outside the claims of this manuscript.

The historical Prüfer tower note included under supporting/ gives an additional written construction on C_(p^infty) × C_p. Its verification paragraph predates the 266-module formalization; consult the latter for the existence theorem. hys-ops directed the research programme. ChatGPT and Codex contributed to developing the mathematical arguments, drafting the manuscript, and writing the Lean formalization. Public packaging changes only documentation and machine-specific path prefixes in supplemental receipts; the Lean source files and principal archive are unchanged. Source and provenance searches are documented separately from proof checking. No external human review is recorded.
