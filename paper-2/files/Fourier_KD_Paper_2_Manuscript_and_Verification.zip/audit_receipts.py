"""Check the identities and archived receipts for the original LCA Lean release."""
import csv
import hashlib
import io
import re
import sys
from collections import Counter
from functools import cache
from pathlib import Path
from zipfile import ZipFile

release = Path(sys.argv[1] if len(sys.argv) > 1 else "Fourier_KD_LCA_Lean_Extension.zip")
expected = "6bf7a554e17768577645b6af8c987180815ee506ece04791a9acea9c38bf4275"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


require(sha(release.read_bytes()) == expected, "Unexpected archive version")
with ZipFile(release) as archive:
    root = "Fourier_KD_LCA_Lean_Extension/"

    def get(name):
        return archive.read(root + name)

    manifest = get("SHA256SUMS").decode().splitlines()
    for line in manifest:
        digest, path = line.split(maxsplit=1)
        require(sha(get(path.lstrip("*"))) == digest, path)

    records = list(csv.DictReader(io.StringIO(get("logs/module-status.tsv").decode()), delimiter="\t"))
    sources = {Path(p).stem: archive.read(p) for p in archive.namelist() if p.startswith(root + "src/") and p.endswith(".lean")}
    recorded = [r["module"] for r in records]
    require(len(set(recorded)) == len(recorded) and set(sources) == set(recorded), "Source coverage mismatch")
    imports = {n: [d for d in re.findall(r"^(?:public )?import ([.\w]+)", s.decode(), re.M) if d in sources] for n, s in sources.items()}

    @cache
    def import_hash(n):
        return sha(sources[n] + b"".join(import_hash(d).encode() for d in imports[n]))

    for r in records:
        n = r["module"]
        require((r["source-sha256"], r["transitive-local-import-hash"], r["strict-compilation"], r["independent-kernel"]) == (sha(sources[n]), import_hash(n), "PASS", "PASS"), n)
    builds = get("logs/build.log").decode().splitlines()
    kernels = get("logs/kernel.log").decode().splitlines()
    require(Counter(n for n in builds if n in sources) == Counter(recorded), "Build markers")
    require(Counter(n.removeprefix("replaying ") for n in kernels if n.startswith("replaying ")) == Counter(recorded), "Kernel markers")
    axioms = get("logs/LCAExtensionAudit-types-and-axioms.txt").decode()
    for n in ["physical_iff", "prescribed_haar_iff", "intrinsic_iff"]:
        key = f"'KDClosure.GeneralAbelian.{n}' depends on axioms: [propext, Classical.choice, Quot.sound]"
        require(key in axioms, n)
    visited = set()

    def visit(n):
        if n not in visited:
            visited.add(n)
            for d in imports[n]:
                visit(d)

    visit("KDGeneralAbelianFinal")
    print(f"Archive SHA-256 {expected}")
    print(f"{len(manifest)} manifest entries, {len(records)} source and import digests, {len(records)} pairs of saved receipts.")
    print(f"KDGeneralAbelianFinal local module closure including itself: {len(visited)}.")
    print("All three archived endpoint axiom lists agree. No recompilation performed by this script.")
