# Fourier Kirkwood–Dirac positivity, Paper 2, §5: pure-state hull criterion
Lean 4.33.1 verification supplement, 2026-11-25. This is not an
independent human peer review or a formal audit of other sections.

## Result
For an arbitrary second-countable locally compact abelian group G and its
physical Plancherel Fourier realization, the set of all trace-one physical
Fourier KD-positive states equals the trace-norm closed convex hull of the
rank-one physical KD-positive states **if and only if** all compact open
subgroups of G are totally ordered by inclusion. Recommended entry point: **`src/KDHullTraceNorm.lean`**,
**`KDClosure.Hull.pure_hull_classical_traceNorm_iff_chain`**.
It states the equality in **Tr sqrt(D†D)** for the approximation error
D=A−T, with no assumed equivalence of two possible norms. The intermediate
variational theorem is `KDClosure.Hull.pure_state_hull_iff_chain`.
This is the displayed “Moreover” equivalence in the proposition in §5,
“Which groups have mixed extreme states?”. It does not rely on formalizing
either the other sentence in that proposition about a mixed extreme within a
finite-dimensional face, or the separate infinite-rank criterion from §7.

- `pure_generating_iff_all_compact_opens_comparable`: intrinsic group-only
  version quantifying over every compatible realization. With a compact open
  subgroup one such Fourier realization and both Haar measures are constructed
  from that subgroup; in particular necessity cannot be vacuous.
- `incomparable_canonical_witness`: any incomparable A, B yield a concrete
  trace-one Fourier KD-positive state on G, outside the full closed hull.
- `no_compact_open_equality`: when no compact open subgroups exist, both
  the state set and its proposed hull are empty (vacuous total order).
- No assumption of the finite witness, compression of a pure state remaining
  in the finite cone, characterization of ambient pure packets, operator rank,
  weak-to-trace upgrading, compact-convex positive-state generation, or either
  direction of the target equivalence is passed to the final theorem.
- `traceVariational` uses the bona fide extended trace norm dual formula
  sup over all matched finite orthonormal frames u,v of
  sum |<vᵢ, T uᵢ>|; this is not operator-norm or Hilbert–Schmidt closure. Here this formula is actually
  proved equal to the sum of the singular values for every compact operator,
  using the Hilbert spectral theorem, and to the intrinsic trace of the
  positive square root of D†D at finite gauge. For all pairs of physical
  states compactness and finite gauge (≤2) are proved, not assumptions.
  Physical states have norm 1; there is no 1/2 normalization. In
  `traceNormClosure` an arbitrary bounded candidate is permitted; each
  approximating error must itself have finite Schatten-1 norm. The two
  closures are proved identical for every subset of physical states, and
  the final equivalence is then independently checked.

## Why this goes beyond a formal outline
**If the subgroups form a chain:** Krein–Milman on a compact convex set of
subnormalized KD kernels and the existing ambient rank-one extreme-point
theorem give WOT approximation by finite convex mixtures of *normalized*
rank-one physical states, with zero removed. A separate Hilbert-space theorem
`Tight.wot_tendsto_trace` upgrades WOT convergence of positive substates to
variational-trace convergence at every positive trace-one limit. Its proof
approximates by a finite basis window and obtains an explicit cut-off error
≤2√(trace outside the window). Finite matrix entries then control the middle
block. Complements, frames, and arbitrary nets are genuine, with no
finite-dimensional or separability assumption on the generic estimate.
Convexity and variational-trace closedness of the physical state set prove
the reverse set inclusion.

**If two subgroups are incomparable:** their finite quotient is
nonexceptional. The genuine finite classification constructs a trace-one KD
operator outside the finite pure hull. It is lifted to an actual ambient
physical state with exactly that finite block. For *all* ambient pure states,
compression is either zero or a nonnegative multiple of an actual finite KD
pure state. The cone over the finite pure hull is closed; the compactness,
trace-one slice and trace-continuous matrix tests are proved. Therefore the
lift could not be approximated by pure mixtures. This argument does not use
an external pure-state parametrization or assume finite rank one survived
a compression without proof.

What is new, in dependency order:
- KDPacketCompression: for arbitrary compact-open H and L≤K, arbitrary center
  a and arbitrary unitary ambient character (not necessarily trivial on L),
  integration over quotient cells gives zero or a scalar times an actual
  finite character times the indicator of a coset of W=image(H∩K→K/L).
  The character on W is proved to descend and extend to *all* K/L.
- KDPhysicalCompression: same result for the actual adjoint of the explicitly
  normalized Haar-cell isometry J:ℓ²(K/L)→L²(G), with the exact Haar and
  arbitrary wavefunction normalization factors. The compression of |ψ><ψ|
  really is |J*ψ><J*ψ|. The archive's atom_orthonormal is reused unchanged.
- KDFinitePacketSign: direct Fourier calculation of nonnegative KD rows for
  all finite subgroup-coset character packets including the zero vector.
- KDClosedHullSeparation: proof that the cone over a compact trace-one convex
  base is closed and convex, its trace-one slice is the original base, and a
  continuous linear compression mapping every pure atom into that cone
  excludes a lift of a finite witness from the closed hull. This general
  separation theorem is *not* claimed as the global KD theorem.

- KDTraceCompression: compression by an isometry is non-expansive for the
  extended trace norm defined by the supremum over pairs of finite orthonormal
  frames. We also prove one-unit-vector matrix coefficients are bounded by it.
  This is the variational trace norm, not the operator or Hilbert–Schmidt norm;
  equivalence to a separately defined singular-value norm is not assumed.
- KDPacketRays: actual J*ψ entries give a nonnegative multiple of a *normalized*
  finite packet projector. The explicit finite set is proved finite, trace one,
  positive semidefinite, of literal matrix rank one, and KD positive in the
  physical (ket) convention. Both complex conjugation conventions are checked.
- KDPacketExclusion: if C is a trace-one finite matrix outside the full finite
  pure-state convex hull, its concrete Haar-cell operator, the sum of its
  matrix coefficients times |e_i><e_j|, is not in the variational trace-norm
  closure of convex mixtures of *any* ambient character/coset wavefunctions,
  even unnormalized ones. No assumption that compression preserves a cone,
  finite pure-state classification, trace continuity, or assumed separation.

  This is a supplementary direct computation. The global necessity theorem
  does not assume Spriet's pure-wavefunction classification.
- KDFinitePurePort: prove finiteness of *every* rank-one physical finite KD
  matrix, not only named packets. Selectively ports authentic finite Paper 1
  vector and literal-rank arguments. KDAllAmbientPure: the block of every
  ambient pure state is zero or a positive multiple of a finite physical pure
  state; this follows directly from positivity, KD block sign, and rank and
  covers all pure states without geometric classification.
- KDFiniteStateLift: every positive finite KD matrix of trace one is realized
  by a genuine ambient physical state with exactly that finite block;
  proves physical trace and Fourier positivity through original quotient lift.
- 14 finite 4.34.1 Paper 1 modules (names prefixed KF, namespaces KFS5) are
  selectively ported into 4.33.1 (imports adjusted, one concrete finite-cyclic
  subgroup divisibility lemma re-proved in KDCyclicCompat). The finite witness
  is the original, compiled Paper 1 strict-converse proof; it is not an axiom.
- KDHullNonchain: incomparable compact opens produce a finite nonexceptional
  abelian quotient, that quotient has a trace-one matrix outside the finite
  pure hull, and its full ambient lift still lies outside the trace-norm closed
  hull. No external literature placeholders or custom axioms.
- Original sources: GitHub hys-ops/fourier-kd-polytopes (tree at
  343c4732a6b6668a97023ab641def82eb1bf93ed), Paper 2 LCA archive, finite
  section and nested Paper 1 archive. Includes only reachable original imports
  and explicitly identified ports, not all 266 LCA modules.
  
## Reproduce
Use Lean 4.33.1 and a prepared mathlib4 checkout with compiled artifacts
at commit 0df444a360eaa60ab8c11dca51a86af692955474:

```sh
MATHLIB_DIR=/path/to/mathlib4 ./replay.sh
```
If available, set KD_DEPENDENCY_OLEANS to the immutable prebuilt LCA modules
to avoid rebuilding unchanged dependencies. The shipped MANIFEST.tsv lists
all actual imports in topological order and separates new proofs, finite
ports, and verbatim LCA source. Every new module and the audited top-level
declaration is checked with warning-as-error and leanchecker. logs/replay.txt
includes all source SHA-256 and transitive axiom outputs. Only propext,
Classical.choice, and Quot.sound occur in the supported declarations.

## Scope
The formal theorem is for the actual Fourier realization (Haar pair plus
L² Fourier isometry agreeing with the ordinary integrable Fourier
transform), as in the existing model. The group-level statement explicitly
constructs these data from a compact open subgroup when one exists. We do
not claim a new from-scratch proof of general Plancherel theory for groups
with no compact opens. Nor is this an independent human refereeing report.
The proof uses both the original Lean evidence and additional new checked
lemmas; it is not a certificate for every claim in the entire paper.

The recorded run reused unchanged dependencies from a previously audited
build at the same Lean and mathlib pins. It rechecked all affected modules,
including the final theorem and audit, with Lean and leanchecker. The normal
fresh replay above needs only the pinned mathlib checkout, not a prior archive
or its project cache.
