#!/usr/bin/env bash
set -euo pipefail
# Run in an environment supplying the pinned mathlib and its lake packages:
# MATHLIB_DIR=/path/to/mathlib4 ./replay.sh
root="$(cd "$(dirname "$0")" && pwd)"
if [[ -n "${MATHLIB_DIR:-}" ]]; then
  test "$(git -C "$MATHLIB_DIR" rev-parse HEAD)" = 0df444a360eaa60ab8c11dca51a86af692955474
  export LEAN_PATH="$root/build:$(cd "$MATHLIB_DIR" && lake env printenv LEAN_PATH)"
else
  : "${LEAN_PATH:?Set MATHLIB_DIR to the checkout, or supply a compatible existing LEAN_PATH}"
  export LEAN_PATH="$root/build:$LEAN_PATH"
fi
mkdir -p "$root/build" "$root/logs"
: > "$root/logs/verified-cache-modules.txt"
if [[ -n "${KD_PREVIOUS_V3:-}" ]]; then
  : "${KD_DEPENDENCY_OLEANS:?Set this to compatible prebuilt modules for the certified baseline}"
  python3 "$root/verify_cached.py" "$root" "$KD_PREVIOUS_V3" "$KD_DEPENDENCY_OLEANS" > "$root/logs/verified-cache-modules.txt"
fi
cd "$root/src"
exec > >(sed -u "s|$root|<KIT>|g" | tee "$root/logs/replay.txt") 2>&1
if [[ -n "${KD_DEPENDENCY_OLEANS:-}" ]]; then export LEAN_PATH="$root/build:$KD_DEPENDENCY_OLEANS:$LEAN_PATH"; fi
set -x
lean --version | grep -F 'version 4.33.1,'
test -d "$root/src"
sha256sum -c "$root/SOURCES.sha256"

while IFS=$'\t' read -r idx role n; do
  if [[ "$idx" == "order" ]]; then continue; fi
  if grep -F -x -q "$n" "$root/logs/verified-cache-modules.txt"; then
    : # Fully certified transitive input DAG from the read-back v3 baseline.
  elif [[ "$role" == "verbatim-lca" && -n "${KD_DEPENDENCY_OLEANS:-}" && -f "$KD_DEPENDENCY_OLEANS/$n.olean" ]]; then
    # Cache only the exact unchanged dependency pin, never a new proof.
    :
  elif [[ "$role" == "verbatim-lca" ]]; then
    lean -o "$root/build/$n.olean" "$n.lean"
  elif [[ "$role" == "finite-ported" ]]; then
    # Independently kernel-check the complete port's transitive route below.
    lean -o "$root/build/$n.olean" "$n.lean"
  else
    lean -DwarningAsError=true -o "$root/build/$n.olean" "$n.lean"
    leanchecker "$n"
  fi
done < "$root/MANIFEST.tsv"
