import KDDiscreteReduction
import KDCompactDualReduction
import Mathlib.Topology.Algebra.Group.Quotient

noncomputable section
namespace KDClosure.ActualCore
open Set Topology CompactCore
variable (G : Type*) [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
variable [Nonempty (CO G)]

/-- The open union of the actual compact open subgroups. -/
def U : OpenAddSubgroup G where
  carrier := {x | ∃ K : CO G, x ∈ subgroup K}
  zero_mem' := ⟨Classical.choice ‹Nonempty (CO G)›,AddSubgroup.zero_mem _⟩
  add_mem' := by
    rintro x y ⟨K,hx⟩ ⟨H,hy⟩
    refine ⟨join K H,?_⟩
    exact (subgroup (join K H)).add_mem ((le_sup_left : K.val ≤ K.val ⊔ H.val) hx)
      ((le_sup_right : H.val ≤ K.val ⊔ H.val) hy)
  neg_mem' := by rintro x ⟨K,hx⟩; exact ⟨K,(subgroup K).neg_mem hx⟩
  isOpen' := by
    rw [show {x | ∃ K : CO G, x ∈ subgroup K} = ⋃ K : CO G, (K.val : Set G) from Set.ext fun _ => Set.mem_iUnion.symm]
    exact isOpen_iUnion fun K => K.val.isOpen

abbrev base := ↥(U G).toAddSubgroup
def allK : AddSubgroup (base G) := ⨅ K : CO G, (subgroup K).comap (U G).toAddSubgroup.subtype
abbrev C := base G ⧸ allK G
abbrev π := QuotientAddGroup.mk' (allK G)
def inside (K : CO G) : AddSubgroup (base G) := (subgroup K).comap (U G).toAddSubgroup.subtype

theorem inside_open (K : CO G) : IsOpen (inside G K : Set (base G)) :=
  K.val.isOpen.preimage continuous_subtype_val

theorem inside_compact (K : CO G) : IsCompact (inside G K : Set (base G)) := by
  apply Topology.IsEmbedding.subtypeVal.isCompact_iff.mpr
  have eqn : (fun x : base G => (x:G)) '' (inside G K : Set (base G)) = (K.val : Set G) := by
    ext x
    exact ⟨fun ⟨y,hy,h⟩ => h ▸ hy,fun hx => ⟨⟨x,⟨K,hx⟩⟩,hx,rfl⟩⟩
  rw [eqn]
  exact K.property

theorem allK_le (K : CO G) : allK G ≤ inside G K := iInf_le _ K

theorem allK_closed : IsClosed (allK G : Set (base G)) := by
  change IsClosed ((⨅ K : CO G, inside G K : AddSubgroup (base G)) : Set (base G))
  rw [AddSubgroup.coe_iInf]
  exact isClosed_iInter fun K => (inside G K).isClosed_of_isOpen (inside_open G K)

theorem allK_compact : IsCompact (allK G : Set (base G)) :=
  (inside_compact G (Classical.choice ‹Nonempty (CO G)›)).of_isClosed_subset
    (allK_closed G) (allK_le G _)

def block (K : CO G) : CO (C G) :=
  ⟨⟨(inside G K).map (π G),QuotientAddGroup.isOpenMap_coe _ (inside_open G K)⟩,
   (inside_compact G K).image QuotientAddGroup.continuous_mk⟩

theorem preimage_block (K : CO G) : (subgroup (block G K)).comap (π G) = inside G K :=
  (QuotientAddGroup.comap_map_mk' (allK G) (inside G K)).trans (sup_eq_right.mpr (allK_le G K))

theorem block_cover (x : C G) : ∃ K : CO G, x ∈ subgroup (block G K) := by
  induction x using QuotientAddGroup.induction_on with
  | _ z =>
    obtain ⟨K,hK⟩ := z.property
    exact ⟨K,z,hK,rfl⟩

theorem block_le_iff (H K : CO G) : block G H ≤ block G K ↔ H ≤ K := by
  constructor
  · intro h x hx
    let z : base G := ⟨x,⟨H,hx⟩⟩
    have hz : π G z ∈ subgroup (block G H) := ⟨z,hx,rfl⟩
    have h' : z ∈ (subgroup (block G K)).comap (π G) := h hz
    rwa [preimage_block] at h'
  · intro h
    exact AddSubgroup.map_mono (AddSubgroup.comap_mono h)

theorem compact_contained {S : Set (C G)} (hs : IsCompact S) :
    ∃ K : CO G, S ⊆ (subgroup (block G K) : Set (C G)) := by
  apply hs.elim_directed_cover (fun K : CO G => (subgroup (block G K) : Set (C G)))
    (fun K => (block G K).val.isOpen)
  · exact fun x _ => Set.mem_iUnion.mpr (block_cover G x)
  · intro H K
    exact ⟨join H K,(block_le_iff G _ _).mpr (le_sup_left : H.val ≤ H.val⊔K.val),
      (block_le_iff G _ _).mpr (le_sup_right : K.val ≤ H.val⊔K.val)⟩

theorem blocks_separate {x : C G} (hx : x≠0) : ∃ K : CO G, x ∉ subgroup (block G K) := by
  induction x using QuotientAddGroup.induction_on with
  | _ z =>
    by_contra! bad
    apply hx
    apply (QuotientAddGroup.eq_zero_iff _).mpr
    apply AddSubgroup.mem_iInf.mpr
    intro K
    rw [←show inside G K = (subgroup K).comap (U G).toAddSubgroup.subtype from rfl,←preimage_block]
    exact bad K

end KDClosure.ActualCore
