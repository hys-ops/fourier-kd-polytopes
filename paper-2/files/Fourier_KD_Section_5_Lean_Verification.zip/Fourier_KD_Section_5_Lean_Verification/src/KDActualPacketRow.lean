import KDAtomPort
import KDWaveSupport

/-! Exact operator identification shared by the KD table and weighted-Gram/PSD routes. -/
namespace KDClosure.AtomBridge
open WaveSupport AmbientFourier Classical
open scoped BigOperators
variable {p : ℕ} [Fact p.Prime]

/-- Literal transport over the proved equality of the cardinalities. -/
def reindex {a b : ℕ} (h : a=b) : ZMod a ≃+* ZMod b := by
  subst b
  exact RingEquiv.refl _

omit [Fact p.Prime] in
theorem reindex_chart {a b : ℕ} [NeZero a] [NeZero b] (h : a=b)
    (ha : rootsOfUnity a ℂ ≤ pRoots p) (hb : rootsOfUnity b ℂ ≤ pRoots p) (x : ZMod a) :
    rootHead ha x = rootHead hb (reindex h x) := by
  subst b
  rfl

noncomputable def sparseKet (p : ℕ) [Fact p.Prime] (m j n : ℕ)
    (x : ZMod (p^(1+n*(m+1)))) : ℂ :=
  cyclicPacket (L:=p^m) (fun _ => negativeDigit p) j n ((reindex (size_prime_power p m n)).symm x)

theorem sparseKet_value (m j n : ℕ) (hj : j<n) (x : ZMod (p^(1+n*(m+1)))) :
    let b := (j+1)*(m+1)
    sparseKet p m j n x =
      (Real.sqrt (Fintype.card (insideGroup (N:=1+n*(m+1)) p (b+1)) : ℝ) : ℂ)⁻¹ *
      (if Frequency.inside p (b+1) x then negFreq ((p:ZMod (p^(1+n*(m+1))))^b) x else 0) := by
  classical
  let e := reindex (size_prime_power p m n)
  let u := (encodeLevel p (p^m) n).symm (e.symm x)
  let z := sparsePoint p m n u
  have coords : z = powerChart p (1+n*(m+1)) x := by
    change sparseRootHead p m n ((encodeLevel p (p^m) n) u) = _
    simp only [u,Equiv.apply_symm_apply]
    calc sparseRootHead p m n (e.symm x) =
          powerChart p (1+n*(m+1)) (e (e.symm x)) :=
            reindex_chart (size_prime_power p m n) _ _ _
         _ = _ := by rw [e.apply_symm_apply]
  have raw := rawPacket_formula m j n hj u
  change rawPacket _ j n u = (if ambientInside p (1+(j+1)*(m+1)) z then
      childPhase p ((j+1)*(m+1)) z else 0) at raw
  rw [coords] at raw
  rw [chart_phase,chart_inside] at raw
  have le : (j+1)*(m+1)+1 ≤ 1+n*(m+1) := by
    rw [Nat.add_comm 1 (n*(m+1))]
    exact Nat.add_le_add_right (Nat.mul_le_mul_right (m+1) (Nat.succ_le_of_lt hj)) 1
  dsimp only
  change (packetNormInv p (p^m) j : ℂ) * rawPacket _ j n u = _
  rw [raw,inner_card _ le,negFreq_apply]
  simp [packetNormInv,size_prime_power,Nat.add_comm]

/-- On every deeper sparse head, exactly the same physical rank-one entries occur
in the Gram certificate and in the inverse Fourier tile, with no scalar or sign change. -/
theorem sparse_projector_row (m j n : ℕ) (hj : j<n) :
    (fun x h => sparseKet p m j n x * star (sparseKet p m j n (x+h))) =
      Frequency.rowFromTile ((j+1)*(m+1)) := by
  apply projector_row (p:=p) (N:=1+n*(m+1))
  exact sparseKet_value m j n hj

/-- The actual row transform of a packet in the sparse Gram certificate is the
same characteristic tile used in the finiteWitness KD certificate. -/
theorem sparse_projector_symbol (m j n : ℕ) (hj : j<n)
    (x k : ZMod (p^(1+n*(m+1)))) :
    ZMod.dft (fun h => sparseKet p m j n x * star (sparseKet p m j n (x+h))) k =
      (Frequency.tile ((j+1)*(m+1)) x k : ℂ) := by
  rw [show (fun h => sparseKet p m j n x * star (sparseKet p m j n (x+h))) =
      Frequency.rowFromTile ((j+1)*(m+1)) x from congrFun (sparse_projector_row m j n hj) x]
  simp [Frequency.rowFromTile]

/-- Relabel the sparse birth j by the dense child-character index (j+1)(m+1).
The amplitude sampler is its exact left inverse on the chosen levels. -/
def birthIndices (m : ℕ) (J : Finset ℕ) : Finset ℕ :=
  J.image (fun j => (j+1)*(m+1))

def birthAmplitude (m : ℕ) (y : ℕ → ℝ) (b : ℕ) := y (b/(m+1)-1)

theorem perturbRow_eq_sparse_outer (m n : ℕ) (J : Finset ℕ) (hj : ∀ j ∈ J, j<n)
    (y : ℕ → ℝ) (x h : ZMod (p^(1+n*(m+1)))) :
    Frequency.perturbRow (birthIndices m J) (birthAmplitude m y) x h =
      ∑ j ∈ J, (y j:ℂ) * sparseKet p m j n x * star (sparseKet p m j n (x+h)) := by
  have inj (a b : ℕ) : (a+1)*(m+1)=(b+1)*(m+1) → a=b := by
    intro e
    exact Nat.add_right_cancel (Nat.mul_right_cancel (Nat.succ_pos m) e)
  simp only [Frequency.perturbRow,Finset.sum_apply,Pi.smul_apply,smul_eq_mul,birthIndices]
  rw [Finset.sum_image (fun a _ b _ e => inj a b e)]
  refine Finset.sum_congr rfl (fun j hmem => ?_)
  simp [birthAmplitude,← sparse_projector_row m j n (hj j hmem),mul_assoc]

/-- Every entry of the KD-certified witness: its perturbation is built from
the same sparse physical ket columns as the weighted two-channel Gram argument. -/
theorem witness_eq_physical_sparse (m n : ℕ) (J : Finset ℕ) (hj : ∀ j ∈ J, j<n)
    (y : ℕ → ℝ) (d : ZMod (p^(1+n*(m+1))) → ℝ) (pos : ZMod (p^(1+n*(m+1))) → Prop)
    [DecidablePred pos] (x h : ZMod (p^(1+n*(m+1)))) {q : ℕ} (t u : ZMod q) :
    Frequency.finiteWitness (birthIndices m J) (birthAmplitude m y) d pos x h t u =
      (if h=0 then (d x:ℂ) else 0) * Frequency.baseBlock q (pos x) t u +
      (∑ j ∈ J, (y j:ℂ)*sparseKet p m j n x*star (sparseKet p m j n (x+h))) *
        (Frequency.U q t u-Frequency.V q t u) := by
  change _ + Frequency.perturbRow _ _ x h * _ = _
  rw [perturbRow_eq_sparse_outer m n J hj y]
  rfl

end KDClosure.AtomBridge
