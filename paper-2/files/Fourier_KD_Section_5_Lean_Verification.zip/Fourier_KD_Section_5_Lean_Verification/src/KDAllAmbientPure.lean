import KDPacketExclusion
import KDFinitePurePort
import KDChainLimitBlockHull
import KDLCANoOpen

/-! A stronger proof of the nonchain obstruction than the literal paper route.
Every actual rank-one physical state is controlled directly by finite Haar
block positivity. No external pure-state characterization on the ambient
group, assumed continuity, or axioms about trace class are used. -/
noncomputable section
set_option linter.unusedSectionVars false
namespace KDClosure.Hull
open Classical Set MeasureTheory CompactCore LCAReality LCAQuotient ChainLimit Matrix
open scoped Matrix.Norms.Elementwise ComplexOrder ComplexConjugate InnerProductSpace ENNReal
open scoped KDClosure.SubgroupMeasure

variable {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℂ X] [CompleteSpace X]
variable {D : Type*} [Fintype D] [DecidableEq D]

private theorem ps_factor (T : X →L[ℂ] X) (p : T.IsPositive) : ∃ S, T=star S*S :=
  CStarAlgebra.nonneg_iff_eq_star_mul_self.mp ((ContinuousLinearMap.nonneg_iff_isPositive T).mpr p)

theorem matrixTests_rank_le_one (e : D → X) (T : X →L[ℂ] X)
    (rank1 : Module.rank ℂ (LinearMap.range T.toLinearMap) ≤ 1) :
    (matrixTests e T).rank ≤ 1 := by
  obtain ⟨v,hv⟩ := rank_le_one_iff.mp rank1
  have cols (j : D) : ∃ r : ℂ, r • v.val = T (e j) := by
    obtain ⟨c,h⟩ := hv ⟨T (e j), e j,rfl⟩
    exact ⟨c,congrArg Subtype.val h⟩
  choose c h using cols
  have hm : matrixTests e T = Matrix.vecMulVec (fun i => inner ℂ (e i) v.val) c := by
    ext i j
    change inner ℂ (e i) (T (e j)) = inner ℂ (e i) v.val * c j
    rw [← h j,inner_smul_right,mul_comm]
  rw [hm]
  exact Matrix.rank_vecMulVec_le _ _

variable [AddCommGroup D]
theorem kd_matrix_rankone_ray {A : Matrix D D ℂ} (ps : A.PosSemidef) (rank1 : A.rank ≤ 1)
    (kd : ∀ x χ, 0 ≤ KDFourier.symbol A x χ) : A ∈ rays (convexHull ℝ (finitePure D)) := by
  classical
  let t := A.trace.re
  have ht : 0 ≤ t := (Complex.nonneg_iff.mp ps.trace_nonneg).1
  have tr : A.trace=(t:ℂ) := Complex.ext rfl (by simpa using (Complex.nonneg_iff.mp ps.trace_nonneg).2.symm)
  rcases ht.eq_or_lt with zero|hp
  · have hz := ps.trace_eq_zero_iff.mp (by rw [tr,← zero]; norm_num)
    refine ⟨0,le_rfl,packetMatrix (⊥:AddSubgroup D) 0 0,
      subset_convexHull ℝ _ (finitePackets_subset ⟨⟨⊥,0,0⟩,rfl⟩),?_⟩
    simpa using hz
  let B := t⁻¹ • A
  have bpos : B.PosSemidef := ps.smul (inv_nonneg.mpr ht)
  have btr : B.trace = 1 := by
    change (t⁻¹ • A).trace=1
    rw [trace_smul,tr,Complex.real_smul,Complex.ofReal_inv]
    exact inv_mul_cancel₀ (Complex.ofReal_ne_zero.mpr hp.ne')
  have hbr : B.rank = A.rank := by
    have eq : B = ((t⁻¹:ℝ):ℂ) • A := by ext i j; change (t⁻¹:ℝ) • A i j = _; rfl
    rw [eq,Matrix.rank_smul_of_mem_nonZeroDivisors A (mem_nonZeroDivisors_of_ne_zero (Complex.ofReal_ne_zero.mpr (inv_ne_zero hp.ne')))]
  obtain ⟨j,hj⟩ := FinitePort.hasEig bpos.isHermitian btr
  have : Nonempty {i // bpos.isHermitian.eigenvalues i ≠ 0} := ⟨⟨j,hj⟩⟩
  have br : 0 < B.rank := bpos.isHermitian.rank_eq_card_non_zero_eigs ▸ Fintype.card_pos
  have bpure : B ∈ finitePure D := by
    refine ⟨bpos,btr,le_antisymm (hbr ▸ rank1) (Nat.one_le_iff_ne_zero.mpr (ne_of_gt br)),?_⟩
    intro x χ; change 0 ≤ KDFourier.symbol (t⁻¹ • A) x χ
    rw [KDFourier.symbol_smul]
    exact mul_nonneg (Complex.zero_le_real.mpr (inv_nonneg.mpr ht)) (kd _ _)
  exact ⟨t,ht,B,subset_convexHull ℝ _ bpure,by simp [B,smul_smul,hp.ne']⟩

variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
    [T2Space G] [LocallyCompactSpace G] [SecondCountableTopology G] [MeasurableSpace G] [BorelSpace G]
variable (μ : Measure G) [μ.IsAddHaarMeasure] (ν : Measure (LCAReality.Dual G)) [SFinite ν]
variable (F : FourierRealization μ ν)
local instance (L K : CO G) : Fintype (CoreQuot L K) := @Fintype.ofFinite _ (finite_core L K)

def ambientPure : Set (Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ) :=
  {T | T∈ambientStates μ ν F ∧ Module.rank ℂ (LinearMap.range T.toLinearMap)=1}

theorem all_ambient_pure_ray (L K : CO G) (le : L≤K) (u : G) (ξ : LCAReality.Dual G)
    (T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ) (hp : T ∈ ambientPure μ ν F) :
    normalizedBlock L K μ T u ξ ∈ rays (convexHull ℝ (finitePure (CoreQuot L K))) := by
  classical
  obtain ⟨hs,rank⟩ := hp
  let e := normalizedCell L K μ u ξ
  let A := normalizedBlock L K μ T u ξ
  apply kd_matrix_rankone_ray
  · obtain ⟨S,hs'⟩ := ps_factor T hs.1
    have eq : A = Matrix.gram ℂ (fun i => S (e i)) := by
      ext i j
      change inner ℂ _ (T _) = inner ℂ (S _) (S _)
      rw [hs']; exact S.adjoint_inner_right _ _
    change A.PosSemidef
    rw [eq]; exact Matrix.posSemidef_gram _ _
  · exact matrixTests_rank_le_one e T rank.le
  · obtain ⟨k,act,_,kd⟩ := hs.2.2
    intro i γ
    have hk := block_symbol_nonneg L K μ ν F T k act (ambientKD_rows μ ν F k kd) le u ξ i γ
    have eq : A = ((scale μ L)^2) • blockEntries L K μ T u ξ := by
      ext i j
      change inner ℂ ((scale μ L:ℂ) • _) (T ((scale μ L:ℂ) • _))=_
      rw [map_smul,inner_smul_left,inner_smul_right,Complex.conj_ofReal]
      change _ = ((scale μ L)^2) • inner ℂ (cellVector L K μ u ξ i) (T (cellVector L K μ u ξ j))
      rw [Complex.real_smul,Complex.ofReal_pow]; ring
    change 0 ≤ KDFourier.symbol A _ _
    rw [eq,KDFourier.symbol_smul]
    exact mul_nonneg (Complex.zero_le_real.mpr (sq_nonneg _)) hk

/-- The finite-witness obstruction now quantifies over ALL ambient physical
rank-one states, whether or not one uses Spriet's classification. -/
theorem finite_witness_excludes_ALL_ambient_pure_of_tests (L K : CO G) (le : L≤K) (u : G) (ξ : LCAReality.Dual G)
    (T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ) (C : Matrix (CoreQuot L K) (CoreQuot L K) ℂ)
    (data : normalizedBlock L K μ T u ξ = C) (ht : C.trace=1)
    (hout : C ∉ convexHull ℝ (finitePure (CoreQuot L K))) :
    T ∉ traceClosure (convexHull ℝ (ambientPure μ ν F)) := by
  classical
  let e := normalizedCell L K μ u ξ
  let B := convexHull ℝ (finitePure (CoreQuot L K))
  have one : ∀ x ∈ B, realTrace x = 1 := trace_on_convexHull _ (fun x hx => congrArg Complex.re hx.2.1)
  have closed := rays_closed (realTrace (D:=CoreQuot L K)) (FinitePort.full_finitePure_finite.isCompact_convexHull ℝ) one
  have conv : Convex ℝ (rays B) := rays_convex (convex_convexHull _ _)
  have gen : ambientPure μ ν F ⊆ (matrixTests e) ⁻¹' rays B :=
    fun T hT => all_ambient_pure_ray μ ν F L K le u ξ T hT
  have below := convexHull_min gen (conv.is_linear_preimage (matrixTests e).isLinear)
  have sub : matrixTests e '' convexHull ℝ (ambientPure μ ν F) ⊆ rays B := by
    rintro _ ⟨x,hx,rfl⟩; exact below hx
  have on : Orthonormal ℂ e := normalizedCell_orthonormal L K μ u ξ
  intro near
  have inCone := closure_minimal sub closed (tests_map_traceClosure e on.1 near)
  change normalizedBlock L K μ T u ξ ∈ rays B at inCone
  rw [data] at inCone
  exact hout ((trace_one_slice _ one (congrArg Complex.re ht)).mp inCone)

theorem finite_witness_excludes_ALL_ambient_pure (L K : CO G) (le : L≤K) (u : G) (ξ : LCAReality.Dual G)
    (C : Matrix (CoreQuot L K) (CoreQuot L K) ℂ) (ht : C.trace=1)
    (hout : C ∉ convexHull ℝ (finitePure (CoreQuot L K))) :
    finiteLift (normalizedCell L K μ u ξ) C ∉ traceClosure (convexHull ℝ (ambientPure μ ν F)) := by
  apply finite_witness_excludes_ALL_ambient_pure_of_tests μ ν F L K le u ξ _ C _ ht hout
  exact tests_finiteLift _ (normalizedCell_orthonormal L K μ u ξ) C

/-- The original ambient physical no-compact-open theorem really gives
the empty closed convex hull, including the variational trace-closure convention. -/
theorem no_compact_open_equality (none : ¬Nonempty (CO G)) :
    ambientStates μ ν F = traceClosure (convexHull ℝ (ambientPure μ ν F)) := by
  have eq := LCAReality.ambient_states_empty μ ν F none
  have pp : ambientPure μ ν F = ∅ := by
    apply Set.eq_empty_iff_forall_notMem.mpr
    intro T h; have hh := h.1; rw [eq] at hh; exact hh
  rw [eq,pp,convexHull_empty]
  ext T
  change False ↔ _
  constructor
  · exact False.elim
  · intro near
    obtain ⟨_,absurd,_⟩ := near 1 one_pos
    exact absurd

end KDClosure.Hull
