import KDFrequencyMasks
import KDSymbolBridge
import KDGroupTower

/-! Zero extension of finite physical KD rows and the actual mixed Prüfer dual. -/
namespace KDClosure.AmbientFourier
open scoped BigOperators ComplexOrder
variable {G D : Type*} [AddCommGroup G] [AddCommGroup D]

noncomputable def pad (e : G →+ D) (A : Matrix G G ℂ) : Matrix D D ℂ :=
  Function.extend e (fun x => Function.extend e (A x) (fun _ => 0)) (fun _ _ => 0)

theorem pad_inside (e : G →+ D) (he : Function.Injective e) (A : Matrix G G ℂ) (x y : G) :
    pad e A (e x) (e y) = A x y := by
  simp [pad,he.extend_apply]

theorem pad_row_outside (e : G →+ D) (A : Matrix G G ℂ) {x : D}
    (hx : x ∉ Set.range e) (y : D) : pad e A x y = 0 := by
  simp [pad,Function.extend_apply' _ _ _ hx]

theorem pad_col_outside (e : G →+ D) (he : Function.Injective e) (A : Matrix G G ℂ)
    {y : D} (hy : y ∉ Set.range e) (x : D) : pad e A x y = 0 := by
  by_cases h : x ∈ Set.range e
  · obtain ⟨a,rfl⟩ := h
    simp [pad,he.extend_apply,Function.extend_apply' _ _ _ hy]
  · exact pad_row_outside _ _ h _

/-- The actual ambient character sum over physical columns, with zero padding. -/
noncomputable def rowSymbol (A : Matrix D D ℂ) (x : D) (χ : AddChar D ℂ) :=
  ∑' y, A x y * χ (y-x)

theorem pad_symbol [Fintype G] (e : G →+ D) (he : Function.Injective e)
    (A : Matrix G G ℂ) (x : G) (χ : AddChar D ℂ) :
    rowSymbol (pad e A) (e x) χ = ∑ y, A x y * χ (e (y-x)) := by
  unfold rowSymbol
  rw [← he.tsum_eq (f:=fun y => pad e A (e x) y * χ (y-e x)) ?_]
  · simp [pad_inside _ he,map_sub]
  · intro y hy
    by_contra hn
    exact hy (by simp [pad_col_outside _ he _ hn])

theorem pad_symbol_outside (e : G →+ D) (A : Matrix G G ℂ) {x : D}
    (hx : x ∉ Set.range e) (χ : AddChar D ℂ) : rowSymbol (pad e A) x χ=0 := by
  simp [rowSymbol,pad_row_outside _ _ hx]

variable {p q : ℕ} [Fact p.Prime] [Fact q.Prime]

/-- A single pair of local labels works simultaneously at every position in the head. -/
theorem head_test (n : ℕ) (χ : AddChar (Additive (pRoots p) × ZMod q) ℂ) :
    ∃ k s, ∀ (F : Blocks (p^(n+1)) q) x t,
      rowSymbol (pad (cyclicMixedHead p q n) (physical F)) (cyclicMixedHead p q n (x,t)) χ =
      table F x t k s := by
  obtain ⟨⟨k,s⟩,hk⟩ := all_frequencies (χ.compAddMonoidHom (cyclicMixedHead p q n))
  refine ⟨k,s,fun F x t => ?_⟩
  rw [pad_symbol _ (cyclicMixedHead_injective ..),table_old_symbol]
  simp only [hk,AddChar.compAddMonoidHom_apply]

theorem prefix_KD (n : ℕ) (J : Finset ℕ) (levels : ∀ j ∈ J, j < n+1)
    (y : ℕ → ℝ) (d : ZMod (p^(n+1)) → ℝ) (hd : ∀ x, 0 < d x)
    (amp : ∀ j ∈ J, ∀ x, Frequency.inside p (j+1) x → |y j| < d x)
    (pos : ZMod (p^(n+1)) → Prop) [DecidablePred pos]
    (χ : AddChar (Additive (pRoots p) × ZMod q) ℂ) :
    let A := pad (cyclicMixedHead p q n) (physical (Frequency.finiteWitness J y d pos))
    (∀ z, 0 ≤ (rowSymbol A z χ).re ∧ (rowSymbol A z χ).im = 0) ∧
    (∃ s, ∀ x t, rowSymbol A (cyclicMixedHead p q n (x,t)) χ = 0 ↔ Protected pos x t s) := by
  obtain ⟨k,s,restrict⟩ := head_test n χ
  dsimp only
  constructor
  · intro z
    by_cases hz : z ∈ Set.range (cyclicMixedHead p q n)
    · obtain ⟨⟨x,t⟩,rfl⟩ := hz
      rw [restrict]
      have h := Frequency.finite_witness_KD J levels y d hd amp pos x k t s
      exact ⟨h.1,h.2.1⟩
    · simp [pad_symbol_outside _ _ hz]
  · exact ⟨s,fun x t => (restrict _ x t) ▸
        (Frequency.finite_witness_KD J levels y d hd amp pos x k t s).2.2⟩

/-- Ambient subgroup and the inverse-power child phase, in the actual roots model. -/
def ambientInside (p j : ℕ) (z : Additive (pRoots p)) : Prop :=
  z.toMul.val ∈ rootsOfUnity (p^j) ℂ

noncomputable def childPhase (p j : ℕ) (z : Additive (pRoots p)) : ℂ :=
  rootFrequency p (p^j) (-z)

def ambientCylinder (p j : ℕ) (χ : AddChar (Additive (pRoots p)) ℂ) :=
  ∀ z, ambientInside p (j+1) z → χ z = childPhase p j z

noncomputable def powerChart (p N : ℕ) [NeZero p] :
    ZMod (p^N) →+ Additive (pRoots p) :=
  rootHead (le_iSup (fun i : ℕ => rootsOfUnity (p^i) ℂ) N)

theorem chart_inside (N j : ℕ) (x : ZMod (p^N)) :
    ambientInside p j (powerChart p N x) ↔ Frequency.inside p j x := by
  change (_ ∈ rootsOfUnity _ ℂ) ↔ _
  rw [mem_rootsOfUnity']
  change (ZMod.stdAddChar x)^(p^j) = 1 ↔ _
  rw [← AddChar.map_nsmul_eq_pow,← (ZMod.stdAddChar (N:=p^N)).map_zero_eq_one,
    ZMod.injective_stdAddChar.eq_iff]
  simp [Frequency.inside,nsmul_eq_mul]

theorem chart_phase (N j : ℕ) (x : ZMod (p^N)) :
    childPhase p j (powerChart p N x) = ZMod.stdAddChar (-(x*(p:ZMod (p^N))^j)) := by
  rw [childPhase,← map_neg]
  change (ZMod.stdAddChar (-x))^(p^j) = _
  rw [← AddChar.map_nsmul_eq_pow,nsmul_eq_mul]
  simp [mul_comm]

theorem cylinder_on_head {N j : ℕ} (hj : j<N)
    (χ : AddChar (Additive (pRoots p)) ℂ) (k : ZMod (p^N))
    (label : ∀ x, χ (powerChart p N x) = ZMod.stdAddChar (-(x*k))) :
    ambientCylinder p j χ ↔ Frequency.cylinder p j k := by
  constructor
  · intro hc x hx
    rw [← label,← chart_phase]
    exact hc _ ((chart_inside ..).2 hx)
  · intro hf z hz
    have hN : z.toMul.val ∈ rootsOfUnity (p^N) ℂ :=
      rootsMonotone p (Nat.succ_le_of_lt hj) hz
    obtain ⟨x,rfl⟩ := (range_rootHead (le_iSup (fun i : ℕ => rootsOfUnity (p^i) ℂ) N) z).2 hN
    change χ (powerChart p N x) = childPhase p j (powerChart p N x)
    rw [label,chart_phase]
    exact hf _ ((chart_inside ..).1 hz)

theorem ambient_unique {i j : ℕ} (χ : AddChar (Additive (pRoots p)) ℂ)
    (hi : ambientCylinder p i χ) (hj : ambientCylinder p j χ) : i=j := by
  let N := max i j + 1
  have h : ∀ a < N, ∀ b < N, a < b → ambientCylinder p a χ → ambientCylinder p b χ → False := by
    intro a ha b _ hab hca hcb
    obtain ⟨x,hax,hn⟩ := Frequency.child_nontrivial (p:=p) a ha
    have hb := Frequency.inner_mono (Nat.succ_le_of_lt hab) hax
    have h := (hca _ ((chart_inside N (a+1) x).2 hax)).symm.trans
      (hcb _ ((chart_inside N (b+1) x).2 (Frequency.inner_mono b.le_succ hb)))
    simp only [chart_phase,ZMod.injective_stdAddChar.eq_iff,neg_inj] at h
    apply hn
    change _ * x = 0
    rw [mul_comm,h,mul_comm]
    exact hb
  have hiN : i<N := Nat.lt_succ_of_le (le_max_left ..)
  have hjN : j<N := Nat.lt_succ_of_le (le_max_right ..)
  rcases lt_trichotomy i j with l|e|l
  · exact False.elim (h i hiN j hjN l hi hj)
  · exact e
  · exact False.elim (h j hjN i hiN l hj hi)

/-- The local transverse label is zero precisely when the ambient character
is trivial on the physical transverse subgroup. No label choice appears in the outcome. -/
theorem prefix_mask_character (n : ℕ) (J : Finset ℕ) (levels : ∀ j ∈ J, j < n+1)
    (y : ℕ → ℝ) (d : ZMod (p^(n+1)) → ℝ) (hd : ∀ x, 0 < d x)
    (amp : ∀ j ∈ J, ∀ x, Frequency.inside p (j+1) x → |y j| < d x)
    (pos : ZMod (p^(n+1)) → Prop) [DecidablePred pos]
    (χ : AddChar (Additive (pRoots p) × ZMod q) ℂ) (x t) :
    rowSymbol (pad (cyclicMixedHead p q n) (physical (Frequency.finiteWitness J y d pos)))
      (cyclicMixedHead p q n (x,t)) χ = 0 ↔
      (pos x ∧ t ≠ 0 ∧ χ (0,1) ≠ 1) ∨ (¬pos x ∧ t=0 ∧ χ (0,1)=1) := by
  obtain ⟨⟨k,s⟩,hk⟩ := all_frequencies (χ.compAddMonoidHom (cyclicMixedHead p q n))
  have eval := congrArg (fun χ' : AddChar (ZMod (p^(n+1)) × ZMod q) ℂ => χ' (0,1)) hk
  have h0 : (cyclicMixedHead p q n) (0,1) = (0,1) := by
    refine Prod.ext ?_ rfl
    exact map_zero (powerChart p (n+1))
  have eqv : s=0 ↔ χ (0,1)=1 := by
    simp [frequency,AddChar.compAddMonoidHom_apply,h0] at eval
    rw [← eval,← (ZMod.stdAddChar (N:=q)).map_zero_eq_one, ZMod.injective_stdAddChar.eq_iff]
    simp
  have sym := table_old_symbol (Frequency.finiteWitness J y d pos) x t k s
  rw [hk] at sym
  simp only [AddChar.compAddMonoidHom_apply] at sym
  rw [pad_symbol _ (cyclicMixedHead_injective ..)]
  change (∑ w, _ * χ _) = 0 ↔ _
  rw [← sym]
  exact (Frequency.finite_witness_KD J levels y d hd amp pos x k t s).2.2.trans
    (by simp only [Protected, eqv,ne_eq])

noncomputable def ambientTile (p j : ℕ) (z : Additive (pRoots p))
    (χ : AddChar (Additive (pRoots p)) ℂ) : ℝ := by
  classical
  exact if ambientInside p (j+1) z ∧ ambientCylinder p j χ then 1 else 0

/-- The infinite displayed symbol sums pointwise absolutely, even when no global
summability hypothesis on the amplitudes is made; at each frequency at most one term survives. -/
theorem infinite_margin (I : Set ℕ) (y : ℕ → ℝ) (d : Additive (pRoots p) → ℝ)
    (hd : ∀ z, 0 < d z) (amp : ∀ j ∈ I, ∀ z, ambientInside p (j+1) z → |y j| < d z)
    (z : Additive (pRoots p)) (χ : AddChar (Additive (pRoots p)) ℂ) :
    let term := fun j : I => y j.val * ambientTile p j.val z χ
    Summable term ∧ |∑' j, term j| < d z := by
  classical
  dsimp only
  by_cases hit : ∃ j : I, ambientInside p (j.val+1) z ∧ ambientCylinder p j.val χ
  · obtain ⟨j,hz,hχ⟩ := hit
    have other (k : I) (h : k ≠ j) : y k.val * ambientTile p k.val z χ = 0 := by
      have out : ¬ ambientCylinder p k.val χ :=
        fun hc => h (Subtype.ext (ambient_unique χ hc hχ))
      simp [ambientTile,out]
    exact ⟨summable_of_ne_finset_zero (s:={j}) (fun k hk => other k (by simpa using hk)),
      by rw [tsum_eq_single j other]; simpa [ambientTile,hz,hχ] using amp j j.property z hz⟩
  · have h (j : I) : y j.val * ambientTile p j.val z χ = 0 := by
      have absent : ¬(ambientInside p (j.val+1) z ∧ ambientCylinder p j.val χ) :=
        fun hh => hit ⟨j,hh⟩
      simp [ambientTile,absent]
    simp [h,hd]

end KDClosure.AmbientFourier
