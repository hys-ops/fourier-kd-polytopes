import KDPhysicalLift
import KDWaveSupport

namespace KDClosure.SparseKD
open PhysicalLift WaveSupport
open scoped BigOperators
variable {p q L : ℕ} [Fact p.Prime] [Fact q.Prime] [NeZero L]

noncomputable def r (p l : ℕ) : ℝ := 2*(l:ℝ)/p - 1
noncomputable def kappa (p q l : ℕ) : ℝ := b q / Real.sqrt (1-(a q*r p l)^2)
noncomputable def mu (L : ℕ) (f : ℕ → ℝ) (j : ℕ) : ℝ :=
  reciprocalMean (1/(L:ℝ)) f (j+1)

def plus (j : ℕ) : Bool := decide (j%2=1)
noncomputable def amplitude (p q L l : ℕ) (f : ℕ → ℝ) (j : ℕ) : ℝ :=
  if plus j then kappa p q l / mu L f j else -(kappa p q l / mu L f j)

theorem r_bound {l : ℕ} (hl : 0<l) (hlt : l<p) : (r p l)^2 < 1 := by
  have hp : 0 < (p:ℝ) := by exact_mod_cast (Fact.out : p.Prime).pos
  have hl0 : 0 < (l:ℝ) := by exact_mod_cast hl
  have hlt' : (l:ℝ)<p := by exact_mod_cast hlt
  have h0 : 0 < 2*(l:ℝ)/(p:ℝ) := div_pos (by positivity) hp
  have h2 : 2*(l:ℝ)/(p:ℝ)<2 := (div_lt_iff₀ hp).mpr (by linarith)
  unfold r
  nlinarith [mul_pos h0 (sub_pos.mpr h2)]

theorem mu_pos (f : ℕ → ℝ) (hf : ∀ i,0<f i) (hm : Monotone f) (j) : 0<mu L f j := by
  have hl : 1≤(L:ℝ) := by exact_mod_cast Nat.pos_of_ne_zero (NeZero.ne L)
  exact (reciprocal_bounds _ f (by positivity) ((div_le_one (by positivity)).mpr hl) hf hm _).1

theorem abs_amplitude {l : ℕ} (hl : 0<l) (hlt : l<p) (f : ℕ → ℝ)
    (hf : ∀ i,0<f i) (hm : Monotone f) (j) :
    |amplitude p q L l f j| = kappa p q l / mu L f j := by
  have hk := packetConstants (a:=a q) (r:=r p l) a_properties.1 a_properties.2.1
    (r_bound hl hlt) (mu_pos (L:=L) f hf hm j)
  have pos : 0<kappa p q l / mu L f j := div_pos hk.1 (mu_pos _ hf hm _)
  unfold amplitude
  split_ifs <;> simp [abs_of_pos pos]

/-- Exact positive scalar multiplying a physical column product; the
positive square roots eliminate the potential sign ambiguity of the square identity. -/
theorem positive_scale {l : ℕ} (hl : 0<l) (hlt : l<p) (f : ℕ → ℝ)
    (hf : ∀ i,0<f i) (hm : Monotone f) (j : ℕ) :
    (b q)⁻¹ * invroot (cyclicMass (p:=p) (L:=L) f (paperChannelStat (a q) l) j) *
      invroot (cyclicMass (p:=p) (L:=L) f (paperChannelStat (-a q) l) j) =
      kappa p q l / mu L f j := by
  let P := cyclicMass (p:=p) (L:=L) f (paperChannelStat (a q) l) j
  let M := cyclicMass (p:=p) (L:=L) f (paperChannelStat (-a q) l) j
  let y := kappa p q l / mu L f j
  have hμ := mu_pos (L:=L) f hf hm j
  obtain ⟨ha,ha1,_⟩ := a_properties (q:=q)
  have aa : 0<1-(a q)^2 := by nlinarith [mul_pos (sub_pos.mpr ha1) (by linarith : 0<1+a q)]
  have bb : (b q)^2 = 1-(a q)^2 := Real.sq_sqrt aa.le
  have bp : 0 < b q := Real.sqrt_pos.mpr aa
  have hp := paperChannelMass (L:=L) (fun _ => negativeDigit p) (fun _ => negativeDigit_nontrivial)
    f (a q) (by linarith) l hlt j
  have hm' := paperChannelMass (L:=L) (fun _ => negativeDigit p) (fun _ => negativeDigit_nontrivial)
    f (-a q) (by rw [neg_sq]; linarith) l hlt j
  have hP : P = mu L f j*(1-a q*r p l)/(b q)^2 := by rw [bb]; exact hp
  have hM : M = mu L f j*(1+a q*r p l)/(b q)^2 := by
    rw [bb]; simpa [M,mu,r,neg_sq] using hm'
  have hp0 : 0<P := cyclicMass_pos f hf hm _ (paperChannelStat_pos (by linarith) ha1 l) j
  have hm0 : 0<M := cyclicMass_pos f hf hm _ (paperChannelStat_pos (by linarith) (by linarith) l) j
  have hc := packetConstants ha ha1 (r_bound hl hlt) hμ
  have hy : 0<y := div_pos hc.1 hμ
  have bound : (b q)^2*y^2*P*M=1 := by rw [hP,hM]; exact hc.2.2.2.2.2
  have prod : (b q * Real.sqrt P * Real.sqrt M) * y = 1 := by
    apply (sq_eq_sq₀ (by positivity) (by norm_num : (0:ℝ)≤1)).mp
    calc _ = (b q)^2 * y^2 * P * M := by
              rw [mul_pow,mul_pow,mul_pow,Real.sq_sqrt hp0.le,Real.sq_sqrt hm0.le]; ring
         _ = _ := by simpa using bound
  change (b q)⁻¹*(Real.sqrt P)⁻¹*(Real.sqrt M)⁻¹=y
  rw [← mul_inv,← mul_inv]
  exact inv_eq_of_mul_eq_one_right prod

theorem complex_scale {l n : ℕ} (hl : 0<l) (hlt : l<p) (f : ℕ → ℝ)
    (hf : ∀ i,0<f i) (hm : Monotone f) (j : Fin n) :
    (b q : ℂ)⁻¹ * (columnScale (p:=p) (L:=L) f (a q) l j.val *
      star (signedScale (p:=p) (L:=L) f (-a q) l n (fun i => plus i.val) j)) =
      (amplitude p q L l f j.val : ℂ) := by
  have h := congrArg Complex.ofReal (positive_scale (q:=q) (L:=L) hl hlt f hf hm j.val)
  by_cases e : plus j.val = true <;>
    simp [columnScale,signedScale,amplitude,e] <;> push_cast at h <;> linear_combination h

end KDClosure.SparseKD
