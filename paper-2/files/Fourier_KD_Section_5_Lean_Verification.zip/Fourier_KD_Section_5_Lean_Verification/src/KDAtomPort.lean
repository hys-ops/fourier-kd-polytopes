import KDPeriodPort
import KDAmbientFourier
import KDWaveMoments

/-! The old finite atom proof with its original names, followed by the link
from its conjugated-vector convention to actual cyclic row displacements.
Source line numbers refer to Finite_Fourier_KD_Lean_Audit/src. -/
noncomputable section
set_option autoImplicit false
open Matrix Classical
open scoped BigOperators ComplexOrder
namespace KDFourier
open KDOperator
variable {G : Type*} [AddCommGroup G] [Fintype G]
-- KDAudit.lean:568–570
theorem symbol_smul (r : ℝ) (A : Op G) (x : G) (χ : AddChar G ℂ) :
    symbol (r • A) x χ = (r : ℂ) * symbol A x χ := by
  simp [symbol,Complex.real_smul,Finset.mul_sum,mul_assoc]

end KDFourier
namespace KDPure
open KDOperator KDFourier
variable {G : Type*} [AddCommGroup G] [Fintype G]
-- KDPure.lean:57, 60–65, 88–89, 140–141
def outer (u : G → ℂ) : Op G := of fun x y => star (u x) * u y
theorem symbol_outer (u : G → ℂ) (x : G) (k : AddChar G ℂ) :
    symbol (outer u) x k = star (u x) * k (-x) * amp u k := by
  unfold symbol amp; rw [Finset.mul_sum]
  apply Finset.sum_congr rfl; intro y _
  change star (u x) * u y * k (y-x) = _
  rw [sub_eq_add_neg,AddChar.map_add_eq_mul]; ring
theorem char_ne (k : AddChar G ℂ) (x : G) : k x ≠ 0 := by
  intro hx; have hh := k.norm_apply x; simp [hx] at hh
def tile (H : AddSubgroup G) (a : G) (b : AddChar G ℂ) (x : G) (k : AddChar G ℂ) : ℝ :=
  if x-a ∈ H ∧ ∀ h ∈ H, k h=b h then 1 else 0

end KDPure
namespace KDAtoms
set_option linter.unusedSimpArgs false
open KDOperator KDFourier KDPure
variable {G : Type*} [AddCommGroup G] [Fintype G]
-- KDAtoms.lean:52–88. The rank-one character orthogonality proof is reused verbatim.
def v (U : AddSubgroup G) (a:G) (b:AddChar G ℂ) (x:G) : ℂ :=
  if x-a ∈ U then b (-x) else 0
def atom (U : AddSubgroup G) (a:G) (b:AddChar G ℂ) : Op G :=
  ((Fintype.card U:ℝ)⁻¹) • outer (v U a b)

theorem atom_symbol (U : AddSubgroup G) (a:G) (b:AddChar G ℂ) (x:G) (k:AddChar G ℂ) :
    symbol (atom U a b) x k = (tile U a b x k:ℂ) := by
  classical
  rw [atom,symbol_smul]
  let d := (k-b).compAddMonoidHom U.subtype
  have dz : d=0 ↔ ∀ h∈U,k h=b h := by
    constructor
    · intro h y hy
      have e := congrArg (fun t:AddChar U ℂ => t ⟨y,hy⟩) h
      change (k-b) y=1 at e
      rw [AddChar.sub_apply',div_eq_one_iff_eq (char_ne b y)] at e; exact e
    · intro h; ext y; change (k-b) y=1
      simp [AddChar.sub_apply',h _ y.property,char_ne]
  by_cases hx : x-a ∈ U
  · have eq : (∑ h:U,d h)=symbol (outer (v U a b)) x k := by
      apply Fintype.sum_of_injective (fun h:U => x+h.val)
        (fun {s t} e => Subtype.ext (add_left_cancel e))
      · intro y hy
        have hv : y-a ∉ U := fun e => hy ⟨⟨y-x,by simpa using U.sub_mem e hx⟩,by simp⟩
        simp [outer,v,hv]
      · intro h
        have hv : x+h.val-a ∈ U := by convert U.add_mem hx h.property using 1; abel
        change (k-b) h.val = star (v U a b x)*v U a b (x+h.val)*k ((x+h.val)-x)
        simp [v,hx,hv,char_conj,AddChar.map_add_eq_mul,AddChar.map_neg_eq_inv,
          AddChar.sub_apply',div_eq_mul_inv,char_ne,mul_assoc,mul_comm,mul_left_comm]
    rw [← eq,AddChar.sum_eq_ite]
    by_cases hd : d=0
    · have hh := dz.mp hd
      have et : tile U a b x k=1 := if_pos ⟨hx,hh⟩
      rw [et]; simp [hd,Fintype.card_ne_zero]
    · simp [hd,tile,hx,not_congr dz |>.mp hd]

  · simp [symbol_outer,v,hx,tile]
end KDAtoms
namespace KDClosure.AtomBridge
open KDAtoms KDPure KDFourier

/-- Same rank-one matrix in the ket convention. The older outer definition
takes the conjugated ket, so conjugation of the two characters reverses. -/
theorem physical_projector {G : Type*} [AddCommGroup G] [Fintype G]
    (H : AddSubgroup G) (β : AddChar G ℂ) (ψ : G → ℂ)
    (value : ∀ x, ψ x = (Real.sqrt (Fintype.card H : ℝ) : ℂ)⁻¹ *
      (if x ∈ H then β x else 0)) (x y : G) :
    ψ x * star (ψ y) = atom H 0 β x y := by
  have hc : (Real.sqrt (Fintype.card H : ℝ):ℂ)^2 = (Fintype.card H:ℂ) := by
    exact_mod_cast Real.sq_sqrt (Nat.cast_nonneg _)
  have hs : ((Real.sqrt (Fintype.card H : ℝ):ℂ)⁻¹)^2 = (Fintype.card H:ℂ)⁻¹ := by
    rw [inv_pow,hc]
  rw [value x,value y]
  have ha : atom H 0 β x y = ((Fintype.card H:ℂ)⁻¹) * (star (v H 0 β x) * v H 0 β y) := by
    simp [atom,outer,Complex.real_smul]
  rw [ha]
  by_cases hx : x∈H <;> by_cases hy : y∈H <;>
    simp [hx,hy,v,char_conj,star_mul,Complex.conj_ofReal]
  rw [← hs]
  ring

variable {p N : ℕ} [Fact p.Prime]

def insideGroup (p b : ℕ) {N : ℕ} : AddSubgroup (ZMod (p^N)) where
  carrier := {x | Frequency.inside p b x}
  zero_mem' := by simp [Frequency.inside]
  add_mem' := by intro a b ha hb; exact (mul_add ..).trans (by rw [ha,hb,zero_add])
  neg_mem' := by intro a ha; exact (mul_neg ..).trans (by rw [ha,neg_zero])

def negFreq {m : ℕ} [NeZero m] (k : ZMod m) : AddChar (ZMod m) ℂ :=
  ZMod.stdAddChar.mulShift (-k)

@[simp] theorem negFreq_apply {m : ℕ} [NeZero m] (x k : ZMod m) :
    negFreq k x = ZMod.stdAddChar (-(x*k)) := by simp [negFreq,mul_comm]

theorem original_atom_row (b : ℕ) :
    (fun x h : ZMod (p^N) => atom (insideGroup p (b+1)) 0
      (negFreq ((p:ZMod (p^N))^b)) x (x+h)) = Frequency.rowFromTile b := by
  apply Frequency.legacy_physical_atom
  intro x k
  have ht := atom_symbol (insideGroup (N:=N) p (b+1)) 0 (negFreq ((p:ZMod (p^N))^b)) x (negFreq k)
  have mem (u : ZMod (p^N)) : u ∈ insideGroup p (b+1) ↔ Frequency.inside p (b+1) u := Iff.rfl
  by_cases h : Frequency.inside p (b+1) x ∧ Frequency.cylinder p b k <;>
    unfold Frequency.cylinder at h <;>
    simpa [symbol,tile,Frequency.tile,Frequency.cylinder,mem,h] using ht

/-- Invert the negative-DFT tile into an explicit, unit-normalised physical
rank-one ket for every child depth and enclosing power-of-p cyclic group. -/
theorem projector_row (b : ℕ) (ψ : ZMod (p^N) → ℂ)
    (value : ∀ x, ψ x =
      (Real.sqrt (Fintype.card (insideGroup (N:=N) p (b+1)) : ℝ) : ℂ)⁻¹ *
      (if Frequency.inside p (b+1) x then negFreq ((p:ZMod (p^N))^b) x else 0)) :
    (fun x h => ψ x * star (ψ (x+h))) = Frequency.rowFromTile b := by
  rw [← original_atom_row]
  funext x h
  exact physical_projector (insideGroup p (b+1)) (negFreq _) ψ value x (x+h)
/-- The finite cyclic subgroup of positions of order dividing p^t really
has p^t points inside every enclosing head, including t=N. -/
theorem inner_card (t : ℕ) (ht : t≤N) :
    Fintype.card (insideGroup (N:=N) p t) = p^t := by
  let f := AmbientFourier.powerChart p N
  let g := AmbientFourier.powerChart p t
  have fi : Function.Injective f := rootHead_injective _
  have gi : Function.Injective g := rootHead_injective _
  have ic (x : ZMod (p^N)) : f x ∈ Set.range g ↔ x ∈ insideGroup p t :=
    (range_rootHead _ _).trans (AmbientFourier.chart_inside ..)
  have incl : Set.range g ⊆ Set.range f := by
    intro z hz
    apply (range_rootHead _ _).2
    exact rootsMonotone p ht ((range_rootHead _ _).1 hz)
  let E : (insideGroup (N:=N) p t) → Set.range g := fun z => ⟨f z.val,(ic z.val).2 z.property⟩
  have ei : Function.Injective E := fun _ _ h => Subtype.ext (fi (congrArg Subtype.val h))
  have es : Function.Surjective E := by
    rintro ⟨z,hz⟩
    obtain ⟨x,rfl⟩ := incl hz
    exact ⟨⟨x,(ic x).1 hz⟩,rfl⟩
  calc _ = Fintype.card (ZMod (p^t)) :=
          Fintype.card_congr ((Equiv.ofBijective E ⟨ei,es⟩).trans (Equiv.ofInjective g gi).symm)
       _ = _ := ZMod.card _

end KDClosure.AtomBridge
