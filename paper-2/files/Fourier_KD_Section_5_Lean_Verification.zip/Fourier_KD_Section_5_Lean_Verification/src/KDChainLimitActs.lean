import KDChainLimitIntegral
import Mathlib.MeasureTheory.Function.AEEqOfIntegral

noncomputable section
namespace KDClosure.ChainLimit.Kernel
open MeasureTheory Filter Set LCAQuotient
open scoped ComplexConjugate ENNReal InnerProductSpace
variable {X : Type*} [MeasurableSpace X] (μ : Measure X) [SFinite μ]

private def cellIntegrand (k : K μ) (v : H μ) (s : Set X) (z : X×X) :=
  s.indicator (fun x => k (x,z.2)*v z.2) z.1

private theorem testing_cells (k : K μ) (v : H μ) {s:Set X} (hs:MeasurableSet s) (fin:μ s≠∞) :
    Integrable (cellIntegrand μ k v s) (μ.prod μ) ∧
    (∫ z, cellIntegrand μ k v s z ∂μ.prod μ) = ∫ x in s, op μ k v x ∂μ := by
  let u : H μ := indicatorConstLp 2 hs fin (1:ℂ)
  have ua : (u:X→ℂ) =ᵐ[μ] s.indicator (fun _ => (1:ℂ)) := indicatorConstLp_coeFn
  have equ : (fun z : X×X => inner ℂ (rect μ u v z) (k z)) =ᵐ[μ.prod μ] cellIntegrand μ k v s := by
    filter_upwards [rect_ae μ u v, Measure.quasiMeasurePreserving_fst.ae_eq_comp ua] with z hr hu
    rw [RCLike.inner_apply,hr,map_mul,Complex.conj_conj]
    change u z.1 = s.indicator (fun _ => (1:ℂ)) z.1 at hu
    rw [hu]
    by_cases h : z.1∈s
    · simp [cellIntegrand,Set.indicator_of_mem h]
    · simp [cellIntegrand,Set.indicator_of_notMem h]
  refine ⟨(MeasureTheory.L2.integrable_inner _ _).congr equ,?_⟩
  rw [←MeasureTheory.L2.inner_indicatorConstLp_one hs fin,op_test,MeasureTheory.L2.inner_def]
  exact integral_congr_ae equ.symm

omit [SFinite μ] in
private theorem average (k : K μ) (v : H μ) (s : Set X) (x : X) :
    (∫ y, cellIntegrand μ k v s (x,y) ∂μ)=s.indicator (fun z => ∫ y, k (z,y)*v y ∂μ) x := by
  classical
  by_cases hx : x∈s
  · simp [cellIntegrand,indicator_of_mem hx]
  · simp [cellIntegrand,indicator_of_notMem hx]

/-- The Riesz operator obtained by bounded tests acts by its actual
kernel when applied to every square-integrable input. -/
theorem op_acts [SigmaFinite μ] (k : K μ) : ActsBy μ (op μ k) k := by
  intro f
  apply ae_eq_of_forall_setIntegral_eq_of_sigmaFinite
  · intro s _ hs
    let _ : IsFiniteMeasure (μ.restrict s) := isFiniteMeasure_restrict.mpr hs.ne
    exact ((Lp.memLp (op μ k f)).restrict s).integrable (by norm_num)
  · intro s hs fin
    have h := ((testing_cells μ k f hs fin.ne).1).integral_prod_left
    rw [show (fun x => ∫ y, cellIntegrand μ k f s (x,y) ∂μ)=_ from funext (average μ k f s)] at h
    exact (integrable_indicator_iff hs).mp h
  · intro s hs fin
    obtain ⟨int,h⟩ := testing_cells μ k f hs fin.ne
    rw [←h,integral_prod _ int,←integral_indicator hs]
    exact integral_congr_ae (Eventually.of_forall (average μ k f s))

theorem op_eq_of_acts [SigmaFinite μ] {T : H μ →L[ℂ] H μ} {k : K μ} (act : ActsBy μ T k) :
    op μ k = T := by
  apply ContinuousLinearMap.ext; intro v
  apply Lp.ext
  filter_upwards [op_acts μ k v,act v] with x h₁ h₂
  exact h₁.trans h₂.symm

theorem op_injective [SigmaFinite μ] [MeasurableSpace.CountablyGenerated X] : Function.Injective (op μ) := by
  intro k l h
  exact kernel_unique μ _ (op_acts μ k) (h ▸ op_acts μ l)

end KDClosure.ChainLimit.Kernel
