import KDChainLimitCompression
import KDLCAQuotientState

noncomputable section
namespace KDClosure.ChainLimit
open MeasureTheory Set CompactCore CompactCoset LCAReality LCAQuotient Classical
open scoped KDClosure.SubgroupMeasure ComplexOrder ComplexConjugate ENNReal BigOperators
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
  [MeasurableSpace G] [BorelSpace G] [MeasurableAdd G] [T2Space G] [SecondCountableTopology G]
variable (H K : CO G)
local instance : Fintype (CoreQuot H K) := @Fintype.ofFinite _ (finite_core H K)

omit [MeasurableSpace G] [BorelSpace G] [MeasurableAdd G] [T2Space G] [SecondCountableTopology G] in
theorem section_chain (le : H≤K) (chain : ∀ P Q : CO G, P≤Q ∨ Q≤P) (P Q : AddSubgroup (CoreQuot H K)) :
    P≤Q ∨ Q≤P := by
  let q := QuotientAddGroup.mk' ((subgroup H).addSubgroupOf (subgroup K))
  let t (A : AddSubgroup (CoreQuot H K)) := (A.comap q).map (subgroup K).subtype
  have lower (A : AddSubgroup (CoreQuot H K)) : subgroup H ≤ t A := by
    intro x hx
    refine ⟨⟨x,le hx⟩,?_,rfl⟩
    change q ⟨x,le hx⟩ ∈ A
    rw [show q ⟨x,le hx⟩=0 from (QuotientAddGroup.eq_zero_iff _).mpr hx]; exact A.zero_mem
  have op (A : AddSubgroup (CoreQuot H K)) := intermediate (lower A) (AddSubgroup.map_subtype_le _)
  let C (A : AddSubgroup (CoreQuot H K)) : CO G := ⟨⟨t A,(op A).1⟩,(op A).2⟩
  have mono (A B : AddSubgroup (CoreQuot H K)) (h : C A ≤ C B) : A≤B := by
    have h' : A.comap q ≤ B.comap q :=
      (AddSubgroup.map_le_map_iff_of_injective (subgroup K).subtype_injective).mp h
    intro z hz; obtain ⟨p,rfl⟩ := QuotientAddGroup.mk'_surjective ((subgroup H).addSubgroupOf (subgroup K)) z
    exact h' (show p∈A.comap q from hz)
  exact (chain (C P) (C Q)).imp (mono P Q) (mono Q P)

variable (μ : Measure G) [μ.IsAddHaarMeasure] [SFinite μ]

def normalizedCell (u : G) (ξ : LCAReality.Dual G) (i : CoreQuot H K) : Lp ℂ 2 μ :=
  (scale μ H : ℂ) • cellVector H K μ u ξ i

private def cellLabel (u : G) (i : CoreQuot H K) := π H (u+(representative H K i:G))

omit [IsTopologicalAddGroup G] [MeasurableSpace G] [BorelSpace G] [MeasurableAdd G] [T2Space G] [SecondCountableTopology G] in
private theorem cellLabel_injective (u : G) : Function.Injective (cellLabel H K u) := by
  intro i j eqn
  change π H (u+(representative H K i:G)) = π H (u+(representative H K j:G)) at eqn
  simp only [map_add,add_right_inj] at eqn
  have dx : (representative H K i:G)-(representative H K j:G)∈H.val := QuotientAddGroup.eq_iff_sub_mem.mp eqn
  have h : QuotientAddGroup.mk' ((subgroup H).addSubgroupOf (subgroup K)) (representative H K i) =
      QuotientAddGroup.mk' ((subgroup H).addSubgroupOf (subgroup K)) (representative H K j) :=
    QuotientAddGroup.eq_iff_sub_mem.mpr dx
  simpa only [representative_spec] using h

omit [T2Space G] [SecondCountableTopology G] [SFinite μ] in
theorem normalizedCell_ae (u : G) (ξ : LCAReality.Dual G) (i : CoreQuot H K) :
    (normalizedCell H K μ u ξ i : G→ℂ) =ᵐ[μ] fun x => LCAReality.phase ξ x * atom μ H (cellLabel H K u i) x := by
  have r : fiber H (cellLabel H K u i) = region H K u i := fiber_coset H _
  filter_upwards [Lp.coeFn_smul (scale μ H:ℂ) (cellVector H K μ u ξ i),cellVector_ae H K μ u ξ i,
      atom_ae μ H (cellLabel H K u i)] with x hs hc ha
  change ((scale μ H:ℂ) • cellVector H K μ u ξ i) x = _
  change ((scale μ H:ℂ) • cellVector H K μ u ξ i) x = ((scale μ H:ℂ) • (cellVector H K μ u ξ i:G→ℂ)) x at hs
  rw [hs,Pi.smul_apply,smul_eq_mul,hc,ha,r]
  by_cases hx : x∈region H K u i
  · rw [indicator_of_mem hx,indicator_of_mem hx,mul_comm]
  · simp [indicator_of_notMem hx]

omit [T2Space G] [SecondCountableTopology G] [SFinite μ] in
theorem normalizedCell_orthonormal (u : G) (ξ : LCAReality.Dual G) : Orthonormal ℂ (normalizedCell H K μ u ξ) := by
  let v := fun i => atom μ H (cellLabel H K u i)
  have onv : Orthonormal ℂ v := (atom_orthonormal μ H).comp (cellLabel H K u) (cellLabel_injective H K u)
  refine orthonormal_iff_ite.mpr (fun i j => ?_)
  rw [←orthonormal_iff_ite.mp onv i j,MeasureTheory.L2.inner_def,MeasureTheory.L2.inner_def]
  apply integral_congr_ae
  filter_upwards [normalizedCell_ae H K μ u ξ i,normalizedCell_ae H K μ u ξ j] with x hi hj
  rw [hi,hj,RCLike.inner_apply,RCLike.inner_apply,map_mul]
  change ((ξ (Multiplicative.ofAdd x):ℂ) * _) * (conj (ξ (Multiplicative.ofAdd x):ℂ) * _) = _
  have pu : (ξ (Multiplicative.ofAdd x):ℂ)*conj (ξ (Multiplicative.ofAdd x):ℂ)=1 := by
    rw [←Circle.coe_inv_eq_conj,Circle.coe_inv,mul_inv_cancel₀ (Circle.coe_ne_zero _)]
  calc
    _ = ((ξ (Multiplicative.ofAdd x):ℂ)*conj (ξ (Multiplicative.ofAdd x):ℂ)) *
      (v j x * conj (v i x)) := by dsimp [v]; ring
    _ = _ := by rw [pu,one_mul]

def normalizedBlock (T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ) (u : G) (ξ : LCAReality.Dual G) :
    Matrix (CoreQuot H K) (CoreQuot H K) ℂ :=
  Matrix.of fun i j => inner ℂ (normalizedCell H K μ u ξ i) (T (normalizedCell H K μ u ξ j))

private theorem factor {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℂ X] [CompleteSpace X]
    (T : X →L[ℂ] X) (p : T.IsPositive) : ∃ S, T=star S*S :=
  CStarAlgebra.nonneg_iff_eq_star_mul_self.mp ((ContinuousLinearMap.nonneg_iff_isPositive T).mpr p)

variable (ν : Measure (LCAReality.Dual G)) [SFinite ν]

omit [T2Space G] in
/-- The actual normalized compression of an arbitrary ambient physical state
is a subprobability mixture of finite pure KD states on the true quotient. -/
theorem normalizedBlock_hull (F : FourierRealization μ ν) (T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ)
    (state : T∈ambientStates μ ν F) (le : H≤K) (chain : ∀ P Q : CO G, P≤Q ∨ Q≤P)
    (u : G) (ξ : LCAReality.Dual G) :
    normalizedBlock H K μ T u ξ ∈ convexHull ℝ (insert 0 (Finite.pureSet (CoreQuot H K))) := by
  obtain ⟨k,act,herm,kd⟩ := state.2.2
  let v := normalizedCell H K μ u ξ
  let A := normalizedBlock H K μ T u ξ
  change A∈_
  apply Finite.subnormalized_hull (section_chain H K le chain)
  · obtain ⟨S,hs⟩ := factor T state.1
    let w (i : CoreQuot H K) := S (v i)
    have eqn : A = Matrix.gram ℂ w := by
      ext i j
      change inner ℂ _ (T _) = inner ℂ (S _) (S _)
      rw [hs]; exact S.adjoint_inner_right _ _
    exact eqn ▸ Matrix.posSemidef_gram _ _
  · let e := Fintype.equivFin (CoreQuot H K)
    have hon := (normalizedCell_orthonormal H K μ u ξ).comp e.symm e.symm.injective
    apply state.2.1.1
    refine ⟨Fintype.card (CoreQuot H K),v ∘ e.symm,hon,?_⟩
    simpa only [Matrix.trace,Matrix.diag,Complex.re_sum,normalizedBlock,A,Matrix.of_apply,Function.comp_apply] using
      e.symm.sum_comp (fun i => (inner ℂ (v i) (T (v i))).re)
  · intro i γ
    have hk := block_symbol_nonneg H K μ ν F T k act (ambientKD_rows μ ν F k kd) le u ξ i γ
    have eqn : A = ((scale μ H)^2) • blockEntries H K μ T u ξ := by
      ext j l
      change inner ℂ ((scale μ H:ℂ) • _) (T ((scale μ H:ℂ) • _))=_
      rw [map_smul,inner_smul_left,inner_smul_right,Complex.conj_ofReal]
      change _ = ((scale μ H)^2) • inner ℂ (cellVector H K μ u ξ j) (T (cellVector H K μ u ξ l))
      rw [Complex.real_smul,Complex.ofReal_pow]; ring
    rw [eqn,KDFourier.symbol_smul]
    exact mul_nonneg (Complex.zero_le_real.mpr (sq_nonneg _)) hk

end KDClosure.ChainLimit
