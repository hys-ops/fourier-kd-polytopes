import KDChainLimitActs

noncomputable section
namespace KDClosure.ChainLimit.Kernel
open MeasureTheory Set Filter CompactFourier LCAQuotient
open scoped ComplexConjugate ENNReal InnerProductSpace BigOperators
variable {X : Type*} [MeasurableSpace X] (μ : Measure X) [SigmaFinite μ]

theorem op_gram (u v : H μ) : op μ (gram u) v = inner ℂ u v • u := by
  apply Lp.ext
  filter_upwards [op_acts μ (gram u) v,Measure.ae_ae_of_ae_prod (gram_ae u),Lp.coeFn_smul (inner ℂ u v) u]
    with x act g sc
  rw [act,sc,Pi.smul_apply,smul_eq_mul,MeasureTheory.L2.inner_def,mul_comm,←integral_const_mul]
  apply integral_congr_ae
  filter_upwards [g] with y hy
  rw [hy,RCLike.inner_apply]; ring

/-- The Hilbert–Schmidt norm of every actual positive trace-at-most-one
kernel is at most one, also in infinite dimension. -/
theorem norm_le_frame_budget [MeasurableSpace.CountablyGenerated X] {k : K μ}
    (p : (op μ k).IsPositive) (ub : ∀ r ∈ frameMass (op μ k), r≤1) : ‖k‖≤1 := by
  classical
  let T := op μ k
  obtain ⟨I,b,_⟩ := exists_hilbertBasis ℂ (H μ)
  obtain ⟨S,sa,fact,hs⟩ := root_columns T p ⟨1,ub⟩ b
  let a (i : I) := S (b i)
  have budget (t : Finset I) : ∑ i ∈t, ‖a i‖^2 ≤ 1 := by
    apply ub
    let j (i : Fin t.card) : I := (t.equivFin.symm i : t).val
    refine ⟨t.card,b ∘ j,b.orthonormal.comp j (Subtype.val_injective.comp t.equivFin.symm.injective),?_⟩
    have id (i) : (inner ℂ (b i) (T (b i))).re = ‖a i‖^2 := by
      rw [fact,←sa,S.adjoint_inner_right,sa,norm_sq_eq_re_inner (𝕜:=ℂ)]; rfl
    change (∑ i, (inner ℂ (b (j i)) (T (b (j i)))).re)=_
    simp only [id]
    exact (t.equivFin.symm.sum_comp (fun i:t => ‖a i.val‖^2)).trans (t.sum_coe_sort (fun i => ‖a i‖^2))
  have gsum : Summable (fun i => ‖gram (a i)‖) := by simpa only [norm_gram] using hs
  let k' := ∑' i, gram (a i)
  have ident : op μ k'=T := by
    apply ContinuousLinearMap.ext; intro v
    have sumout : HasSum (fun i => inner ℂ (a i) v • a i) (T v) := by
      rw [fact]
      convert! (b.hasSum_repr (S v)).mapL S using 1
      funext i
      simp only [a,map_smul,b.repr_apply_apply]
      congr 1
      conv_lhs => rw [←sa,S.adjoint_inner_left]
    have hs' := (ContinuousLinearMap.apply ℂ (H μ) v).hasSum ((operatorMap μ).hasSum gsum.of_norm.hasSum)
    apply HasSum.unique _ sumout
    simpa only [ContinuousLinearMap.apply_apply,show (operatorMap μ : K μ → (H μ →L[ℂ] H μ)) = op μ from rfl,
      op_gram] using hs'
  have eqn : k'=k := op_injective μ ident
  rw [←eqn]
  calc
    ‖k'‖ ≤ ∑' i, ‖gram (a i)‖ := norm_tsum_le_tsum_norm gsum
    _ = ∑' i, ‖a i‖^2 := tsum_congr fun i => norm_gram _
    _ ≤ 1 := Real.tsum_le_of_sum_le (fun i => sq_nonneg ‖a i‖) budget

end KDClosure.ChainLimit.Kernel
