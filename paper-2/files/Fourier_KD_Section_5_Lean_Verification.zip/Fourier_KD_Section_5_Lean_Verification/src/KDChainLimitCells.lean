import KDChainLimitWindow

noncomputable section
namespace KDClosure.ChainLimit
open MeasureTheory Filter Set CompactCore CompactCoset LCAReality Classical
open scoped ComplexOrder ComplexConjugate ENNReal BigOperators
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
  [MeasurableSpace G] [BorelSpace G] [MeasurableAdd G] [T2Space G] [SecondCountableTopology G]
variable (H K : CO G)
local instance : Fintype (CoreQuot H K) := @Fintype.ofFinite _ (finite_core H K)

omit [MeasurableSpace G] [BorelSpace G] [MeasurableAdd G] [T2Space G] [SecondCountableTopology G] in
theorem section_freq (le : H≤K) (γ : AddChar (CoreQuot H K) ℂ) :
    ∃ η : LCAReality.Dual G, ∀ d (hd : d∈K.val), LCAReality.phase η d = γ (quotientIndex H K d hd) := by
  obtain ⟨χ,hc,unit,ha,e⟩ := section_character_lift H K le γ
  let ch (x : G) : Circle := ⟨χ x,by change dist (χ x) 0=1; simpa using unit x⟩
  let a : AddChar G Circle :=
    { toFun := ch, map_zero_eq_one' := Subtype.ext χ.map_zero_eq_one,
      map_add_eq_mul' x y := Subtype.ext (χ.map_add_eq_mul x y) }
  let η : LCAReality.Dual G := ⟨a.toMonoidHom,show Continuous ch from hc.subtype_mk _⟩
  refine ⟨η,?_⟩
  intro d hd
  let q := quotientIndex H K d hd
  let r := representative H K q
  have eqn : QuotientAddGroup.mk' ((subgroup H).addSubgroupOf (subgroup K)) ⟨d,hd⟩ =
      QuotientAddGroup.mk' ((subgroup H).addSubgroupOf (subgroup K)) r :=
    (representative_spec H K q).symm
  have h : d-r.val∈H.val := (QuotientAddGroup.eq_iff_sub_mem (N:=((subgroup H).addSubgroupOf (subgroup K)))
    (x:=(⟨d,hd⟩:subgroup K)) (y:=r)).mp eqn
  change χ d=γ q
  rw [←e]; change χ d=χ r.val
  calc χ d = χ ((d-r.val)+r.val) := by rw [sub_add_cancel]
       _ = χ r.val := by rw [AddChar.map_add_eq_mul,ha _ h,one_mul]

variable (μ : Measure G) [μ.IsAddHaarMeasure] [SFinite μ]
  [MeasurableSpace (LCAReality.Dual G)] (ν : Measure (LCAReality.Dual G)) [SFinite ν]

def blockMeasure (U : Set G) := (μ.restrict U).prod (μ.restrict (K.val:Set G))
def rowIntegrand (k : Lp ℂ 2 (μ.prod μ)) (ξ : LCAReality.Dual G) (z : G×G) :=
  k (z.1,z.1+z.2)*LCAReality.phase ξ z.2
def cell (q : CoreQuot H K) : Set (G×G) := Prod.snd ⁻¹' coset H (representative H K q:G)

/-- Unscaled matrix entry in displacement q, integrated over physical row positions U. -/
def displacementCell (U : Set G) (k : Lp ℂ 2 (μ.prod μ)) (ξ : LCAReality.Dual G) (q : CoreQuot H K) :=
  ∫ z, (cell H K q).indicator (rowIntegrand μ k ξ) z ∂blockMeasure K μ U

omit [MeasurableSpace (LCAReality.Dual G)] [T2Space G] [MeasurableAdd G] in
theorem integrable_row (U : Set G) (u : μ U≠∞) (k : Lp ℂ 2 (μ.prod μ)) (ξ : LCAReality.Dual G) :
    Integrable (rowIntegrand μ k ξ) (blockMeasure K μ U) := by
  let _ : IsFiniteMeasure (μ.restrict U) := isFiniteMeasure_restrict.mpr u
  let _ : IsFiniteMeasure (μ.restrict (K.val:Set G)) := isFiniteMeasure_restrict.mpr K.property.measure_ne_top
  let _ : IsFiniteMeasure (blockMeasure K μ U) := inferInstanceAs (IsFiniteMeasure ((μ.restrict U).prod (μ.restrict (K.val:Set G))))
  have mk := (Lp.memLp k).comp_measurePreserving (measurePreserving_prod_add μ μ)
  have mk' : MemLp (fun z:G×G => k (z.1,z.1+z.2)) 2 (blockMeasure K μ U) := by
    unfold blockMeasure; rw [Measure.prod_restrict]; exact mk.restrict _
  have c : Continuous (fun z : G×G => LCAReality.phase ξ z.2) :=
    (show Continuous (LCAReality.phase ξ) from continuous_subtype_val.comp ξ.continuous).comp continuous_snd
  exact (mk'.integrable (by norm_num)).mul_bdd c.aestronglyMeasurable
    (Eventually.of_forall (fun z => (Circle.norm_coe _).le))

omit [T2Space G] [SFinite ν] in
/-- Averaging a genuine KD-positive kernel over physical finite-volume row
positions and partitioning displacement into K/H cosets gives a nonnegative
finite symbol at every character of K/H, including a modulation by ξ. -/
theorem finite_cell_symbol (F : FourierRealization μ ν) (k : Lp ℂ 2 (μ.prod μ))
    (kd : ∀ᵐ x ∂μ, ∀ᵐ χ ∂ν, 0 ≤ F.isometry (rowAt μ k x) χ)
    (le : H≤K) (U : Set G) (u : μ U ≠ ∞) (ξ : LCAReality.Dual G) (γ : AddChar (CoreQuot H K) ℂ) :
    0 ≤ ∑ q, displacementCell H K μ U k ξ q * γ q := by
  obtain ⟨η,agree⟩ := section_freq H K le γ
  let m := blockMeasure K μ U
  let g (q : CoreQuot H K) (z : G×G) := (cell H K q).indicator (rowIntegrand μ k ξ) z * γ q
  have ci (q : CoreQuot H K) : Integrable (g q) m :=
    ((integrable_row K μ U u k ξ).indicator ((coset_meas H _).preimage measurable_snd)).mul_const _
  have k2 : ∀ᵐ z : G×G ∂m, z.2∈K.val := by
    change ∀ᵐ z ∂(μ.restrict U).prod (μ.restrict (K.val:Set G)), z.2∈(K.val:Set G)
    exact (Measure.ae_prod_iff_ae_ae (K.val.isOpen.measurableSet.preimage measurable_snd)).mpr (Eventually.of_forall fun _ => ae_restrict_mem K.val.isOpen.measurableSet)
  have agree_point : (fun z => ∑ q, g q z) =ᵐ[m] rowIntegrand μ k (ξ*η) := by
    filter_upwards [k2] with z hz
    let t := quotientIndex H K z.2 hz
    have membership (q : CoreQuot H K) : z∈cell H K q ↔ t=q := by
      change z.2-(representative H K q:G)∈H.val ↔ _
      have h := (QuotientAddGroup.eq_iff_sub_mem (N:=((subgroup H).addSubgroupOf (subgroup K)))
        (x:=(⟨z.2,hz⟩:subgroup K)) (y:=representative H K q)).symm
      have rep : (representative H K q : CoreQuot H K) = q := representative_spec H K q
      exact h.trans (by rw [rep]; rfl)
    rw [Finset.sum_eq_single t]
    · change (cell H K t).indicator _ z * γ t = _
      rw [indicator_of_mem ((membership _).mpr rfl),←agree z.2 hz]
      change (k (z.1,z.1+z.2)*(ξ (Multiplicative.ofAdd z.2):ℂ))*(η (Multiplicative.ofAdd z.2):ℂ) =
        k (z.1,z.1+z.2)*((ξ (Multiplicative.ofAdd z.2)*η (Multiplicative.ofAdd z.2):Circle):ℂ)
      rw [Circle.coe_mul,mul_assoc]
    · intro q _ ne; change (cell H K q).indicator _ z * _=0
      rw [indicator_of_notMem (fun h => ne ((membership q).mp h).symm),zero_mul]
    · simp
  have eqn : (∑ q, displacementCell H K μ U k ξ q * γ q) = ∫ z, rowIntegrand μ k (ξ*η) z ∂m := by
    change (∑ q, (∫ z, _ ∂m) * γ q)=_
    simp_rw [←integral_mul_const]
    exact (integral_finsetSum Finset.univ (fun q _ => ci q)).symm.trans (integral_congr_ae agree_point)
  rw [eqn]
  have h := kernel_window_nonneg μ ν F k kd U K (ξ*η)
  rw [show (∫ z, rowIntegrand μ k (ξ*η) z ∂m) = _ from integral_prod _ (integrable_row K μ U u k (ξ*η))]
  exact h

end KDClosure.ChainLimit
