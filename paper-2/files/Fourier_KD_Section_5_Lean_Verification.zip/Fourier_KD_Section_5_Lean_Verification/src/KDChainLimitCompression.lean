import KDChainLimitCells
import KDLCAQuotientUniqueness
import KDChainLimitFinite

noncomputable section
namespace KDClosure.ChainLimit
open MeasureTheory Filter Set CompactCore CompactCoset LCAReality Classical
open scoped ComplexOrder ComplexConjugate ENNReal BigOperators
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
  [MeasurableSpace G] [BorelSpace G] [MeasurableAdd G] [T2Space G] [SecondCountableTopology G]
variable (H K : CO G)
local instance : Fintype (CoreQuot H K) := @Fintype.ofFinite _ (finite_core H K)

def region (u : G) (i : CoreQuot H K) : Set G := coset H (u+(representative H K i:G))

omit [MeasurableSpace G] [BorelSpace G] [MeasurableAdd G] [T2Space G] [SecondCountableTopology G]
  [IsTopologicalAddGroup G] in
theorem region_delta_iff (u x d : G) (i j : CoreQuot H K) (hx : x∈region H K u i) :
    d+x∈region H K u j ↔ d∈coset H (representative H K (j-i):G) := by
  let r (a : CoreQuot H K) := representative H K a
  have eqn : QuotientAddGroup.mk' ((subgroup H).addSubgroupOf (subgroup K)) (r j-r i) =
      QuotientAddGroup.mk' ((subgroup H).addSubgroupOf (subgroup K)) (r (j-i)) := by
    simp only [r,map_sub,representative_spec]
  have delta : (r j:G)-(r i:G)-(r (j-i):G)∈H.val :=
    (QuotientAddGroup.eq_iff_sub_mem (N:=((subgroup H).addSubgroupOf (subgroup K))) (x:=r j-r i) (y:=r (j-i))).mp eqn
  change x-(u+(r i:G)) ∈ H.val at hx
  change d+x-(u+(r j:G))∈H.val ↔ d-(r (j-i):G)∈H.val
  constructor
  · intro hy
    convert! H.val.add_mem (H.val.sub_mem hy hx) delta using 1; abel
  · intro hy
    convert! H.val.sub_mem (H.val.add_mem hy hx) delta using 1; abel

variable (μ : Measure G) [μ.IsAddHaarMeasure] [SFinite μ]
omit [MeasurableAdd G] [T2Space G] [SecondCountableTopology G] [SFinite μ] in
private theorem packet_mem (u : G) (ξ : LCAReality.Dual G) (i : CoreQuot H K) :
    MemLp ((region H K u i).indicator (LCAReality.phase ξ)) 2 μ := by
  let _ : IsFiniteMeasure (μ.restrict (region H K u i)) := isFiniteMeasure_restrict.mpr (coset_compact H _).measure_ne_top
  apply (memLp_indicator_iff_restrict (show MeasurableSet (region H K u i) from coset_meas H _)).mpr
  have c : Continuous (LCAReality.phase ξ) := continuous_subtype_val.comp ξ.continuous
  exact MemLp.of_bound c.aestronglyMeasurable 1 (Eventually.of_forall fun z => (Circle.norm_coe _).le)

def cellVector (u : G) (ξ : LCAReality.Dual G) (i : CoreQuot H K) : Lp ℂ 2 μ :=
  (packet_mem H K μ u ξ i).toLp _

omit [MeasurableAdd G] [T2Space G] [SecondCountableTopology G] [SFinite μ] in
theorem cellVector_ae (u : G) (ξ : LCAReality.Dual G) (i : CoreQuot H K) :
    (cellVector H K μ u ξ i : G→ℂ) =ᵐ[μ] (region H K u i).indicator (LCAReality.phase ξ) :=
  (packet_mem H K μ u ξ i).coeFn_toLp

def blockEntries (T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ) (u : G) (ξ : LCAReality.Dual G) :
    Matrix (CoreQuot H K) (CoreQuot H K) ℂ :=
  Matrix.of fun i j => inner ℂ (cellVector H K μ u ξ i) (T (cellVector H K μ u ξ j))

omit [IsTopologicalAddGroup G] [MeasurableSpace G] [BorelSpace G] [MeasurableAdd G] [T2Space G] [SecondCountableTopology G] in
private theorem phase_shift (ξ : LCAReality.Dual G) (x d : G) :
    LCAReality.phase ξ (d+x) * conj (LCAReality.phase ξ x) = LCAReality.phase ξ d := by
  change complexChar ξ (d+x) * conj (ξ (Multiplicative.ofAdd x):ℂ) = complexChar ξ d
  rw [AddChar.map_add_eq_mul,←Circle.coe_inv_eq_conj, Circle.coe_inv]
  change LCAReality.phase ξ d * (ξ (Multiplicative.ofAdd x):ℂ) * (ξ (Multiplicative.ofAdd x):ℂ)⁻¹=_
  rw [mul_inv_cancel_right₀ (Circle.coe_ne_zero _)]; rfl

omit [T2Space G] in
/-- Concrete matrix of the compressed operator in the physical modulated
coset vectors, as a finite displacement-cell integral of its unique kernel. -/
theorem blockEntries_eq (le : H≤K) (k : Lp ℂ 2 (μ.prod μ)) (T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ)
    (act : LCAQuotient.ActsBy μ T k) (u : G) (ξ : LCAReality.Dual G) (i j : CoreQuot H K) :
    blockEntries H K μ T u ξ i j = displacementCell H K μ (region H K u i) k ξ (j-i) := by
  let U := region H K u i
  let V := region H K u j
  let Z := coset H (representative H K (j-i):G)
  let b := rowIntegrand μ k ξ
  have um : MeasurableSet U := coset_meas H _
  have vm : MeasurableSet V := coset_meas H _
  have km : MeasurableSet (K.val:Set G) := K.val.isOpen.measurableSet
  have zk (d:G) (hd : d∈Z) : d∈K.val := by
    change d-(representative H K (j-i):G) ∈ H.val at hd
    have p := K.val.add_mem (le hd) (representative H K (j-i)).property
    rw [sub_add_cancel] at p; exact p
  have integ : Integrable ((cell H K (j-i)).indicator b) (blockMeasure K μ U) :=
    (integrable_row K μ U (coset_compact H _).measure_ne_top k ξ).indicator ((coset_meas H _).preimage measurable_snd)
  change inner ℂ (cellVector H K μ u ξ i) (T (cellVector H K μ u ξ j)) = _
  rw [MeasureTheory.L2.inner_def]
  change _ = ∫ z, (cell H K (j-i)).indicator b z ∂(μ.restrict U).prod (μ.restrict (K.val:Set G))
  rw [integral_prod _ integ,←integral_indicator um]
  apply integral_congr_ae
  filter_upwards [cellVector_ae H K μ u ξ i,act (cellVector H K μ u ξ j)] with x hx hT
  rw [RCLike.inner_apply,hx,hT]
  by_cases hu : x∈U
  · rw [indicator_of_mem hu,indicator_of_mem hu,←integral_mul_const,←integral_indicator km]
    rw [←integral_add_left_eq_self (μ:=μ) (fun y => k (x,y)*cellVector H K μ u ξ j y*conj (LCAReality.phase ξ x)) x]
    apply integral_congr_ae
    filter_upwards [(measurePreserving_add_left μ x).quasiMeasurePreserving.ae_eq_comp (cellVector_ae H K μ u ξ j)] with d hd
    change cellVector H K μ u ξ j (x+d) = V.indicator (LCAReality.phase ξ) (x+d) at hd
    rw [hd]
    have test : x+d∈V ↔ d∈Z := by rw [add_comm x]; exact region_delta_iff H K u x d i j hu
    by_cases h : d∈Z
    · rw [indicator_of_mem (test.mpr h),indicator_of_mem (zk d h),indicator_of_mem (show (x,d)∈cell H K (j-i) from h)]
      change k (x,x+d)*LCAReality.phase ξ (x+d)*conj (LCAReality.phase ξ x) = _
      rw [mul_assoc,add_comm x d,phase_shift]
      change k (x,d+x)*LCAReality.phase ξ d=k (x,x+d)*LCAReality.phase ξ d
      rw [add_comm d x]
    · rw [indicator_of_notMem (fun hv => h (test.mp hv)),mul_zero,zero_mul]
      by_cases hk : d∈K.val
      · rw [indicator_of_mem hk,indicator_of_notMem (show (x,d)∉cell H K (j-i) from h)]
      · rw [indicator_of_notMem hk]
  · rw [indicator_of_notMem hu,indicator_of_notMem hu,map_zero,mul_zero]

variable [MeasurableSpace (LCAReality.Dual G)] (ν : Measure (LCAReality.Dual G)) [SFinite ν]

omit [SFinite ν] [T2Space G] in
/-- Genuine finite matrix KD positivity of every translated, modulated
compact-open block (unnormalized vectors have the common norm √μ(H)). -/
theorem block_symbol_nonneg (F : FourierRealization μ ν) (T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ)
    (k : Lp ℂ 2 (μ.prod μ)) (act : LCAQuotient.ActsBy μ T k)
    (kd : ∀ᵐ x ∂μ, ∀ᵐ χ ∂ν, 0 ≤ F.isometry (rowAt μ k x) χ) (le : H≤K) (u : G)
    (ξ : LCAReality.Dual G) (i : CoreQuot H K) (γ : AddChar (CoreQuot H K) ℂ) :
    0 ≤ KDFourier.symbol (blockEntries H K μ T u ξ) i γ := by
  have hh := finite_cell_symbol H K μ ν F k kd le (region H K u i) (coset_compact H _).measure_ne_top ξ γ
  change 0≤∑ j, blockEntries H K μ T u ξ i j * γ (j-i)
  simp_rw [blockEntries_eq H K μ le k T act]
  exact ((Fintype.sum_equiv (Equiv.subRight i) _ (fun d => displacementCell H K μ (region H K u i) k ξ d * γ d) (fun _ => rfl)) ▸ hh : _)

end KDClosure.ChainLimit
