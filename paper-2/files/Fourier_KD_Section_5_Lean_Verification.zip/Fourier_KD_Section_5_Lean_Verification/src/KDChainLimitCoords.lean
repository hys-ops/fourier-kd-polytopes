import KDChainLimitWeak
import KDChainLimitIntegral

noncomputable section
namespace KDClosure.ChainLimit.Kernel
open MeasureTheory Set Filter Topology
open scoped InnerProductSpace
variable {G : Type*} [MeasurableSpace G] (μ : Measure G) [SigmaFinite μ]

/-- All (not merely diagonal) weak operator tests on the actual Haar Hilbert space. -/
def coord : (H μ →L[ℂ] H μ) →ₗ[ℝ] (H μ × H μ → ℂ) where
  toFun T z := inner ℂ z.1 (T z.2)
  map_add' a b := by ext1 z; simp [inner_add_right]
  map_smul' r a := by
    ext1 z
    change inner ℂ z.1 (r • a z.2) = r • inner ℂ z.1 (a z.2)
    rw [←algebraMap_smul ℂ r,inner_smul_right,←algebraMap_smul ℂ r]
    rfl

omit [SigmaFinite μ] in
theorem coord_inj : Function.Injective (coord μ) := by
  intro a b eqn; apply ContinuousLinearMap.ext; intro y; apply ext_inner_left ℂ; intro x; exact congrFun eqn (x,y)

omit [SigmaFinite μ] in
theorem minors_iff (T : H μ →L[ℂ] H μ) :
    Discrete.minorsVanish (coord μ T) ↔ Module.rank ℂ (LinearMap.range T.toLinearMap) ≤ 1 := by
  classical
  let A := coord μ T
  change Discrete.minorsVanish A ↔ _
  constructor
  · intro minors
    apply rank_le_one_iff.mpr
    by_cases has : ∃ x i, A (x,i) ≠ 0
    · obtain ⟨x,i,hp⟩ := has
      let c := A (x,i)
      have hc : c≠0 := hp
      let F : H μ →L[ℂ] ℂ := (innerSL ℂ x).comp T
      let B : H μ →L[ℂ] H μ := F.smulRight (c⁻¹ • T i)
      have factor : T=B := by
        apply coord_inj μ; ext1 z; obtain ⟨y,j⟩ := z
        change A (y,j) = inner ℂ y (F j • (c⁻¹ • T i))
        rw [inner_smul_right,inner_smul_right]
        change A (y,j)=A (x,j)*(c⁻¹*A (y,i))
        have minor : c * A (y,j)=A (x,j)*A (y,i) := minors x y i j
        field_simp
        linear_combination minor
      refine ⟨⟨T i,i,rfl⟩,?_⟩
      rintro ⟨_,z,rfl⟩
      refine ⟨F z*c⁻¹,Subtype.ext ?_⟩
      change (F z*c⁻¹) • T i = T z
      exact (mul_smul ..).trans (DFunLike.congr_fun factor z).symm
    · have hz : T=0 := by
        apply coord_inj μ; ext1 z; obtain ⟨i,j⟩ := z
        have h : A (i,j)=0 := by by_contra ne; exact has ⟨i,j,ne⟩
        exact h.trans (by simp [coord])
      refine ⟨0,?_⟩
      rintro ⟨_,z,rfl⟩
      exact ⟨0,Subtype.ext (by simp [hz])⟩
  · intro rankone
    obtain ⟨v,hv⟩ := rank_le_one_iff.mp rankone
    have multiples (i : H μ) : ∃ c : ℂ, c • v.val = T i := by
      obtain ⟨c,h⟩ := hv ⟨T i,i,rfl⟩
      exact ⟨c,congrArg Subtype.val h⟩
    choose c hc using multiples
    have coeff (x i : H μ) : A (x,i)=c i*inner ℂ x v.val := by
      change inner ℂ x (T i)=_
      rw [←hc,inner_smul_right]
    intro x y i j
    simp only [coeff]; ring

def cmap := (coord μ).comp ((operatorMap μ).restrictScalars ℝ).toLinearMap

/-- Every WOT coefficient is a pair of weakly continuous real functionals on kernel space. -/
theorem weak_coords : Continuous (fun w : WeakSpace ℝ (K μ) =>
    cmap μ ((toWeakSpace ℝ (K μ)).symm w)) := by
  apply continuous_pi; intro z
  let f := (innerSL ℂ (rect μ z.1 z.2)).restrictScalars ℝ
  have h (L : K μ →L[ℝ] ℝ) : Continuous (fun w : WeakSpace ℝ (K μ) => L ((toWeakSpace ℝ (K μ)).symm w)) :=
    WeakBilin.eval_continuous (topDualPairing ℝ (K μ)).flip L
  have hc := (Complex.continuous_ofReal.comp (h (Complex.reCLM.comp f))).add
    ((Complex.continuous_ofReal.comp (h (Complex.imCLM.comp f))).mul (continuous_const (y:=Complex.I)))
  apply hc.congr
  intro w
  change ((f _).re : ℂ) + ((f _).im : ℂ) * Complex.I = inner ℂ z.1 (op μ _ z.2)
  rw [op_test]; exact Complex.re_add_im _

end KDClosure.ChainLimit.Kernel
