import KDChainLimitSubstate
import KDChainLimitCoords

noncomputable section
namespace KDClosure.ChainLimit.Kernel
open MeasureTheory Filter Set CompactFourier LCAQuotient LCAReality
open scoped ComplexOrder KDClosure.SubgroupMeasure Topology InnerProductSpace
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
  [MeasurableSpace G] [BorelSpace G] [SecondCountableTopology G]
  (μ : Measure G) [SigmaFinite μ] [μ.IsAddLeftInvariant]
  (ν : Measure (LCAReality.Dual G)) [SFinite ν] (F : FourierRealization μ ν)

theorem compact_coords : IsCompact (cmap μ '' substate μ ν F) := by
  have h := (substate_compact μ ν F).image (weak_coords μ)
  rw [Set.image_image] at h
  exact h

theorem extreme_coords {k : K μ} (ex : op μ k ∈ (ambientStates μ ν F).extremePoints ℝ) :
    cmap μ k ∈ (cmap μ '' substate μ ν F).extremePoints ℝ := by
  have h := full_extreme μ ν ex
  have injective : Function.Injective (cmap μ) := (coord_inj μ).comp (op_injective μ)
  refine ⟨⟨k,h.1,rfl⟩,?_⟩
  rintro _ ⟨a,ha,rfl⟩ _ ⟨b,hb,rfl⟩ ⟨s,t,hs,ht,sum,e⟩
  exact congrArg (cmap μ) (h.2 ha hb ⟨s,t,hs,ht,sum,injective (by rw [map_add,map_smul,map_smul]; exact e)⟩)

def atoms := insert 0 {S | S ∈ ambientStates μ ν F ∧ Module.rank ℂ (LinearMap.range S.toLinearMap)≤1}

theorem atoms_coords_subset : coord μ '' atoms μ ν F ⊆ cmap μ '' substate μ ν F := by
  rintro _ ⟨S,h,rfl⟩
  rcases h with rfl|⟨state,_⟩
  · exact ⟨0,zero_substate μ ν F,by simp⟩
  · obtain ⟨k,act,_,_⟩ := state.2.2
    have eqn := op_eq_of_acts μ act
    exact ⟨k,((ambient_iff μ ν k).mp (eqn.symm ▸ state)).1,congrArg (coord μ) eqn⟩

/-- A physical trace-one extreme point in the WOT-closed convex hull of genuine
rank-one physical states and zero has rank at most one. No trace tightness,
unproved Milman converse, nuclearity hypothesis, or common eigenbasis is assumed. -/
theorem rank_le_one_of_wot {T : H μ →L[ℂ] H μ}
    (ex : T ∈ (ambientStates μ ν F).extremePoints ℝ)
    (approx : coord μ T ∈ closure (convexHull ℝ (coord μ '' atoms μ ν F))) :
    Module.rank ℂ (LinearMap.range T.toLinearMap)≤1 := by
  obtain ⟨k,act,_,_⟩ := ex.1.2.2
  obtain rfl := (op_eq_of_acts μ act).symm
  have h := individual_closure (compact_coords μ ν F)
    ((substate_convex μ ν F).linear_image (cmap μ)) (atoms_coords_subset μ ν F)
    (extreme_coords μ ν F ex) approx
  apply (minors_iff μ _).mp
  apply closure_minimal _ (Discrete.closed_minors (H μ)) h
  rintro _ ⟨S,hs,rfl⟩
  apply (minors_iff μ S).mpr
  rcases hs with rfl|⟨_,rankone⟩
  · simp
  · exact rankone

theorem rank_le_one_of_tendsto {T : H μ →L[ℂ] H μ}
    (ex : T ∈ (ambientStates μ ν F).extremePoints ℝ) {A : ℕ → (H μ →L[ℂ] H μ)}
    (hA : ∀ n, A n∈convexHull ℝ (atoms μ ν F))
    (lim : ∀ x y : H μ, Tendsto (fun n => inner ℂ x (A n y)) atTop (𝓝 (inner ℂ x (T y)))) :
    Module.rank ℂ (LinearMap.range T.toLinearMap)≤1 := by
  apply rank_le_one_of_wot μ ν F ex
  have h : Tendsto (fun n => coord μ (A n)) atTop (𝓝 (coord μ T)) :=
    tendsto_pi_nhds.mpr fun z => lim z.1 z.2
  apply mem_closure_of_tendsto h
  apply Eventually.of_forall; intro n
  rw [← (coord μ).image_convexHull]
  exact ⟨_,hA n,rfl⟩

end KDClosure.ChainLimit.Kernel
