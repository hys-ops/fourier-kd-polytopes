import KDAtomPort
import Mathlib.Analysis.Fourier.FiniteAbelian.PontryaginDuality
import Mathlib.Algebra.Ring.Periodic

/-! The finite positive-chain proof from the archived finite classification.
Only the positive declarations are ported; the actual character frame below
is assembled directly from mathlib's finite Fourier orthogonality. -/
noncomputable section
set_option autoImplicit false
set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false
open scoped ComplexOrder MatrixOrder BigOperators
open Matrix Classical
namespace KDClosure.ChainLimit.Finite
open KDOperator KDFourier KDPure KDAtoms
universe u v
variable {G : Type u} {I : Type v} [AddCommGroup G] [Fintype G] [DecidableEq G] [Fintype I]

/-- Finite corner tests at every complex character. -/
def states (G : Type*) [AddCommGroup G] [Fintype G] [DecidableEq G] : Set (Op G) :=
  {A | A.PosSemidef ∧ A.trace=1 ∧ ∀ x k, 0 ≤ symbol A x k}

def pureSet (G : Type*) [AddCommGroup G] [Fintype G] [DecidableEq G] : Set (Op G) :=
  {A | ∃ u : G → ℂ, A=outer u ∧ A.trace=1 ∧ ∀ x k, 0 ≤ symbol A x k}

theorem symbol_add (A B : Op G) (x : G) (χ : AddChar G ℂ) :
    symbol (A+B) x χ = symbol A x χ + symbol B x χ := by
  simp [symbol,add_mul,Finset.sum_add_distrib]
theorem symbol_injective (F : Frame G I) {A B : Op G}
    (he : ∀ x i, symbol A x (F.char i)=symbol B x (F.char i)) : A=B := by
  ext x y
  have hh : KDAtoms.row A x=KDAtoms.row B x := row_unique F (fun i => by simp [row_amp,he])
  simpa [KDAtoms.row] using congrFun hh (y-x)

theorem atom_trace (U : AddSubgroup G) (a:G) (b:AddChar G ℂ) : (atom U a b).trace=1 := by
  classical
  have e : (∑ _h:U,(1:ℂ))=(outer (v U a b)).trace := by
    apply Fintype.sum_of_injective (fun h:U => a+h.val)
      (fun {s t} h => Subtype.ext (add_left_cancel h))
    · intro x hx; have hv : x-a ∉ U := fun h => hx ⟨⟨x-a,h⟩,by simp⟩
      simp [outer,v,hv]
    · intro h; change 1=star (v U a b (a+h.val))*v U a b (a+h.val)
      have ha : a+(h:G)-a ∈ U := by simp
      rw [v,if_pos ha,char_conj,neg_neg,AddChar.map_neg_eq_inv,mul_inv_cancel₀ (char_ne _ _)]
  simp [atom,trace_smul,← e,Complex.real_smul,Fintype.card_ne_zero]

theorem atom_pure (U : AddSubgroup G) (a:G) (b:AddChar G ℂ) : atom U a b ∈ pureSet G := by
  let c : ℝ := (Fintype.card U:ℝ)⁻¹
  have nc : 0≤c := by dsimp [c]; positivity
  refine ⟨fun x => (Real.sqrt c:ℂ)*v U a b x,?_,atom_trace _ _ _,?_⟩
  · ext x y; change (c:ℂ)*(star (v U a b x)*v U a b y)=_
    change _ = star ((Real.sqrt c:ℂ)*v U a b x)*((Real.sqrt c:ℂ)*v U a b y)
    have sq : (Real.sqrt c:ℂ)^2=(c:ℂ) := by exact_mod_cast Real.sq_sqrt nc
    simp only [star_mul,Complex.star_def,Complex.conj_ofReal]; linear_combination -(starRingEnd ℂ) (v U a b x)*v U a b y*sq
  · intro x k; rw [atom_symbol]; unfold tile; split <;> norm_num
abbrev Arr (G I : Type*) := G × I → ℝ
def rel (F : Frame G I) (H : AddSubgroup G) (z t : G×I) :=
  z.1-t.1 ∈ H ∧ ∀ h ∈ H,F.char z.2 h=F.char t.2 h
def eqv (F : Frame G I) (H : AddSubgroup G) : Setoid (G×I) where
  r := rel F H
  iseqv := {
    refl := fun z => ⟨by simp,fun _ _ => rfl⟩
    symm := fun ⟨hp,hk⟩ => ⟨by simpa using H.neg_mem hp,fun x h => (hk x h).symm⟩
    trans := fun ⟨h₁,k₁⟩ ⟨h₂,k₂⟩ => ⟨by simpa using H.add_mem h₁ h₂,fun x h => (k₁ x h).trans (k₂ x h)⟩ }
def Adapt (F : Frame G I) (H : AddSubgroup G) (f : Arr G I) :=
  ∀ z t, rel F H z t → f z=f t

def Cert (F : Frame G I) (f : Arr G I) := ∃ (T : Type (max u v)) (_ : Fintype T)
    (w : T → ℝ) (P : T → Op G), (∀ i, 0 ≤ w i) ∧ (∀ i, P i ∈ pureSet G) ∧
    ∀ z : G×I, (f z : ℂ)=∑ i, (w i:ℂ)*symbol (P i) z.1 (F.char z.2)

theorem ofAdapt (F : Frame G I) (H : AddSubgroup G) {f : Arr G I} (ha : Adapt F H f)
    (hn : ∀ z, 0 ≤ f z) : Cert F f := by
  let R := eqv F H
  let T := Quotient R
  let : Fintype T := Fintype.ofFinite _
  refine ⟨T,inferInstance,fun t => f t.out,fun t => atom H t.out.1 (F.char t.out.2),
    fun _ => hn _,fun _ => atom_pure _ _ _,?_⟩
  intro z; let t : T := Quotient.mk R z
  have iff (s:T) : rel F H z s.out ↔ s=t := by
    change (R.r z s.out) ↔ _
    rw [← Quotient.eq,Quotient.out_eq,eq_comm]
  have he := ha z t.out ((iff t).mpr rfl)
  simp_rw [atom_symbol]
  rw [Finset.sum_eq_single t]
  · have one : tile H t.out.1 (F.char t.out.2) z.1 (F.char z.2)=1 := if_pos ((iff t).mpr rfl)
    simp [he,one]
  · intro i _ hh
    have zero : tile H i.out.1 (F.char i.out.2) z.1 (F.char z.2)=0 := if_neg (fun h => hh ((iff i).mp h))
    simp [zero]
  · simp

theorem cert_add (F : Frame G I) {a b : Arr G I} (ca : Cert F a) (cb : Cert F b) :
    Cert F (a+b) := by
  obtain ⟨S,_,w,P,hw,hP,h₁⟩ := ca
  obtain ⟨T,_,v,Q,hv,hQ,h₂⟩ := cb
  refine ⟨S⊕T,inferInstance,Sum.elim w v,Sum.elim P Q,by rintro (i|i); exact hw i; exact hv i,
    by rintro (i|i); exact hP i; exact hQ i,?_⟩
  intro z; simp [Fintype.sum_sum_type,h₁,h₂]

/-- The minimum over the position coset of K; no arbitrary minimizer is used in its value. -/
def lo (K : AddSubgroup G) (f : Arr G I) (z : G×I) : ℝ :=
  (Finset.univ : Finset K).inf' Finset.univ_nonempty (fun h => f (z.1+h.val,z.2))

theorem lo_le (K : AddSubgroup G) (f : Arr G I) (z : G×I) (h:K) :
    lo K f z ≤ f (z.1+h.val,z.2) := Finset.inf'_le _ (Finset.mem_univ h)
theorem lo_at (K : AddSubgroup G) (f : Arr G I) (z : G×I) :
    ∃ h : K, lo K f z=f (z.1+h.val,z.2) := by
  obtain ⟨h,_,hh⟩ := Finset.exists_mem_eq_inf' Finset.univ_nonempty (fun h:K => f (z.1+h.val,z.2))
  exact ⟨h,hh⟩

theorem lo_same (F : Frame G I) {H K : AddSubgroup G} {f : Arr G I} (ha : Adapt F H f)
    {z t : G×I} (hp : z.1-t.1 ∈ K) (hk : ∀ h ∈ H,F.char z.2 h=F.char t.2 h) :
    lo K f z=lo K f t := by
  have le {b c : G×I} (hp : b.1-c.1 ∈ K)
      (hk : ∀ h ∈ H,F.char b.2 h=F.char c.2 h) : lo K f b ≤ lo K f c := by
    obtain ⟨h,eq⟩ := lo_at K f c
    let h' : K := ⟨h.val-(b.1-c.1),K.sub_mem h.property hp⟩
    calc
      _ ≤ f (b.1+h'.val,b.2) := lo_le K f b h'
      _ = f (c.1+h.val,c.2) := ha _ _ ⟨by dsimp [h']; convert H.zero_mem using 1; abel,hk⟩
      _ = _ := eq.symm
  exact le_antisymm (le hp hk) (le (by simpa using K.neg_mem hp) (fun h hh => (hk h hh).symm))

theorem peel (F : Frame G I) {H K : AddSubgroup G} (hHK : H≤K) {a b : Arr G I}
    (ha : Adapt F H a) (hb : Adapt F K b) :
    Adapt F H (a-lo K a) ∧ Adapt F K (lo K a+b) ∧ ∀ z, 0 ≤ (a-lo K a) z := by
  refine ⟨?_,?_,?_⟩
  · intro z t h; exact congrArg₂ Sub.sub (ha _ _ h) (lo_same F ha (hHK h.1) h.2)
  · intro z t h; exact congrArg₂ HAdd.hAdd (lo_same F ha h.1 (fun x hx => h.2 x (hHK hx))) (hb _ _ h)
  · intro z; exact sub_nonneg.mpr (by simpa using lo_le K a z 0)

def layerSum (s : List (AddSubgroup G × Arr G I)) : Arr G I := (s.map Prod.snd).sum

theorem value_sum {α : Type*} (s : List α) (g : α → Arr G I) (z : G×I) :
    ((s.map g).sum) z=(s.map (fun a => g a z)).sum := by
  induction s with
  | nil => rfl
  | cons a s ih => simp [ih]

theorem layers (F : Frame G I) (s : List (AddSubgroup G × Arr G I))
    (chain : s.Pairwise (fun a b => a.1≤b.1))
    (adapt : ∀ t∈s, Adapt F t.1 t.2) (nonneg : ∀ z, 0≤layerSum s z) : Cert F (layerSum s) := by
  match s with
  | [] => exact ofAdapt F ⊥ (fun _ _ _ => rfl) nonneg
  | [a] => simpa [layerSum] using ofAdapt F a.1 (adapt a (by simp)) (by simpa [layerSum] using nonneg)
  | a::b::tail =>
    let m := lo b.1 a.2
    let b' : AddSubgroup G × Arr G I := (b.1,m+b.2)
    have hf := List.pairwise_cons.mp chain
    have hg := List.pairwise_cons.mp hf.2
    obtain ⟨ph,pk,pz⟩ := peel F (hf.1 b (by simp)) (adapt a (by simp)) (adapt b (by simp))
    have ct := ofAdapt F a.1 ph pz
    have ch' : (b'::tail).Pairwise (fun u v => u.1≤v.1) := List.pairwise_cons.mpr hg
    have ad' : ∀ t∈b'::tail, Adapt F t.1 t.2 := by
      intro t ht; rcases List.mem_cons.mp ht with rfl|h
      · exact pk
      · exact adapt _ (by simp [h])
    have nn' (z : G×I) : 0 ≤ layerSum (b'::tail) z := by
      obtain ⟨h,he⟩ := lo_at b.1 a.2 z
      let t : G×I := (z.1+h.val,z.2)
      have same (c : AddSubgroup G × Arr G I) (hc : c∈b::tail) : c.2 t=c.2 z := by
        apply adapt c (by simp [hc]); refine ⟨?_, fun _ _ => rfl⟩
        have le : b.1≤c.1 := by rcases List.mem_cons.mp hc with rfl|h'; exact le_rfl; exact hg.1 _ h'
        apply le; simp [t]
      have sm : layerSum tail t=layerSum tail z := by
        simp only [layerSum,value_sum]
        apply congrArg List.sum; apply List.map_congr_left
        intro c hc; exact same c (List.mem_cons_of_mem _ hc)
      have hnn := nonneg t
      change 0 ≤ a.2 t + (b.2 t + layerSum tail t) at hnn
      change 0 ≤ (lo b.1 a.2 z + b.2 z) + layerSum tail z
      rw [sm,same b (by simp)] at hnn
      rw [he,add_assoc]; exact hnn
    have smaller :=  layers F (b'::tail) ch' ad' nn'
    convert cert_add F ct smaller using 1
    funext z; simp [layerSum,b',m]; abel
termination_by s.length
decreasing_by simp_wf
def component (F : Frame G I) (A : Op G) (d : G) : AddSubgroup G × Arr G I :=
  (AddSubgroup.zmultiples d,fun z => (KDAtoms.row A z.1 d*F.char z.2 d).re)
theorem component_ok (F : Frame G I) {A: Op G} (ha : A∈states G) (d:G) :
    Adapt F (component F A d).1 (component F A d).2 := by
  rintro ⟨x,k⟩ ⟨y,l⟩ ⟨hp,hk⟩
  obtain ⟨n,hn⟩ := AddSubgroup.mem_zmultiples_iff.mp hp
  have hp' : Function.Periodic (fun t => KDAtoms.row A t d) d := hermitian_period F ha.1.isHermitian ha.2.2 d
  have eq := hp'.zsmul n y
  rw [hn] at eq
  change (KDAtoms.row A x d * F.char k d).re=(KDAtoms.row A y d * F.char l d).re
  rw [hk _ (AddSubgroup.mem_zmultiples d),show KDAtoms.row A x d=KDAtoms.row A y d by simpa using eq]

theorem cert_hull (F : Frame G I) {A : Op G} (ha : A ∈ states G)
    (hc : Cert F (fun z => (symbol A z.1 (F.char z.2)).re)) :
    A ∈ convexHull ℝ (pureSet G) := by
  obtain ⟨T,_,w,P,hw,hP,hval⟩ := hc
  have mat : ∑ i, w i • P i = A := by
    apply symbol_injective F; intro x j
    have sumsym (s : Finset T) : symbol (∑ i∈s, w i • P i) x (F.char j) =
        ∑ i∈s, (w i:ℂ)*symbol (P i) x (F.char j) := by
      induction s using Finset.induction_on with
      | empty => simp [symbol]
      | insert i s hn ih => simp only [Finset.sum_insert hn,symbol_add,symbol_smul,ih]
    rw [sumsym,← hval (x,j)]
    exact Complex.ext rfl (Complex.nonneg_iff.mp (ha.2.2 x (F.char j))).2
  have csum := congrArg Matrix.trace mat
  have one (i:T) : (P i).trace=1 := by obtain ⟨_,_,h,_⟩ := hP i; exact h
  simp [Matrix.trace_sum,Matrix.trace_smul,one,Complex.real_smul,ha.2.1] at csum
  apply mem_convexHull_of_exists_fintype w P hw _ hP mat
  exact_mod_cast csum

theorem chain_positive (F : Frame G I) (total : ∀ H K : AddSubgroup G, H≤K ∨ K≤H)
    {A : Op G} (ha : A∈states G) : A ∈ convexHull ℝ (pureSet G) := by
  let r := fun d e : G => AddSubgroup.zmultiples d ≤ AddSubgroup.zmultiples e
  let : Std.Total r := ⟨fun a b => total _ _⟩
  let : IsTrans G r := ⟨fun _ _ _ h k => h.trans k⟩
  let l := (Finset.univ : Finset G).toList.insertionSort r
  let s := l.map (component F A)
  have ch : s.Pairwise (fun a b => a.1≤b.1) := by
    simpa only [s,List.pairwise_map,component,r,l] using List.pairwise_insertionSort r (Finset.univ : Finset G).toList
  have ad : ∀ t∈s, Adapt F t.1 t.2 := by
    intro t ht; obtain ⟨d,_,rfl⟩ := List.mem_map.mp ht; exact component_ok F ha _
  have val : layerSum s = fun z => (symbol A z.1 (F.char z.2)).re := by
    funext z
    have hperm := List.perm_insertionSort r (Finset.univ : Finset G).toList
    have sm := (hperm.map (fun d => (KDAtoms.row A z.1 d*F.char z.2 d).re)).sum_eq
    rw [layerSum,value_sum,← row_amp]
    simpa [s,List.map_map,component,Function.comp_def,amp,Complex.re_sum,l] using sm
  apply cert_hull F ha
  rw [← val]; apply layers F s ch ad
  intro z; rw [val]; exact (Complex.nonneg_iff.mp (ha.2.2 _ _)).1


theorem pure_hull {A : Op G} (total : ∀ H K : AddSubgroup G, H≤K ∨ K≤H)
    (ha : A ∈ states G) : A ∈ convexHull ℝ (pureSet G) := by
  let F : Frame G (AddChar G ℂ) := ⟨id, AddChar.sum_apply_eq_ite⟩
  exact chain_positive F total ha

end KDClosure.ChainLimit.Finite

namespace KDClosure.ChainLimit.Finite
open KDOperator KDFourier KDPure KDAtoms Matrix Set
variable {G : Type*} [AddCommGroup G] [Fintype G] [DecidableEq G]

/-- Subnormalizing costs a single additional allowed kernel, zero; this
allows exact finite corners of an infinite trace-one operator. -/
theorem subnormalized_hull (chain : ∀ H K : AddSubgroup G, H ≤ K ∨ K ≤ H)
    {A : Op G} (ps : A.PosSemidef) (mass : A.trace.re ≤ 1)
    (kd : ∀ x γ, 0 ≤ symbol A x γ) : A ∈ convexHull ℝ (insert 0 (pureSet G)) := by
  classical
  let t := A.trace.re
  have ht : 0 ≤ t := (Complex.nonneg_iff.mp ps.trace_nonneg).1
  have tr : A.trace=(t:ℂ) := Complex.ext rfl (by
    simpa using (Complex.nonneg_iff.mp ps.trace_nonneg).2.symm)
  have zeroIn : (0 : Op G) ∈ convexHull ℝ (insert 0 (pureSet G)) :=
    subset_convexHull ℝ _ (mem_insert _ _)
  rcases ht.eq_or_lt with hz|hp
  · have z : A=0 := ps.trace_eq_zero_iff.mp (by rw [tr,←hz]; norm_num)
    exact z ▸ zeroIn
  let B := t⁻¹ • A
  have st : B ∈ states G := by
    refine ⟨ps.smul (inv_nonneg.mpr ht),?_,?_⟩
    · change (t⁻¹ • A).trace=1
      rw [trace_smul,tr,Complex.real_smul,Complex.ofReal_inv]
      exact inv_mul_cancel₀ (Complex.ofReal_ne_zero.mpr hp.ne')
    · intro x γ; rw [show B=t⁻¹ • A from rfl,symbol_smul]
      exact mul_nonneg (Complex.zero_le_real.mpr (inv_nonneg.mpr ht)) (kd x γ)
  have hb := (convexHull_mono (subset_insert (0:Op G) (pureSet G))) (pure_hull chain st)
  have hm := (convex_convexHull ℝ (insert (0:Op G) (pureSet G))) hb zeroIn ht
    (sub_nonneg.mpr mass) (add_sub_cancel t 1)
  simpa [B,smul_smul,hp.ne'] using hm

end KDClosure.ChainLimit.Finite
