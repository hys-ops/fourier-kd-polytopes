import KDCompactFourierKernel
import KDLCAQuotientUniqueness

noncomputable section
namespace KDClosure.ChainLimit.Kernel
open MeasureTheory Set Filter CompactFourier LCAQuotient
open scoped ComplexConjugate ENNReal InnerProductSpace
variable {X : Type*} [MeasurableSpace X] (μ : Measure X) [SFinite μ]
abbrev H := Lp ℂ 2 μ
abbrev K := Lp ℂ 2 (μ.prod μ)

omit [SFinite μ] in
private theorem rect_mem (u v : H μ) : MemLp (fun z : X×X => u z.1 * conj (v z.2)) 2 (μ.prod μ) := by
  have h := (Lp.stronglyMeasurable u).measurable
  have j := (Lp.stronglyMeasurable v).measurable
  apply (memLp_two_iff_integrable_sq_norm (((h.comp measurable_fst).mul
    (Complex.continuous_conj.measurable.comp (j.comp measurable_snd))).aestronglyMeasurable)).2
  have hi := (memLp_two_iff_integrable_sq_norm (Lp.aestronglyMeasurable u)).1 (Lp.memLp u)
  have hj := (memLp_two_iff_integrable_sq_norm (Lp.aestronglyMeasurable v)).1 (Lp.memLp v)
  change Integrable (fun z:X×X => ‖u z.1 * conj (v z.2)‖^2) _
  simpa only [norm_mul,Complex.norm_conj,mul_pow] using hi.mul_prod hj

def rect (u v : H μ) : K μ := (rect_mem μ u v).toLp _

omit [SFinite μ] in
theorem rect_ae (u v : H μ) : (rect μ u v : X×X→ℂ)=ᵐ[μ.prod μ] fun z => u z.1 * conj (v z.2) :=
  (rect_mem μ u v).coeFn_toLp

theorem norm_rect (u v : H μ) : ‖rect μ u v‖=‖u‖*‖v‖ := by
  have h : ‖rect μ u v‖^2=‖u‖^2*‖v‖^2 := by
    rw [←sq_integral,←sq_integral u,←sq_integral v]
    calc
      _ = ∫ z : X×X, ‖u z.1‖^2 * ‖v z.2‖^2 ∂μ.prod μ := by
        apply integral_congr_ae
        filter_upwards [rect_ae μ u v] with z hz
        rw [hz,norm_mul,Complex.norm_conj,mul_pow]
      _ = _ := integral_prod_mul (μ:=μ) (ν:=μ) (fun x => ‖u x‖^2) (fun x => ‖v x‖^2)
  exact (sq_eq_sq₀ (norm_nonneg _) (mul_nonneg (norm_nonneg _) (norm_nonneg _))).mp (h.trans (mul_pow ..).symm)

omit [SFinite μ] in
theorem rect_add_left (u v w : H μ) : rect μ (u+v) w = rect μ u w + rect μ v w := by
  apply Lp.ext
  filter_upwards [rect_ae μ (u+v) w,Lp.coeFn_add (rect μ u w) (rect μ v w),rect_ae μ u w,rect_ae μ v w,
    Measure.quasiMeasurePreserving_fst.ae_eq_comp (Lp.coeFn_add u v)] with z h₁ h₂ h₃ h₄ h₅
  simp only [h₁,h₂,Pi.add_apply,h₃,h₄,Function.comp_apply] at *
  rw [show (u+v) z.1 = u z.1 + v z.1 from h₅,add_mul]

omit [SFinite μ] in
theorem rect_smul_left (c : ℂ) (u v : H μ) : rect μ (c • u) v = c • rect μ u v := by
  apply Lp.ext
  filter_upwards [rect_ae μ (c • u) v,Lp.coeFn_smul c (rect μ u v),rect_ae μ u v,
    Measure.quasiMeasurePreserving_fst.ae_eq_comp (Lp.coeFn_smul c u)] with z h₁ h₂ h₃ h₄
  rw [h₁,h₂,Pi.smul_apply,h₃,show (c • u) z.1 = c*u z.1 from h₄,smul_eq_mul,mul_assoc]

omit [SFinite μ] in
theorem rect_add_right (u v w : H μ) : rect μ u (v+w) = rect μ u v + rect μ u w := by
  apply Lp.ext
  filter_upwards [rect_ae μ u (v+w),Lp.coeFn_add (rect μ u v) (rect μ u w),rect_ae μ u v,rect_ae μ u w,
    Measure.quasiMeasurePreserving_snd.ae_eq_comp (Lp.coeFn_add v w)] with z h₁ h₂ h₃ h₄ h₅
  simp only [h₁,h₂,Pi.add_apply,h₃,h₄,Function.comp_apply] at *
  rw [show (v+w) z.2 = v z.2 + w z.2 from h₅,map_add,mul_add]

omit [SFinite μ] in
theorem rect_smul_right (c : ℂ) (u v : H μ) : rect μ u (c • v) = conj c • rect μ u v := by
  apply Lp.ext
  filter_upwards [rect_ae μ u (c • v),Lp.coeFn_smul (conj c) (rect μ u v),rect_ae μ u v,
    Measure.quasiMeasurePreserving_snd.ae_eq_comp (Lp.coeFn_smul c v)] with z h₁ h₂ h₃ h₄
  rw [h₁,h₂,Pi.smul_apply,h₃,show (c • v) z.2 = c*v z.2 from h₄,smul_eq_mul,map_mul]; ring

/-- The scalar product matrix elements determine the integral operator. -/
def tested (k : K μ) (v : H μ) : H μ →L[ℂ] ℂ :=
  LinearMap.mkContinuous
    { toFun := fun u => inner ℂ k (rect μ u v)
      map_add' := fun x y => by rw [rect_add_left,inner_add_right]
      map_smul' := fun c x => by rw [rect_smul_left,inner_smul_right]; rfl }
    (‖k‖*‖v‖) (fun u => (norm_inner_le_norm k _).trans_eq (by rw [norm_rect]; ring))

private def image (k : K μ) (v : H μ) : H μ := (InnerProductSpace.toDual ℂ (H μ)).symm (tested μ k v)

theorem image_test (k : K μ) (v u : H μ) : inner ℂ (image μ k v) u = inner ℂ k (rect μ u v) := by
  change InnerProductSpace.toDual ℂ (H μ) ((InnerProductSpace.toDual ℂ (H μ)).symm (tested μ k v)) u = _
  rw [LinearIsometryEquiv.apply_symm_apply]; rfl

/-- The genuine bounded operator for every square-integrable kernel. -/
def op (k : K μ) : H μ →L[ℂ] H μ :=
  LinearMap.mkContinuous
    { toFun := image μ k
      map_add' := fun x y => by
        apply ext_inner_right ℂ; intro u
        rw [image_test,inner_add_left,image_test,image_test,rect_add_right,inner_add_right]
      map_smul' := fun c x => by
        apply ext_inner_right ℂ; intro u
        rw [image_test,rect_smul_right,inner_smul_right,inner_smul_left,image_test]; rfl }
    ‖k‖ (fun v => by
      change ‖(InnerProductSpace.toDual ℂ (H μ)).symm (tested μ k v)‖ ≤ _
      rw [LinearIsometryEquiv.norm_map]
      exact ContinuousLinearMap.opNorm_le_bound _ (mul_nonneg (norm_nonneg _) (norm_nonneg _)) (fun u =>
        (norm_inner_le_norm k (rect μ u v)).trans_eq (by rw [norm_rect]; ring)))

theorem op_test (k : K μ) (u v : H μ) : inner ℂ u (op μ k v) = inner ℂ (rect μ u v) k := by
  rw [←inner_conj_symm,←inner_conj_symm (x:=rect μ u v)]
  exact congrArg conj (image_test μ k v u)

theorem op_bounded (k : K μ) : ‖op μ k‖ ≤ ‖k‖ := by
  apply ContinuousLinearMap.opNorm_le_bound _ (norm_nonneg k); intro v
  change ‖(InnerProductSpace.toDual ℂ (H μ)).symm (tested μ k v)‖ ≤ _
  rw [LinearIsometryEquiv.norm_map]
  exact ContinuousLinearMap.opNorm_le_bound _ (mul_nonneg (norm_nonneg _) (norm_nonneg _)) (fun u =>
    (norm_inner_le_norm k (rect μ u v)).trans_eq (by rw [norm_rect]; ring))

/-- Convergence in L² of kernels bounds convergence in operator norm. -/
def operatorMap : K μ →L[ℂ] (H μ →L[ℂ] H μ) :=
  LinearMap.mkContinuous
    { toFun := op μ
      map_add' := fun k l => by
        apply ContinuousLinearMap.ext; intro v
        apply ext_inner_left ℂ; intro u
        change inner ℂ u (op μ (k+l) v) = inner ℂ u (op μ k v + op μ l v)
        rw [inner_add_right,op_test,op_test,op_test,inner_add_right]
      map_smul' := fun c k => by
        apply ContinuousLinearMap.ext; intro v
        apply ext_inner_left ℂ; intro u
        change inner ℂ u (op μ (c • k) v) = inner ℂ u (c • op μ k v)
        rw [inner_smul_right,op_test,op_test,inner_smul_right] }
    1 (fun k => by change ‖op μ k‖ ≤ 1*‖k‖; rw [one_mul]; exact op_bounded μ k)

end KDClosure.ChainLimit.Kernel
