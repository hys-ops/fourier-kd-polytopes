import KDChainLimitPosition
import KDLCARealitySingleSector

noncomputable section
namespace KDClosure.LCAQuotient
open MeasureTheory Filter Set CompactCore LCAReality
open scoped KDClosure.SubgroupMeasure
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
  [T2Space G] [LocallyCompactSpace G] [MeasurableSpace G] [BorelSpace G] [SecondCountableTopology G]
variable (μ : Measure G) [μ.IsAddHaarMeasure] (ν : Measure (Dual G)) [SFinite ν]

/-- In a single physical extreme state the entire range simultaneously has
one position coset modulo the union and one character on the intersection. -/
theorem extreme_one_sector [Nonempty (CO G)] (F : FourierRealization μ ν) (T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ)
    (e : T∈(ambientStates μ ν F).extremePoints ℝ) :
    ∃ (u : G) (ψ : Dual G), (∀ f : Lp ℂ 2 μ, ∀ᵐ x ∂μ, x-u∉ActualCore.U G → T f x=0) ∧
      (∀ l : G, (∀ H : CO G, l∈subgroup H) → ∀ f, LCAReality.shift μ l (T f)=phase ψ l • T f) := by
  let L : AddSubgroup G := ⨅ H : CO G, subgroup H
  let K := Classical.choice ‹Nonempty (CO G)›
  have closed : IsClosed (L : Set G) := by
    change IsClosed ((⨅ H : CO G, subgroup H : AddSubgroup G) : Set G)
    rw [AddSubgroup.coe_iInf]
    exact isClosed_iInter fun H => (subgroup H).isClosed_of_isOpen H.val.isOpen
  have compact : IsCompact (L : Set G) := K.property.of_isClosed_subset closed (show L ≤ subgroup K from iInf_le subgroup K)
  obtain ⟨k,act,herm,kd⟩ := e.1.2.2
  have info := (kernel_blocks_of_rows μ ν K F k herm (ambientKD_rows μ ν F k kd)).2
  have comm (l : L) : (LCAReality.shift μ (l:G)).comp T = T.comp (LCAReality.shift μ (l:G)) :=
    operator_translation_commutes μ k act l.val (info l (AddSubgroup.mem_iInf.mp l.property))
  obtain ⟨ψ,hψ⟩ := compact_translation_sector μ ν F L compact T e comm
  obtain ⟨u,hu⟩ := extreme_one_union_coset μ ν F T e
  exact ⟨u,ψ,hu,fun l hl => hψ ⟨l,AddSubgroup.mem_iInf.mpr hl⟩⟩
end KDClosure.LCAQuotient
