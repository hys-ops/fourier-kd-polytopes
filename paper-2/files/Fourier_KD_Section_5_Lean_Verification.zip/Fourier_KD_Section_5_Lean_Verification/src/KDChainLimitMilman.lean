import KDClosedRankOne
import Mathlib.Analysis.Convex.KreinMilman
import Mathlib.Analysis.Convex.Join

/-! Compact coordinate version of Milman's converse, used to pass from
finite pure convex mixtures to rank at most one at an extreme point. -/
namespace KDClosure.ChainLimit
open Set
variable {E : Type*} [AddCommGroup E] [Module ℝ E] [TopologicalSpace E]
  [T2Space E] [IsTopologicalAddGroup E] [ContinuousSMul ℝ E] [LocallyConvexSpace ℝ E]

omit [T2Space E] [LocallyConvexSpace ℝ E] in
private theorem compact_join {S T : Set E} (s : IsCompact S) (t : IsCompact T) :
    IsCompact (convexJoin ℝ S T) := by
  let f (p : ℝ × E × E) := (1-p.1) • p.2.1 + p.1 • p.2.2
  have im : f '' ((Icc (0:ℝ) 1) ×ˢ (S ×ˢ T)) = convexJoin ℝ S T := by
    ext z
    rw [mem_convexJoin]
    constructor
    · rintro ⟨⟨r,x,y⟩,⟨hr,hx,hy⟩,rfl⟩
      exact ⟨x,hx,y,hy,segment_eq_image ℝ x y ▸ ⟨r,hr,rfl⟩⟩
    · rintro ⟨x,hx,y,hy,h⟩
      rw [segment_eq_image] at h
      obtain ⟨r,hr,rfl⟩ := h
      exact ⟨⟨r,x,y⟩,⟨hr,hx,hy⟩,rfl⟩
  rw [← im]
  exact (isCompact_Icc.prod (s.prod t)).image (by dsimp [f]; fun_prop)

omit [T2Space E] [LocallyConvexSpace ℝ E] in
private theorem compact_union_hull {S T : Set E}
    (s : IsCompact (convexHull ℝ S)) (t : IsCompact (convexHull ℝ T)) :
    IsCompact (convexHull ℝ (S ∪ T)) := by
  rcases S.eq_empty_or_nonempty with rfl|hs
  · simpa using t
  rcases T.eq_empty_or_nonempty with rfl|ht
  · simpa using s
  rw [convexHull_union hs ht]
  exact compact_join s t

omit [T2Space E] [LocallyConvexSpace ℝ E] in
private theorem finite_hull {ι : Type*} (T : ι → Set E)
    (c : ∀ i, IsCompact (T i)) (v : ∀ i, Convex ℝ (T i)) (s : Finset ι) :
    IsCompact (convexHull ℝ (⋃ i ∈ s, T i)) := by
  classical
  induction s using Finset.induction_on with
  | empty => simp
  | insert a s ha ih =>
    rw [Finset.set_biUnion_insert]
    exact compact_union_hull ((v a).convexHull_eq.symm ▸ c a) ih

/-- An extreme point of a compact convex ambient set, approximable by
finite convex combinations of P, is already a limit of individual P's.
The conclusion is valid even when just this one point is approximable. -/
theorem individual_closure {K P : Set E} (compact : IsCompact K) (convex : Convex ℝ K)
    (sub : P ⊆ K) {x : E} (extreme : x ∈ K.extremePoints ℝ)
    (approx : x ∈ closure (convexHull ℝ P)) : x ∈ closure P := by
  classical
  by_contra outside
  have incl := closure_minimal sub compact.isClosed
  have cp : IsCompact (closure P) := compact.of_isClosed_subset isClosed_closure incl
  have sep (y : closure P) : ∃ (f : StrongDual ℝ E) (c : ℝ), f x < c ∧ c < f y := by
    have ne : x ≠ y.val := fun eq => outside (eq ▸ y.property)
    obtain ⟨f,hf⟩ := geometric_hahn_banach_point_point ne
    exact ⟨f,(f x+f y)/2,by linarith,by linarith⟩
  choose f c below above using sep
  let U (y : closure P) := {z : E | c y < f y z}
  let C (y : closure P) := K ∩ {z : E | c y ≤ f y z}
  have uo (y) : IsOpen (U y) := isOpen_lt continuous_const (f y).continuous
  have cv (y) : Convex ℝ (C y) := convex.inter (convex_halfSpace_ge (f y).toLinearMap.isLinear _)
  have cc (y) : IsCompact (C y) := compact.inter_right (isClosed_le continuous_const (f y).continuous)
  have cover : closure P ⊆ ⋃ y, U y := fun z hz => mem_iUnion.mpr ⟨⟨z,hz⟩,above _⟩
  obtain ⟨s,hs⟩ := cp.elim_finite_subcover U uo cover
  let S := ⋃ i ∈ s, C i
  have big : P ⊆ S := by
    intro z hz
    obtain ⟨y,hy,hu⟩ := mem_iUnion₂.mp (hs (subset_closure hz))
    exact mem_iUnion₂.mpr ⟨y,hy,sub hz,(show c y < f y z from hu).le⟩
  have small : S ⊆ K := by
    intro z hz
    obtain ⟨i,_,hi⟩ := mem_iUnion₂.mp hz
    exact hi.1
  have xx : x ∈ convexHull ℝ S :=
    closure_minimal (convexHull_mono big) (finite_hull C cc cv s).isClosed approx
  have ex' := inter_extremePoints_subset_extremePoints_of_subset
    (convexHull_min small convex) ⟨xx,extreme⟩
  obtain ⟨i,_,hi⟩ := mem_iUnion₂.mp (extremePoints_convexHull_subset ex' : x∈S)
  exact (not_lt_of_ge (hi.2)) (below i)

/-- A genuine operator at an extreme of the coordinate compactification
cannot have two independent range vectors when the approximants are
convex combinations of coordinate kernels of rank-one operators. -/
theorem operator_rank_le_one {D : Type*} [DecidableEq D]
    (K : Set (D × D → ℂ)) (compact : IsCompact K) (convex : Convex ℝ K)
    (P : Set (Discrete.L2 D →L[ℂ] Discrete.L2 D)) (sub : Discrete.entries '' P ⊆ K)
    (rank : ∀ T ∈ P, Module.rank ℂ (LinearMap.range T.toLinearMap) ≤ 1)
    {T : Discrete.L2 D →L[ℂ] Discrete.L2 D} (extreme : Discrete.entries T ∈ K.extremePoints ℝ)
    (approx : Discrete.entries T ∈ closure (convexHull ℝ (Discrete.entries '' P))) :
    Module.rank ℂ (LinearMap.range T.toLinearMap) ≤ 1 :=
  Discrete.rank_le_one_of_coordinate_closure P rank (individual_closure compact convex sub extreme approx)

end KDClosure.ChainLimit
