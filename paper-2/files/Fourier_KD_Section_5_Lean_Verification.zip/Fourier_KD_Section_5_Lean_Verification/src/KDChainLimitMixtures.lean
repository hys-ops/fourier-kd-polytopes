import KDChainLimitFinite
import KDChainLimitTraceFace
import KDCofinalCorners
import KDStateTransfer

noncomputable section
namespace KDClosure.ChainLimit
open Set Matrix Discrete DiscreteKDRow DiscreteTransfer Filter Classical
open scoped BigOperators ComplexOrder Topology

section Index
variable {I G : Type*} (e : I ↪ G)

/-- Zero padding as a real-linear map on finite coordinate kernels. -/
def pad : Matrix I I ℂ →ₗ[ℝ] (G×G → ℂ) where
  toFun A z := if hx : z.1 ∈ range e then
    if hy : z.2 ∈ range e then A hx.choose hy.choose else 0 else 0
  map_add' A B := by
    funext z; simp only [Pi.add_apply,Matrix.add_apply]; split_ifs <;> simp
  map_smul' c A := by
    funext z; simp only [Pi.smul_apply,Matrix.smul_apply]; split_ifs <;> simp

theorem pad_on (A : Matrix I I ℂ) (i j : I) : pad e A (e i,e j)=A i j := by
  change (if hx : e i ∈ range e then if hy : e j ∈ range e then A hx.choose hy.choose else 0 else 0)=_
  rw [dif_pos (mem_range_self i),dif_pos (mem_range_self j),
    e.injective (mem_range_self i).choose_spec,e.injective (mem_range_self j).choose_spec]

theorem pad_off_left (A : Matrix I I ℂ) (x y : G) (h : x ∉ range e) : pad e A (x,y)=0 := by
  change (if hx : x ∈ range e then if hy : y ∈ range e then A hx.choose hy.choose else 0 else 0)=_
  exact dif_neg h

theorem pad_off_right (A : Matrix I I ℂ) (x y : G) (h : y ∉ range e) : pad e A (x,y)=0 := by
  change (if hx : x ∈ range e then if hy : y ∈ range e then A hx.choose hy.choose else 0 else 0)=_
  split_ifs <;> simp_all

theorem padded_outer_minors (u : I → ℂ) : minorsVanish (pad e (KDPure.outer u)) := by
  let v (x : G) : ℂ := if h : x ∈ range e then u h.choose else 0
  have each (x y : G) : pad e (KDPure.outer u) (x,y)=star (v x)*v y := by
    change (if hx : x ∈ range e then if hy : y ∈ range e then star (u hx.choose)*u hy.choose else 0 else 0)=_
    dsimp only [v]; split_ifs <;> simp
  intro x y i j
  simp only [each]; ring

end Index

section Group
variable {G : Type*} [CommGroup G] [TopologicalSpace G] [DiscreteTopology G] [DecidableEq G]
variable {I : Type*} [AddCommGroup I] [Fintype I] [DecidableEq I]

/-- Every old finite pure matrix, padded into an arbitrary discrete ambient
abelian group, represents an actual normalized positive KD operator. -/
theorem pad_pure_state (e : Multiplicative I →* G) (he : Function.Injective e)
    (P : Matrix I I ℂ) (hp : P ∈ Finite.pureSet I) :
    ∃ T ∈ states G, entries T = pad (⟨fun i => e (.ofAdd i),he⟩ : I ↪ G) P := by
  let _ : TopologicalSpace (Multiplicative I) := ⊥
  let _ : DiscreteTopology (Multiplicative I) := ⟨rfl⟩
  obtain ⟨u,hu,tr,kd⟩ := hp
  have ps : P.PosSemidef := hu ▸ Matrix.posSemidef_vecMulVec_star_self u
  have diag : (∑' i : I, (P i i).re)=1 := by
    rw [tsum_fintype,←Complex.re_sum]; exact congrArg Complex.re tr
  obtain ⟨A,pos,coeff⟩ := realizePSD P ps ((hasSum_fintype _).summable) diag.le
  have htr : IsLUB (finiteFrameMass A) 1 := (trace_hasSum pos).mpr (by
    convert! ((hasSum_fintype (fun i : I => (P i i).re)).summable).hasSum using 1
    · funext i; exact congrArg Complex.re (coeff i i)
    · exact diag.symm)
  have hkd : RowNonneg (Multiplicative I) A := by
    let j := fun _ : ℕ => MonoidHom.id (Multiplicative I)
    apply (PhysicalCorner.exhaustion_iff (I:=fun _ => I) j (fun _ => Function.injective_id)
      (fun _ _ _ => Subset.rfl) (fun z => ⟨0,z,rfl⟩) A).mpr
    intro _ x γ
    have v := kd x γ
    rw [←KDAtoms.row_amp] at v
    change 0 ≤ ∑ d : I, entries A (x,x+d)*γ d
    simpa only [show ∀ x y:I, entries A (x,y)=P x y from coeff,KDPure.amp,KDAtoms.row] using v
  have st : A∈states (Multiplicative I) := ⟨pos,htr,hkd⟩
  let i : I ↪ G := ⟨fun t => e (.ofAdd t),he⟩
  refine ⟨DiscreteKDRow.push e he A,(push_mem_iff e he A).mpr st,?_⟩
  funext z
  obtain ⟨x,y⟩ := z
  by_cases xmem : x∈range i
  · obtain ⟨x,rfl⟩ := xmem
    by_cases ymem : y∈range i
    · obtain ⟨y,rfl⟩ := ymem
      exact ((DiscreteEmbedding.entries_on i A x y).trans (coeff _ _)).trans (pad_on i P x y).symm
    · exact (DiscreteEmbedding.entries_off_right i A _ _ ymem).trans (pad_off_right i P _ _ ymem).symm
  · exact (DiscreteEmbedding.entries_off_left i A _ _ xmem).trans (pad_off_left i P _ _ xmem).symm


def generators (G : Type*) [CommGroup G] [TopologicalSpace G] [DiscreteTopology G] [DecidableEq G] :
    Set (G×G → ℂ) := insert 0 {M | ∃ T ∈ states G, entries T = M ∧ minorsVanish M}

private theorem gram_factor {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℂ H]
    [CompleteSpace H] (T : H →L[ℂ] H) (pos : T.IsPositive) :
    ∃ S, T=star S*S := CStarAlgebra.nonneg_iff_eq_star_mul_self.mp
      ((ContinuousLinearMap.nonneg_iff_isPositive T).mpr pos)

omit [DecidableEq I] in
/-- Every subnormalized physical finite corner of a KD state belongs, upon
zero padding, to the real convex hull of zero and individual pure KD kernels. -/
theorem padded_corner_hull (e : Multiplicative I →* G) (he : Function.Injective e)
    (chain : ∀ H K : AddSubgroup I, H ≤ K ∨ K ≤ H)
    (T : L2 G →L[ℂ] L2 G) (st : T ∈ states G) :
    let i : I ↪ G := ⟨fun x => e (.ofAdd x),he⟩
    let B : Matrix I I ℂ := Matrix.of (fun x y => entries T (i x,i y))
    pad i B ∈ convexHull ℝ (generators G) := by
  classical
  let i : I ↪ G := ⟨fun x => e (.ofAdd x),he⟩
  let B : Matrix I I ℂ := Matrix.of fun x y => entries T (i x,i y)
  change pad i B ∈ _
  have ps : B.PosSemidef := by
    obtain ⟨S,hs⟩ := gram_factor T st.1
    let w (x : I) := S (lp.single 2 (i x) (1:ℂ))
    have eq : B=Matrix.gram ℂ w := by
      ext x y
      change inner ℂ _ (T _) = inner ℂ (S _) (S _)
      rw [hs]
      exact S.adjoint_inner_right _ _
    exact eq ▸ Matrix.posSemidef_gram ℂ w
  have msum := (trace_hasSum st.1).mp st.2.1
  have mass : B.trace.re ≤ 1 := by
    have nonneg (z : G) (_ : z∉Finset.univ.map i) : 0 ≤ (entries T (z,z)).re :=
      st.1.re_inner_nonneg_right _
    have b := msum.summable.sum_le_tsum (Finset.univ.map i) nonneg
    rw [msum.tsum_eq] at b
    simpa only [Matrix.trace,Matrix.diag,Complex.re_sum,B,Matrix.of_apply,Finset.sum_map,Function.comp_apply] using b
  have k (x : I) (γ : AddChar I ℂ) : 0 ≤ KDFourier.symbol B x γ := by
    rw [←KDAtoms.row_amp]
    have v := PhysicalCorner.finite_symbol_nonneg e T st.2.2 (i x) γ
    have mul (d : I) : i (x+d)=i x*e (.ofAdd d) := (e.map_mul _ _)
    simpa only [KDPure.amp,KDAtoms.row,B,Matrix.of_apply,mul] using v
  have hs := Finite.subnormalized_hull chain ps mass k
  have mapgen : pad i '' (insert (0 : Matrix I I ℂ) (Finite.pureSet I)) ⊆ generators G := by
    rintro _ ⟨P,rfl|p,rfl⟩
    · exact (pad i).map_zero ▸ mem_insert _ _
    · right
      obtain ⟨A,hA,eq⟩ := pad_pure_state e he P p
      obtain ⟨u,rfl,_,_⟩ := p
      exact ⟨A,hA,eq,padded_outer_minors i u⟩
  apply convexHull_mono mapgen
  rw [← (pad i).image_convexHull]
  exact mem_image_of_mem _ hs

end Group

/-- Coordinate convergence of the finite subnormalized pure mixtures. For
each pair of indices both entries are exactly correct from a finite stage on. -/
theorem approximate {G : Type*} [CommGroup G] [TopologicalSpace G] [DiscreteTopology G] [DecidableEq G]
    {I : ℕ → Type*} [∀ n, AddCommGroup (I n)] [∀ n, Fintype (I n)] [∀ n, DecidableEq (I n)]
    (e : ∀ n, Multiplicative (I n) →* G) (inj : ∀ n, Function.Injective (e n))
    (inc : Monotone (fun n => range (e n))) (exh : ∀ x, ∃ n, x∈range (e n))
    (chain : ∀ n (H K : AddSubgroup (I n)), H ≤ K ∨ K ≤ H)
    (T : Discrete.L2 G →L[ℂ] Discrete.L2 G) (st : T ∈ DiscreteTransfer.states G) :
    Discrete.entries T ∈ closure (convexHull ℝ (generators G)) := by
  let i (n : ℕ) : I n ↪ G := ⟨fun x => e n (.ofAdd x),inj n⟩
  let B (n : ℕ) := Matrix.of fun x y => entries T (i n x,i n y)
  have lim : Tendsto (fun n => pad (i n) (B n)) atTop (𝓝 (entries T)) := by
    apply tendsto_pi_nhds.mpr
    rintro ⟨x,y⟩
    obtain ⟨n,hn⟩ := exh x
    obtain ⟨m,hm⟩ := exh y
    apply tendsto_const_nhds.congr'
    filter_upwards [eventually_ge_atTop (max n m)] with k hk
    obtain ⟨a,rfl⟩ := inc ((le_max_left n m).trans hk) hn
    obtain ⟨b,rfl⟩ := inc ((le_max_right n m).trans hk) hm
    exact (pad_on (i k) (B k) a.toAdd b.toAdd).symm
  exact mem_closure_of_tendsto lim (Eventually.of_forall fun n =>
    padded_corner_hull (e n) (inj n) (chain n) T st)

end KDClosure.ChainLimit
