import KDLCAQuotientLocalize
import KDActualCore

noncomputable section
namespace KDClosure.LCAQuotient
open MeasureTheory Filter Set CompactCore LCAReality
open scoped KDClosure.SubgroupMeasure ComplexOrder ENNReal
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
  [T2Space G] [LocallyCompactSpace G] [MeasurableSpace G] [BorelSpace G] [SecondCountableTopology G]
variable (μ : Measure G) [μ.IsAddHaarMeasure] (ν : Measure (Dual G)) [SFinite ν]

/-- The output of a physical extreme state lives on one translate of the union
of the compact open subgroups, even when that union is noncompact. -/
theorem extreme_one_union_coset [Nonempty (CO G)] (F : FourierRealization μ ν) (T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ)
    (e : T∈(ambientStates μ ν F).extremePoints ℝ) :
    ∃ u : G, ∀ f : Lp ℂ 2 μ, ∀ᵐ x ∂μ, x-u∉ActualCore.U G → T f x=0 := by
  classical
  let U := ActualCore.U G
  let Q := G ⧸ U.toAddSubgroup
  let q := QuotientAddGroup.mk' U.toAddSubgroup
  let _ : DiscreteTopology Q := QuotientAddGroup.discreteTopology U.isOpen
  let _ : Countable Q := countable_of_Lindelof_of_discrete
  let S (i : Q) := q ⁻¹' {i}
  have ms (i : Q) : MeasurableSet (S i) :=
    ((isOpen_discrete ({i} : Set Q)).preimage (QuotientAddGroup.continuous_mk (N:=U.toAddSubgroup))).measurableSet
  have cut (i : Q) := position_dichotomy μ ν (Classical.choice ‹Nonempty (CO G)›) F T e (S i) (ms i) (fun x y h => by
    have eqn : q x=q y := (QuotientAddGroup.eq_iff_sub_mem.mpr (show y-x ∈ U.toAddSubgroup from h)).symm
    change q x=i ↔ q y=i
    rw [eqn])
  have chosen : ∃ i : Q, (mask μ (S i) (ms i)).comp T=T := by
    by_contra! contra
    have zero (i : Q) := (cut i).resolve_right (contra i)
    have op : T=0 := by
      ext f : 1
      apply Lp.ext
      have member (i : Q) : ∀ᵐ x ∂μ, x∈S i → T f x=0 := by
        have z : mask μ (S i) (ms i) (T f)=0 := DFunLike.congr_fun (zero i) f
        filter_upwards [mask_ae μ (S i) (ms i) (T f),Lp.coeFn_zero ℂ 2 μ] with x hx ho
        intro hi
        rw [z,ho,Set.indicator_of_mem hi] at hx
        exact hx.symm
      filter_upwards [ae_all_iff.mpr member,Lp.coeFn_zero ℂ 2 μ] with x hx ho
      exact (hx (q x) rfl).trans ho.symm
    have t0 : IsLUB (mass T) 0 := by
      rw [op]
      constructor
      · rintro _ ⟨_,_,_,rfl⟩; simp
      · intro v hv
        apply hv
        exact ⟨0,Fin.elim0,(orthonormal_subsingleton_iff.mpr (fun i : Fin 0 => i.elim0)),by simp⟩
    exact zero_ne_one (t0.unique e.1.2.1)
  obtain ⟨i,hi⟩ := chosen
  obtain ⟨u,rfl⟩ := QuotientAddGroup.mk'_surjective U.toAddSubgroup i
  refine ⟨u,fun f => ?_⟩
  have z : mask μ (S (q u)) (ms (q u)) (T f) = T f := DFunLike.congr_fun hi f
  filter_upwards [mask_ae μ (S (q u)) (ms (q u)) (T f)] with x hx
  intro outside
  have out : x∉S (q u) := fun eqn => outside (QuotientAddGroup.eq_iff_sub_mem.mp eqn)
  rwa [z,Set.indicator_of_notMem out] at hx

end KDClosure.LCAQuotient
