import KDChainLimitBudget
import KDChainLimitWeak
import KDLCAJointKD

noncomputable section
set_option linter.unusedSectionVars false
namespace KDClosure.ChainLimit.Kernel
open MeasureTheory Filter Set CompactFourier LCAQuotient LCAReality
open scoped ComplexOrder KDClosure.SubgroupMeasure Topology InnerProductSpace
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
  [MeasurableSpace G] [BorelSpace G] [SecondCountableTopology G]
  (μ : Measure G) [SigmaFinite μ] [μ.IsAddLeftInvariant]
  (ν : Measure (LCAReality.Dual G)) [SFinite ν]

def test {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E] {n : ℕ}
    (b : Fin n → E) (T : E →L[ℂ] E) : ℝ := ∑ i, (inner ℂ (b i) (T (b i))).re

theorem test_mix {n : ℕ}
    (b : Fin n → H μ) (a c : ℝ) (T U : H μ →L[ℂ] H μ) :
    test b (a • T+c • U) = a*test b T+c*test b U := by
  have sm (r : ℝ) (x : H μ) : r • x=(r:ℂ) • x := (algebraMap_smul ℂ r x).symm
  simp only [test,add_apply,smul_apply,sm,inner_add_right,
    inner_smul_right,Complex.add_re,Complex.re_ofReal_mul,Finset.sum_add_distrib,Finset.mul_sum]

def substate (F : FourierRealization μ ν) : Set (K μ) :=
  {k | (op μ k).IsPositive ∧ (∀ (n:ℕ) (b : Fin n → H μ), Orthonormal ℂ b → test b (op μ k) ≤ 1) ∧
    ambientKD μ ν F k}

private theorem mix_op (a c : ℝ) (k l : K μ) : op μ (a • k + c • l)=a • op μ k + c • op μ l := by
  exact ((operatorMap μ).restrictScalars ℝ).map_add _ _ |>.trans (by rw [map_smul,map_smul]; rfl)

theorem substate_convex (F : FourierRealization μ ν) : Convex ℝ (substate μ ν F) := by
  rintro k ⟨pk,bk,hk⟩ l ⟨pl,bl,hl⟩ a c ha hc sum
  refine ⟨?_,?_,Joint.kd_convex μ ν F hk hl ha hc sum⟩
  · rw [mix_op,←algebraMap_smul ℂ a,←algebraMap_smul ℂ c]
    exact (pk.smul_of_nonneg (Complex.zero_le_real.mpr ha)).add (pl.smul_of_nonneg (Complex.zero_le_real.mpr hc))
  · intro n b orth; rw [mix_op,test_mix μ b a c (op μ k) (op μ l)]
    nlinarith [mul_le_mul_of_nonneg_left (bk n b orth) ha,mul_le_mul_of_nonneg_left (bl n b orth) hc]

private theorem substate_closed (F : FourierRealization μ ν) : IsClosed (substate μ ν F) := by
  have pos : IsClosed {k:K μ | (op μ k).IsPositive} := by
    simp only [ContinuousLinearMap.isPositive_iff_complex,ofPred_forall]
    apply isClosed_iInter; intro x
    change IsClosed ({k : K μ | ((inner ℂ (operatorMap μ k x) x).re : ℂ) =
      inner ℂ (operatorMap μ k x) x} ∩ {k : K μ | 0 ≤ (inner ℂ (operatorMap μ k x) x).re})
    apply IsClosed.inter
    · apply isClosed_eq <;> fun_prop
    · apply isClosed_le continuous_const; fun_prop
  have bound : IsClosed {k:K μ | ∀ (n:ℕ) (b : Fin n → H μ), Orthonormal ℂ b → test b (op μ k) ≤ 1} := by
    simp only [ofPred_forall]; apply isClosed_iInter; intro n; apply isClosed_iInter; intro b
    apply isClosed_iInter; intro _
    apply isClosed_le _ continuous_const
    change Continuous (fun k:K μ => ∑ i, (inner ℂ (b i) (operatorMap μ k (b i))).re)
    fun_prop
  exact pos.inter (bound.inter (Joint.kd_closed μ ν F))

private theorem draw_budget (F : FourierRealization μ ν) {k : K μ} (h : k ∈ substate μ ν F) :
    ∀ r ∈ CompactFourier.frameMass (op μ k), r≤1 := by
  rintro _ ⟨n,b,on,rfl⟩; exact h.2.1 n b on

theorem substate_compact (F : FourierRealization μ ν) : IsCompact (toWeakSpace ℝ (K μ) '' substate μ ν F) := by
  apply weak_compact_convex _ (substate_convex μ ν F) (substate_closed μ ν F)
  apply (Metric.isBounded_closedBall (x:=0) (r:=1)).subset
  intro k hk
  exact mem_closedBall_zero_iff.mpr (norm_le_frame_budget μ hk.1 (draw_budget μ ν F hk))

theorem zero_substate (F : FourierRealization μ ν) : (0:K μ)∈substate μ ν F := by
  have z : op μ 0 = 0 := (operatorMap μ).map_zero
  refine ⟨by rw [z]; exact ContinuousLinearMap.isPositive_zero,?_,?_⟩
  · intro n b _; simp [test,z]
  · apply (Joint.kd_iff_sign μ ν F _).mpr
    rw [map_zero]
    filter_upwards [Lp.coeFn_zero ℂ 2 (μ.prod ν)] with x h
    rw [h]; exact le_rfl

theorem ambient_iff {F : FourierRealization μ ν} (k : K μ) :
    op μ k ∈ ambientStates μ ν F ↔ k ∈ substate μ ν F ∧ IsLUB (LCAQuotientTrace.frameMass (op μ k)) 1 := by
  constructor
  · rintro ⟨p,tr,k',act,_,kd⟩
    have eqn : k'=k := kernel_unique μ (op μ k) act (op_acts μ k)
    exact ⟨⟨p,fun n b orth => tr.1 ⟨n,b,orth,rfl⟩,eqn ▸ kd⟩,tr⟩
  · rintro ⟨h,tr⟩
    exact ⟨h.1,tr,k,op_acts μ k,hermitian_of_acts μ _ h.1 ⟨1,tr.1⟩ (op_acts μ k),h.2.2⟩

/-- Finite orthonormal frame tests suffice to make trace-one a face even
if the normalized states have unbounded operator rank. -/
theorem full_extreme {F : FourierRealization μ ν} {k : K μ}
    (ex : op μ k ∈ (ambientStates μ ν F).extremePoints ℝ) :
    k ∈ (substate μ ν F).extremePoints ℝ := by
  obtain ⟨member,full⟩ := (ambient_iff μ ν k).mp ex.1
  refine ⟨member,?_⟩
  intro l hl m hm seg
  obtain ⟨a,b,ha,hb,hs,blend⟩ := seg
  have eqn := congrArg (op μ) blend
  rw [mix_op] at eqn
  have endmass (p q : K μ) (hp : p∈substate μ ν F) (hq : q∈substate μ ν F)
      (s t : ℝ) (ps : 0<s) (pt : 0<t) (st : s+t=1)
      (mix : s • op μ p+t • op μ q = op μ k) : IsLUB (LCAQuotientTrace.frameMass (op μ p)) 1 := by
    refine ⟨draw_budget μ ν F hp,?_⟩
    intro v upper
    have bound : 1 ≤ s*v+t*1 := full.2 (by
      rintro _ ⟨n,y,on,rfl⟩
      change test y (op μ k) ≤ _
      rw [←mix,test_mix μ y s t (op μ p) (op μ q)]
      exact add_le_add (mul_le_mul_of_nonneg_left (upper ⟨n,y,on,rfl⟩) ps.le)
        (mul_le_mul_of_nonneg_left (hq.2.1 n y on) pt.le))
    nlinarith
  have left := endmass l m hl hm a b ha hb hs eqn
  have right := endmass m l hm hl b a hb ha ((add_comm _ _).trans hs) ((add_comm _ _).trans eqn)
  apply op_injective μ
  exact ex.2 ((ambient_iff μ ν l).mpr ⟨hl,left⟩) ((ambient_iff μ ν m).mpr ⟨hm,right⟩) ⟨a,b,ha,hb,hs,eqn⟩

end KDClosure.ChainLimit.Kernel
