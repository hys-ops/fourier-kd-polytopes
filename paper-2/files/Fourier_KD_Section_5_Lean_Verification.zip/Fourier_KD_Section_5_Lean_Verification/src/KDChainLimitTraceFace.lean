import KDDiscreteTransfer
import KDChainLimitMilman

/-! In a compact coordinate substate space, no probability mass can disappear
in either endpoint of a decomposition of a trace-one operator. -/
noncomputable section
namespace KDClosure.ChainLimit
open Set Discrete DiscreteKDRow DiscreteTransfer
variable {G : Type*} [CommGroup G] [TopologicalSpace G] [DiscreteTopology G] [DecidableEq G]

omit [CommGroup G] [TopologicalSpace G] [DiscreteTopology G] in
theorem trace_hasSum {T : L2 G →L[ℂ] L2 G} (p : T.IsPositive) {r : ℝ} :
    IsLUB (finiteFrameMass T) r ↔ HasSum (fun i => (entries T (i,i)).re) r := by
  constructor
  · intro h
    have s := (boundedFrames_iff_diagonal p).mp ⟨_,h.1⟩
    exact (trace_isLUB p s).unique h ▸ s.hasSum
  · intro h; exact h.tsum_eq ▸ trace_isLUB p h.summable

/-- For an arbitrary set of coordinate kernels representing positive
KD substates, normalized extremality implies coordinate extremality.
The premise is a representation of the individual kernels, not a
hypothesis about their extremes or the extremality of the trace-one face. -/
theorem full_trace_extreme {K : Set (G×G → ℂ)}
    (realized : ∀ B∈K, ∃ U : L2 G →L[ℂ] L2 G, entries U=B ∧ U.IsPositive ∧
      RowNonneg G U ∧ ∃ m : ℝ, m ≤ 1 ∧ HasSum (fun i => (entries U (i,i)).re) m)
    {T : L2 G →L[ℂ] L2 G} (extreme : T ∈ (states G).extremePoints ℝ)
    (inside : entries T ∈ K) : entries T ∈ K.extremePoints ℝ := by
  refine ⟨inside,?_⟩
  intro B hB C hC seg
  obtain ⟨a,b,ha,hb,hab,blend⟩ := seg
  obtain ⟨U,rfl,pu,ku,m,hm,sm⟩ := realized B hB
  obtain ⟨V,rfl,pv,kv,n,hn,sn⟩ := realized C hC
  have op : a • U + b • V = T := by
    apply entries_injective
    simpa only [map_add,map_smul] using blend
  have full := (trace_hasSum extreme.1.1).mp extreme.1.2.1
  have sums := (sm.mul_left a).add (sn.mul_left b)
  have diag : (fun i => a * (entries U (i,i)).re + b * (entries V (i,i)).re) =
      (fun i => (entries T (i,i)).re) := by
    funext i
    have v := congrFun blend (i,i)
    change a • entries U (i,i) + b • entries V (i,i) = entries T (i,i) at v
    rw [←v]
    simp [Complex.real_smul]
  rw [diag] at sums
  have val := sums.unique full
  have eqm : m=1 := by
    apply le_antisymm hm
    by_contra! h
    nlinarith [mul_pos ha (sub_pos.mpr h),mul_nonneg hb.le (sub_nonneg.mpr hn)]
  have eqn : n=1 := by
    apply le_antisymm hn
    by_contra! h
    nlinarith [mul_pos hb (sub_pos.mpr h),mul_nonneg ha.le (sub_nonneg.mpr hm)]
  have hU : U ∈ states G := ⟨pu,(trace_hasSum pu).mpr (eqm ▸ sm),ku⟩
  have hV : V ∈ states G := ⟨pv,(trace_hasSum pv).mpr (eqn ▸ sn),kv⟩
  exact congrArg (entries (D:=G)) (extreme.2 hU hV ⟨a,b,ha,hb,hab,op⟩)

end KDClosure.ChainLimit
