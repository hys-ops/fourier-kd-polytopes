import KDChainLimitMilman
import Mathlib.Analysis.InnerProductSpace.Dual
import Mathlib.Analysis.Normed.Module.DoubleDual
import Mathlib.Analysis.LocallyConvex.WeakSpace

noncomputable section
namespace KDClosure.ChainLimit
open Set Metric NormedSpace InnerProductSpace
open scoped Topology
variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E] [CompleteSpace E]

/-- Real Hilbert-space reflexivity, in the exact weak topology used for
kernel compactness. -/
theorem weak_double_surj : Function.Surjective (inclusionInDoubleDualWeak ℝ E) := by
  intro φ
  let d := toDual ℝ E
  let u := φ.comp d.toContinuousLinearEquiv.toContinuousLinearMap
  let x := d.symm u
  refine ⟨toWeakSpace ℝ E x,?_⟩
  apply ContinuousLinearMap.ext; intro ψ
  obtain ⟨v,rfl⟩ := d.surjective ψ
  change inner ℝ v x=φ (d v)
  rw [real_inner_comm]
  change d (d.symm u) v=φ (d v)
  rw [LinearIsometryEquiv.apply_symm_apply]; rfl

/-- Every norm-closed bounded real convex set of Hilbert kernels is compact
in the weak topology. Norm and weak closures of its convex subsets agree. -/
theorem weak_compact_convex {S : Set E} (b : Bornology.IsBounded S) (c : Convex ℝ S) (hc : IsClosed S) :
    IsCompact (toWeakSpace ℝ E '' S) := by
  have bounded : Bornology.IsBounded (toWeakSpace ℝ E ⁻¹' (toWeakSpace ℝ E '' S)) := by
    simpa only [Set.preimage_image_eq _ (toWeakSpace ℝ E).injective] using b
  have cl := isCompact_closure_of_isBounded (𝕜:=ℝ) (X:=E) (toWeakSpace ℝ E '' S) bounded (by
    rw [Set.range_eq_univ.mpr weak_double_surj]; exact subset_univ _)
  rwa [←c.toWeakSpace_closure ℝ,hc.closure_eq] at cl

end KDClosure.ChainLimit
