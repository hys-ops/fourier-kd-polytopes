import KDLCARealitySymbol
import KDCompactCosetAE

noncomputable section
namespace KDClosure.ChainLimit
open MeasureTheory Filter Set CompactCore CompactCoset LCAReality Classical
open scoped ComplexOrder ComplexConjugate ENNReal
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
  [MeasurableSpace G] [BorelSpace G] [MeasurableAdd G] [T2Space G]
  (μ : Measure G) [μ.IsAddHaarMeasure]
  [MeasurableSpace (LCAReality.Dual G)] (ν : Measure (LCAReality.Dual G))

def windowFn (K : CO G) (η : LCAReality.Dual G) (d : G) : ℂ :=
  (K.val : Set G).indicator (fun t => complexChar η⁻¹ t) d

omit [IsTopologicalAddGroup G] [T2Space G] [MeasurableAdd G] [MeasurableSpace (LCAReality.Dual G)] in
theorem window_mem (K : CO G) (η : LCAReality.Dual G) (p : ℝ≥0∞) : MemLp (windowFn K η) p μ := by
  let _ : IsFiniteMeasure (μ.restrict (K.val:Set G)) := isFiniteMeasure_restrict.mpr K.property.measure_ne_top
  apply (memLp_indicator_iff_restrict K.val.isOpen.measurableSet).mpr
  apply MemLp.of_bound _ 1 (Filter.Eventually.of_forall fun x => (Circle.norm_coe _).le)
  have c : Continuous (complexChar η⁻¹ : G → ℂ) := continuous_subtype_val.comp η⁻¹.continuous
  exact c.aestronglyMeasurable

def window (K : CO G) (η : LCAReality.Dual G) : Lp ℂ 2 μ :=
  (window_mem μ K η 2).toLp (windowFn K η)

private theorem integral_nonneg_complex {X : Type*} [MeasurableSpace X] (m : Measure X) (f : X → ℂ)
    (h : ∀ᵐ z ∂m, 0 ≤ f z) : 0 ≤ ∫ z, f z ∂m := by
  have eqn : (∫ z, f z ∂m) = ∫ z, ((f z).re:ℂ) ∂m := by
    apply integral_congr_ae
    filter_upwards [h] with z hz
    exact Complex.eq_re_of_ofReal_le hz
  rw [eqn,integral_complex_ofReal,Complex.zero_le_real]
  exact integral_nonneg_of_ae (h.mono fun z hz => (Complex.nonneg_iff.mp hz).1)

omit [T2Space G] [IsTopologicalAddGroup G] in
theorem fourier_window (F : FourierRealization μ ν) (K : CO G) (η : LCAReality.Dual G) :
    ∀ᵐ χ ∂ν, F.isometry (window μ K η) χ =
      if annihilates K (complexChar (η⁻¹*χ)) then (μ.real (K.val : Set G) : ℂ) else 0 := by
  classical
  let w := window μ K η
  have ae : (w : G→ℂ) =ᵐ[μ] windowFn K η := (window_mem μ K η 2).coeFn_toLp
  have int : Integrable (w:G→ℂ) μ := ((memLp_one_iff_integrable.mp (window_mem μ K η 1))).congr ae.symm
  filter_upwards [F.integral_ae w int] with χ hc
  rw [hc,←subgroup_orthogonality μ K (complexChar (η⁻¹*χ)),←integral_indicator K.val.isOpen.measurableSet]
  apply integral_congr_ae
  filter_upwards [ae] with t ht
  rw [ht]; by_cases h : t∈(K.val : Set G)
  · simp only [windowFn,indicator_of_mem h]; rfl
  · simp only [windowFn,indicator_of_notMem h,zero_mul]

omit [T2Space G] [IsTopologicalAddGroup G] in
/-- A genuine positive Fourier row remains positive when restricted to
a compact-open displacement window and tested against *any* character.
This applies to a general L² row, without an L¹ row assumption. -/
theorem window_nonneg (F : FourierRealization μ ν) (K : CO G) (η : LCAReality.Dual G)
    (f : Lp ℂ 2 μ) (positive : ∀ᵐ χ ∂ν, 0 ≤ F.isometry f χ) :
    0 ≤ ∫ d in (K.val : Set G), f d * LCAReality.phase η d ∂μ := by
  classical
  let w := window μ K η
  have ae : (w : G→ℂ) =ᵐ[μ] windowFn K η := (window_mem μ K η 2).coeFn_toLp
  have pairing : inner ℂ w f = ∫ d in (K.val:Set G), f d * LCAReality.phase η d ∂μ := by
    rw [MeasureTheory.L2.inner_def,←integral_indicator K.val.isOpen.measurableSet]
    apply integral_congr_ae
    filter_upwards [ae] with t ht
    rw [RCLike.inner_apply,ht]
    by_cases h : t∈(K.val : Set G)
    · simp only [windowFn,indicator_of_mem h]
      change f t*conj (((η (Multiplicative.ofAdd t))⁻¹:Circle):ℂ)=_
      rw [Circle.coe_inv_eq_conj,starRingEnd_self_apply]; rfl
    · simp only [windowFn,indicator_of_notMem h,map_zero,mul_zero]
  rw [←pairing,←F.isometry.inner_map_map,MeasureTheory.L2.inner_def]
  apply integral_nonneg_complex
  filter_upwards [fourier_window μ ν F K η,positive] with χ hw hf
  rw [RCLike.inner_apply,hw]; split_ifs
  · rw [Complex.conj_ofReal]; exact mul_nonneg hf (Complex.zero_le_real.mpr (measureReal_nonneg))
  · simp


omit [T2Space G] in
/-- The same compact window test after averaging over a physical position
cell, starting from the joint a.e. KD condition on the represented kernel. -/
theorem kernel_window_nonneg [SecondCountableTopology G] [SFinite μ] (F : FourierRealization μ ν)
    (k : Lp ℂ 2 (μ.prod μ)) (kd : ∀ᵐ x ∂μ, ∀ᵐ χ ∂ν,
      0 ≤ F.isometry (rowAt μ k x) χ) (U : Set G) (K : CO G) (η : LCAReality.Dual G) :
    0 ≤ ∫ x in U, ∫ d in (K.val : Set G), k (x,x+d) * LCAReality.phase η d ∂μ ∂μ := by
  apply integral_nonneg_complex
  apply ae_restrict_of_ae
  filter_upwards [rowAt_ae μ k,kd] with x hx hq
  have h := window_nonneg μ ν F K η (rowAt μ k x) hq
  convert! h using 1
  apply integral_congr_ae
  filter_upwards [ae_restrict_of_ae hx] with d hd
  rw [hd]

end KDClosure.ChainLimit
