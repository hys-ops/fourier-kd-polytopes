import KDAllAmbientPure
import KDGeneralAbelianChain
import KDChainLimitEndpoint

/-! Krein–Milman on actual Haar-kernel substates.  A nonzero extreme
substate cannot have trace less than one: it could be expanded along
its own ray. The zero vertex disappears on the trace-one slice, even
when trace itself is not weakly continuous. -/
noncomputable section
set_option linter.unusedSectionVars false
namespace KDClosure.Hull
open MeasureTheory Filter Set CompactCore LCAReality LCAQuotient ChainLimit ChainLimit.Kernel
open scoped ComplexOrder KDClosure.SubgroupMeasure Topology InnerProductSpace
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
  [T2Space G] [LocallyCompactSpace G] [SecondCountableTopology G] [MeasurableSpace G] [BorelSpace G]
variable (μ : Measure G) [μ.IsAddHaarMeasure] (ν : Measure (LCAReality.Dual G)) [SFinite ν] [ν.IsHaarMeasure]
variable (F : FourierRealization μ ν)

private theorem kernel_test_scale {n : ℕ} (e : Fin n → H μ) (s : ℝ) (T : H μ →L[ℂ] H μ) :
    test e (s • T) = s * test e T := by
  simpa using test_mix μ e s 0 T T

private theorem kernel_op_scale (s : ℝ) (k : K μ) : op μ (s • k) = s • op μ k :=
  ((operatorMap μ).restrictScalars ℝ).map_smul s k

private theorem scaled_sub {k : K μ} (hk : k ∈ substate μ ν F) {m : ℝ} (pos : 0 < m)
    (h : m ∈ upperBounds (LCAQuotientTrace.frameMass (op μ k))) :
    m⁻¹ • k ∈ substate μ ν F := by
  refine ⟨?_,?_,?_⟩
  · rw [kernel_op_scale,←algebraMap_smul ℂ m⁻¹]
    exact hk.1.smul_of_nonneg (Complex.zero_le_real.mpr (inv_nonneg.mpr pos.le))
  · intro n b orth
    rw [kernel_op_scale,kernel_test_scale,←div_eq_inv_mul]
    exact (div_le_one pos).mpr (h ⟨n,b,orth,rfl⟩)
  · apply (Joint.kd_iff_sign μ ν F _).mpr
    let P := (Joint.KDTransform μ ν F).restrictScalars ℝ
    change ∀ᵐ z ∂μ.prod ν, 0 ≤ P (m⁻¹ • k) z
    rw [map_smul]
    filter_upwards [(Joint.kd_iff_sign μ ν F _).mp hk.2.2,Lp.coeFn_smul m⁻¹ (P k)] with z hz hs
    rw [hs]
    exact mul_nonneg (Complex.zero_le_real.mpr (inv_nonneg.mpr pos.le)) hz

private theorem state_coords {T : H μ →L[ℂ] H μ} (h : T ∈ ambientStates μ ν F) :
    coord μ T ∈ cmap μ '' substate μ ν F := by
  obtain ⟨k,act,_,_⟩ := h.2.2
  obtain rfl := (op_eq_of_acts μ act).symm
  exact ⟨k,((ambient_iff μ ν k).mp h).1,rfl⟩

/-- Every nonzero extreme coordinate of the compactification belongs
to an actual trace-one extreme physical state. -/
theorem nonzero_extreme_coordinate {z : H μ × H μ → ℂ}
    (ex : z ∈ (cmap μ '' substate μ ν F).extremePoints ℝ) (nz : z ≠ 0) :
    ∃ T ∈ (ambientStates μ ν F).extremePoints ℝ, coord μ T = z := by
  obtain ⟨k,hk,rfl⟩ := ex.1
  have full : IsLUB (LCAQuotientTrace.frameMass (op μ k)) 1 := by
    refine ⟨?_,?_⟩
    · rintro _ ⟨n,b,orth,rfl⟩; exact hk.2.1 n b orth
    · intro u upper
      by_contra! hu
      let m : ℝ := (max u 0 + 1)/2
      have hm : 0 < m := by dsimp [m]; linarith [le_max_right u 0]
      have mu : u ≤ m := by dsimp [m]; linarith [le_max_left u 0]
      have small : m < 1 := by dsimp [m]; linarith [max_lt hu zero_lt_one]
      have big := scaled_sub μ ν F hk hm (fun _ hx => (upper hx).trans mu)
      apply nz
      symm
      exact ex.2 (show (0 : H μ × H μ → ℂ) ∈ _ from
        ⟨0,zero_substate μ ν F,map_zero _⟩) (mem_image_of_mem (cmap μ) big)
        ⟨1-m,m,by linarith,hm,by ring,by simp [map_smul,smul_smul,hm.ne']⟩
  have st := (ambient_iff μ ν k).mpr ⟨hk,full⟩
  refine ⟨op μ k,⟨st,?_⟩,rfl⟩
  intro S hS T hT blend
  obtain ⟨a,b,ha,hb,sum,eqn⟩ := blend
  apply coord_inj μ
  apply ex.2 (state_coords μ ν F hS) (state_coords μ ν F hT)
  refine ⟨a,b,ha,hb,sum,?_⟩
  change a • coord μ S + b • coord μ T = coord μ (op μ k)
  rw [←map_smul,←map_smul,←map_add,eqn]

theorem chain_compact_substate_hull (chain : ∀ A B : CO G, A≤B ∨ B≤A) :
    cmap μ '' substate μ ν F =
      closure (convexHull ℝ (insert 0 (coord μ '' ambientPure μ ν F))) := by
  let C := cmap μ '' substate μ ν F
  have comp : IsCompact C := compact_coords μ ν F
  have conv : Convex ℝ C := (substate_convex μ ν F).linear_image (cmap μ)
  apply Set.Subset.antisymm
  · change C ⊆ _
    rw [←closure_convexHull_extremePoints comp conv]
    apply closure_mono; apply convexHull_mono
    intro z hz
    by_cases zero : z=0
    · exact Or.inl zero
    · obtain ⟨T,ex,rfl⟩ := nonzero_extreme_coordinate μ ν F hz zero
      exact Or.inr ⟨T,⟨ex.1,GeneralAbelian.ambient_chain_rank_eq_one μ ν F chain T ex⟩,rfl⟩
  · apply closure_minimal _ comp.isClosed
    apply convexHull_min _ conv
    rintro z (rfl|⟨T,h,rfl⟩)
    · exact ⟨0,zero_substate μ ν F,map_zero _⟩
    · exact state_coords μ ν F h.1

private theorem compact_join_zero {E : Type*} [AddCommGroup E] [Module ℝ E]
    [TopologicalSpace E] [IsTopologicalAddGroup E] [ContinuousSMul ℝ E]
    {S : Set E} (hc : IsCompact S) : IsCompact (convexJoin ℝ {0} S) := by
  let f (p : ℝ × E) := p.1 • p.2
  have im : f '' (Icc (0:ℝ) 1 ×ˢ S) = convexJoin ℝ {0} S := by
    ext z
    rw [mem_convexJoin]
    constructor
    · rintro ⟨⟨s,x⟩,⟨hs,hx⟩,rfl⟩
      exact ⟨0,rfl,x,hx,1-s,s,by linarith [hs.2],hs.1,by ring,by simp [f]⟩
    · rintro ⟨_,rfl,x,hx,a,b,ha,hb,sum,rfl⟩
      exact ⟨⟨b,x⟩,⟨⟨hb,by linarith⟩,hx⟩,by simp [f]⟩
  rw [←im]
  exact (isCompact_Icc.prod hc).image (by dsimp [f]; fun_prop)

/-- **Coordinate-closure sufficiency with NO zero among approximating
states**. The finite mixtures being approximated all have trace one. -/
theorem chain_state_wot_hull (chain : ∀ A B : CO G, A≤B ∨ B≤A)
    {T : H μ →L[ℂ] H μ} (hT : T ∈ ambientStates μ ν F) :
    coord μ T ∈ closure (convexHull ℝ (coord μ '' ambientPure μ ν F)) := by
  let P := coord μ '' ambientPure μ ν F
  let S := closure (convexHull ℝ P)
  let C := cmap μ '' substate μ ν F
  have comp : IsCompact C := compact_coords μ ν F
  have conv : Convex ℝ C := (substate_convex μ ν F).linear_image (cmap μ)
  have sub : S ⊆ C := by
    apply closure_minimal _ comp.isClosed; apply convexHull_min _ conv
    rintro _ ⟨U,h,rfl⟩; exact state_coords μ ν F h.1
  have h : coord μ T ∈ closure (convexHull ℝ (insert 0 P)) :=
    chain_compact_substate_hull μ ν F chain ▸ state_coords μ ν F hT
  rcases P.eq_empty_or_nonempty with hp|hp
  · rw [hp] at h
    have zero : T=0 := coord_inj μ (by simpa using h)
    rw [zero] at hT
    have bd : (0:ℝ) ∈ upperBounds (LCAQuotientTrace.frameMass (0 : H μ →L[ℂ] H μ)) := by
      rintro _ ⟨n,v,_,rfl⟩; simp
    exact False.elim (not_le_of_gt zero_lt_one (hT.2.1.2 bd))
  have cs : IsCompact S := comp.of_isClosed_subset isClosed_closure sub
  have hj : coord μ T ∈ convexJoin ℝ {0} S := by
    apply closure_minimal _ (compact_join_zero cs).isClosed h
    rw [convexHull_insert hp]
    exact convexJoin_mono_right subset_closure
  obtain ⟨_,rfl,z,hz,a,b,ha,hb,sum,mix⟩ := mem_convexJoin.mp hj
  obtain ⟨k,hk,rfl⟩ := sub hz
  have eqn : b • op μ k = T := by
    apply coord_inj μ
    rw [map_smul]
    change b • cmap μ k = _
    simpa only [smul_zero,zero_add] using mix
  have one : 1 ≤ b := hT.2.1.2 (by
    rintro _ ⟨n,e,orth,rfl⟩
    change test e T ≤ b
    rw [←eqn,kernel_test_scale]
    simpa using mul_le_mul_of_nonneg_left (hk.2.1 n e orth) hb)
  have eq : b=1 := by linarith
  rw [eq,one_smul] at eqn
  rw [←eqn]
  exact hz

end KDClosure.Hull
#print axioms KDClosure.Hull.chain_state_wot_hull
