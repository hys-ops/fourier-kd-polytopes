import Mathlib.Analysis.Convex.KreinMilman
namespace KDClosure
open Set
variable {E ι : Type*} [AddCommGroup E] [Module ℝ E] [TopologicalSpace E] [T2Space E]
  [IsTopologicalAddGroup E] [ContinuousSMul ℝ E] [LocallyConvexSpace ℝ E] [Nonempty ι]

/-- A common zero set of nonnegative continuous linear tests contains a nonzero
ambient extreme if one element has a strictly positive continuous readout. -/
theorem extremeWithZeros (K : Set E) (compact : IsCompact K)
    (tests : ι → E →L[ℝ] ℝ) (nonneg : ∀ i, ∀ x ∈ K, 0 ≤ tests i x)
    (readout : E →L[ℝ] ℝ) {a : E} (ha : a ∈ K) (hits : ∀ i, tests i a = 0)
    (visible : 0 < readout a) :
    ∃ t ∈ K.extremePoints ℝ, 0 < readout t ∧ ∀ i, tests i t = 0 := by
  let F (i : ι) := {x ∈ K | tests i x = 0}
  have exp (i : ι) : IsExposed ℝ K (F i) := by
    intro _
    refine ⟨-tests i, ?_⟩
    ext x
    change (x ∈ K ∧ tests i x = 0) ↔ x ∈ K ∧ ∀ y ∈ K, (-tests i) y ≤ (-tests i) x
    simp only [neg_apply,neg_le_neg_iff]
    constructor
    · rintro ⟨hx,h⟩; exact ⟨hx,fun y hy => h ▸ nonneg i y hy⟩
    · rintro ⟨hx,h⟩; exact ⟨hx,le_antisymm ((hits i) ▸ h a ha) (nonneg i x hx)⟩
  let S := ⋂ i, F i
  have face : IsExtreme ℝ K S := isExtreme_iInter fun i => (exp i).isExtreme
  have cs : IsCompact S := compact.of_isClosed_subset
    (isClosed_iInter fun i => (exp i).isClosed compact.isClosed) face.1
  have has : a ∈ S := mem_iInter.mpr fun i => ⟨ha,hits i⟩
  obtain ⟨z,hz,hm⟩ := cs.exists_isMaxOn ⟨a,has⟩ readout.continuous.continuousOn
  let T := {z ∈ S | ∀ y ∈ S, readout y ≤ readout z}
  have topFace : IsExposed ℝ S T := fun _ => ⟨readout,rfl⟩
  have ct : IsCompact T := cs.of_isClosed_subset (topFace.isClosed cs.isClosed) topFace.isExtreme.1
  obtain ⟨t,ht⟩ := ct.extremePoints_nonempty ⟨z,hz,hm⟩
  have htT : t ∈ T := extremePoints_subset ht
  exact ⟨t,(face.trans topFace.isExtreme).extremePoints_subset_extremePoints ht,
    visible.trans_le (htT.2 a has),fun i => (mem_iInter.mp htT.1 i).2⟩

end KDClosure
