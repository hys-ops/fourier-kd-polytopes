import Mathlib.Analysis.Convex.Topology
import Mathlib.Analysis.Normed.Module.Basic
import Mathlib.Topology.Maps.Proper.Basic
import Mathlib.Analysis.Normed.Operator.ContinuousLinearMap
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Ring

/-! §5. A compact convex trace-one base generates a closed cone. The proof uses
a compact projection, not compactness of the infinite-dimensional state space.
We keep topology explicit; no operator norm is claimed equal to trace norm. -/
noncomputable section
namespace KDClosure.Hull
open Set

variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]

/-- Nonnegative multiples of the base. If the base is empty this convention gives
the empty set. §5 applies it to a nonempty finite pure hull. -/
def rays (B : Set E) := {z : E | ∃ (r : ℝ), 0 ≤ r ∧ ∃ b ∈ B, z = r • b}

theorem mem_rays_iff (τ : E →L[ℝ] ℝ) {B : Set E} (one : ∀ b ∈ B, τ b = 1) (z : E) :
    z ∈ rays B ↔ 0 ≤ τ z ∧ ∃ b ∈ B, z = τ z • b := by
  constructor
  · rintro ⟨r,hr,b,hb,rfl⟩
    simpa [one _ hb] using (show 0 ≤ r ∧ ∃ u ∈ B, r • b = r • u from ⟨hr,b,hb,rfl⟩)
  · rintro ⟨hz,b,hb,he⟩
    exact ⟨τ z,hz,b,hb,he⟩

theorem rays_closed (τ : E →L[ℝ] ℝ) {B : Set E} (Bcompact : IsCompact B)
    (one : ∀ b ∈ B, τ b = 1) : IsClosed (rays B) := by
  let : CompactSpace B := isCompact_iff_compactSpace.mp Bcompact
  let graph : Set (E × B) := {p | 0 ≤ τ p.1 ∧ p.1 = τ p.1 • p.2.val}
  have hc₁ : Continuous (fun p : E × B => τ p.1) := τ.continuous.comp continuous_fst
  have hc₂ : Continuous (fun p : E × B => p.2.val) := continuous_subtype_val.comp continuous_snd
  have cgraph : IsClosed graph := (isClosed_le continuous_const hc₁).inter
    (isClosed_eq continuous_fst (hc₁.smul hc₂))
  have hgraph : Prod.fst '' graph = rays B := by
    ext z
    rw [mem_rays_iff τ one]
    constructor
    · rintro ⟨⟨u,b⟩,⟨hp,he⟩,rfl⟩
      exact ⟨hp,b.val,b.property,he⟩
    · rintro ⟨hp,b,hb,he⟩
      exact ⟨(z,⟨b,hb⟩),⟨hp,he⟩,rfl⟩
  rw [← hgraph]
  exact isClosedMap_fst_of_compactSpace _ cgraph

theorem rays_convex {B : Set E} (Bc : Convex ℝ B) : Convex ℝ (rays B) := by
  rintro x ⟨r,hr,p,hp,rfl⟩ y ⟨s,hs,q,hq,rfl⟩ a b ha hb _
  let t := a*r+b*s
  have har := mul_nonneg ha hr
  have hbs := mul_nonneg hb hs
  have ht : 0 ≤ t := add_nonneg har hbs
  by_cases htt : t = 0
  · have za : a*r=0 := by dsimp [t] at htt; linarith
    have zb : b*s=0 := by dsimp [t] at htt; linarith
    exact ⟨0, le_rfl, p, hp, by simp [smul_smul,za,zb]⟩
  · have hsum : a*r/t + b*s/t = 1 := by rw [← add_div]; exact div_self htt
    refine ⟨t,ht,(a*r/t) • p + (b*s/t) • q,
      Bc hp hq (div_nonneg har ht) (div_nonneg hbs ht) hsum, ?_⟩
    rw [smul_add,smul_smul,smul_smul,smul_smul,smul_smul]
    rw [mul_div_cancel₀ (a*r) htt, mul_div_cancel₀ (b*s) htt]

theorem trace_one_slice (τ : E →L[ℝ] ℝ) {B : Set E} (one : ∀ b ∈ B, τ b = 1)
    {z : E} (hz : τ z = 1) : z ∈ rays B ↔ z ∈ B := by
  rw [mem_rays_iff τ one,hz]
  simp

theorem trace_on_convexHull (τ : E →L[ℝ] ℝ) {P : Set E} (one : ∀ b ∈ P, τ b = 1) :
    ∀ x ∈ convexHull ℝ P, τ x = 1 := by
  have inc : P ⊆ τ ⁻¹' ({1} : Set ℝ) := one
  exact convexHull_min inc ((convex_singleton (1 : ℝ)).is_linear_preimage τ.isLinear)

/-- Continuous linear compression carries even limits of arbitrary ambient finite
pure mixtures into the closed finite cone. At trace one this contradicts a witness
outside the finite pure hull. This lemma does not *assume* the separation conclusion. -/
theorem obstruction_of_compression {X : Type*} [NormedAddCommGroup X] [NormedSpace ℝ X]
    (C : X →L[ℝ] E) (τ : E →L[ℝ] ℝ) {ambient : Set X} {P : Set E}
    (fin : P.Finite) (one : ∀ b ∈ P, τ b = 1)
    (pure : ∀ x ∈ ambient, C x ∈ rays (convexHull ℝ P))
    {z : X} (hz : τ (C z) = 1) (outside : C z ∉ convexHull ℝ P) :
    z ∉ closedConvexHull ℝ ambient := by
  let B := convexHull ℝ P
  have Bc : Convex ℝ B := convex_convexHull ℝ P
  have Bone : ∀ b ∈ B, τ b = 1 := trace_on_convexHull τ one
  have hp : ambient ⊆ C ⁻¹' rays B := pure
  have hi := closedConvexHull_min hp ((rays_convex Bc).is_linear_preimage C.isLinear)
    ((rays_closed τ (fin.isCompact_convexHull ℝ) Bone).preimage C.continuous)
  intro hz'
  exact outside ((trace_one_slice τ Bone hz).1 (hi hz'))

end KDClosure.Hull
