import KDDiscreteOperator
import Mathlib.LinearAlgebra.Dimension.FreeAndStrongRankCondition

noncomputable section
namespace KDClosure.Discrete
open Set
open scoped InnerProductSpace

/-- All two-row/two-column determinants vanish, in coordinates on the fixed
orthonormal basis. Equal row/column indices are allowed. -/
def minorsVanish {D : Type*} (A : D×D→ℂ) : Prop :=
  ∀ x y i j, A (x,i)*A (y,j)=A (x,j)*A (y,i)

theorem closed_minors (D : Type*) : IsClosed {A : D×D→ℂ | minorsVanish A} := by
  change IsClosed {A : D×D→ℂ | ∀ x y i j, A (x,i)*A (y,j)=A (x,j)*A (y,i)}
  simp only [Set.ofPred_forall]
  repeat' (apply isClosed_iInter; intro)
  apply isClosed_eq <;> fun_prop

/-- No positivity, trace, or finite-dimensionality assumption is used. The
rank is a cardinal, so infinite-dimensional range is correctly excluded. -/
theorem minors_iff_operator_rank_le_one {D : Type*} [DecidableEq D]
    (T : L2 D →L[ℂ] L2 D) :
    minorsVanish (entries T) ↔ Module.rank ℂ (LinearMap.range T.toLinearMap) ≤ 1 := by
  classical
  let E (i : D) : L2 D := lp.single 2 i (1:ℂ)
  let A := entries T
  change minorsVanish A ↔ _
  constructor
  · intro minors
    apply rank_le_one_iff.mpr
    by_cases has : ∃ x i, A (x,i) ≠ 0
    · obtain ⟨x,i,hp⟩ := has
      let c := A (x,i)
      have hc : c≠0 := hp
      let F : L2 D →L[ℂ] ℂ := (innerSL ℂ (E x)).comp T
      let B : L2 D →L[ℂ] L2 D := F.smulRight (c⁻¹ • T (E i))
      have factor : T=B := by
        apply ext_of_entries
        intro y j
        change A (y,j) = inner ℂ (E y) (F (E j) • (c⁻¹ • T (E i)))
        rw [inner_smul_right,inner_smul_right]
        change A (y,j)=A (x,j)*(c⁻¹*A (y,i))
        have minor : c * A (y,j)=A (x,j)*A (y,i) := minors x y i j
        field_simp
        linear_combination minor
      refine ⟨⟨T (E i),E i,rfl⟩,?_⟩
      rintro ⟨_,z,rfl⟩
      refine ⟨F z*c⁻¹,Subtype.ext ?_⟩
      change (F z*c⁻¹) • T (E i) = T z
      exact (mul_smul ..).trans (DFunLike.congr_fun factor z).symm
    · have hz : T=0 := by
        apply ext_of_entries
        intro i j
        have h : A (i,j)=0 := by by_contra ne; exact has ⟨i,j,ne⟩
        simpa [A,entries] using h
      refine ⟨0,?_⟩
      rintro ⟨_,z,rfl⟩
      exact ⟨0,Subtype.ext (by simp [hz])⟩
  · intro rankone
    obtain ⟨v,hv⟩ := rank_le_one_iff.mp rankone
    have multiples (i : D) : ∃ c : ℂ, c • v.val = T (E i) := by
      obtain ⟨c,h⟩ := hv ⟨T (E i),E i,rfl⟩
      exact ⟨c,congrArg Subtype.val h⟩
    choose c hc using multiples
    have coeff (x i : D) : A (x,i)=c i*inner ℂ (E x) v.val := by
      change inner ℂ (E x) (T (E i))=_
      rw [←hc,inner_smul_right]
    intro x y i j
    simp only [coeff]
    ring

/-- A realized operator in the coordinate closure of any set of rank-at-most-
one operators still has rank at most one. Nets and sequences are both covered. -/
theorem rank_le_one_of_coordinate_closure {D : Type*} [DecidableEq D]
    (S : Set (L2 D →L[ℂ] L2 D))
    (one : ∀ U∈S, Module.rank ℂ (LinearMap.range U.toLinearMap) ≤ 1)
    {T : L2 D →L[ℂ] L2 D} (limit : entries T ∈ closure (entries '' S)) :
    Module.rank ℂ (LinearMap.range T.toLinearMap) ≤ 1 := by
  apply (minors_iff_operator_rank_le_one T).mp
  apply closure_minimal _ (closed_minors D) limit
  rintro _ ⟨U,hU,rfl⟩
  exact (minors_iff_operator_rank_le_one U).mpr (one U hU)

end KDClosure.Discrete
