import KDFinitePhysicalCorners
import Mathlib.MeasureTheory.Function.ConvergenceInMeasure

noncomputable section
namespace KDClosure.PhysicalCorner
open Filter Set MeasureTheory Discrete DiscreteKDRow DiscreteOrtho SubgroupMeasure FourierSynthesis
open scoped ComplexOrder Topology KDClosure.SubgroupMeasure BigOperators
variable {G : Type*} [CommGroup G] [TopologicalSpace G] [DiscreteTopology G] [DecidableEq G]
variable {I : ℕ → Type*} [∀ n, AddCommGroup (I n)] [∀ n, Fintype (I n)]

theorem ae_nonneg_limit {X : Type*} [MeasurableSpace X] {μ : Measure X} {f : ℕ → Lp ℂ 2 μ}
    {g : Lp ℂ 2 μ} (lim : Tendsto f atTop (𝓝 g))
    (hp : ∀ᶠ n in atTop, ∀ᵐ z ∂μ, 0 ≤ f n z) : ∀ᵐ z ∂μ, 0 ≤ g z := by
  obtain ⟨u,hu,hh⟩ := (tendstoInMeasure_of_tendsto_Lp lim).exists_seq_tendsto_ae
  obtain ⟨N,hN⟩ := eventually_atTop.mp hp
  have posall : ∀ n, ∀ᵐ z ∂μ, N ≤ n → 0 ≤ f n z := by
    intro n
    by_cases hn : N ≤ n
    · exact (hN n hn).mono (fun z h _ => h)
    · exact Eventually.of_forall (fun _ h => (hn h).elim)
  have closed : IsClosed {z : ℂ | 0 ≤ z} := by
    simp only [Complex.nonneg_iff,Set.ofPred_and]
    exact (isClosed_le continuous_const Complex.continuous_re).inter
      (isClosed_eq continuous_const Complex.continuous_im)
  filter_upwards [hh,ae_all_iff.mpr posall] with z hz hpos
  exact closed.mem_of_tendsto hz ((hu.tendsto_atTop.eventually (eventually_ge_atTop N)).mono
    (fun n hn => hpos _ hn))

/-- Ambient Fourier KD positivity is exactly the collection of tests on
finite subgroup corners of any ascending, exhausting sequence. -/
theorem exhaustion_iff (e : ∀ n, Multiplicative (I n) →* G)
    (inj : ∀ n, Function.Injective (e n)) (inc : Monotone (fun n => range (e n)))
    (exh : ∀ z, ∃ n, z ∈ range (e n)) (T : L2 G →L[ℂ] L2 G) :
    RowNonneg G T ↔ ∀ n (t : I n) (γ : AddChar (I n) ℂ),
      0 ≤ ∑ d : I n, entries T (e n (.ofAdd t),e n (.ofAdd (t+d))) * γ d := by
  classical
  constructor
  · intro pos n t γ
    have eqn (d : I n) : e n (.ofAdd (t+d)) = e n (.ofAdd t) * e n (.ofAdd d) := (e n).map_mul _ _
    simpa only [eqn] using finite_symbol_nonneg (e n) T pos (e n (.ofAdd t)) γ
  · intro tests x
    let j := fun n (t : I n) => e n (.ofAdd t)
    have hlim := head_synthesis j inj inc exh (phase G x) (phase_orthonormal G x) T x
    apply ae_nonneg_limit hlim
    obtain ⟨N,hx⟩ := exh x
    filter_upwards [eventually_ge_atTop N] with n hn
    obtain ⟨a,ha⟩ := inc hn hx
    let θ (χ : PontryaginDual G) : AddChar (I n) ℂ :=
      { toFun := fun d => (χ (j n d):ℂ)
        map_zero_eq_one' := by change (χ (e n 1):ℂ)=1; simp
        map_add_eq_mul' := by intro r s; change (χ (e n ((.ofAdd r)*(.ofAdd s))):ℂ)=_; simp [j] }
    have point (χ : PontryaginDual G) : 0 ≤ ∑ t : I n, entries T (x,j n t) * (χ (j n t / x):ℂ) := by
      have shift := Equiv.sum_comp (Equiv.addLeft a.toAdd) (fun t : I n => entries T (x,j n t)*(χ (j n t/x):ℂ))
      rw [←shift,←ha]
      convert! tests n a.toAdd (θ χ) using 1
      apply Finset.sum_congr rfl; intro d _
      change entries T (_,_) * (χ (e n (a * .ofAdd d) / e n a):ℂ) = _
      rw [map_mul,mul_div_cancel_left]
      rfl
    have repr := poly_ae j (phase G x) (fun y (χ : PontryaginDual G) => (χ (y/x):ℂ)) (phase_ae G x) T x n
    exact repr.mono (fun χ h => h.symm ▸ point χ)
end KDClosure.PhysicalCorner
