import KDCompactCosetConverse
import Mathlib.MeasureTheory.Measure.Prod

noncomputable section
namespace KDClosure.CompactCoset
open Set MeasureTheory CompactCore Classical
open scoped BigOperators ComplexOrder
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]

/-- The actual compact-open unitary dual in Mathlib's multiplicative type tag. -/
abbrev Dual (G : Type*) [AddCommGroup G] [TopologicalSpace G] := PontryaginDual (Multiplicative G)

def complexChar (φ : Dual G) : AddChar G ℂ where
  toFun x := (φ (Multiplicative.ofAdd x):ℂ)
  map_zero_eq_one' := by change (φ (1:Multiplicative G):ℂ)=1; simp
  map_add_eq_mul' x y := by change (φ (Multiplicative.ofAdd x*Multiplicative.ofAdd y):ℂ)=_; simp

omit [IsTopologicalAddGroup G] in
private theorem complexChar_cont (φ : Dual G) : Continuous (complexChar φ) :=
  continuous_subtype_val.comp φ.continuous

private def makeDual (χ : AddChar G ℂ) (hc : Continuous χ) (unit : ∀ x, ‖χ x‖=1) : Dual G := by
  let u (x : G) : Circle := ⟨χ x,by change dist (χ x) 0=1; simpa using unit x⟩
  let f : AddChar G Circle :=
    { toFun := u
      map_zero_eq_one' := Subtype.ext χ.map_zero_eq_one
      map_add_eq_mul' x y := Subtype.ext (χ.map_add_eq_mul x y) }
  exact ⟨f.toMonoidHom,show Continuous u from hc.subtype_mk _⟩

variable (H K : CO G)
local instance : Fintype (CoreQuot H K) := @Fintype.ofFinite _ (finite_core H K)

def agree (φ : Dual G) : Set (Dual G) := {ψ | ∀ z : subgroup K, complexChar ψ z = complexChar φ z}

omit [IsTopologicalAddGroup G] in
theorem agree_isOpen (φ : Dual G) : IsOpen (agree K φ) := by
  let S : OpenSubgroup (Multiplicative G) := ⟨(subgroup K).toSubgroup,K.val.isOpen⟩
  have : CompactSpace S := isCompact_iff_compactSpace.mp K.property
  let inc : S →ₜ* Multiplicative G := ⟨S.toSubgroup.subtype,continuous_subtype_val⟩
  let R := PontryaginDual.map inc
  have eq : agree K φ = R ⁻¹' {R φ} := by
    ext ψ
    constructor
    · intro h
      apply DFunLike.ext
      intro z
      exact Subtype.ext (h (⟨z.val.toAdd,z.property⟩ : subgroup K))
    · intro h z
      exact congrArg (fun ρ : PontryaginDual S => (ρ ⟨Multiplicative.ofAdd z.val,z.property⟩ : ℂ)) h
  rw [eq]
  exact (isOpen_discrete _).preimage R.continuous

variable [T2Space G] [MeasurableSpace G] [BorelSpace G] [MeasurableAdd G]
variable (μ : Measure G) [μ.IsAddHaarMeasure]

/-- An entire nonempty open rectangle realizes the very same finite KD cell,
including its complex phase. This prevents failures hidden on sets of zero Haar mass. -/
theorem open_cell (le : H≤K) (A : Matrix (CoreQuot H K) (CoreQuot H K) ℂ)
    (i : CoreQuot H K) (γ : AddChar (CoreQuot H K) ℂ) :
    ∃ X : Set G, ∃ V : Set (Dual G), IsOpen X ∧ X.Nonempty ∧ IsOpen V ∧ V.Nonempty ∧
    ∀ x ∈ X, ∀ φ ∈ V, (∫ y, liftedKernel μ H K A x y * complexChar φ (y-x) ∂μ) =
      ∑ j : CoreQuot H K, A i j * γ (j-i) := by
  obtain ⟨χ,hc,hu,ha,des⟩ := section_character_lift H K le γ
  let f := makeDual χ hc hu
  have fe (z : G) : complexChar f z = χ z := rfl
  refine ⟨coset H (representative H K i:G),agree K f,
    H.val.isOpen.preimage (continuous_id.sub continuous_const),⟨representative H K i,?_⟩,
    agree_isOpen K f,⟨f,fun _ => rfl⟩,?_⟩
  · change _ - _ ∈ H.val
    simp
  · intro x hx φ hφ
    change x-(representative H K i:G) ∈ H.val at hx
    have xK : x ∈ K.val := by
      have d : x-(representative H K i:G) ∈ K.val := le hx
      simpa using K.val.add_mem d (representative H K i).property
    have agreeχ (z : subgroup K) : complexChar φ z = χ z := (hφ z).trans (fe z)
    have hφa : annihilates H (complexChar φ) := by
      intro z hz; exact (agreeχ ⟨z,le hz⟩).trans (ha z hz)
    have dφ : descended H K (complexChar φ) hφa = γ := by
      ext j
      exact (agreeχ (representative H K j)).trans (congrArg (fun θ : AddChar (CoreQuot H K) ℂ => θ j) des)
    have xi : quotientIndex H K x xK = i := by
      rw [← representative_spec H K i]
      exact (QuotientAddGroup.eq_iff_sub_mem (N:=((subgroup H).addSubgroupOf (subgroup K)))
        (x:=(⟨x,xK⟩ : subgroup K)) (y:=representative H K i)).2 hx
    rw [liftedKernel_KD μ H K A x _ (complexChar_cont φ),dif_pos xK,dif_pos hφa,dφ,xi]

variable [MeasurableSpace (Dual G)]

/-- The exact product-almost-everywhere criterion. Any sigma-finite dual Haar
measure works; only its open-set positivity is required in the reflection direction. -/
theorem liftedKernel_KD_ae_iff (ν : Measure (Dual G)) [ν.IsOpenPosMeasure] [SFinite ν]
    (le : H≤K) (A : Matrix (CoreQuot H K) (CoreQuot H K) ℂ) :
    (∀ (i : CoreQuot H K) (γ : AddChar (CoreQuot H K) ℂ),
      0 ≤ ∑ j : CoreQuot H K, A i j * γ (j-i)) ↔
    ∀ᵐ z : G × Dual G ∂μ.prod ν,
      0 ≤ ∫ y, liftedKernel μ H K A z.1 y * complexChar z.2 (y-z.1) ∂μ := by
  constructor
  · intro hp
    exact Filter.Eventually.of_forall (fun z => liftedKernel_preserves_KD μ H K A hp
      z.1 _ (complexChar_cont z.2))
  · intro hp i γ
    by_contra failure
    obtain ⟨X,V,xopen,xnon,vopen,vnon,cell⟩ := open_cell H K μ le A i γ
    have subset : X ×ˢ V ⊆ {z : G × Dual G |
        ¬0 ≤ ∫ y, liftedKernel μ H K A z.1 y * complexChar z.2 (y-z.1) ∂μ} := by
      intro z hz
      change ¬0 ≤ _
      rw [cell z.1 hz.1 z.2 hz.2]
      exact failure
    have zero := measure_mono_null subset (ae_iff.mp hp)
    rw [Measure.prod_prod] at zero
    exact (mul_ne_zero (xopen.measure_pos μ xnon).ne' (vopen.measure_pos ν vnon).ne') zero

end KDClosure.CompactCoset
