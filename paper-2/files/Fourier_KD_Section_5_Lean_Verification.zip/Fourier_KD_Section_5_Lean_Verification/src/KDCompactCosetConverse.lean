import KDCompactCosetRow
import KDOpenCharacterExtension

noncomputable section
namespace KDClosure.CompactCoset
open MeasureTheory Set CompactCore Classical
open scoped BigOperators ComplexOrder
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]

variable (H K : CO G)
local instance : Fintype (CoreQuot H K) := @Fintype.ofFinite _ (finite_core H K)

/-- Every finite section frequency has a genuine continuous unitary lift on G
in the annihilator of H, with the sign preserved. -/
theorem section_character_lift (le : H≤K) (γ : AddChar (CoreQuot H K) ℂ) :
    ∃ χ : AddChar G ℂ, Continuous χ ∧ (∀ z, ‖χ z‖=1) ∧
      ∃ ha : annihilates H χ, descended H K χ ha = γ := by
  let π := QuotientAddGroup.mk' ((subgroup H).addSubgroupOf (subgroup K))
  let S : OpenSubgroup (Multiplicative G) := ⟨(subgroup K).toSubgroup,K.val.isOpen⟩
  let α (w : CoreQuot H K) : Circle := ⟨γ w,by
    change dist (γ w) 0=1; simp⟩
  have ds : DiscreteTopology (CoreQuot H K) := QuotientAddGroup.discreteTopology_iff.mpr
    (H.val.isOpen.preimage continuous_subtype_val)
  let f : PontryaginDual S :=
    { toFun := fun z => α (π ⟨z.val.toAdd,z.property⟩)
      map_one' := by apply Subtype.ext; exact (congrArg γ (map_zero π)).trans γ.map_zero_eq_one
      map_mul' := fun u v => by
        apply Subtype.ext
        change γ (π ((⟨u.val.toAdd,u.property⟩ : subgroup K)+⟨v.val.toAdd,v.property⟩))=_
        rw [map_add,AddChar.map_add_eq_mul]; rfl
      continuous_toFun := by
        have h : Continuous (fun z : S => (⟨z.val.toAdd,z.property⟩ : subgroup K)) := continuous_id
        exact (continuous_of_discreteTopology (f:=α)).comp (QuotientAddGroup.continuous_mk.comp h) }
  obtain ⟨ψ,hψ⟩ := OpenCharacter.extends_of_open S f
  let χ : AddChar G ℂ :=
    { toFun := fun x => (ψ (Multiplicative.ofAdd x):ℂ)
      map_zero_eq_one' := by change (ψ (1:Multiplicative G):ℂ)=1; simp
      map_add_eq_mul' x y := by change (ψ (Multiplicative.ofAdd x*Multiplicative.ofAdd y):ℂ)=_; simp }
  have hc : Continuous χ := continuous_subtype_val.comp ψ.continuous
  have norm (z : G) : ‖χ z‖=1 := Circle.norm_coe _
  have hk (z : subgroup K) : χ (z:G) = γ (π z) :=
    congrArg (fun u : Circle => (u:ℂ)) (hψ (⟨Multiplicative.ofAdd z.val,z.property⟩ : S))
  have ha : annihilates H χ := by
    intro z hz
    let v : subgroup K := ⟨z,le hz⟩
    have e : π v=0 := (QuotientAddGroup.eq_zero_iff _).mpr hz
    exact (hk v).trans ((congrArg γ e).trans γ.map_zero_eq_one)
  refine ⟨χ,hc,norm,ha,?_⟩
  ext i
  exact (hk (representative H K i)).trans (congrArg γ (representative_spec H K i))

variable [T2Space G] [MeasurableSpace G] [BorelSpace G] [MeasurableAdd G]
variable (μ : Measure G) [μ.IsAddHaarMeasure]

/-- Exact pointwise equivalence for the normalized finite-section kernel. The
ambient side tests all continuous unitary characters, just as on the finite side. -/
theorem liftedKernel_KD_iff (le : H≤K) (A : Matrix (CoreQuot H K) (CoreQuot H K) ℂ) :
    (∀ (i : CoreQuot H K) (γ : AddChar (CoreQuot H K) ℂ),
      0 ≤ ∑ j : CoreQuot H K, A i j * γ (j-i)) ↔
    (∀ (x : G) (χ : AddChar G ℂ), Continuous χ → (∀ z,‖χ z‖=1) →
      0 ≤ ∫ y, liftedKernel μ H K A x y * χ (y-x) ∂μ) := by
  constructor
  · intro h x χ hc _
    exact liftedKernel_preserves_KD μ H K A h x χ hc
  · intro h i γ
    obtain ⟨χ,hc,hn,ha,he⟩ := section_character_lift H K le γ
    let x := representative H K i
    have hit := h x.val χ hc hn
    have hx : x.val ∈ K.val := x.property
    rw [liftedKernel_KD μ H K A x.val χ hc,dif_pos hx,dif_pos ha,he] at hit
    have hi : quotientIndex H K x.val hx=i := representative_spec H K i
    simpa only [hi] using hit

end KDClosure.CompactCoset
