import KDCompactOpenCore
import Mathlib.MeasureTheory.Group.Integral
import Mathlib.MeasureTheory.Measure.Haar.Basic
import Mathlib.MeasureTheory.Function.LocallyIntegrable
import Mathlib.MeasureTheory.Integral.Bochner.Set

/-! The physical coset-step Fourier row on an actual Haar group. -/
noncomputable section
namespace KDClosure.CompactCoset
open MeasureTheory Set CompactCore Classical
open scoped BigOperators

variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
  [T2Space G] [MeasurableSpace G] [BorelSpace G] [MeasurableAdd G]

def coset (H : CO G) (a : G) := {x : G | x-a ∈ H.val}
def annihilates (H : CO G) (χ : AddChar G ℂ) : Prop := ∀ h ∈ H.val, χ h = 1

omit [T2Space G] [MeasurableSpace G] in
theorem coset_compact (H : CO G) (a : G) : IsCompact (coset H a) := by
  have eq : coset H a = (fun x => a+x) '' (H.val : Set G) := by
    ext x
    constructor
    · intro hx; exact ⟨x-a,hx,by simp⟩
    · rintro ⟨y,hy,rfl⟩
      change a+y-a∈H.val
      simpa using hy
  rw [eq]
  exact H.property.image (continuous_const.add continuous_id)

omit [T2Space G] [MeasurableAdd G] in
theorem coset_meas (H : CO G) (a : G) : MeasurableSet (coset H a) :=
  (H.val.isOpen.preimage (continuous_id.sub continuous_const)).measurableSet

variable (μ : Measure G) [μ.IsAddHaarMeasure]

omit [T2Space G] [IsTopologicalAddGroup G] in
theorem subgroup_orthogonality (H : CO G) (χ : AddChar G ℂ) :
    ∫ x in (H.val : Set G), χ x ∂μ =
      if annihilates H χ then (μ.real (H.val : Set G) : ℂ) else 0 := by
  have hm := H.val.isOpen.measurableSet
  by_cases ha : annihilates H χ
  · rw [if_pos ha]
    calc
      _ = ∫ _x in (H.val : Set G), (1 : ℂ) ∂μ := setIntegral_congr_fun hm ha
      _ = _ := by rw [setIntegral_const]; simp
  · rw [if_neg ha]
    obtain ⟨h,hh,ne⟩ : ∃ h ∈ H.val, χ h ≠ 1 := by simpa [annihilates] using ha
    let f := (H.val : Set G).indicator (fun x => χ x)
    have shift (x) : f (h+x) = χ h * f x := by
      by_cases hx : x∈H.val
      · have hsum : h+x ∈ (H.val : Set G) := H.val.add_mem hh hx
        exact (Set.indicator_of_mem hsum _).trans ((χ.map_add_eq_mul _ _).trans
          (congrArg (χ h * ·) (Set.indicator_of_mem hx _).symm))
      · have no : h+x ∉ H.val := by intro e; apply hx; simpa using H.val.sub_mem e hh
        simp [f,hx,no]
    let I := ∫ x, f x ∂μ
    have invariant : χ h * I = I := by
      change χ h * (∫ x, f x ∂μ) = _
      rw [← integral_const_mul]
      simpa only [shift] using integral_add_left_eq_self (μ:=μ) f h
    have van : I=0 := by
      have product : (χ h-1)*I=0 := by rw [sub_mul,invariant,one_mul,sub_self]
      exact (mul_eq_zero.mp product).resolve_left (sub_ne_zero.mpr ne)
    simpa [I,f,integral_indicator hm] using van

omit [T2Space G] in
/-- Fourier transform of a single coset at the character χ in the positive
character convention. The Haar mass is that of H; no normalization is fixed. -/
theorem coset_character_integral (H : CO G) (a : G) (χ : AddChar G ℂ) :
    ∫ x in coset H a, χ x ∂μ =
      if annihilates H χ then (μ.real (H.val : Set G) : ℂ) * χ a else 0 := by
  let f := (coset H a).indicator (fun x => χ x)
  have shifted (x : G) : f (a+x) = χ a * (H.val : Set G).indicator (fun u => χ u) x := by
    by_cases hx : x∈H.val
    · have h : a+x ∈ coset H a := by simpa [coset] using hx
      simp [f,hx,h,AddChar.map_add_eq_mul]
    · have h : a+x ∉ coset H a := by simpa [coset] using hx
      simp [f,hx,h]
  calc
    _ = ∫ x, f (a+x) ∂μ := by rw [integral_add_left_eq_self]; exact (integral_indicator (coset_meas H a)).symm
    _ = χ a * ∫ x in (H.val : Set G), χ x ∂μ := by
      simp_rw [shifted]; rw [integral_const_mul,integral_indicator H.val.isOpen.measurableSet]
    _ = _ := by
      rw [subgroup_orthogonality]; split_ifs <;> simp [mul_comm]

/-- A finite row of coset indicators, allowing arbitrary complex coefficients
and overlapping cosets. The physical Fourier convention uses displacement y-x₀. -/
theorem finite_step_KD_row {ι : Type*} (H : CO G) (F : Finset ι) (a : ι → G)
    (c : ι → ℂ) (x₀ : G) (χ : AddChar G ℂ) (hχ : Continuous χ) :
    (∫ y, (∑ j ∈ F, (coset H (a j)).indicator (fun _ => c j) y) * χ (y-x₀) ∂μ) =
    if annihilates H χ then (μ.real (H.val : Set G) : ℂ) *
      ∑ j ∈ F, c j * χ (a j-x₀) else 0 := by
  let v (j : ι) (y : G) := (coset H (a j)).indicator (fun z => χ z) y
  have hi (j : ι) : Integrable (v j) μ := (integrable_indicator_iff (coset_meas H _)).2
    (hχ.continuousOn.integrableOn_compact (coset_compact H _))
  have ev (j : ι) (y : G) :
      (coset H (a j)).indicator (fun _ => c j) y * χ (y-x₀) =
      (c j * χ (-x₀))*v j y := by
    by_cases hy : y∈coset H (a j) <;>
      simp [hy,v,sub_eq_add_neg,AddChar.map_add_eq_mul,mul_comm,mul_left_comm]
  simp_rw [Finset.sum_mul,ev]
  rw [integral_finsetSum F (fun j _ => (hi j).const_mul _)]
  simp_rw [integral_const_mul,v,integral_indicator (coset_meas H _),coset_character_integral]
  by_cases h : annihilates H χ
  · simp only [if_pos h,Finset.mul_sum]
    apply Finset.sum_congr rfl; intro j _
    rw [sub_eq_add_neg,AddChar.map_add_eq_mul]; ring
  · simp [h]

section Quotient
variable (H K : CO G)
local instance : Fintype (CoreQuot H K) := @Fintype.ofFinite _ (finite_core H K)

noncomputable def representative (i : CoreQuot H K) : subgroup K :=
  (QuotientAddGroup.mk'_surjective ((subgroup H).addSubgroupOf (subgroup K)) i).choose

omit [T2Space G] [MeasurableSpace G] [IsTopologicalAddGroup G] in
theorem representative_spec (i : CoreQuot H K) :
    QuotientAddGroup.mk' ((subgroup H).addSubgroupOf (subgroup K)) (representative H K i) = i :=
  (QuotientAddGroup.mk'_surjective ((subgroup H).addSubgroupOf (subgroup K)) i).choose_spec

omit [T2Space G] [MeasurableSpace G] [IsTopologicalAddGroup G] in
private theorem rep_character (χ : AddChar G ℂ) (ha : annihilates H χ)
    (u v : subgroup K) (he : QuotientAddGroup.mk' ((subgroup H).addSubgroupOf (subgroup K)) u =
      QuotientAddGroup.mk' ((subgroup H).addSubgroupOf (subgroup K)) v) :
    χ (u:G) = χ (v:G) := by
  have e : (u:G)-v ∈ H.val := (QuotientAddGroup.eq_iff_sub_mem (N:=((subgroup H).addSubgroupOf (subgroup K))) (x:=u) (y:=v)).mp he
  calc χ (u:G) = χ (((u:G)-v)+v) := by rw [sub_add_cancel]
       _ = χ (v:G) := by rw [AddChar.map_add_eq_mul,ha _ e,one_mul]

def descended (χ : AddChar G ℂ) (ha : annihilates H χ) : AddChar (CoreQuot H K) ℂ where
  toFun i := χ (representative H K i : G)
  map_zero_eq_one' := by
    simpa using rep_character H K χ ha (representative H K 0) 0
      ((representative_spec H K _).trans (map_zero _).symm)
  map_add_eq_mul' i j := by
    have h := rep_character H K χ ha (representative H K (i+j))
      (representative H K i + representative H K j)
      (by rw [representative_spec,map_add,representative_spec,representative_spec])
    simpa [AddChar.map_add_eq_mul] using h

/-- The normalized matrix kernel on a genuine compact-open section K/H:
for every physical position in the chosen row coset, the Haar integral is
exactly the *finite* quotient KD symbol, or zero outside the annihilator.
The inverse mass is the two factors from normalized coset basis vectors. -/
theorem quotient_matrix_KD (A : Matrix (CoreQuot H K) (CoreQuot H K) ℂ)
    (i : CoreQuot H K) (x : G) (hx : x-(representative H K i:G) ∈ H.val)
    (χ : AddChar G ℂ) (hχ : Continuous χ) :
    (∫ y, (∑ j : CoreQuot H K, (coset H (representative H K j:G)).indicator
      (fun _ => (μ.real (H.val : Set G):ℂ)⁻¹ * A i j) y) * χ (y-x) ∂μ) =
    if h : annihilates H χ then ∑ j : CoreQuot H K, A i j * descended H K χ h (j-i) else 0 := by
  rw [finite_step_KD_row μ H Finset.univ _ _ x χ hχ]
  by_cases hh : annihilates H χ
  · rw [if_pos hh,dif_pos hh,Finset.mul_sum]
    have mass : (μ.real (H.val : Set G):ℂ) ≠ 0 := by
      apply Complex.ofReal_ne_zero.mpr
      exact ENNReal.toReal_ne_zero.mpr ⟨(H.val.isOpen.measure_pos μ ⟨0,H.val.zero_mem⟩).ne',
        H.property.measure_ne_top⟩
    have ex : χ x = χ (representative H K i:G) := by
      calc χ x = χ ((x-(representative H K i:G))+representative H K i) := by rw [sub_add_cancel]
           _ = _ := by rw [AddChar.map_add_eq_mul,hh _ hx,one_mul]
    apply Finset.sum_congr rfl
    intro j _
    have ev := rep_character H K χ hh (representative H K (j-i))
      (representative H K j-representative H K i)
      (by rw [representative_spec,map_sub,representative_spec,representative_spec])
    change _ = A i j * χ (representative H K (j-i):G)
    rw [ev]
    change _ = A i j * χ ((representative H K j:G)-(representative H K i:G))
    simp only [sub_eq_add_neg,AddChar.map_add_eq_mul,AddChar.map_neg_eq_inv,ex]
    field_simp
  · simp [hh]

def quotientIndex (x : G) (hx : x ∈ K.val) : CoreQuot H K :=
  QuotientAddGroup.mk' ((subgroup H).addSubgroupOf (subgroup K)) ⟨x,hx⟩

/-- Kernel on the ambient group; the normalized indicators are the position basis. -/
def liftedKernel (A : Matrix (CoreQuot H K) (CoreQuot H K) ℂ) (x y : G) : ℂ :=
  if hx : x ∈ K.val then
    ∑ j : CoreQuot H K, (coset H (representative H K j:G)).indicator
      (fun _ => (μ.real (H.val : Set G):ℂ)⁻¹ * A (quotientIndex H K x hx) j) y
  else 0

omit [T2Space G] [BorelSpace G] [MeasurableAdd G] [μ.IsAddHaarMeasure] in
theorem liftedKernel_support (hHK : H≤K) (A : Matrix (CoreQuot H K) (CoreQuot H K) ℂ)
    {x y : G} (outside : x ∉ K.val ∨ y ∉ K.val) : liftedKernel μ H K A x y = 0 := by
  by_cases hx : x∈K.val
  · obtain hy | hy := outside
    · exact False.elim (hy hx)
    · simp only [liftedKernel,dif_pos hx]
      refine Finset.sum_eq_zero (fun j _ => indicator_of_notMem ?_ _)
      intro mem
      have h : y-(representative H K j:G) ∈ K.val := hHK mem
      exact hy (by simpa using K.val.add_mem h (representative H K j).property)
  · simp [liftedKernel,hx]

theorem liftedKernel_KD (A : Matrix (CoreQuot H K) (CoreQuot H K) ℂ)
    (x : G) (χ : AddChar G ℂ) (hχ : Continuous χ) :
    (∫ y, liftedKernel μ H K A x y * χ (y-x) ∂μ) =
    if hx : x ∈ K.val then
      if ha : annihilates H χ then
        ∑ j : CoreQuot H K, A (quotientIndex H K x hx) j *
          descended H K χ ha (j-quotientIndex H K x hx) else 0
    else 0 := by
  by_cases hx : x ∈ K.val
  · simp only [liftedKernel,dif_pos hx]
    apply quotient_matrix_KD
    let u : subgroup K := ⟨x,hx⟩
    let v := representative H K (quotientIndex H K x hx)
    have h : QuotientAddGroup.mk' ((subgroup H).addSubgroupOf (subgroup K)) u =
        QuotientAddGroup.mk' ((subgroup H).addSubgroupOf (subgroup K)) v :=
      (representative_spec H K _).symm
    exact (QuotientAddGroup.eq_iff_sub_mem (N:=((subgroup H).addSubgroupOf (subgroup K)))
      (x:=u) (y:=v)).mp h
    exact hχ
  · simp [liftedKernel,hx]

open scoped ComplexOrder in
theorem liftedKernel_preserves_KD (A : Matrix (CoreQuot H K) (CoreQuot H K) ℂ)
    (positive : ∀ (i : CoreQuot H K) (γ : AddChar (CoreQuot H K) ℂ),
      0 ≤ ∑ j : CoreQuot H K, A i j * γ (j-i))
    (x : G) (χ : AddChar G ℂ) (hχ : Continuous χ) :
    0 ≤ ∫ y, liftedKernel μ H K A x y * χ (y-x) ∂μ := by
  rw [liftedKernel_KD μ H K A x χ hχ]
  split_ifs <;> first | exact le_rfl | apply positive

end Quotient

end KDClosure.CompactCoset
