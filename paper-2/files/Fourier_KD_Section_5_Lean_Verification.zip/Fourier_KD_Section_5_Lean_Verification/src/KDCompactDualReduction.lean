import KDDiscreteOrtho
import Mathlib.GroupTheory.Torsion
import Mathlib.Topology.ContinuousMap.SecondCountableSpace
import Mathlib.Topology.Separation.Profinite

noncomputable section
namespace KDClosure.CompactDualReduction
open Topology TopologicalSpace

variable {G : Type*} [CommGroup G] [TopologicalSpace G] [IsTopologicalGroup G]

/-- Every identity neighborhood contains an open subgroup, necessarily
compact when G is compact. -/
def OpenBasis (G : Type*) [CommGroup G] [TopologicalSpace G] : Prop :=
  ∀ W : Set G, W ∈ 𝓝 1 → ∃ H : OpenSubgroup G, (H : Set G) ⊆ W

/-- The actual subgroup of circle-valued continuous characters that are
trivial on H. -/
def ann (H : OpenSubgroup G) : Subgroup (PontryaginDual G) where
  carrier := {χ | ∀ x ∈ H, χ x = 1}
  one_mem' := fun _ _ => rfl
  mul_mem' := fun {a b} ha hb x hx => by change a x * b x = 1; rw [ha x hx,hb x hx,one_mul]
  inv_mem' := fun {a} ha x hx => by change (a x)⁻¹ = 1; rw [ha x hx,inv_one]

abbrev Q (H : OpenSubgroup G) := G ⧸ H.toSubgroup

def pull (H : OpenSubgroup G) : PontryaginDual (Q H) →ₜ* PontryaginDual G :=
  PontryaginDual.map (⟨QuotientGroup.mk' H.toSubgroup,QuotientGroup.continuous_mk⟩ : G →ₜ* Q H)

theorem ann_range (H : OpenSubgroup G) : (ann H : Set (PontryaginDual G)) = Set.range (pull H) := by
  ext χ
  constructor
  · intro hχ
    let f := QuotientGroup.lift H.toSubgroup χ.toMonoidHom (show H.toSubgroup ≤ χ.toMonoidHom.ker from
      fun x hx => hχ x hx)
    let _ : DiscreteTopology (Q H) := QuotientGroup.discreteTopology H.isOpen
    exact ⟨⟨f,continuous_of_discreteTopology⟩,PontryaginDual.ext fun _ => rfl⟩
  · rintro ⟨ψ,rfl⟩ x hx
    change ψ (QuotientGroup.mk' H.toSubgroup x) = 1
    have h : QuotientGroup.mk' H.toSubgroup x = 1 := (QuotientGroup.eq_one_iff _).mpr hx
    rw [h,map_one]

theorem finite_ann [CompactSpace G] (H : OpenSubgroup G) :
    (ann H : Set (PontryaginDual G)).Finite := by
  let _ : DiscreteTopology (Q H) := QuotientGroup.discreteTopology H.isOpen
  rw [ann_range]
  exact Set.finite_range _

/-- A point outside H is distinguished from H by a character of the
discrete quotient, pulled back without changing its kernel on H. -/
theorem distinguishes_subgroup (H : OpenSubgroup G) {g : G} (hg : g ∉ H) :
    ∃ χ ∈ ann H, χ g ≠ 1 := by
  let _ : DiscreteTopology (Q H) := QuotientGroup.discreteTopology H.isOpen
  obtain ⟨ψ,hψ⟩ := DiscreteOrtho.separates_one (Q H)
    (show QuotientGroup.mk' H.toSubgroup g ≠ 1 from fun h => hg ((QuotientGroup.eq_one_iff _).mp h))
  exact ⟨pull H ψ,(show pull H ψ ∈ (ann H : Set (PontryaginDual G)) by
    rw [ann_range]; exact ⟨ψ,rfl⟩),hψ⟩

theorem ann_le_iff (H K : OpenSubgroup G) : ann H ≤ ann K ↔ K ≤ H := by
  constructor
  · intro h g hg
    by_contra gnot
    obtain ⟨χ,hχ,hgχ⟩ := distinguishes_subgroup H gnot
    exact hgχ (h hχ g hg)
  · intro h χ hχ x hx
    exact hχ x (h hx)

omit [IsTopologicalGroup G] in
/-- There is a fixed arc containing no nontrivial subgroup of the circle.
Continuity and the subgroup basis put an entire open subgroup in the kernel. -/
theorem annihilates_open (basis : OpenBasis G) (χ : PontryaginDual G) : ∃ H : OpenSubgroup G, χ ∈ ann H := by
  let U := Circle.centeredArc (Real.pi / 2)
  have hU : IsOpen U := Circle.isOpen_centeredArc _
  have hone : (1 : Circle) ∈ U := by
    rw [Circle.mem_centeredArc (by linarith [Real.pi_pos])]
    simp [Real.pi_pos]
  obtain ⟨H,hH⟩ := basis (χ ⁻¹' U) ((hU.preimage χ.continuous).mem_nhds (by simpa using hone))
  refine ⟨H,fun x hx => Circle.eq_one_of_forall_pow_mem_centeredArc_pi_div_two ?_⟩
  intro n _
  rw [← map_pow]
  exact hH (H.pow_mem hx n)

theorem dual_torsion [CompactSpace G] (basis : OpenBasis G) : IsMulTorsion (PontryaginDual G) := by
  intro χ
  obtain ⟨H,hχ⟩ := annihilates_open basis χ
  let _ : Finite (ann H) := Set.finite_coe_iff.mpr (finite_ann H)
  obtain ⟨n,hn,he⟩ := (isOfFinOrder_of_finite (⟨χ,hχ⟩ : ann H)).exists_pow_eq_one
  exact isOfFinOrder_iff_pow_eq_one.mpr ⟨n,hn,congrArg Subtype.val he⟩

/-- In the compact core it even suffices that the open subgroups separate
each nonidentity point from the identity. Compactness outside a given
neighborhood reduces the separating family to a finite intersection. -/
theorem basis_of_separation [CompactSpace G]
    (sep : ∀ x : G, x ≠ 1 → ∃ H : OpenSubgroup G, x ∉ H) : OpenBasis G := by
  classical
  intro W hW
  obtain ⟨V,hVW,hVo,h1⟩ := mem_nhds_iff.mp hW
  obtain ⟨t,ht⟩ := hVo.isClosed_compl.isCompact.elim_finite_subcover
    (fun H : OpenSubgroup G => (H : Set G)ᶜ) (fun H => H.isClosed.isOpen_compl) (by
      intro x hx
      have hn : x ≠ 1 := fun h => hx (h ▸ h1)
      obtain ⟨H,hH⟩ := sep x hn
      exact Set.mem_iUnion.mpr ⟨H,hH⟩)
  refine ⟨t.inf id,fun x hx => hVW ?_⟩
  by_contra hn
  obtain ⟨H,hHt,hH⟩ := Set.mem_iUnion₂.mp (ht hn)
  exact hH (Finset.inf_le (f:=id) hHt hx)

/-- The abstract basis premise holds on the usual profinite hypotheses. -/
theorem profinite_basis [CompactSpace G] [T2Space G] [TotallyDisconnectedSpace G] : OpenBasis G := by
  intro W hW
  obtain ⟨V,hV,h1,hVW⟩ := isTopologicalBasis_isClopen.mem_nhds_iff.mp hW
  obtain ⟨H,hH⟩ := IsTopologicalGroup.exist_openSubgroup_sub_clopen_nhds_of_one hV h1
  exact ⟨H,hH.trans hVW⟩

omit [IsTopologicalGroup G] in
theorem dual_countable [CompactSpace G] [T2Space G] [SecondCountableTopology G] :
    Countable (PontryaginDual G) := by
  let _ : SecondCountableTopology (PontryaginDual G) :=
    (ContinuousMonoidHom.isInducing_toContinuousMap G Circle).secondCountableTopology
  exact separableSpace_iff_countable.mp inferInstance

private def eval [CompactSpace G] (g : G) : PontryaginDual (PontryaginDual G) :=
  ⟨{toFun := fun χ : PontryaginDual G => χ g, map_one' := rfl, map_mul' := fun _ _ => rfl},
   continuous_of_discreteTopology⟩

theorem dual_infinite [CompactSpace G] [T2Space G] [Infinite G] (basis : OpenBasis G) :
    Infinite (PontryaginDual G) := by
  apply not_finite_iff_infinite.mp
  intro fin
  let _ : Finite (PontryaginDual G) := fin
  have hi : Function.Injective (eval (G:=G)) := by
    intro x y eqn
    by_contra hxy
    have hne := div_ne_one.mpr hxy
    have nbh : ({x/y}ᶜ : Set G) ∈ 𝓝 1 := isOpen_compl_singleton.mem_nhds (by simpa using Ne.symm hne)
    obtain ⟨H,hH⟩ := basis _ nbh
    obtain ⟨χ,_,hχ⟩ := distinguishes_subgroup H (g:=x/y) (fun hg => hH hg rfl)
    have hval : χ x = χ y := DFunLike.congr_fun eqn χ
    exact hχ (by rw [map_div,hval]; simp)
  exact not_finite_iff_infinite.mpr (inferInstance : Infinite G) (Finite.of_injective _ hi)

/-- The compact branch in the actual dual topology and group, including the
two named annihilators. Infinitude of G is essential to the infinitude clause. -/
theorem compact_dual_reduction [CompactSpace G] [T2Space G] [Infinite G] [SecondCountableTopology G]
    (basis : OpenBasis G) (H K : OpenSubgroup G) (hHK : ¬ H ≤ K) (hKH : ¬ K ≤ H) :
    DiscreteTopology (PontryaginDual G) ∧ Countable (PontryaginDual G) ∧ Infinite (PontryaginDual G) ∧
    IsMulTorsion (PontryaginDual G) ∧ (ann H : Set (PontryaginDual G)).Finite ∧
    (ann K : Set (PontryaginDual G)).Finite ∧ ¬ ann H ≤ ann K ∧ ¬ ann K ≤ ann H :=
  ⟨inferInstance,dual_countable,dual_infinite basis,dual_torsion basis,finite_ann H,finite_ann K,
    fun h => hKH ((ann_le_iff H K).mp h),fun h => hHK ((ann_le_iff K H).mp h)⟩

end KDClosure.CompactDualReduction
