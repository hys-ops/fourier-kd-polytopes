import KDCompactFourierOrbit
import KDCompactFourierRegular

noncomputable section
namespace KDClosure.CompactFourier
open MeasureTheory Set Submodule
open scoped ComplexConjugate ENNReal
variable {G : Type*} [CommGroup G] [TopologicalSpace G] [IsTopologicalGroup G] [CompactSpace G]
  [T2Space G] [MeasurableSpace G] [BorelSpace G] (μ : Measure G) [μ.IsHaarMeasure] [IsProbabilityMeasure μ]

include μ in
theorem separates_nonidentity {g : G} (hg : g ≠ 1) : ∃ χ : PontryaginDual G, χ g ≠ 1 := by
  obtain ⟨v,hv⟩ := regular_moves μ hg
  exact character_of_moved_orbit μ (regular μ) (regular_one μ) (regular_mul μ) (continuous_regular μ) g v hv

include μ in
theorem separate_all (x y : G) (hxy : x ≠ y) : ∃ χ : PontryaginDual G, wave χ x ≠ wave χ y := by
  obtain ⟨χ,hχ⟩ := separates_nonidentity μ (div_ne_one.mpr hxy)
  exact ⟨χ,fun he => hχ (by rw [map_div,show χ x=χ y from Subtype.ext he]; simp)⟩

theorem haar_span : (span ℂ (range (waveLp μ : PontryaginDual G → _))).topologicalClosure = ⊤ := by
  have dense := span_char_dense (wave (G:=G)) rfl (fun _ _ => rfl)
    (fun χ => ContinuousMap.ext fun x => Circle.coe_inv_eq_conj _) (separate_all μ)
  convert! (ContinuousMap.toLp_denseRange ℂ μ ℂ (by simp : (2:ℝ≥0∞) ≠ ⊤)).topologicalClosure_map_submodule dense
  rw [map_span]
  unfold waveLp
  rw [range_comp']
  simp only [ContinuousLinearMap.coe_coe]

/-- All the actual continuous characters form an ONB for *every* compact
Hausdorff abelian group, with any probability Haar measure. -/
def haarFourierBasis : HilbertBasis (PontryaginDual G) ℂ (Lp ℂ 2 μ) :=
  HilbertBasis.mk (wave_orthonormal μ) (haar_span μ).ge

theorem haar_basis_coe : ⇑(haarFourierBasis μ) = waveLp μ := HilbertBasis.coe_mk _ _

theorem haar_coeff (v : Lp ℂ 2 μ) (χ : PontryaginDual G) :
    (haarFourierBasis μ).repr v χ = ∫ x, conj (χ x : ℂ) * v x ∂μ := by
  rw [HilbertBasis.repr_apply_apply,haar_basis_coe,MeasureTheory.L2.inner_def]
  apply integral_congr_ae
  filter_upwards [wave_ae μ χ] with x hx
  rw [hx,RCLike.inner_apply,mul_comm]
end KDClosure.CompactFourier
