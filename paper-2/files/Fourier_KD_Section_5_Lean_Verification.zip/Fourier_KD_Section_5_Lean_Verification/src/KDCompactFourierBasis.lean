import KDCompactDualReduction
import Mathlib.MeasureTheory.Function.ContinuousMapDense
import Mathlib.Topology.ContinuousMap.StoneWeierstrass
import Mathlib.Analysis.InnerProductSpace.l2Space

noncomputable section
namespace KDClosure.CompactFourier
open MeasureTheory Set Submodule Algebra
open scoped Topology ComplexConjugate ENNReal

section Polynomial
variable {I X : Type*} [Group I] [TopologicalSpace X] [CompactSpace X]
  (c : I → C(X,ℂ)) (unit : c 1 = 1)
  (prod : ∀ i j, c (i*j) = c i * c j) (inv : ∀ i, c i⁻¹ = star (c i))

private def algebra : StarSubalgebra ℂ C(X,ℂ) where
  toSubalgebra := Algebra.adjoin ℂ (range c)
  star_mem' := by
    change Algebra.adjoin ℂ (range c) ≤ star (Algebra.adjoin ℂ (range c))
    apply adjoin_le
    rintro _ ⟨i,rfl⟩
    exact subset_adjoin ⟨i⁻¹,inv i⟩

omit [CompactSpace X] in
include unit prod in
private theorem algebra_span :
    (algebra c inv).toSubalgebra.toSubmodule = span ℂ (range c) := by
  apply adjoin_eq_span_of_subset
  refine Subset.trans ?_ Submodule.subset_span
  intro z hz
  refine Submonoid.closure_induction (fun _ => id) ⟨1,unit⟩ ?_ hz
  rintro _ _ _ _ ⟨i,rfl⟩ ⟨j,rfl⟩
  exact ⟨i*j,prod i j⟩

include unit prod inv in
/-- Uniform density of any point-separating multiplicative character family,
including the evaluation characters on the compact bidual. -/
theorem span_char_dense (sep : ∀ x y : X, x≠y → ∃ i, c i x ≠ c i y) :
    (span ℂ (range c)).topologicalClosure = ⊤ := by
  have se : (algebra c inv).SeparatesPoints := by
    intro x y h
    obtain ⟨i,hi⟩ := sep x y h
    exact ⟨_,⟨c i,subset_adjoin ⟨i,rfl⟩,rfl⟩,hi⟩
  rw [←algebra_span c unit prod inv]
  exact congr_arg (Subalgebra.toSubmodule <| StarSubalgebra.toSubalgebra ·)
    (ContinuousMap.starSubalgebra_topologicalClosure_eq_top_of_separatesPoints _ se)
end Polynomial

variable {G : Type*} [CommGroup G] [TopologicalSpace G] [IsTopologicalGroup G]
  [CompactSpace G] [T2Space G]
open CompactDualReduction

def wave (χ : PontryaginDual G) : C(G,ℂ) := ⟨fun x => (χ x:ℂ),continuous_subtype_val.comp χ.continuous⟩

omit [IsTopologicalGroup G] [CompactSpace G] [T2Space G] in
private theorem wave_one : wave (1 : PontryaginDual G) = 1 := rfl
omit [IsTopologicalGroup G] [CompactSpace G] [T2Space G] in
private theorem wave_mul (χ φ : PontryaginDual G) : wave (χ*φ) = wave χ * wave φ := rfl
omit [IsTopologicalGroup G] [CompactSpace G] [T2Space G] in
private theorem wave_inv (χ : PontryaginDual G) : wave χ⁻¹ = star (wave χ) := by
  ext x
  exact Circle.coe_inv_eq_conj _

omit [CompactSpace G] in
theorem separate (b : OpenBasis G) (x y:G) (hne:x≠y) :
    ∃ χ : PontryaginDual G, wave χ x ≠ wave χ y := by
  have hn := div_ne_one.mpr hne
  have nbh : ({x/y}ᶜ : Set G) ∈ 𝓝 1 := isOpen_compl_singleton.mem_nhds (by simpa using Ne.symm hn)
  obtain ⟨H,hH⟩ := b _ nbh
  obtain ⟨χ,_,hχ⟩ := distinguishes_subgroup H (g:=x/y) (fun hg => hH hg rfl)
  exact ⟨χ,fun he => hχ (by rw [map_div,show χ x=χ y from Subtype.ext he]; simp)⟩

variable [MeasurableSpace G] [BorelSpace G] (μ : Measure G)
  [μ.IsHaarMeasure] [IsProbabilityMeasure μ]

abbrev waveLp (χ : PontryaginDual G) : Lp ℂ 2 μ :=
  ContinuousMap.toLp 2 μ ℂ (wave χ)

omit [IsTopologicalGroup G] [T2Space G] [μ.IsHaarMeasure] in
theorem wave_ae (χ : PontryaginDual G) :
    (waveLp μ χ : G → ℂ) =ᵐ[μ] (fun x => (χ x:ℂ)) :=
  ContinuousMap.coeFn_toLp μ (wave χ)

omit [CompactSpace G] [T2Space G] in
theorem integral_wave (χ : PontryaginDual G) [Decidable (χ=1)] :
    ∫ x, (χ x:ℂ) ∂μ = if χ=1 then 1 else 0 := by
  classical
  by_cases h : χ=1
  · subst χ; simp
  rw [if_neg h]
  obtain ⟨x,hx⟩ : ∃ x:G, χ x ≠1 := by
    by_contra! hn
    exact h (PontryaginDual.ext hn)
  have tr := integral_mul_left_eq_self (μ:=μ) (fun y : G => (χ y:ℂ)) x
  simp only [map_mul,Circle.coe_mul,integral_const_mul] at tr
  by_contra nz
  exact hx (Subtype.ext ((mul_eq_right₀ nz).mp tr))

omit [T2Space G] in
theorem wave_orthonormal : Orthonormal ℂ (waveLp μ : PontryaginDual G → _) := by
  classical
  apply orthonormal_iff_ite.mpr
  intro i j
  rw [MeasureTheory.L2.inner_def]
  have ex : (fun x => inner ℂ (waveLp μ i x) (waveLp μ j x)) =ᵐ[μ] fun x => ((j/i) x : ℂ) := by
    filter_upwards [wave_ae μ i,wave_ae μ j] with x hi hj
    rw [hi,hj,RCLike.inner_apply]
    change _ = ((j x / i x : Circle) : ℂ)
    rw [div_eq_mul_inv,Circle.coe_mul,Circle.coe_inv_eq_conj]
  rw [integral_congr_ae ex,integral_wave]
  by_cases h : i=j
  · simp [h]
  · simp [h,div_ne_one.mpr (Ne.symm h)]

theorem span_waveLp (b : OpenBasis G) :
    (span ℂ (range (waveLp μ : PontryaginDual G → _))).topologicalClosure = ⊤ := by
  have dense := span_char_dense (wave (G:=G)) wave_one wave_mul wave_inv (separate b)
  convert! (ContinuousMap.toLp_denseRange ℂ μ ℂ (by simp : (2:ℝ≥0∞)≠⊤)).topologicalClosure_map_submodule dense
  rw [map_span]
  unfold waveLp
  rw [range_comp']
  simp only [ContinuousLinearMap.coe_coe]

def fourierBasis (b : OpenBasis G) : HilbertBasis (PontryaginDual G) ℂ (Lp ℂ 2 μ) :=
  HilbertBasis.mk (wave_orthonormal μ) (span_waveLp μ b).ge

theorem basis_coe (b : OpenBasis G) : ⇑(fourierBasis μ b) = waveLp μ :=
  HilbertBasis.coe_mk _ _

end KDClosure.CompactFourier
