import KDCompactFourierBasis
import Mathlib.MeasureTheory.Measure.HasOuterApproxClosed

/-! Compact bidual evaluation preserves normalized Haar. The proof uses
density of the evaluation polynomials on the bidual itself, avoiding any
assumed Pontryagin biduality or LCA Plancherel theorem. -/
noncomputable section
namespace KDClosure.CompactFourier
open MeasureTheory Set SubgroupMeasure
open scoped Topology KDClosure.SubgroupMeasure ComplexConjugate

variable {G : Type*} [CommGroup G] [TopologicalSpace G] [IsTopologicalGroup G]
  [CompactSpace G] [T2Space G]

def evalAt (x:G) : PontryaginDual (PontryaginDual G) :=
  ⟨{toFun := fun φ => φ x, map_one' := rfl, map_mul' := fun _ _ => rfl},
   continuous_of_discreteTopology⟩

omit [IsTopologicalGroup G] [T2Space G] in
theorem eval_cont : Continuous (evalAt (G:=G)) := by
  apply (ContinuousMonoidHom.isInducing_toContinuousMap (PontryaginDual G) Circle).continuous_iff.mpr
  apply ContinuousMap.homeoFnOfDiscrete.isInducing.continuous_iff.mpr
  exact continuous_pi (fun χ => χ.continuous)

private def probe (ξ : PontryaginDual G) : C(PontryaginDual (PontryaginDual G),ℂ) :=
  ⟨fun u => (u ξ:ℂ), continuous_subtype_val.comp (continuous_eval_const
    (F:=PontryaginDual G →ₜ* Circle) ξ)⟩

omit [T2Space G] in
private theorem probes_dense :
    (Submodule.span ℂ (range (probe (G:=G)))).topologicalClosure = ⊤ := by
  apply span_char_dense _ ?_ ?_ ?_ ?_
  · ext x; simp [probe]
  · intro i j; ext x; simp [probe]
  · intro i; ext x
    change ((x i⁻¹ : Circle) : ℂ) = _
    rw [map_inv,Circle.coe_inv_eq_conj]; rfl
  · intro x y h
    by_contra! eqn
    exact h (PontryaginDual.ext (fun i => Subtype.ext (eqn i)))

variable [MeasurableSpace G] [BorelSpace G] (μ : Measure G)
  [μ.IsHaarMeasure] [IsProbabilityMeasure μ]

private def mean {X : Type*} [TopologicalSpace X] [CompactSpace X] [MeasurableSpace X] [BorelSpace X]
    (ν : Measure X) [IsFiniteMeasure ν] : C(X,ℂ) →L[ℂ] ℂ :=
  (MeasureTheory.L1.integralCLM' (α:=X) (E:=ℂ) (μ:=ν) ℂ).comp (ContinuousMap.toLp 1 ν ℂ)

private theorem mean_eq {X : Type*} [TopologicalSpace X] [CompactSpace X] [MeasurableSpace X]
    [BorelSpace X] (ν : Measure X) [IsFiniteMeasure ν] (f : C(X,ℂ)) :
    mean ν f = ∫ x, f x ∂ν := by
  let t := ContinuousMap.toLp 1 ν ℂ f
  change MeasureTheory.L1.integralCLM' ℂ t = _
  rw [←MeasureTheory.L1.integral_eq' ℂ,MeasureTheory.L1.integral_eq_integral]
  exact integral_congr_ae (ContinuousMap.coeFn_toLp ν f)

/-- Haar probabilities correspond under true compact bidual evaluation.
Second countability is used in the finite-measure extensionality step. -/
theorem eval_preserves [SecondCountableTopology G] :
    MeasurePreserving (evalAt (G:=G)) μ (dualHaar (PontryaginDual G)) := by
  classical
  let D := PontryaginDual G
  let B := PontryaginDual D
  let ν := dualHaar D
  let κ := Measure.map (evalAt (G:=G)) μ
  have m : Measurable (evalAt (G:=G)) := eval_cont.measurable
  let _ : IsProbabilityMeasure κ := Measure.isProbabilityMeasure_map m.aemeasurable
  have equal : mean κ = mean ν := by
    apply ContinuousLinearMap.ext_on (s:=range (probe (G:=G)))
    · intro x
      change x ∈ (Submodule.span ℂ (range (probe (G:=G)))).topologicalClosure
      rw [probes_dense]; trivial
    · rintro _ ⟨i,rfl⟩
      rw [mean_eq,mean_eq]
      change (∫ z, probe i z ∂Measure.map evalAt μ) = ∫ z, (z i : ℂ) ∂dualHaar D
      rw [integral_map m.aemeasurable (probe i).continuous.aestronglyMeasurable]
      exact (integral_wave μ i).trans (DiscreteOrtho.integral_eval D i).symm
  let _ : Countable D := CompactDualReduction.dual_countable
  let _ : SecondCountableTopology D := inferInstance
  let _ : SecondCountableTopology B :=
    (ContinuousMonoidHom.isInducing_toContinuousMap D Circle).secondCountableTopology
  refine ⟨m,ext_of_forall_integral_eq_of_IsFiniteMeasure (Ω:=B) (μ:=κ) (ν:=ν) ?_⟩
  intro f
  let z : C(B,ℂ) := ⟨fun x => (f x:ℂ), Complex.continuous_ofReal.comp f.continuous⟩
  have eqn := DFunLike.congr_fun equal z
  rw [mean_eq,mean_eq] at eqn
  apply Complex.ofReal_injective
  rw [← integral_complex_ofReal, ← integral_complex_ofReal]
  exact eqn

end KDClosure.CompactFourier
