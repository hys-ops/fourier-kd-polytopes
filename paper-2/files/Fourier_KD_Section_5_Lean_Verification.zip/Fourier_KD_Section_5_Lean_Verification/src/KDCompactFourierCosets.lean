import KDCompactFourierHaar
import Mathlib.Dynamics.Ergodic.MeasurePreserving
import Mathlib.MeasureTheory.Integral.Bochner.SumMeasure

noncomputable section
namespace KDClosure.CompactFourier.Coset
open MeasureTheory MeasureTheory.Measure Set Function Topology
open scoped Topology
variable {G : Type*} [CommGroup G] [TopologicalSpace G] [IsTopologicalGroup G]
    [MeasurableSpace G] [BorelSpace G] (N : OpenSubgroup G) (μ : Measure G) [μ.IsHaarMeasure]

def chart (g : G) (n : N) := g * n.val

def fiber (g : G) : Set G := {x | g⁻¹*x ∈ N}

omit [IsTopologicalGroup G] [MeasurableSpace G] [BorelSpace G] in
theorem chart_range (g : G) : range (chart N g) = fiber N g := by
  ext x
  constructor
  · rintro ⟨n,rfl⟩
    change g⁻¹*(g*n.val)∈N
    simp
  · intro h
    exact ⟨⟨g⁻¹*x,h⟩,by simp [chart]⟩

theorem chart_measurableEmbedding (g : G) : MeasurableEmbedding (chart N g) :=
  (MeasurableEquiv.mulLeft g).measurableEmbedding.comp (MeasurableEmbedding.subtype_coe N.isOpen.measurableSet)

theorem chart_preserves (g : G) : MeasurePreserving (chart N g) (μ.comap (Subtype.val : N → G))
    (μ.restrict (fiber N g)) := by
  have sub : MeasurePreserving (Subtype.val : N→G) (μ.comap Subtype.val) (μ.restrict (N:Set G)) :=
    ⟨measurable_subtype_coe,map_comap_subtype_coe N.isOpen.measurableSet μ⟩
  have tr := (measurePreserving_mul_left μ g).restrict_image_emb (MeasurableEquiv.mulLeft g).measurableEmbedding (N : Set G)
  have eq : (g*·) '' (N:Set G) = fiber N g := by
    rw [←chart_range]
    ext x
    exact ⟨fun ⟨n,hn,h⟩ => ⟨⟨n,hn⟩,h⟩,fun ⟨n,h⟩ => ⟨n,n.property,h⟩⟩
  rw [eq] at tr
  exact tr.comp sub

omit [IsTopologicalGroup G] [MeasurableSpace G] [BorelSpace G] in
theorem fiber_quot (g : G) : fiber N g = {x | QuotientGroup.mk' N.toSubgroup x = QuotientGroup.mk' N.toSubgroup g} := by
  ext x
  change g⁻¹*x ∈ N.toSubgroup ↔ (x : G ⧸ N.toSubgroup) = (g : G ⧸ N.toSubgroup)
  rw [QuotientGroup.eq_iff_div_mem,div_eq_mul_inv,mul_comm]

/-- Disintegration of Haar on a countable family of open cosets, without
normalization or compactness assumptions on the open subgroup. -/
theorem sum_charts [Countable (G ⧸ N.toSubgroup)] (r : (G ⧸ N.toSubgroup) → G)
    (hr : ∀ j, QuotientGroup.mk' N.toSubgroup (r j) = j) :
    μ = Measure.sum (fun j => (μ.comap (Subtype.val : N→G)).map (chart N (r j))) := by
  let p := QuotientGroup.mk' N.toSubgroup
  have cells (j) : fiber N (r j) = {x | p x = j} := by rw [fiber_quot,hr]
  have dj : Pairwise (Disjoint on fun j => fiber N (r j)) := by
    intro a b h
    rw [Function.onFun,cells,cells,Set.disjoint_left]
    exact fun x ha hb => h (ha.symm.trans hb)
  have meas (j) : MeasurableSet (fiber N (r j)) := N.isOpen.measurableSet.preimage (continuous_const.mul continuous_id).measurable
  have cover : (⋃ j, fiber N (r j)) = univ := by
    apply eq_univ_of_forall
    intro x
    exact mem_iUnion.mpr ⟨p x,(cells _).symm ▸ rfl⟩
  have eq := Measure.restrict_iUnion (μ:=μ) dj meas
  rw [cover,restrict_univ] at eq
  simpa only [(chart_preserves N μ _).map_eq] using eq

end KDClosure.CompactFourier.Coset
