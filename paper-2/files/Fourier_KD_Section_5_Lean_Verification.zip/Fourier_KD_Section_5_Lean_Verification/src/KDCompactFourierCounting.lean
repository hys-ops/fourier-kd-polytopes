import KDCompactFourierRepresent

noncomputable section
namespace KDClosure.CompactFourier
open Set MeasureTheory MeasureTheory.Measure
open scoped ENNReal ComplexConjugate
variable {D : Type*} [MeasurableSpace D] [MeasurableSingletonClass D] [Countable D]

private theorem lp_count_iff (f : D → ℂ) : MemLp f 2 .count ↔ Memℓp f 2 := by
  have meas : Measurable f := measurable_of_countable f
  rw [memLp_two_iff_integrable_sq_norm meas.aestronglyMeasurable,integrable_count_iff,
    memℓp_gen_iff (by norm_num : 0 < (2:ℝ≥0∞).toReal)]
  simp only [ENNReal.toReal_ofNat,Real.rpow_two,Real.norm_eq_abs,abs_pow,abs_norm]

/-- Counting-measure L² and square-summable sequences, with coefficients
literally equal at each point; no arbitrary representatives are involved. -/
def countEquiv : Lp ℂ 2 (count : Measure D) ≃ₗᵢ[ℂ] Discrete.L2 D where
  toFun f := ⟨(fun x => f x),(lp_count_iff f).mp (Lp.memLp f)⟩
  invFun f := ((lp_count_iff f).mpr f.property).toLp f
  left_inv f := by apply Lp.ext; exact MemLp.coeFn_toLp _
  right_inv f := by
    apply lp.ext
    funext x
    exact ae_count_iff.mp (((lp_count_iff f).mpr f.property).coeFn_toLp) x
  map_add' f g := by apply lp.ext; funext x; exact ae_count_iff.mp (Lp.coeFn_add f g) x
  map_smul' c f := by apply lp.ext; funext x; exact ae_count_iff.mp (Lp.coeFn_smul c f) x
  norm_map' f := by
    let g : Discrete.L2 D := ⟨(fun x => f x),(lp_count_iff f).mp (Lp.memLp f)⟩
    change ‖g‖ = ‖f‖
    have hi := (memLp_two_iff_integrable_sq_norm (Lp.aestronglyMeasurable f)).mp (Lp.memLp f)
    have sum : (∑' i, ‖f i‖^2) = ‖f‖^2 := by
      rw [←sq_integral,integral_countable hi]
      simp [measureReal_def]
    have sn := lp.hasSum_norm (by norm_num : 0 < (2:ℝ≥0∞).toReal) g
    have sq : ‖g‖^2 = ‖f‖^2 := by
      apply Eq.trans _ sum
      simpa only [ENNReal.toReal_ofNat,Real.rpow_two] using sn.tsum_eq.symm
    nlinarith [norm_nonneg g,norm_nonneg f]

theorem countEquiv_apply (f : Lp ℂ 2 (count : Measure D)) (x : D) :
    countEquiv f x = f x := rfl

theorem countEquiv_symm_apply (f : Discrete.L2 D) (x : D) :
    countEquiv.symm f x = f x :=
  congrArg (fun z : Discrete.L2 D => z x) (countEquiv.apply_symm_apply f)

end KDClosure.CompactFourier
