import KDCompactFourierBasis
import Mathlib.MeasureTheory.Function.LpSpace.InfiniteSum

noncomputable section
namespace KDClosure.CompactFourier
open Set MeasureTheory SubgroupMeasure Submodule
open scoped KDClosure.SubgroupMeasure ComplexConjugate
variable (D : Type*) [CommGroup D] [TopologicalSpace D] [DiscreteTopology D]

private def evaluationWave (x : D) : C(PontryaginDual D,ℂ) :=
  ⟨fun χ => (χ x:ℂ),continuous_subtype_val.comp (continuous_eval_const (F:=ContinuousMonoidHom D Circle) x)⟩

theorem discrete_span :
    (span ℂ (range (DiscreteOrtho.basis D))).topologicalClosure = ⊤ := by
  have den : (span ℂ (range (evaluationWave D))).topologicalClosure = ⊤ := by
    apply span_char_dense _ ?_ ?_ ?_ ?_
    · ext x; simp [evaluationWave]
    · intro i j; ext x; simp [evaluationWave]
    · intro i; ext x
      change ((x i⁻¹ : Circle) : ℂ) = _
      rw [map_inv,Circle.coe_inv_eq_conj]; rfl
    · intro x y hn
      by_contra! h
      exact hn (PontryaginDual.ext fun i => Subtype.ext (h i))
  have eqn : DiscreteOrtho.basis D = ContinuousMap.toLp 2 (dualHaar D) ℂ ∘ evaluationWave D := by
    funext x
    apply Lp.ext
    filter_upwards [DiscreteOrtho.basis_ae D x,ContinuousMap.coeFn_toLp (𝕜:=ℂ) (p:=2) (dualHaar D) (evaluationWave D x)] with χ h t
    exact h.trans t.symm
  convert! (ContinuousMap.toLp_denseRange ℂ (dualHaar D) ℂ (by simp : (2:ENNReal)≠⊤)).topologicalClosure_map_submodule den using 2
  rw [eqn,Set.range_comp,map_span]; rfl

def discreteFourierBasis : HilbertBasis D ℂ (Lp ℂ 2 (dualHaar D)) :=
  HilbertBasis.mk (DiscreteOrtho.basis_orthonormal D) (discrete_span D).ge

theorem discrete_basis_coe : ⇑(discreteFourierBasis D) = DiscreteOrtho.basis D := HilbertBasis.coe_mk _ _

/-- The genuine discrete Fourier transform on absolutely summable vectors
is represented on the compact dual by the positive-phase Fourier series. -/
theorem discrete_series [Countable D] (f : lp (fun _ : D => ℂ) 2) (hi : Summable fun x => ‖f x‖) :
    ((discreteFourierBasis D).repr.symm f : PontryaginDual D → ℂ) =ᵐ[dualHaar D]
      fun χ => ∑' x, f x * (χ x : ℂ) := by
  let t (x) := f x • DiscreteOrtho.basis D x
  have hs : HasSum t ((discreteFourierBasis D).repr.symm f) := by
    simpa only [t,discrete_basis_coe] using (discreteFourierBasis D).hasSum_repr_symm f
  have hn : Summable (fun x => ‖t x‖) := by
    simpa only [t,norm_smul,(DiscreteOrtho.basis_orthonormal D).norm_eq_one,mul_one] using hi
  have a : ∀ᵐ χ ∂dualHaar D, ∀ x, t x χ = f x * (χ x : ℂ) := by
    apply ae_all_iff.mpr
    intro x
    filter_upwards [Lp.coeFn_smul (f x) (DiscreteOrtho.basis D x),DiscreteOrtho.basis_ae D x] with χ h hz
    change t x χ = f x * DiscreteOrtho.basis D x χ at h
    rw [h,hz]
  rw [←hs.tsum_eq]
  filter_upwards [Lp.coeFn_tsum (tsum_enorm_ne_top_iff_summable_norm.mpr hn),a] with χ h p
  exact h.trans (tsum_congr p)
end KDClosure.CompactFourier
