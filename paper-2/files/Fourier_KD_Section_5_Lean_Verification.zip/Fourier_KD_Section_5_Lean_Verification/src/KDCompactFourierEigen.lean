import KDCompactFourierBasis
import Mathlib.Analysis.InnerProductSpace.Spectrum
import Mathlib.LinearAlgebra.Eigenspace.Triangularizable

noncomputable section
namespace KDClosure.CompactFourier
open Set Module Module.End
open scoped ComplexConjugate

/-- A commuting family of endomorphisms on a finite-dimensional nonzero complex
vector space has a common eigenvector, for an arbitrary index set. -/
theorem common_eigenvector {J V : Type*} [AddCommGroup V] [Module ℂ V]
    [FiniteDimensional ℂ V] [Nontrivial V] (A : J → Module.End ℂ V)
    (ab : ∀ s t x, A s (A t x) = A t (A s x)) :
    ∃ (v : V) (_ : v ≠ 0) (c : J → ℂ), ∀ s, A s v = c s • v := by
  classical
  generalize hn : Module.finrank ℂ V = n
  induction n using Nat.strongRecOn generalizing V with | ind n ih => ?_
  by_cases scalar : ∀ s, ∃ c : ℂ, ∀ v, A s v = c • v
  · choose c hc using scalar
    obtain ⟨v,hv⟩ := exists_ne (0 : V)
    exact ⟨v,hv,c,fun s => hc s v⟩
  push Not at scalar
  obtain ⟨s,diff⟩ := scalar
  obtain ⟨mu₀,eig⟩ := (A s).exists_eigenvalue
  let W := (A s).eigenspace mu₀
  have wne : W ≠ ⊥ := eig
  let _ : Nontrivial W := Submodule.nontrivial_iff_ne_bot.mpr wne
  have wt : W ≠ ⊤ := by
    obtain ⟨v,hv⟩ := diff mu₀
    exact fun hh => hv (mem_eigenspace_iff.mp (show v∈W by rw [hh]; trivial))
  have inv (j) (x) (hx : x ∈ W) : A j x ∈ W := by
    rw [mem_eigenspace_iff] at hx ⊢
    rw [ab,hx,map_smul]
  let R (j) := (A j).restrict (inv j)
  have comm (s t) (x : W) : R s (R t x) = R t (R s x) := Subtype.ext (ab s t _)
  obtain ⟨v,hv,c,hc⟩ := ih _ ((Submodule.finrank_lt wt).trans_eq hn) R comm rfl
  exact ⟨v.val,fun h => hv (Subtype.ext h),c,fun j => congrArg Subtype.val (hc j)⟩

section Representation
variable {G H : Type*} [CommGroup G] [TopologicalSpace G]
  [NormedAddCommGroup H] [InnerProductSpace ℂ H]

/-- Extract an actual continuous circle character from a finite invariant
subspace in which a designated group element has no nonzero fixed vector. -/
theorem character_of_finite_invariant (U : G → H ≃ₗᵢ[ℂ] H)
    (one : ∀ x, U 1 x = x) (mul : ∀ g h x, U (g*h) x = U g (U h x))
    (cont : ∀ x, Continuous fun g => U g x) (g₀ : G)
    (W : Submodule ℂ H) [FiniteDimensional ℂ W] (wne : W ≠ ⊥)
    (inv : ∀ g x, x∈W → U g x ∈W)
    (moves : ∀ x∈W, U g₀ x = x → x = 0) :
    ∃ χ : PontryaginDual G, χ g₀ ≠ 1 := by
  let _ : Nontrivial W := Submodule.nontrivial_iff_ne_bot.mpr wne
  let A g := (U g).toLinearEquiv.toLinearMap.restrict (inv g)
  have ab (g h) (x : W) : A g (A h x) = A h (A g x) := by
    apply Subtype.ext
    change U g (U h x.val) = U h (U g x.val)
    rw [←mul,←mul,mul_comm]
  obtain ⟨v,hv,c,eig⟩ := common_eigenvector A ab
  have e (g) : U g v.val = c g • v.val := congrArg Subtype.val (eig g)
  have nv : v.val ≠ 0 := fun h => hv (Subtype.ext h)
  have cn (g) : ‖c g‖ = 1 := by
    have z := (U g).norm_map v.val
    rw [e,norm_smul] at z
    exact (mul_eq_right₀ (norm_ne_zero_iff.mpr nv)).mp z
  have inj (a b : ℂ) : a • v.val = b • v.val → a = b := by
    intro h
    exact (smul_left_injective _ nv) h
  have den : inner ℂ v.val v.val ≠ 0 := inner_self_ne_zero.mpr nv
  have hc (g) : c g = inner ℂ v.val (U g v.val) / inner ℂ v.val v.val := by
    rw [e,inner_smul_right]; field_simp
  let χ : PontryaginDual G :=
    { toFun := fun g => ⟨c g,by change dist (c g) 0 = 1; simpa using cn g⟩
      map_one' := by apply Subtype.ext; change c 1 = 1; apply inj; rw [←e,one,one_smul]
      map_mul' := fun g h => by
        apply Subtype.ext; change c (g*h) = c g * c h
        apply inj
        rw [←e,mul,e h,map_smul,e g,smul_smul,mul_comm]
      continuous_toFun := by
        apply Continuous.subtype_mk
        simpa only [funext hc] using ((continuous_const.inner (cont v.val)).div_const (inner ℂ v.val v.val)) }
  refine ⟨χ,fun h => nv (moves _ v.property ?_)⟩
  have c1 : c g₀ = 1 := congrArg Subtype.val h
  rw [e,c1,one_smul]
end Representation
end KDClosure.CompactFourier
