import KDCompactFourierRealization
import KDCompactFourierCosets

noncomputable section
namespace KDClosure.CompactFourier
open MeasureTheory MeasureTheory.Measure Set SubgroupMeasure
open scoped KDClosure.SubgroupMeasure ENNReal NNReal ComplexConjugate
variable {X : Type*} [MeasurableSpace X]

def energy (μ : Measure X) (f : X → ℂ) : ℝ≥0∞ := ∫⁻ x, ‖f x‖ₑ ^ 2 ∂μ

theorem energy_eLp (μ : Measure X) (f : X → ℂ) : energy μ f = eLpNorm f 2 μ ^ 2 := by
  simpa only [energy,NNReal.coe_ofNat,ENNReal.coe_ofNat,ENNReal.rpow_ofNat] using
    (eLpNorm_nnreal_pow_eq_lintegral (f:=f) (μ:=μ) (p:=(2:ℝ≥0)) (by norm_num)).symm

theorem energy_Lp (μ : Measure X) (f : Lp ℂ 2 μ) : energy μ f = ‖f‖ₑ^2 := by rw [energy_eLp,Lp.enorm_def]

theorem energy_congr {μ : Measure X} {f g : X → ℂ} (h : f =ᵐ[μ] g) : energy μ f = energy μ g :=
  lintegral_congr_ae (h.mono fun _ e => congrArg (fun z : ℂ => ‖z‖ₑ^2) e)

theorem count_energy [MeasurableSingletonClass X] (f : X → ℂ) : energy count f = ∑' x, ‖f x‖ₑ^2 :=
  lintegral_count _

/-- Parseval in a compact position fiber, for true scalar character integrals. -/
theorem energy_compact {K : Type*} [CommGroup K] [TopologicalSpace K] [IsTopologicalGroup K]
    [CompactSpace K] [T2Space K] [SecondCountableTopology K] [MeasurableSpace K] [BorelSpace K]
    (μ : Measure K) [μ.IsHaarMeasure] [IsProbabilityMeasure μ] {f : K → ℂ} (hf : MemLp f 2 μ) :
    (∑' χ : PontryaginDual K, ‖∫ x, f x * (χ x:ℂ) ∂μ‖ₑ^2) = energy μ f := by
  let v := hf.toLp f
  have he (χ : PontryaginDual K) : ∫ x, f x * (χ x:ℂ) ∂μ = compactForward μ v χ := by
    rw [compactForward_eval]
    exact integral_congr_ae (hf.coeFn_toLp.symm.mono fun x hx => congrArg (· * (χ x:ℂ)) hx)
  simp only [he,←count_energy,energy_Lp,LinearIsometry.enorm_map]
  exact (energy_Lp μ v).symm.trans (energy_congr hf.coeFn_toLp)

/-- Parseval in a discrete position fiber, with ordinary pointwise (indeed
absolutely convergent) positive-phase Fourier series. -/
theorem energy_discrete {D : Type*} [CommGroup D] [TopologicalSpace D] [DiscreteTopology D] [Countable D]
    {f : D → ℂ} (hf : Summable fun i => ‖f i‖) :
    energy (dualHaar D) (fun φ => ∑' i, f i * (φ i : ℂ)) = ∑' i, ‖f i‖ₑ^2 := by
  let _ : MeasurableSpace D := borel D
  let _ : BorelSpace D := ⟨rfl⟩
  have sq : Summable (fun i => ‖f i‖^2) := by
    apply (hf.mul_left (∑' i, ‖f i‖)).of_nonneg_of_le (fun _ => sq_nonneg _)
    intro i
    rw [pow_two]
    exact mul_le_mul_of_nonneg_right (hf.le_tsum i (fun _ _ => norm_nonneg _)) (norm_nonneg _)
  let v : Discrete.L2 D := ⟨f,memℓp_gen (by simpa only [ENNReal.toReal_ofNat,Real.rpow_two] using sq)⟩
  have eqn := discrete_series D v hf
  calc
    _ = energy (dualHaar D) ((discreteFourierBasis D).repr.symm v) := energy_congr eqn.symm
    _ = ‖v‖ₑ^2 := by rw [energy_Lp,LinearIsometryEquiv.enorm_map]
    _ = energy (count : Measure D) (countEquiv.symm v) := by rw [energy_Lp,LinearIsometryEquiv.enorm_map]
    _ = _ := by rw [count_energy]; exact tsum_congr fun i => by rw [countEquiv_symm_apply]
end KDClosure.CompactFourier
