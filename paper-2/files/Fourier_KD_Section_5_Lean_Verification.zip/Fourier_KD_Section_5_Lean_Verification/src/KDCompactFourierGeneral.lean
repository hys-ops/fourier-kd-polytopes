import KDCompactFourierMixed
import KDLCAQuotientDenseFourier
import KDLCAQuotientRows

/-! Concrete Fourier realizations from a single compact open subgroup.
Position and frequency Haar assign unit mass to a subgroup and its annihilator.
No character separation or Plancherel input is required from the caller. -/
noncomputable section
namespace KDClosure.CompactFourier.General
open MeasureTheory MeasureTheory.Measure TopologicalSpace Set CompactCore
open scoped KDClosure.SubgroupMeasure
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
    [MeasurableSpace G] [BorelSpace G] [T2Space G] [LocallyCompactSpace G] [SecondCountableTopology G]
variable (N : CO G)
local instance : MeasurableSpace (Multiplicative G) := ‹MeasurableSpace G›
local instance : BorelSpace (Multiplicative G) := ‹BorelSpace G›
local instance : T2Space (Multiplicative G) := ‹T2Space G›
local instance : LocallyCompactSpace (Multiplicative G) := ‹LocallyCompactSpace G›
local instance : SecondCountableTopology (Multiplicative G) := ‹SecondCountableTopology G›

def posCompact : PositiveCompacts G :=
  ⟨⟨N.val,N.property⟩,N.val.isOpen.interior_eq.symm ▸ ⟨0,N.val.zero_mem⟩⟩

def freqCompact : PositiveCompacts (LCAReality.Dual G) :=
  ⟨⟨CompactDualReduction.ann (LCAQuotient.openMul N), LCAQuotientDual.ann_compact _⟩,
    (LCAQuotientDual.ann_open (LCAQuotient.openMul N) N.property).interior_eq.symm ▸
      ⟨1,(CompactDualReduction.ann (LCAQuotient.openMul N)).one_mem⟩⟩

def positionHaar : Measure G := addHaarMeasure (posCompact N)
def frequencyHaar : Measure (LCAReality.Dual G) := haarMeasure (freqCompact N)
instance : (positionHaar N).IsAddHaarMeasure :=
  inferInstanceAs (IsAddHaarMeasure (addHaarMeasure (posCompact N)))
instance : (frequencyHaar N).IsHaarMeasure :=
  inferInstanceAs (IsHaarMeasure (haarMeasure (freqCompact N)))

omit [IsTopologicalAddGroup G] [MeasurableSpace G] [BorelSpace G] [T2Space G] in
theorem dual_secondCountable : SecondCountableTopology (LCAReality.Dual G) :=
  (ContinuousMonoidHom.isInducing_toContinuousMap (Multiplicative G) Circle).secondCountableTopology

instance : SigmaFinite (frequencyHaar N) := by
  let _ : SecondCountableTopology (LCAReality.Dual G) := dual_secondCountable (G:=G)
  infer_instance

variable (μ : Measure G) [μ.IsAddHaarMeasure] (ν : Measure (LCAReality.Dual G)) [ν.IsHaarMeasure]
local instance : Measure.IsMulLeftInvariant (G:=Multiplicative G) μ :=
  ⟨fun x => Measure.IsAddLeftInvariant.map_add_left_eq_self x.toAdd⟩
local instance : IsFiniteMeasureOnCompacts (α:=Multiplicative G) μ := inferInstanceAs (IsFiniteMeasureOnCompacts (α:=G) μ)
local instance : Measure.IsOpenPosMeasure (X:=Multiplicative G) μ := inferInstanceAs (Measure.IsOpenPosMeasure (X:=G) μ)
local instance : Measure.IsHaarMeasure (G:=Multiplicative G) μ := ⟨⟩

def realizationOfUnitMass (hN : μ (N.val : Set G)=1)
    (hA : ν (CompactDualReduction.ann (LCAQuotient.openMul N) : Set _)=1) :
    LCAReality.FourierRealization μ ν :=
  LCAReality.fourierOfParseval μ ν (fun f hf =>
    Mixed.scalar_parseval (LCAQuotient.openMul N) μ ν N.property hN hA f hf)

/-- On every second-countable LCA group with a compact open subgroup, the
directly constructed position/dual Haar pair has a true integral Fourier
isometry on all of L². -/
def realization : LCAReality.FourierRealization (positionHaar N) (frequencyHaar N) :=
  realizationOfUnitMass N _ _ addHaarMeasure_self haarMeasure_self

end KDClosure.CompactFourier.General
