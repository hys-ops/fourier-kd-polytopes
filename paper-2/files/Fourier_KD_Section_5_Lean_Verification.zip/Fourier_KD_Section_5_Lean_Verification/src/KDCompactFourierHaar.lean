import KDCompactFourierAllBasis

noncomputable section
namespace KDClosure.CompactFourier.Coset
open MeasureTheory Set
variable (K : Type*) [CommGroup K] [TopologicalSpace K] [IsTopologicalGroup K] [CompactSpace K]
  [MeasurableSpace K] [BorelSpace K]

private def full (K : Type*) [TopologicalSpace K] [Nonempty K] [CompactSpace K] :
    TopologicalSpace.PositiveCompacts K := ⟨⟨univ,isCompact_univ⟩,by simp⟩

/-- Probability Haar is normalized by the full compact group itself. -/
def probabilityHaar : Measure K := Measure.haarMeasure (full K)
instance : IsProbabilityMeasure (probabilityHaar K) := ⟨Measure.haarMeasure_self⟩
instance : (probabilityHaar K).IsHaarMeasure := inferInstanceAs (Measure.IsHaarMeasure (Measure.haarMeasure (full K)))
end KDClosure.CompactFourier.Coset
