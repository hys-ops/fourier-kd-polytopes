import KDCompactFourierTransfer
import Mathlib.Analysis.InnerProductSpace.StarOrder
import Mathlib.Analysis.SpecialFunctions.ContinuousFunctionalCalculus.Rpow.Basic
import Mathlib.MeasureTheory.Function.LpSpace.InfiniteSum

noncomputable section
namespace KDClosure.CompactFourier
open MeasureTheory Set Filter ContinuousLinearMap
open scoped ComplexConjugate ComplexOrder ENNReal Topology BigOperators

section General
variable {X I : Type*} [MeasurableSpace X] {ν : Measure X} [SFinite ν] [Countable I]
abbrev Space (ν : Measure X) := Lp ℂ 2 ν

omit [SFinite ν] in
theorem sq_integral (v : Space ν) : (∫ x, ‖v x‖ ^ 2 ∂ν) = ‖v‖ ^ 2 := by
  rw [norm_sq_eq_re_inner (𝕜:=ℂ),MeasureTheory.L2.inner_def,←integral_re]
  · apply integral_congr_ae
    exact ae_of_all _ fun x => (norm_sq_eq_re_inner (𝕜:=ℂ) (v x))
  · exact MeasureTheory.L2.integrable_inner v v

omit [SFinite ν] in
private theorem gram_mem (v : Space ν) :
    MemLp (fun z : X × X => v z.1 * conj (v z.2)) 2 (ν.prod ν) := by
  have h := (Lp.stronglyMeasurable v).measurable
  apply (memLp_two_iff_integrable_sq_norm (((h.comp measurable_fst).mul (Complex.continuous_conj.measurable.comp (h.comp measurable_snd))).aestronglyMeasurable)).2
  have hi := (memLp_two_iff_integrable_sq_norm (Lp.aestronglyMeasurable v)).1 (Lp.memLp v)
  change Integrable (fun z : X × X => ‖v z.1 * conj (v z.2)‖^2) _
  simpa only [norm_mul,Complex.norm_conj,mul_pow] using hi.mul_prod hi

def gram (v : Space ν) : Space (ν.prod ν) := (gram_mem v).toLp _

omit [SFinite ν] in
theorem gram_ae (v : Space ν) :
    (gram v : X × X → ℂ) =ᵐ[ν.prod ν] fun z => v z.1 * conj (v z.2) := (gram_mem v).coeFn_toLp

theorem norm_gram (v : Space ν) : ‖gram v‖ = ‖v‖ ^ 2 := by
  have h : ‖gram v‖^2 = (‖v‖^2)^2 := by
    rw [← sq_integral, ←sq_integral v]
    calc
      _ = ∫ z : X × X, ‖v z.1‖^2 * ‖v z.2‖^2 ∂(ν.prod ν) := by
        apply integral_congr_ae
        filter_upwards [gram_ae v] with z hz
        rw [hz,norm_mul,Complex.norm_conj,mul_pow]
      _ = _ := (integral_prod_mul (μ:=ν) (ν:=ν) (fun x => ‖v x‖^2) (fun x => ‖v x‖^2)).trans (sq _).symm
  nlinarith [norm_nonneg (gram v),sq_nonneg ‖v‖]

variable {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℂ H] [CompleteSpace H]
omit [Countable I] in
theorem root_columns (T : H →L[ℂ] H) (hp : T.IsPositive)
    (ht : BddAbove (frameMass T)) (b : HilbertBasis I ℂ H) :
    ∃ S : H →L[ℂ] H, S.adjoint = S ∧ (∀ x, T x = S (S x)) ∧
       Summable (fun i => ‖S (b i)‖^2) := by
  classical
  let S := CFC.sqrt T
  have sa : S.adjoint = S := (CFC.sqrt_nonneg T).star_eq
  have fact (x) : T x = S (S x) :=
    DFunLike.congr_fun (CFC.sqrt_mul_sqrt_self T ((nonneg_iff_isPositive T).mpr hp)).symm x
  refine ⟨S,sa,fact,?_⟩
  obtain ⟨M,hM⟩ := ht
  apply summable_of_sum_le (c:=M) (fun i => sq_nonneg _)
  intro t
  apply hM
  let j (k : Fin t.card) : I := (t.equivFin.symm k : t).val
  have hj : Function.Injective j := Subtype.val_injective.comp t.equivFin.symm.injective
  refine ⟨t.card,b ∘ j,b.orthonormal.comp j hj,?_⟩
  have tr (i) : (inner ℂ (b i) (T (b i))).re = ‖S (b i)‖^2 := by
    rw [fact,←sa]; rw [S.adjoint_inner_right,sa,norm_sq_eq_re_inner (𝕜:=ℂ)]; rfl
  simp only [Function.comp_apply,tr]
  exact (t.equivFin.symm.sum_comp (fun i : t => ‖S (b i.val)‖^2)).trans
    (t.sum_coe_sort (fun i => ‖S (b i)‖^2))

omit [SFinite ν] in
private theorem row_norms (a : I → Space ν) (hs : Summable fun i => ‖a i‖^2) :
    ∀ᵐ x ∂ν, Summable (fun i => ‖a i x‖ * ‖a i‖) := by
  let f (i : I) : Space ν := (‖a i‖:ℂ) • a i
  have hn : Summable (fun i => ‖f i‖) := by
    simpa only [f,norm_smul,Complex.norm_real,Real.norm_eq_abs,abs_norm,pow_two] using hs
  have summ := summable_norm_of_tsum_eLpNorm_ne_top (p:=(2:ℝ≥0∞)) (by norm_num)
    (fun i => Lp.aestronglyMeasurable (f i)) (by
      simpa only [←Lp.enorm_def] using tsum_enorm_ne_top_iff_summable_norm.mpr hn)
  have ae : ∀ᵐ x ∂ν, ∀ i, f i x = (‖a i‖:ℂ) * a i x :=
    ae_all_iff.mpr fun i => Lp.coeFn_smul _ _
  filter_upwards [summ,ae] with x h e
  simpa only [e,norm_mul,Complex.norm_real,Real.norm_eq_abs,abs_norm,mul_comm] using h

/-- A positive bounded-trace operator on a scalar L² space with a countable
Hilbert basis has an actual square-integrable jointly measurable kernel.
Its formula is a norm-absolutely converging series of rank-one kernels. -/
theorem exists_hermitian_kernel_of_frameBound (T : Space ν →L[ℂ] Space ν) (hp : T.IsPositive)
    (ht : BddAbove (frameMass T)) (b : HilbertBasis I ℂ (Space ν)) :
    ∃ k : Space (ν.prod ν), (∀ᵐ z ∂ν.prod ν, k z.swap = conj (k z)) ∧
      ∀ f : Space ν, ∀ᵐ x ∂ν,
      T f x = ∫ y, k (x,y) * f y ∂ν := by
  obtain ⟨S,sa,fact,hs⟩ := root_columns T hp ht b
  let a (i : I) := S (b i)
  have gs : Summable (fun i => ‖gram (a i)‖) := by simpa only [norm_gram] using hs
  let k := ∑' i, gram (a i)
  have raw : (k : X × X → ℂ) =ᵐ[ν.prod ν] fun z => ∑' i, a i z.1 * conj (a i z.2) := by
    have all_ae := ae_all_iff.mpr (fun i => gram_ae (a i))
    filter_upwards [Lp.coeFn_tsum (tsum_enorm_ne_top_iff_summable_norm.mpr gs),all_ae] with z hz he
    exact hz.trans (tsum_congr he)
  refine ⟨k,?_,?_⟩
  · have sw : ∀ᵐ z ∂ν.prod ν, k z.swap = ∑' i, a i z.2 * conj (a i z.1) :=
      (Measure.measurePreserving_swap (μ:=ν) (ν:=ν)).quasiMeasurePreserving.ae raw
    filter_upwards [sw,raw] with z hsw hr
    rw [hsw,hr]
    change _ = Complex.conjCLE.toContinuousLinearEquiv _
    rw [ContinuousLinearEquiv.map_tsum]
    apply tsum_congr
    intro i
    change _ = conj (_ * _)
    rw [map_mul,Complex.conj_conj,mul_comm]
  intro f
  let out (i : I) := (inner ℂ (a i) f) • a i
  have sOut : Summable (fun i => ‖out i‖) := by
    apply (hs.mul_right ‖f‖).of_nonneg_of_le (fun _ => norm_nonneg _)
    intro i
    rw [norm_smul]
    calc
      _ ≤ (‖a i‖*‖f‖)*‖a i‖ := mul_le_mul_of_nonneg_right (norm_inner_le_norm _ _) (norm_nonneg _)
      _ = _ := by change _ = ‖a i‖^2*‖f‖; ring
  have sumout : HasSum out (T f) := by
    rw [fact]
    convert! (b.hasSum_repr (S f)).mapL S using 1
    funext i
    simp only [out,a,map_smul,b.repr_apply_apply]
    congr 1
    conv_lhs => rw [←sa,S.adjoint_inner_left]
  have allOut : ∀ᵐ x ∂ν, ∀ i, out i x = (inner ℂ (a i) f) * (a i x) :=
    ae_all_iff.mpr fun i => Lp.coeFn_smul _ _
  filter_upwards [Measure.ae_ae_of_ae_prod raw,row_norms a hs,
    Lp.coeFn_tsum (tsum_enorm_ne_top_iff_summable_norm.mpr sOut), allOut] with x hraw hr ho hout
  rw [←sumout.tsum_eq,ho]
  let row (i : I) := conj (a i x) • a i
  have sr : Summable (fun i => ‖row i‖) := by
    simpa only [row,norm_smul,Complex.norm_conj] using hr
  have aeRow : ∀ᵐ y ∂ν, ∀ i, row i y = conj (a i x) * a i y :=
    ae_all_iff.mpr fun i => Lp.coeFn_smul _ _
  have rowRaw : ∀ᵐ y ∂ν, conj ((∑' i, row i : Space ν) y) = k (x,y) := by
    filter_upwards [Lp.coeFn_tsum (tsum_enorm_ne_top_iff_summable_norm.mpr sr),aeRow,hraw] with y hy he ky
    rw [hy,ky]
    change Complex.conjCLE.toContinuousLinearEquiv (∑' i, row i y) = _
    rw [ContinuousLinearEquiv.map_tsum]
    apply tsum_congr
    intro i
    change conj (row i y) = _
    rw [he,map_mul,Complex.conj_conj]
  have ip : inner ℂ (∑' i, row i) f = ∫ y, k (x,y) * f y ∂ν := by
    rw [MeasureTheory.L2.inner_def]
    apply integral_congr_ae
    filter_upwards [rowRaw] with y hy
    rw [RCLike.inner_apply,hy,mul_comm]
  rw [←ip]
  have inn := (sr.of_norm.hasSum.mapL ((innerSL ℂ).flip f)).tsum_eq
  apply Eq.trans _ inn
  apply tsum_congr
  intro i
  rw [hout]
  change _ = inner ℂ (conj (a i x) • a i) f
  rw [inner_smul_left,Complex.conj_conj,mul_comm]

theorem exists_kernel_of_frameBound (T : Space ν →L[ℂ] Space ν) (hp : T.IsPositive)
    (ht : BddAbove (frameMass T)) (b : HilbertBasis I ℂ (Space ν)) :
    ∃ k : Space (ν.prod ν), ∀ f : Space ν, ∀ᵐ x ∂ν,
      T f x = ∫ y, k (x,y) * f y ∂ν := by
  obtain ⟨k,_,h⟩ := exists_hermitian_kernel_of_frameBound T hp ht b
  exact ⟨k,h⟩

end General
end KDClosure.CompactFourier
