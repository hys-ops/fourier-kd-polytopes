import KDCompactFourierParseval
import KDLCAQuotientDual

noncomputable section
namespace KDClosure.CompactFourier.Mixed
open TopologicalSpace MeasureTheory MeasureTheory.Measure Set SubgroupMeasure CompactDualReduction
open scoped KDClosure.SubgroupMeasure ENNReal Topology
variable {G : Type*} [CommGroup G] [TopologicalSpace G] [IsTopologicalGroup G]
  [MeasurableSpace G] [BorelSpace G] [T2Space G] [LocallyCompactSpace G] [SecondCountableTopology G]
  (N : OpenSubgroup G)
local instance : DiscreteTopology (Q N) := QuotientGroup.discreteTopology N.isOpen
local instance : Countable (Q N) := by
  let _ : SecondCountableTopology (Q N) := QuotientGroup.instSecondCountableTopology N.toSubgroup
  exact separableSpace_iff_countable.mp inferInstance
local instance : SecondCountableTopology N := Subtype.secondCountableTopology (N : Set G)
def rep (q : Q N) : G := (QuotientGroup.mk'_surjective N.toSubgroup q).choose
omit [MeasurableSpace G] [BorelSpace G] [IsTopologicalGroup G] [T2Space G] [LocallyCompactSpace G]
    [SecondCountableTopology G] in
theorem rep_law (q : Q N) : QuotientGroup.mk' N.toSubgroup (rep N q) = q :=
  (QuotientGroup.mk'_surjective N.toSubgroup q).choose_spec

def lift (j : PontryaginDual N) : PontryaginDual G := (OpenCharacter.extends_of_open N j).choose
omit [MeasurableSpace G] [BorelSpace G] [T2Space G] [LocallyCompactSpace G] [SecondCountableTopology G] in
theorem lift_law (j : PontryaginDual N) (u : N) : lift N j (u:G) = j u :=
  (OpenCharacter.extends_of_open N j).choose_spec u

def freq (j : PontryaginDual N) (φ : PontryaginDual (Q N)) := lift N j * pull N φ

def res := SubgroupMeasure.restrictChar N.toSubgroup

omit [MeasurableSpace G] [BorelSpace G] [IsTopologicalGroup G] [T2Space G] [LocallyCompactSpace G]
    [SecondCountableTopology G] in
theorem ann_eq : (ann N : Set (PontryaginDual G)) = {χ | res N χ = 1} := by
  ext χ
  constructor
  · intro h
    exact PontryaginDual.ext fun u => h u.val u.property
  · intro h x hx
    exact congrArg (fun z : PontryaginDual N => z ⟨x,hx⟩) h

omit [MeasurableSpace G] [BorelSpace G] [T2Space G] [LocallyCompactSpace G] [SecondCountableTopology G] in
theorem res_lift (j : PontryaginDual N) : res N (lift N j) = j := PontryaginDual.ext (lift_law N j)

omit [MeasurableSpace G] [BorelSpace G] [T2Space G] [LocallyCompactSpace G] [SecondCountableTopology G] in
theorem freq_fiber (j : PontryaginDual N) :
    (lift N j * ·) '' (ann N : Set (PontryaginDual G)) = {χ | res N χ = j} := by
  rw [ann_eq]
  ext χ
  constructor
  · rintro ⟨t,ht,rfl⟩
    change res N (lift N j * t) = j
    rw [map_mul,show res N t=1 from ht,res_lift,mul_one]
  · intro h
    refine ⟨(lift N j)⁻¹*χ,?_,by simp⟩
    change res N ((lift N j)⁻¹*χ)=1
    rw [map_mul,map_inv,res_lift,show res N χ=j from h,inv_mul_cancel]

variable (μ : Measure G) [μ.IsHaarMeasure] (ν : Measure (PontryaginDual G)) [ν.IsHaarMeasure]

def positionSlices : Slices (Q N) μ (μ.comap (Subtype.val : N→G)) where
  atFiber := fun q => Coset.chart N (rep N q)
  emb := fun q => Coset.chart_measurableEmbedding N (rep N q)
  split := Coset.sum_charts N μ (rep N) (rep_law N)

def frequencySlices (compactN : IsCompact (N : Set G)) (oneDual : ν (ann N : Set _) = 1) :
    Slices (PontryaginDual N) ν (dualHaar (Q N)) where
  atFiber := freq N
  emb j := (MeasurableEquiv.mulLeft (lift N j)).measurableEmbedding.comp (LCAQuotientDual.pull_me N)
  split := by
    let _ : CompactSpace N := isCompact_iff_compactSpace.mp compactN
    let _ : Countable (PontryaginDual N) := CompactDualReduction.dual_countable
    have one := LCAQuotientDual.map_mass_eq_restrict N ν
    rw [oneDual,one_smul] at one
    have cell (j) : (dualHaar (Q N)).map (freq N j) = ν.restrict {χ | res N χ = j} := by
      have tr := (measurePreserving_mul_left ν (lift N j)).restrict_image_emb
        (MeasurableEquiv.mulLeft (lift N j)).measurableEmbedding (ann N : Set (PontryaginDual G))
      rw [freq_fiber] at tr
      have pr : MeasurePreserving (pull N) (dualHaar (Q N)) (ν.restrict (ann N : Set _)) :=
        ⟨(LCAQuotientDual.pull_me N).measurable,one⟩
      exact (tr.comp pr).map_eq
    have dj : Pairwise (Function.onFun Disjoint fun j : PontryaginDual N => {χ | res N χ = j}) :=
      fun _ _ hn => Set.disjoint_left.mpr fun _ ha hb => hn (ha.symm.trans hb)
    have meas (j : PontryaginDual N) : MeasurableSet {χ | res N χ = j} :=
      (res N).continuous.measurable (measurableSet_singleton j)
    have total : (⋃ j : PontryaginDual N, {χ | res N χ = j}) = univ :=
      eq_univ_of_forall fun χ => mem_iUnion.mpr ⟨res N χ,rfl⟩
    have eqn := Measure.restrict_iUnion (μ:=ν) dj meas
    rw [total,restrict_univ] at eqn
    simpa only [cell] using eqn

omit [T2Space G] [LocallyCompactSpace G] [SecondCountableTopology G] [MeasurableSpace G] [BorelSpace G] in
theorem factor (j : PontryaginDual N) (φ : PontryaginDual (Q N)) (i : Q N) (u : N) :
    freq N j φ (Coset.chart N (rep N i) u) = (lift N j (rep N i)) * j u * φ i := by
  change lift N j (rep N i * u.val) * φ (QuotientGroup.mk' N.toSubgroup (rep N i * u.val)) = _
  rw [map_mul,map_mul,rep_law,lift_law]
  have q : QuotientGroup.mk' N.toSubgroup u.val = 1 := (QuotientGroup.eq_one_iff _).mpr u.property
  rw [q,mul_one]

/-- Exact scalar Plancherel for the mixed case. The only normalizations are
unit Haar mass for N and for its annihilator. -/
theorem scalar_parseval (compactN : IsCompact (N : Set G)) (oneN : μ (N : Set G)=1)
    (oneDual : ν (ann N : Set _) = 1) (f : Lp ℂ 2 μ) (hf : Integrable (f:G→ℂ) μ) :
    ∃ m : MemLp (rawTransform μ f) 2 ν, ‖m.toLp (rawTransform μ f)‖=‖f‖ := by
  let _ : CompactSpace N := isCompact_iff_compactSpace.mp compactN
  let _ : MeasurableMul G := ⟨fun _ => (continuous_const.mul continuous_id).measurable,fun _ => (continuous_id.mul continuous_const).measurable⟩
  let _ : IsTopologicalGroup N := inferInstanceAs (IsTopologicalGroup N.toSubgroup)
  let _ : T2Space N := inferInstanceAs (T2Space (N : Set G))
  let κ := μ.comap (Subtype.val : N→G)
  let _ : κ.IsHaarMeasure := Measure.IsHaarMeasure.comap (mH:=(inferInstance : MeasurableMul G)) μ (f:=N.toSubgroup.subtype) N.isOpen.isOpenEmbedding_subtypeVal
  let _ : IsProbabilityMeasure κ := ⟨by
    change μ.comap (Subtype.val : N→G) univ=1
    calc
      _ = μ (Subtype.val '' (univ : Set N)) := Measure.comap_apply (Subtype.val : N→G) Subtype.val_injective
        (fun _ hs => (MeasurableEmbedding.subtype_coe N.isOpen.measurableSet).measurableSet_image.mpr hs) μ MeasurableSet.univ
      _ = 1 := by
        rw [image_univ,show range (Subtype.val : N→G) = (N:Set G) from Set.ext fun x => ⟨fun ⟨u,h⟩ => h ▸ u.property, fun h => ⟨⟨x,h⟩,rfl⟩⟩,oneN]⟩
  apply memLp_of_energy f
  exact double_parseval (positionSlices N μ) (frequencySlices N ν compactN oneDual)
    (fun j i => lift N j (rep N i)) (factor N) f hf
end KDClosure.CompactFourier.Mixed
