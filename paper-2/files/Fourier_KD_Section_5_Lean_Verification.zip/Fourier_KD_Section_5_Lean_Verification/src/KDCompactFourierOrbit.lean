import KDCompactFourierEigen
import Mathlib.Analysis.Convex.Integral
import Mathlib.MeasureTheory.Integral.Bochner.ContinuousLinearMap

noncomputable section
namespace KDClosure.CompactFourier
open Set Module Module.End MeasureTheory InnerProductSpace ContinuousLinearMap
open scoped ComplexConjugate Topology

/-- A compact abelian Haar orbit distinguishing a translation supplies a
genuine continuous character that distinguishes the same translation.
Averaging rank-one operators introduces no finite-dimensional representation
or character-separation hypothesis. -/
theorem character_of_moved_orbit {G H : Type*} [CommGroup G] [TopologicalSpace G]
    [IsTopologicalGroup G] [CompactSpace G] [T2Space G] [MeasurableSpace G] [BorelSpace G]
    (μ : Measure G) [μ.IsHaarMeasure] [IsProbabilityMeasure μ]
    [NormedAddCommGroup H] [InnerProductSpace ℂ H] [CompleteSpace H]
    (U : G → H ≃ₗᵢ[ℂ] H)
    (one : ∀ x, U 1 x = x) (mul : ∀ g h x, U (g*h) x = U g (U h x))
    (cont : ∀ x, Continuous fun g => U g x) (g₀ : G) (z : H) (moves : U g₀ z ≠ z) :
    ∃ χ : PontryaginDual G, χ g₀ ≠ 1 := by
  let v := U g₀ z - z
  have nv : v ≠ 0 := sub_ne_zero.mpr moves
  let w (g) := U g v
  let F (g) := rankOne ℂ (w g) (w g)
  have cf : Continuous F := (((rankOne ℂ (E:=H) (F:=H)).flip.continuous.comp (cont v)).clm_apply (cont v))
  have hf : Integrable F μ := cf.integrable_of_hasCompactSupport (HasCompactSupport.of_compactSpace _)
  let B := ∫ g, F g ∂μ
  have app (x : H) : B x = ∫ g, F g x ∂μ := integral_apply hf _
  have fi (x : H) : Integrable (fun g => F g x) μ :=
    ((ContinuousLinearMap.apply ℂ H x).continuous.comp cf).integrable_of_hasCompactSupport (HasCompactSupport.of_compactSpace _)
  have cp : IsCompactOperator B := by
    let K := compactOperator (RingHom.id ℂ) H H
    apply (K.restrictScalars ℝ).convex.integral_mem isClosed_setOfPred_isCompactOperator _ hf
    apply ae_of_all
    intro g
    change IsCompactOperator (rankOne ℂ (w g) (w g))
    rw [rankOne_def']
    exact (isCompactOperator_of_locallyCompactSpace_dom (innerSL ℂ (w g))).clm_comp (toSpanSingleton ℂ (w g))
  have innerB (x y : H) : inner ℂ x (B y) = ∫ g, inner ℂ x (w g) * inner ℂ (w g) y ∂μ := by
    rw [app,←integral_inner (fi y)]
    exact integral_congr_ae (ae_of_all _ fun g => inner_right_rankOne_apply ..)
  have sy : B.IsSymmetric := by
    intro x y
    change inner ℂ (B x) y = inner ℂ x (B y)
    calc
      inner ℂ (B x) y = conj (inner ℂ y (B x)) := (inner_conj_symm _ _).symm
      _ = _ := by
        rw [innerB,innerB,←integral_conj]
        apply integral_congr_ae
        exact ae_of_all _ fun g => by simp only [map_mul,inner_conj_symm,mul_comm]
  have bn : B ≠ 0 := by
    intro h
    let f (g) := ‖inner ℂ v (w g)‖^2
    have cf' : Continuous f := ((continuous_const.inner (cont v)).norm.pow 2)
    have fi' : Integrable f μ := cf'.integrable_of_hasCompactSupport (HasCompactSupport.of_compactSpace _)
    have iz : ∫ g, f g ∂μ = 0 := by
      have eq := innerB v v
      rw [h,zero_apply,inner_zero_right] at eq
      apply Complex.ofReal_injective
      rw [Complex.ofReal_zero,eq,←integral_complex_ofReal (f:=f)]
      apply integral_congr_ae
      exact ae_of_all _ fun g => by
        change ((‖inner ℂ v (w g)‖^2 : ℝ) : ℂ) = _
        change (↑(‖inner ℂ v (w g)‖^2 : ℝ) : ℂ) = inner ℂ v (w g) * inner ℂ (w g) v
        rw [←inner_conj_symm (𝕜:=ℂ) (w g) v,Complex.mul_conj,Complex.sq_norm]
    have az := (integral_eq_zero_iff_of_nonneg (fun _ => sq_nonneg _) fi').mp iz
    have ident := Measure.eq_of_ae_eq az cf' continuous_const
    have at1 := congrFun ident 1
    change ‖inner ℂ v (U 1 v)‖^2 = 0 at at1
    rw [one] at at1
    exact nv (inner_self_eq_zero.mp (norm_eq_zero.mp (sq_eq_zero_iff.mp at1)))
  have num : ∃ u : ℂ, HasEigenvalue B.toLinearMap u ∧ u ≠ 0 := by
    by_contra! h
    exact bn ((eq_zero_of_forall_hasEigenvalue_eq_zero cp sy).mp (fun u hu => h u hu))
  obtain ⟨u,hu,une⟩ := num
  let W := eigenspace B.toLinearMap u
  let _ : FiniteDimensional ℂ W := finite_dimensional_eigenspace cp u une
  have comm (t) (x : H) : U t (B x) = B (U t x) := by
    change (U t : H →L[ℂ] H) (B x) = B (U t x)
    rw [app,← (U t : H →L[ℂ] H).integral_comp_comm (fi x),app]
    rw [← integral_mul_left_eq_self (μ:=μ) (fun g => F g (U t x)) t]
    apply integral_congr_ae
    apply ae_of_all
    intro g
    change U t (inner ℂ (w g) x • w g) = inner ℂ (U (t*g) v) (U t x) • U (t*g) v
    rw [mul,(U t).inner_map_map,map_smul]
  apply character_of_finite_invariant U one mul cont g₀ W hu
  · intro g x hx
    rw [mem_eigenspace_iff] at hx ⊢
    change B (U g x) = u • U g x
    rw [←comm,show B x = u • x from hx,map_smul]
  · intro x hx fixed
    have bz : B x = 0 := by
      rw [app]
      have zero (t) : F t x = 0 := by
        have idw : w t = U g₀ (U t z) - U t z := by
          change U t (U g₀ z-z) = _
          rw [map_sub,←mul,←mul,mul_comm]
        have ip : inner ℂ (w t) x = 0 := by
          rw [idw,inner_sub_left]
          conv_lhs => lhs; rw [←fixed,(U g₀).inner_map_map]
          exact sub_self _
        change inner ℂ (w t) x • w t = 0
        rw [ip,zero_smul]
      simp only [zero,integral_zero]
    have xe : B x = u • x := mem_eigenspace_iff.mp hx
    exact (smul_eq_zero.mp (xe.symm.trans bz)).resolve_left une
end KDClosure.CompactFourier
