import KDCompactFourierSlices

noncomputable section
namespace KDClosure.CompactFourier
open MeasureTheory MeasureTheory.Measure Set SubgroupMeasure Filter
open scoped KDClosure.SubgroupMeasure ENNReal NNReal ComplexConjugate
variable {G : Type*} [CommGroup G] [TopologicalSpace G] [MeasurableSpace G] [BorelSpace G]
variable {K : Type*} [CommGroup K] [TopologicalSpace K] [IsTopologicalGroup K]
    [MeasurableSpace K] [BorelSpace K] [CompactSpace K] [T2Space K] [SecondCountableTopology K]
variable {D : Type*} [CommGroup D] [TopologicalSpace D] [DiscreteTopology D] [Countable D]
variable {μ : Measure G} {κ : Measure K} [κ.IsHaarMeasure] [IsProbabilityMeasure κ]
    {ν : Measure (PontryaginDual G)}

def rawTransform (μ : Measure G) (f : G → ℂ) (χ : PontryaginDual G) :=
  ∫ x, f x * (χ x:ℂ) ∂μ

theorem raw_measurable [LocallyCompactSpace G] [SecondCountableTopology G] [SFinite μ]
    (f : Lp ℂ 2 μ) : Measurable (rawTransform μ f) := by
  let phase (z : PontryaginDual G × G) : ℂ := z.1 z.2
  have pc : Continuous phase := continuous_subtype_val.comp
    (show Continuous (fun z : (G →ₜ* Circle) × G => z.1 z.2) from continuous_eval)
  have h : StronglyMeasurable (fun z : PontryaginDual G × G => f z.2 * phase z) :=
    (((Lp.stronglyMeasurable f).measurable.comp measurable_snd).mul pc.measurable).stronglyMeasurable
  exact h.integral_prod_right'.measurable

/-- Double Parseval on the actual positive-sign L¹ integral. Only the two
measure decompositions and the factorization of a character in a pair of
coset charts enter; independence of representatives is automatic. -/
theorem double_parseval (P : Slices D μ κ)
    (Q : Slices (PontryaginDual K) ν (dualHaar D))
    (a : PontryaginDual K → D → Circle)
    (law : ∀ j φ i u, Q.atFiber j φ (P.atFiber i u) = a j i * j u * φ i)
    (f : Lp ℂ 2 μ) (hf : Integrable (f : G → ℂ) μ) :
    energy ν (rawTransform μ f) = energy μ f := by
  let coeff (i : D) (j : PontryaginDual K) := ∫ u, f (P.atFiber i u) * (j u:ℂ) ∂κ
  let row (j : PontryaginDual K) (i : D) := coeff i j * (a j i:ℂ)
  have srow (j) : Summable (fun i => ‖row j i‖) := by
    apply (P.summable_norms hf).of_nonneg_of_le (fun _ => norm_nonneg _)
    intro i
    change ‖(∫ u, _ ∂κ) * _‖ ≤ _
    rw [norm_mul,Circle.norm_coe,mul_one]
    simpa only [norm_mul,Circle.norm_coe,mul_one] using
      norm_integral_le_integral_norm (μ:=κ) (fun u => f (P.atFiber i u) * (j u:ℂ))
  have it (χ : PontryaginDual G) : Integrable (fun x => f x * (χ x:ℂ)) μ := by
    apply hf.mono (hf.aestronglyMeasurable.mul ((continuous_subtype_val.comp χ.continuous).aestronglyMeasurable))
    exact ae_of_all _ fun x => by
      change ‖f x * (χ x:ℂ)‖ ≤ ‖f x‖
      rw [norm_mul,Circle.norm_coe,mul_one]
  have one (j φ) : rawTransform μ f (Q.atFiber j φ) = ∑' i, row j i * (φ i : ℂ) := by
    rw [rawTransform,P.integral_sum (it _)]
    apply tsum_congr
    intro i
    simp only [law,Circle.coe_mul,row,coeff]
    rw [←integral_mul_const,←integral_mul_const]
    apply integral_congr_ae
    exact ae_of_all _ fun u => by dsimp; ring
  rw [Q.energy_sum,P.energy_sum]
  calc
    _ = ∑' j, ∑' i, ‖row j i‖ₑ^2 := tsum_congr fun j => by
      change energy (dualHaar D) (fun φ => rawTransform μ f (Q.atFiber j φ)) = _
      simp only [one]
      exact energy_discrete (srow j)
    _ = ∑' i, ∑' j, ‖coeff i j‖ₑ^2 := by
      rw [ENNReal.tsum_comm]
      apply tsum_congr
      intro i
      apply tsum_congr
      intro j
      have un : ‖(a j i : ℂ)‖ₑ = 1 := by rw [←ofReal_norm,Circle.norm_coe,ENNReal.ofReal_one]
      simp only [row,enorm_mul,un,mul_one]
    _ = _ := tsum_congr fun i => energy_compact κ (P.partLp f i)

theorem memLp_of_energy [SFinite μ] [LocallyCompactSpace G] [SecondCountableTopology G]
    (f : Lp ℂ 2 μ) (e : energy ν (rawTransform μ f) = energy μ f) :
    ∃ m : MemLp (rawTransform μ f) 2 ν, ‖m.toLp (rawTransform μ f)‖ = ‖f‖ := by
  have n : eLpNorm (rawTransform μ f) 2 ν = eLpNorm f 2 μ := by
    apply ENNReal.rpow_left_injective (x:=(2:ℝ)) (by norm_num)
    simpa only [energy_eLp,ENNReal.rpow_ofNat] using e
  have m : MemLp (rawTransform μ f) 2 ν :=
    ⟨(raw_measurable f).aestronglyMeasurable,n ▸ (Lp.memLp f).2⟩
  exact ⟨m,by rw [Lp.norm_toLp,n,Lp.norm_def]⟩
end KDClosure.CompactFourier
