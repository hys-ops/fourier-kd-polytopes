import KDCompactFourierCounting
import KDCompactFourierDiscrete
import KDLCARealityFourier

noncomputable section
namespace KDClosure.CompactFourier
open MeasureTheory Set MeasureTheory.Measure SubgroupMeasure
open scoped KDClosure.SubgroupMeasure ComplexConjugate ENNReal
section Multiplicative
variable {K : Type*} [CommGroup K] [TopologicalSpace K] [IsTopologicalGroup K] [CompactSpace K]
  [T2Space K] [SecondCountableTopology K] [MeasurableSpace K] [BorelSpace K]
  (μ : Measure K) [μ.IsHaarMeasure] [IsProbabilityMeasure μ]
local instance : Countable (PontryaginDual K) := CompactDualReduction.dual_countable

def compactForward : Lp ℂ 2 μ →ₗᵢ[ℂ] Lp ℂ 2 (count : Measure (PontryaginDual K)) :=
  (countEquiv (D:=PontryaginDual K)).symm.toLinearIsometry.comp ((haarFourierBasis μ).repr.toLinearIsometry.comp
    (Lp.compMeasurePreservingₗᵢ ℂ Inv.inv (measurePreserving_inv μ)))

theorem compactForward_eval (f : Lp ℂ 2 μ) (χ : PontryaginDual K) :
    compactForward μ f χ = ∫ x, f x * (χ x:ℂ) ∂μ := by
  let v := Lp.compMeasurePreserving Inv.inv (measurePreserving_inv μ) f
  change countEquiv.symm ((haarFourierBasis μ).repr v) χ = _
  rw [countEquiv_symm_apply,haar_coeff]
  calc
    _ = ∫ x, conj (χ x:ℂ) * f x⁻¹ ∂μ := by
      apply integral_congr_ae
      filter_upwards [Lp.coeFn_compMeasurePreserving f (measurePreserving_inv μ)] with x hx
      rw [show v x=f x⁻¹ from hx]
    _ = _ := by
      conv_lhs => rw [←integral_inv_eq_self (μ:=μ)]
      apply integral_congr_ae
      exact ae_of_all _ fun x => by
        change conj (χ x⁻¹ : ℂ) * f (x⁻¹)⁻¹ = f x * (χ x:ℂ)
        rw [map_inv,Circle.coe_inv_eq_conj,Complex.conj_conj,inv_inv,mul_comm]
end Multiplicative

variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [MeasurableSpace G] [BorelSpace G]

section Compact
variable [IsTopologicalAddGroup G] [CompactSpace G] [T2Space G] [SecondCountableTopology G]
    (μ : Measure G) [μ.IsAddHaarMeasure] [IsProbabilityMeasure μ]
local instance : MeasurableSpace (Multiplicative G) := ‹MeasurableSpace G›
local instance : BorelSpace (Multiplicative G) := ‹BorelSpace G›
local instance : Measure.IsMulLeftInvariant (G:=Multiplicative G) μ :=
  ⟨fun x => Measure.IsAddLeftInvariant.map_add_left_eq_self x.toAdd⟩
local instance : IsFiniteMeasureOnCompacts (α:=Multiplicative G) μ := inferInstanceAs (IsFiniteMeasureOnCompacts (α:=G) μ)
local instance : Measure.IsOpenPosMeasure (X:=Multiplicative G) μ := inferInstanceAs (Measure.IsOpenPosMeasure (X:=G) μ)
local instance : IsProbabilityMeasure (α:=Multiplicative G) μ := ‹IsProbabilityMeasure μ›
local instance : Measure.IsHaarMeasure (G:=Multiplicative G) μ := ⟨⟩
local instance : T2Space (Multiplicative G) := ‹T2Space G›
local instance : CompactSpace (Multiplicative G) := ‹CompactSpace G›
local instance : SecondCountableTopology (Multiplicative G) := ‹SecondCountableTopology G›
local instance : Countable (LCAReality.Dual G) := CompactDualReduction.dual_countable

/-- The positive-sign physical Fourier realization on an arbitrary compact
second countable abelian group, from normalized Haar to counting measure. -/
def compactRealization : LCAReality.FourierRealization μ count where
  isometry := compactForward (K:=Multiplicative G) μ
  integral_ae f _ := ae_count_iff.mpr (fun χ => compactForward_eval (K:=Multiplicative G) μ f χ)
end Compact

section Discrete
variable [DiscreteTopology G] [Countable G]
local instance : MeasurableSpace (Multiplicative G) := ‹MeasurableSpace G›
local instance : BorelSpace (Multiplicative G) := ‹BorelSpace G›
local instance : Countable (Multiplicative G) := ‹Countable G›

/-- The positive-sign physical Fourier realization for a countable discrete
abelian group, from counting measure to probability Haar on the full dual. -/
def discreteRealization : LCAReality.FourierRealization (G:=G) count (dualHaar (Multiplicative G)) where
  isometry := (discreteFourierBasis (Multiplicative G)).repr.symm.toLinearIsometry.comp (countEquiv (D:=G)).toLinearIsometry
  integral_ae f hf := by
    let v : Discrete.L2 G := countEquiv (D:=G) f
    have h : Summable (fun i => ‖v i‖) := by change Summable (fun i : G => ‖f i‖); exact integrable_count_iff.mp hf
    filter_upwards [discrete_series (Multiplicative G) v h] with χ hχ
    change (discreteFourierBasis (Multiplicative G)).repr.symm v χ = _
    rw [hχ,integral_countable]
    · apply tsum_congr
      intro i
      change f i.toAdd * _ = (count : Measure G).real {i.toAdd} • (f i.toAdd * _)
      rw [measureReal_def,count_singleton,ENNReal.toReal_one,one_smul]; rfl
    · apply integrable_count_iff.mpr
      simpa only [norm_mul,Circle.norm_coe,mul_one,LCAReality.phase] using integrable_count_iff.mp hf
end Discrete
end KDClosure.CompactFourier
