import KDCompactFourierBasis
import Mathlib.MeasureTheory.Function.LpSpace.DomAct.Continuous
import Mathlib.Topology.UrysohnsLemma

noncomputable section
namespace KDClosure.CompactFourier
open Set MeasureTheory Filter
open scoped ENNReal ComplexConjugate
variable {G : Type*} [CommGroup G] [TopologicalSpace G] [IsTopologicalGroup G] [CompactSpace G]
  [T2Space G] [MeasurableSpace G] [BorelSpace G] (μ : Measure G) [μ.IsHaarMeasure] [IsProbabilityMeasure μ]

def regular (g : G) : Lp ℂ 2 μ ≃ₗᵢ[ℂ] Lp ℂ 2 μ where
  toFun f := DomMulAct.mk g • f
  invFun f := DomMulAct.mk g⁻¹ • f
  left_inv f := by dsimp only; rw [←mul_smul,←DomMulAct.mk_mul,mul_inv_cancel,DomMulAct.mk_one,one_smul]
  right_inv f := by dsimp only; rw [←mul_smul,←DomMulAct.mk_mul,inv_mul_cancel,DomMulAct.mk_one,one_smul]
  map_add' := smul_add _
  map_smul' := smul_comm _
  norm_map' := DomMulAct.norm_smul_Lp _

omit [T2Space G] [CompactSpace G] [IsProbabilityMeasure μ] in
theorem regular_one (f : Lp ℂ 2 μ) : regular μ 1 f = f := by
  change DomMulAct.mk (1:G) • f = f
  rw [DomMulAct.mk_one,one_smul]

omit [T2Space G] [CompactSpace G] [IsProbabilityMeasure μ] in
theorem regular_mul (g h : G) (f : Lp ℂ 2 μ) : regular μ (g*h) f = regular μ g (regular μ h f) := by
  change DomMulAct.mk (g*h) • f = DomMulAct.mk g • DomMulAct.mk h • f
  rw [mul_comm,DomMulAct.mk_mul,mul_smul]

omit [T2Space G] [IsProbabilityMeasure μ] in
theorem continuous_regular (f : Lp ℂ 2 μ) : Continuous fun g => regular μ g f := by
  let _ : Fact ((2:ℝ≥0∞) ≠ ∞) := ⟨by simp⟩
  exact DomMulAct.continuous_mk.smul continuous_const

theorem regular_moves {g : G} (hg : g ≠ 1) : ∃ v : Lp ℂ 2 μ, regular μ g v ≠ v := by
  obtain ⟨u,u1,ug,_⟩ := exists_continuous_zero_one_of_isClosed
    (isClosed_singleton (x:=(1:G))) (isClosed_singleton (x:=g)) (Set.disjoint_singleton.mpr (Ne.symm hg))
  let f : C(G,ℂ) := ⟨fun x => (u x : ℂ), Complex.continuous_ofReal.comp u.continuous⟩
  let v := ContinuousMap.toLp 2 μ ℂ f
  refine ⟨v,fun eqn => ?_⟩
  have ae : (v : G → ℂ) =ᵐ[μ] f := ContinuousMap.coeFn_toLp μ f
  have aep := (measurePreserving_mul_left μ g).quasiMeasurePreserving.ae ae
  have tr := DomMulAct.smul_Lp_ae_eq (DomMulAct.mk g) v
  change (regular μ g v : G → ℂ) =ᵐ[μ] (fun x => v (g*x)) at tr
  rw [eqn] at tr
  have cont := Measure.eq_of_ae_eq ((ae.symm.trans tr).trans aep) f.continuous
    (f.continuous.comp (continuous_const.mul continuous_id))
  have z := congrFun cont 1
  change ((u 1 : ℝ) : ℂ) = ((u (g*1) : ℝ) : ℂ) at z
  rw [mul_one,show u 1=0 from u1 (mem_singleton 1),show u g=1 from ug (mem_singleton g)] at z
  norm_num at z

end KDClosure.CompactFourier
