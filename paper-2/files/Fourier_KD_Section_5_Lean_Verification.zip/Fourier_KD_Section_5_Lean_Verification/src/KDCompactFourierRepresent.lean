import KDCompactFourierKernel
import Mathlib.MeasureTheory.Measure.SeparableMeasure
import Mathlib.Topology.Compactness.Lindelof

noncomputable section
namespace KDClosure.CompactFourier
open MeasureTheory Set CompactDualReduction
open scoped ComplexConjugate ENNReal
section Separable
variable {V : Type*} [NormedAddCommGroup V] [InnerProductSpace ℂ V] [SecondCountableTopology V]

theorem countable_orthonormal (s : Set V) (h : Orthonormal ℂ ((↑) : s → V)) : s.Countable := by
  apply (HereditarilyLindelofSpace.isLindelof s).countable_of_isDiscrete
  apply isDiscrete_iff_forall_mem_exists_isOpen.mpr
  intro x hx
  refine ⟨Metric.ball x 1,Metric.isOpen_ball,?_⟩
  ext y
  constructor
  · rintro ⟨d,hy⟩
    by_contra yn
    have ne : (⟨y,hy⟩ : s) ≠ ⟨x,hx⟩ := fun e => yn (congrArg Subtype.val e)
    have ip := h.inner_eq_zero ne
    have sq := norm_sub_sq (𝕜:=ℂ) y x
    rw [h.norm_eq_one ⟨y,hy⟩,h.norm_eq_one ⟨x,hx⟩,ip] at sq
    change dist y x < 1 at d
    rw [dist_eq_norm] at d
    simp only [map_zero,mul_zero,sub_zero,one_pow] at sq
    nlinarith [norm_nonneg (y-x)]
  · rintro rfl
    exact ⟨Metric.mem_ball_self zero_lt_one,hx⟩
end Separable

section Kernel
variable {X : Type*} [MeasurableSpace X] [MeasurableSpace.CountablyGenerated X] {ν : Measure X} [SFinite ν]

/-- No basis or Fourier-transform data are requested on a countably
generated measurable space. The same representative is both Hermitian and
the action kernel of the original operator. -/
theorem exists_physical_kernel (T : Space ν →L[ℂ] Space ν) (hp : T.IsPositive)
    (ht : BddAbove (frameMass T)) :
    ∃ k : Space (ν.prod ν), (∀ᵐ z ∂ν.prod ν, k z = conj (k z.swap)) ∧
      ∀ f : Space ν, ∀ᵐ x ∂ν, T f x = ∫ y, k (x,y) * f y ∂ν := by
  let _ : Fact ((2:ℝ≥0∞) ≠ ∞) := ⟨by simp⟩
  obtain ⟨s,b,hb⟩ := exists_hilbertBasis ℂ (Space ν)
  have on := b.orthonormal
  rw [hb] at on
  let _ : Countable s := countable_orthonormal s on
  obtain ⟨k,sym,rep⟩ := exists_hermitian_kernel_of_frameBound T hp ht b
  refine ⟨k,?_,rep⟩
  filter_upwards [sym] with z hz
  rw [hz,Complex.conj_conj]
end Kernel

variable {G : Type*} [CommGroup G] [TopologicalSpace G] [IsTopologicalGroup G] [CompactSpace G]
  [T2Space G] [MeasurableSpace G] [BorelSpace G] (μ : Measure G) [μ.IsHaarMeasure] [IsProbabilityMeasure μ]

theorem fourier_coeff (b : OpenBasis G) (v : Lp ℂ 2 μ) (i : PontryaginDual G) :
    (fourierBasis μ b).repr v i = ∫ x, conj (i x : ℂ) * v x ∂μ := by
  rw [HilbertBasis.repr_apply_apply,basis_coe,MeasureTheory.L2.inner_def]
  apply integral_congr_ae
  filter_upwards [wave_ae μ i] with x hx
  rw [hx,RCLike.inner_apply,mul_comm]

variable [SecondCountableTopology G]
omit [T2Space G] [IsTopologicalGroup G] [μ.IsHaarMeasure] in
theorem exists_physical_KD_kernel (T : CompactOp μ) (hp : T.IsPositive) (ht : IsLUB (frameMass T) 1) :
    ∃ k : Space (μ.prod μ), (∀ᵐ z ∂μ.prod μ, k z = conj (k z.swap)) ∧
      Represents μ T (fun x y => k (x,y)) ∧
      ∀ χ : PontryaginDual G, (compactDensity μ T χ : G → ℂ) =ᵐ[μ]
        fun x => ∫ y, k (x,y) * (χ (y/x):ℂ) ∂μ := by
  obtain ⟨k,sym,rep⟩ := exists_physical_kernel T hp ⟨1,ht.1⟩
  exact ⟨k,sym,rep,section_eq_kernel μ T _ rep⟩
end KDClosure.CompactFourier
