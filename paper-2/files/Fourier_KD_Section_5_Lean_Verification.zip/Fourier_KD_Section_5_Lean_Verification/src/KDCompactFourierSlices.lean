import KDCompactFourierEnergy

noncomputable section
namespace KDClosure.CompactFourier
open MeasureTheory MeasureTheory.Measure Set SubgroupMeasure Filter
open scoped KDClosure.SubgroupMeasure ENNReal NNReal ComplexConjugate
variable {J X K : Type*} [MeasurableSpace X] [MeasurableSpace K]

/-- A countable Haar disintegration into translates; all weights are inside
the component measures. The two applications below use unit-mass fibers. -/
structure Slices (J : Type*) (μ : Measure X) (κ : Measure K) where
  atFiber : J → K → X
  emb : ∀ j, MeasurableEmbedding (atFiber j)
  split : μ = Measure.sum (fun j => κ.map (atFiber j))

namespace Slices
variable {μ : Measure X} {κ : Measure K} (P : Slices J μ κ)

theorem energy_sum (f : X → ℂ) : energy μ f = ∑' j, energy κ (f ∘ P.atFiber j) := by
  calc
    _ = ∫⁻ x, ‖f x‖ₑ^2 ∂(Measure.sum fun j => κ.map (P.atFiber j)) := congrArg (fun ρ => energy ρ f) P.split
    _ = _ := by
      rw [lintegral_sum_measure]
      exact tsum_congr fun j => (P.emb j).lintegral_map _

theorem part_le (j : J) : κ.map (P.atFiber j) ≤ μ := (Measure.le_sum (fun i => κ.map (P.atFiber i)) j).trans_eq P.split.symm

theorem partLp (f : Lp ℂ 2 μ) (j : J) : MemLp (f ∘ P.atFiber j) 2 κ :=
  (P.emb j).memLp_map_measure_iff.mp ((Lp.memLp f).mono_measure (P.part_le j))

theorem summable_norms {f : X → ℂ} (hf : Integrable f μ) :
    Summable fun j => ∫ x, ‖f (P.atFiber j x)‖ ∂κ := by
  have hi : Integrable f (Measure.sum fun j => κ.map (P.atFiber j)) := P.split ▸ hf
  exact hi.summable_integral.congr fun j => (P.emb j).integral_map _

theorem integral_sum [Countable J] {f : X → ℂ} (hf : Integrable f μ) :
    ∫ x, f x ∂μ = ∑' j, ∫ u, f (P.atFiber j u) ∂κ := by
  have hi : Integrable f (Measure.sum fun j => κ.map (P.atFiber j)) := P.split ▸ hf
  calc
    _ = ∫ x, f x ∂(Measure.sum fun j => κ.map (P.atFiber j)) := congrArg (fun ρ => ∫x, f x ∂ρ) P.split
    _ = _ := (integral_sum_measure hi).trans (tsum_congr fun j => (P.emb j).integral_map _)
end Slices
end KDClosure.CompactFourier
