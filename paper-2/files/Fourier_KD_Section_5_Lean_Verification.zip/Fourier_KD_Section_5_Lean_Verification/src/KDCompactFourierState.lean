import KDCompactFourierBidual
import KDCompactFourierAllBasis
import KDDiscreteTransfer
import Mathlib.MeasureTheory.Function.Holder

noncomputable section
namespace KDClosure.CompactFourier
open MeasureTheory MeasureTheory.Measure Discrete CompactDualReduction SubgroupMeasure
open scoped Topology KDClosure.SubgroupMeasure ComplexConjugate ComplexOrder ENNReal BigOperators
variable {G : Type*} [CommGroup G] [TopologicalSpace G] [IsTopologicalGroup G] [CompactSpace G]
  [T2Space G] [MeasurableSpace G] [BorelSpace G] (μ : Measure G) [μ.IsHaarMeasure] [IsProbabilityMeasure μ]

/-- KD at fixed frequency: physically the phase factor times the action
of the operator on that frequency wave. -/
private def modulate (χ : PontryaginDual G) : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ :=
  (ContinuousLinearMap.mul ℂ ℂ).holderL μ ⊤ 2 2 (ContinuousMap.toLp ⊤ μ ℂ (wave χ⁻¹))

omit [IsTopologicalGroup G] [T2Space G] [μ.IsHaarMeasure] in
theorem modulate_ae (χ : PontryaginDual G) (v : Lp ℂ 2 μ) :
    ⇑(modulate μ χ v) =ᵐ[μ] fun x => conj (χ x:ℂ) * v x := by
  let f := ContinuousMap.toLp ⊤ μ ℂ (wave χ⁻¹)
  have e := (ContinuousLinearMap.mul ℂ ℂ).coeFn_holder (r:=2) f v
  filter_upwards [e,ContinuousMap.coeFn_toLp (p:=⊤) (𝕜:=ℂ) μ (wave χ⁻¹)] with x hx he
  change modulate μ χ v x = f x * v x at hx
  change f x = ((χ x)⁻¹:Circle) at he
  rw [hx,he,Circle.coe_inv_eq_conj]

def compactDensity (T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ) (χ : PontryaginDual G) : Lp ℂ 2 μ :=
  modulate μ χ (T (waveLp μ χ))

def CompactNonneg (T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ) : Prop :=
  ∀ χ : PontryaginDual G, ∀ᵐ x ∂μ, 0 ≤ compactDensity μ T χ x

variable (b : OpenBasis G)
def synth : L2 (PontryaginDual G) ≃ₗᵢ[ℂ] Lp ℂ 2 μ := (fourierBasis μ b).repr.symm

def conjugate (A : L2 (PontryaginDual G) →L[ℂ] L2 (PontryaginDual G)) :
    Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ :=
  (synth μ b).toContinuousLinearEquiv.toContinuousLinearMap ∘L A ∘L
    (synth μ b).symm.toContinuousLinearEquiv.toContinuousLinearMap

def haarSynth : L2 (PontryaginDual G) ≃ₗᵢ[ℂ] Lp ℂ 2 μ := (haarFourierBasis μ).repr.symm

def haarConjugate (A : L2 (PontryaginDual G) →L[ℂ] L2 (PontryaginDual G)) :
    Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ :=
  (haarSynth μ).toContinuousLinearEquiv.toContinuousLinearMap ∘L A ∘L
    (haarSynth μ).symm.toContinuousLinearEquiv.toContinuousLinearMap

variable [DecidableEq (PontryaginDual G)]
omit [IsTopologicalGroup G] [CompactSpace G] [T2Space G] [MeasurableSpace G] [BorelSpace G] in
private theorem coeff (A : L2 (PontryaginDual G) →L[ℂ] L2 (PontryaginDual G))
    (i j : PontryaginDual G) : A (lp.single 2 j (1:ℂ)) i = entries A (i,j) := by
  change _ = inner ℂ (lp.single 2 i (1:ℂ)) (A (lp.single 2 j (1:ℂ)))
  rw [lp.inner_single_left]
  simp [RCLike.inner_apply]

omit [IsTopologicalGroup G] [CompactSpace G] [T2Space G] [MeasurableSpace G] [BorelSpace G] in
private theorem symmetric_coeff (A : L2 (PontryaginDual G) →L[ℂ] L2 (PontryaginDual G))
    (pos : A.IsPositive) (i j : PontryaginDual G) : conj (entries A (i,j))=entries A (j,i) := by
  change conj (inner ℂ (lp.single 2 i (1:ℂ)) (A (lp.single 2 j (1:ℂ)))) = inner ℂ (lp.single 2 j (1:ℂ)) (A (lp.single 2 i (1:ℂ)))
  rw [inner_conj_symm, pos.inner_left_eq_inner_right]

variable [SecondCountableTopology G]

private def P := Lp.compMeasurePreservingₗᵢ ℂ (evalAt (G:=G) ∘ (·⁻¹))
  ((eval_preserves μ).comp (measurePreserving_inv μ)) (p:=2) (E:=ℂ)

private def Cj : Lp ℂ 2 μ →L[ℝ] Lp ℂ 2 μ := Complex.conjCLE.toContinuousLinearMap.compLpL 2 μ

omit [DecidableEq (PontryaginDual G)] in
private theorem same_term (i j : PontryaginDual G) (c : ℂ) :
    Cj μ (P μ (c • DiscreteKDRow.phase (PontryaginDual G) i j)) =
      conj c • modulate μ i (waveLp μ j) := by
  apply Lp.ext
  let k := evalAt (G:=G) ∘ (·⁻¹)
  have hk := (eval_preserves μ).comp (measurePreserving_inv μ)
  let f := DiscreteKDRow.phase (PontryaginDual G) i j
  have scalar := hk.quasiMeasurePreserving.ae_eq_comp (Lp.coeFn_smul c f)
  have phase := hk.quasiMeasurePreserving.ae_eq_comp (DiscreteKDRow.phase_ae (PontryaginDual G) i j)
  have pull := Lp.coeFn_compMeasurePreserving (c • f) hk
  have cj := Complex.conjCLE.toContinuousLinearMap.coeFn_compLp (P μ (c • f))
  filter_upwards [cj,pull,scalar,phase,Lp.coeFn_smul (conj c) (modulate μ i (waveLp μ j)),
    modulate_ae μ i (waveLp μ j),wave_ae μ j] with x ec ep es eh et em ej
  change Cj μ (P μ (c • f)) x = conj (P μ (c • f) x) at ec
  change P μ (c • f) x = (c • f) (k x) at ep
  change (c • f) (k x) = c * f (k x) at es
  change f (k x) = ((j/i) x⁻¹ : ℂ) at eh
  rw [ec,ep,es,eh,map_mul,et,Pi.smul_apply,smul_eq_mul,em,ej]
  congr 1
  change conj ((j x⁻¹ / i x⁻¹ : Circle) : ℂ) = _
  rw [map_inv j, map_inv i]
  rw [div_eq_mul_inv,inv_inv,Circle.coe_mul,Circle.coe_inv_eq_conj,map_mul,Complex.conj_conj,mul_comm]

/-- Fourier conjugation exchanges compact KD sections and discrete KD
rows with complex conjugation and inversion of physical position. -/
theorem haarSection_eq (A : L2 (PontryaginDual G) →L[ℂ] L2 (PontryaginDual G))
    (pos : A.IsPositive) (i : PontryaginDual G) :
    compactDensity μ (haarConjugate μ A) i = Cj μ (P μ (DiscreteKDRow.rowDensity _ A i)) := by
  have hs := (Cj μ).hasSum ((P μ).toContinuousLinearMap.hasSum (DiscreteKDRow.row_hasSum _ A i))
  have ht := (modulate μ i).hasSum ((haarFourierBasis μ).hasSum_repr_symm (A (lp.single 2 i 1)))
  have iw : (haarSynth μ).symm (waveLp μ i) = lp.single 2 i 1 := by
    change (haarFourierBasis μ).repr _ = _
    rw [←haar_basis_coe μ,HilbertBasis.repr_self]
  have htarget : compactDensity μ (haarConjugate μ A) i =
      modulate μ i ((haarFourierBasis μ).repr.symm (A (lp.single 2 i 1))) := by
    change modulate μ i (haarSynth μ (A ((haarSynth μ).symm (waveLp μ i)))) = _
    rw [iw]; rfl
  rw [htarget]
  apply ht.unique
  convert! hs using 1
  funext j
  change modulate μ i ((A (lp.single 2 i 1)) j • (haarFourierBasis μ) j) =
    Cj μ (P μ (entries A (i,j) • DiscreteKDRow.phase _ i j))
  rw [same_term, symmetric_coeff A pos,coeff,haar_basis_coe,map_smul]

theorem haarNonneg_iff (A : L2 (PontryaginDual G) →L[ℂ] L2 (PontryaginDual G)) (pos : A.IsPositive) :
    CompactNonneg μ (haarConjugate μ A) ↔ DiscreteKDRow.RowNonneg (PontryaginDual G) A := by
  apply forall_congr'
  intro i
  rw [haarSection_eq μ A pos i]
  let f := DiscreteKDRow.rowDensity (PontryaginDual G) A i
  have cj := Complex.conjCLE.toContinuousLinearMap.coeFn_compLp (P μ f)
  have eq : (∀ᵐ x ∂μ, 0 ≤ Cj μ (P μ f) x) ↔ ∀ᵐ x ∂μ, 0 ≤ P μ f x := by
    apply Filter.eventually_congr
    filter_upwards [cj] with x h
    change Cj μ (P μ f) x = conj (P μ f x) at h
    rw [h]; simp [Complex.nonneg_iff,eq_comm]
  exact eq.trans (CountRows.pull_nonneg ((eval_preserves μ).comp (measurePreserving_inv μ)) f)

/-- Backward-compatible profinite versions use the same character basis. -/
theorem section_eq (A : L2 (PontryaginDual G) →L[ℂ] L2 (PontryaginDual G))
    (pos : A.IsPositive) (i : PontryaginDual G) :
    compactDensity μ (conjugate μ b A) i = Cj μ (P μ (DiscreteKDRow.rowDensity _ A i)) :=
  haarSection_eq μ A pos i

theorem nonneg_iff (A : L2 (PontryaginDual G) →L[ℂ] L2 (PontryaginDual G)) (pos : A.IsPositive) :
    CompactNonneg μ (conjugate μ b A) ↔ DiscreteKDRow.RowNonneg (PontryaginDual G) A :=
  haarNonneg_iff μ A pos

end KDClosure.CompactFourier
