import KDCompactFourierState

noncomputable section
namespace KDClosure.CompactFourier
open MeasureTheory MeasureTheory.Measure Set Discrete CompactDualReduction SubgroupMeasure
open scoped ComplexConjugate KDClosure.SubgroupMeasure ComplexOrder BigOperators

section Trace
variable {H K : Type*} [NormedAddCommGroup H] [InnerProductSpace ℂ H]
  [NormedAddCommGroup K] [InnerProductSpace ℂ K]

/-- All finite orthonormal frame tested traces (an intrinsic trace on
positive operators, independent of any chosen coordinates). -/
def frameMass (A : H →L[ℂ] H) : Set ℝ :=
  {r | ∃ n : ℕ, ∃ v : Fin n → H, Orthonormal ℂ v ∧ (∑ j, (inner ℂ (v j) (A (v j))).re)=r}

def unitaryPush (e : H ≃ₗᵢ[ℂ] K) (A : H →L[ℂ] H) : K →L[ℂ] K :=
  (e : H →L[ℂ] K) ∘L A ∘L (e.symm : K →L[ℂ] H)

theorem frameMass_unitary (e : H ≃ₗᵢ[ℂ] K) (A : H →L[ℂ] H) :
    frameMass (unitaryPush e A) = frameMass A := by
  ext r
  constructor
  · rintro ⟨n,v,on,rfl⟩
    refine ⟨n,e.symm ∘ v,on.comp_linearIsometryEquiv e.symm,Finset.sum_congr rfl fun i _ => ?_⟩
    change (inner ℂ (e.symm (v i)) (A (e.symm (v i)))).re = (inner ℂ (v i) (e (A (e.symm (v i))))).re
    rw [←e.inner_map_map,e.apply_symm_apply]
  · rintro ⟨n,v,on,rfl⟩
    refine ⟨n,e ∘ v,on.comp_linearIsometryEquiv e,Finset.sum_congr rfl fun i _ => ?_⟩
    change (inner ℂ (e (v i)) (e (A (e.symm (e (v i)))))).re = _
    rw [e.symm_apply_apply,e.inner_map_map]

variable [CompleteSpace H] [CompleteSpace K]

theorem lift_eq_push (e : H ≃ₗᵢ[ℂ] K) (A : H →L[ℂ] H) :
    IsometricSupport.lift (e : H →L[ℂ] K) A = unitaryPush e A := by
  rw [IsometricSupport.lift,unitaryPush,e.adjoint_eq_symm]

theorem positive_unitary_iff (e : H ≃ₗᵢ[ℂ] K) (A : H →L[ℂ] H) :
    (unitaryPush e A).IsPositive ↔ A.IsPositive := by
  have forward (e : H ≃ₗᵢ[ℂ] K) (T : H →L[ℂ] H) (p : T.IsPositive) : (unitaryPush e T).IsPositive := by
    rw [←lift_eq_push]
    exact p.conj_adjoint _
  refine ⟨fun p => ?_,forward e A⟩
  have big := p.conj_adjoint (e.symm : K →L[ℂ] H)
  rw [e.symm.adjoint_eq_symm] at big
  convert! big using 1
  ext x
  change A x = e.symm (e (A (e.symm (e x))))
  simp

end Trace

variable {G : Type*} [CommGroup G] [TopologicalSpace G] [IsTopologicalGroup G] [CompactSpace G]
  [T2Space G] [MeasurableSpace G] [BorelSpace G] (μ : Measure G) [μ.IsHaarMeasure] [IsProbabilityMeasure μ]
abbrev CompactOp := Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ

/-- A measurable-kernel representation of an operator in the usual integral
sense. This is used *only* to compare two presentations of the KD section.
The final existence/transfer theorems do not assume a kernel representation. -/
def Represents (T : CompactOp μ) (k : G → G → ℂ) : Prop :=
  ∀ f : Lp ℂ 2 μ, ∀ᵐ x ∂μ, T f x = ∫ y, k x y * f y ∂μ

omit [T2Space G] [IsTopologicalGroup G] [μ.IsHaarMeasure] in
theorem section_eq_kernel (T : CompactOp μ) (k : G → G → ℂ) (hk : Represents μ T k)
    (χ : PontryaginDual G) :
    (compactDensity μ T χ : G → ℂ) =ᵐ[μ] fun x => ∫ y, k x y * (χ (y/x):ℂ) ∂μ := by
  filter_upwards [modulate_ae μ χ (T (waveLp μ χ)),hk (waveLp μ χ)] with x hm ht
  change compactDensity μ T χ x = _ at hm
  rw [hm,ht,←integral_const_mul]
  apply integral_congr_ae
  filter_upwards [wave_ae μ χ] with y hy
  rw [hy,map_div,div_eq_mul_inv,Circle.coe_mul,Circle.coe_inv_eq_conj]
  ring

variable [SecondCountableTopology G]

/-- Full compact position Haar × discrete frequency counting measure. -/
def spaceStates : Set (CompactOp μ) :=
  {T | T.IsPositive ∧ IsLUB (frameMass T) 1 ∧
    ∀ᵐ z ∂(μ.prod (Measure.count : Measure (PontryaginDual G))), 0 ≤ compactDensity μ T z.2 z.1}

omit [IsTopologicalGroup G] in
theorem joint_iff (T : CompactOp μ) :
    (∀ᵐ z ∂(μ.prod (Measure.count : Measure (PontryaginDual G))), 0 ≤ compactDensity μ T z.2 z.1) ↔
    CompactNonneg μ T := by
  let _ : Countable (PontryaginDual G) := dual_countable
  let f (z : PontryaginDual G × G) := compactDensity μ T z.1 z.2
  have fm : Measurable f := measurable_from_prod_countable_right fun ξ =>
    (Lp.stronglyMeasurable (compactDensity μ T ξ)).measurable
  have ms : MeasurableSet {z | 0 ≤ f z} := by
    simp only [Complex.nonneg_iff]
    exact (measurableSet_le measurable_const (Complex.continuous_re.measurable.comp fm)).inter
      (measurableSet_eq_fun measurable_const (Complex.continuous_im.measurable.comp fm))
  have swap : MeasurePreserving Prod.swap (μ.prod (Measure.count : Measure (PontryaginDual G))) _ :=
    Measure.measurePreserving_swap
  exact (ae_reflection swap ms.nullMeasurableSet).trans
    (CountRows.product_iff_rows (compactDensity μ T))

variable (b : OpenBasis G) [DecidableEq (PontryaginDual G)]

theorem haarMem_conjugate (A : L2 (PontryaginDual G) →L[ℂ] L2 (PontryaginDual G)) :
    haarConjugate μ A ∈ spaceStates μ ↔ A ∈ DiscreteTransfer.states (PontryaginDual G) := by
  change (unitaryPush (haarSynth μ) A).IsPositive ∧ IsLUB (frameMass (unitaryPush (haarSynth μ) A)) 1 ∧ _ ↔ _
  rw [positive_unitary_iff,frameMass_unitary,joint_iff]
  constructor
  · rintro ⟨pa,tr,kd⟩
    exact ⟨pa,tr,(haarNonneg_iff μ A pa).mp kd⟩
  · rintro ⟨pa,tr,kd⟩
    exact ⟨pa,tr,(haarNonneg_iff μ A pa).mpr kd⟩

/-- Fourier conjugation exactly identifies the two complete extreme-state
sets. The real-linear bijection is used because extreme points are real
convex combinations of complex operators. -/
theorem haarExtreme_iff (A : L2 (PontryaginDual G) →L[ℂ] L2 (PontryaginDual G)) :
    haarConjugate μ A ∈ (spaceStates μ).extremePoints ℝ ↔
    A ∈ (DiscreteTransfer.states (PontryaginDual G)).extremePoints ℝ := by
  let E := (haarSynth μ).toContinuousLinearEquiv.conjContinuousAlgEquiv.toAlgEquiv.toLinearEquiv.restrictScalars ℝ
  let S := DiscreteTransfer.states (PontryaginDual G)
  have img : E '' S = spaceStates μ := by
    ext T
    obtain ⟨B,rfl⟩ := E.surjective T
    rw [E.injective.mem_set_image]
    exact (haarMem_conjugate μ B).symm
  change E A ∈ _ ↔ _
  rw [←img,←image_extremePoints E S,E.injective.mem_set_image]

theorem haarHasInfiniteExtreme_iff : DiscreteTransfer.HasInfiniteExtreme (PontryaginDual G) ↔
    ∃ T ∈ (spaceStates μ).extremePoints ℝ, ¬FiniteDimensional ℂ (LinearMap.range T.toLinearMap) := by
  have rangeE (A : L2 (PontryaginDual G) →L[ℂ] L2 (PontryaginDual G)) :
      LinearMap.range A.toLinearMap ≃ₗ[ℂ] LinearMap.range (haarConjugate μ A).toLinearMap := by
    change _ ≃ₗ[ℂ] LinearMap.range (unitaryPush (haarSynth μ) A).toLinearMap
    rw [←lift_eq_push]
    exact IsometricSupport.rangeEquiv _ (haarSynth μ).isometry A
  have fin (A) : FiniteDimensional ℂ (LinearMap.range A.toLinearMap) ↔
      FiniteDimensional ℂ (LinearMap.range (haarConjugate μ A).toLinearMap) := by
    constructor <;> intro h
    · exact Module.Finite.equiv (rangeE A)
    · exact Module.Finite.equiv (rangeE A).symm
  constructor
  · rintro ⟨A,h,inf⟩
    exact ⟨haarConjugate μ A,(haarExtreme_iff μ A).mpr h,fun finite => inf ((fin A).mpr finite)⟩
  · rintro ⟨B,h,inf⟩
    let E := (haarSynth μ).toContinuousLinearEquiv.conjContinuousAlgEquiv
    obtain ⟨A,eqn⟩ := E.surjective B
    change haarConjugate μ A = B at eqn
    subst B
    exact ⟨A,(haarExtreme_iff μ A).mp h,fun finite => inf ((fin A).mp finite)⟩

theorem mem_conjugate (A : L2 (PontryaginDual G) →L[ℂ] L2 (PontryaginDual G)) :
    conjugate μ b A ∈ spaceStates μ ↔ A ∈ DiscreteTransfer.states (PontryaginDual G) :=
  haarMem_conjugate μ A

theorem extreme_iff (A : L2 (PontryaginDual G) →L[ℂ] L2 (PontryaginDual G)) :
    conjugate μ b A ∈ (spaceStates μ).extremePoints ℝ ↔
    A ∈ (DiscreteTransfer.states (PontryaginDual G)).extremePoints ℝ :=
  haarExtreme_iff μ A

set_option linter.unusedSectionVars false in
include b in
theorem hasInfiniteExtreme_iff : DiscreteTransfer.HasInfiniteExtreme (PontryaginDual G) ↔
    ∃ T ∈ (spaceStates μ).extremePoints ℝ, ¬FiniteDimensional ℂ (LinearMap.range T.toLinearMap) := by
  exact haarHasInfiniteExtreme_iff μ

end KDClosure.CompactFourier
