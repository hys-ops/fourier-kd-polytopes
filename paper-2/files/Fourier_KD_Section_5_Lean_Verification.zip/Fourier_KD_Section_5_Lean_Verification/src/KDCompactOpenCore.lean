import Mathlib.Topology.Algebra.OpenSubgroup
import Mathlib.GroupTheory.Index

namespace KDClosure.CompactCore
open scoped Pointwise

/-- The actual compact open additive subgroups, with their inclusion order. -/
abbrev CO (G : Type*) [AddCommGroup G] [TopologicalSpace G] :=
  {H : OpenAddSubgroup G // IsCompact (H : Set G)}

variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]

abbrev subgroup (H : CO G) : AddSubgroup G := H.val.toAddSubgroup

/-- K / (K ∩ L); for L ≤ K this is K/L. -/
abbrev CoreQuot (L K : CO G) := subgroup K ⧸ (subgroup L).addSubgroupOf (subgroup K)

noncomputable abbrev idx (L K : CO G) := (subgroup L).relIndex (subgroup K)

theorem finite_core (L K : CO G) : Finite (CoreQuot L K) := by
  let _ : CompactSpace (subgroup K) := isCompact_iff_compactSpace.mp K.property
  apply AddSubgroup.quotient_finite_of_isOpen
  exact L.val.isOpen.preimage continuous_subtype_val

theorem index_positive (L K : CO G) : 0 < idx L K := by
  let _ := finite_core L K
  exact Nat.card_pos (α:=CoreQuot L K)

noncomputable def meet (L K : CO G) : CO G :=
  ⟨L.val ⊓ K.val,L.property.inter_right K.val.isClosed⟩

noncomputable def join (L K : CO G) : CO G :=
  ⟨L.val ⊔ K.val,by
    have eqn : ((L.val ⊔ K.val : OpenAddSubgroup G) : Set G) = (L.val : Set G) + (K.val : Set G) :=
      Set.ext fun _ => AddSubgroup.mem_sup
    rw [eqn]
    exact L.property.add K.property⟩

/-- Every algebraic subgroup in an actual compact-open interval is again
compact and open, without a separate closedness assumption. -/
theorem intermediate {L K : CO G} {S : AddSubgroup G} (hl : subgroup L ≤ S)
    (hk : S ≤ subgroup K) : IsOpen (S : Set G) ∧ IsCompact (S : Set G) := by
  have ho := AddSubgroup.isOpen_mono hl L.val.isOpen
  exact ⟨ho,K.property.of_isClosed_subset (S.isClosed_of_isOpen ho) hk⟩

/-- A maximizer for the nested relative index is the least-to-greatest interval.
Enlarging its upper endpoint by a sum, or shrinking its lower endpoint by
an intersection, would multiply the positive index by a factor greater than one. -/
theorem maximal_pair {L K : CO G} (hlk : L ≤ K)
    (maximal : ∀ A B : CO G, A ≤ B → idx A B ≤ idx L K) :
    ∀ C : CO G, L ≤ C ∧ C ≤ K := by
  intro C
  let I := meet L C
  let J := join K C
  have hil : I ≤ L := (inf_le_left : L.val ⊓ C.val ≤ L.val)
  have hic : I ≤ C := (inf_le_right : L.val ⊓ C.val ≤ C.val)
  have hkj : K ≤ J := (le_sup_left : K.val ≤ K.val ⊔ C.val)
  have hcj : C ≤ J := (le_sup_right : C.val ≤ K.val ⊔ C.val)
  have il := AddSubgroup.relIndex_mul_relIndex (subgroup I) (subgroup L) (subgroup K) hil hlk
  have kj := AddSubgroup.relIndex_mul_relIndex (subgroup L) (subgroup K) (subgroup J) hlk hkj
  have il_le : idx I L * idx L K ≤ 1 * idx L K := by
    rw [il,one_mul]
    exact maximal _ _ (hil.trans hlk)
  have kj_le : idx L K * idx K J ≤ idx L K * 1 := by
    rw [kj,mul_one]
    exact maximal _ _ (hlk.trans hkj)
  have il1 : idx I L = 1 := Nat.le_antisymm (Nat.le_of_mul_le_mul_right il_le (index_positive L K)) (index_positive I L)
  have kj1 : idx K J = 1 := Nat.le_antisymm (Nat.le_of_mul_le_mul_left kj_le (index_positive L K)) (index_positive K J)
  exact ⟨(AddSubgroup.relIndex_eq_one.mp il1).trans hic,hcj.trans (AddSubgroup.relIndex_eq_one.mp kj1)⟩

theorem interval_bound {L K : CO G} (interval : ∀ C : CO G, L ≤ C ∧ C ≤ K)
    (A B : CO G) : idx A B ≤ idx L K :=
  (AddSubgroup.relIndex_le_of_le_left (interval A).1 (index_positive L B).ne').trans
    (AddSubgroup.relIndex_le_of_le_right (interval B).2 (index_positive L K).ne')

/-- Exact fixed-bound equivalence. Both endpoints are themselves compact
and open; the order of their finite quotient gives the attained maximum
for arbitrary pairs, including pairs not comparable under inclusion. -/
theorem bounded_iff_finite_core (U : CO G) (M : ℕ) :
    (∀ A B : CO G, A ≤ B → idx A B ≤ M) ↔
    ∃ L K : CO G, (∀ C : CO G, L ≤ C ∧ C ≤ K) ∧ Finite (CoreQuot L K) ∧
      Nat.card (CoreQuot L K) ≤ M := by
  classical
  constructor
  · intro h
    let P (n : ℕ) := ∃ A B : CO G, A ≤ B ∧ idx A B = n
    have hu : P (idx U U) := ⟨U,U,le_rfl,rfl⟩
    obtain ⟨L,K,hlk,hmax⟩ := Nat.findGreatest_spec (P:=P) (h U U le_rfl) hu
    have best (A B : CO G) (hab : A ≤ B) : idx A B ≤ idx L K := by
      rw [hmax]
      exact Nat.le_findGreatest (h _ _ hab) ⟨A,B,hab,rfl⟩
    exact ⟨L,K,maximal_pair hlk best,finite_core L K,h L K hlk⟩
  · rintro ⟨L,K,h,_,hm⟩ A B _
    exact (interval_bound h A B).trans hm


private abbrev Inside (L K : CO G) :=
  {S : AddSubgroup (subgroup K) // (subgroup L).addSubgroupOf (subgroup K) ≤ S}

private def fromInside (L K : CO G) (h : L ≤ K) (S : Inside L K) : CO G := by
  let A := S.val.map (subgroup K).subtype
  have hl : subgroup L ≤ A := by
    intro x hx
    exact ⟨⟨x,h hx⟩,S.property (show x ∈ subgroup L from hx),rfl⟩
  have hk : A ≤ subgroup K := AddSubgroup.map_subtype_le _
  have ho := intermediate hl hk
  exact ⟨⟨A,ho.1⟩,ho.2⟩

/-- The entire compact-open subgroup poset agrees, with inclusions in
both directions, with the subgroup lattice of the single finite core.
The forward direction takes a quotient subgroup to its full inverse
image in K and then its image in G. -/
noncomputable def coreOrderIso (L K : CO G) (all : ∀ C : CO G, L ≤ C ∧ C ≤ K) :
    AddSubgroup (CoreQuot L K) ≃o CO G := by
  let h := (all L).2
  let e : Inside L K ≃o CO G := {
    toFun := fromInside L K h
    invFun := fun C => ⟨(subgroup C).addSubgroupOf (subgroup K), fun _ hx => (all C).1 hx⟩
    left_inv := fun S => Subtype.ext (AddSubgroup.comap_map_eq_self_of_injective
      (subgroup K).subtype_injective S.val)
    right_inv := fun C => Subtype.ext (OpenAddSubgroup.toAddSubgroup_injective
      (AddSubgroup.map_addSubgroupOf_eq_of_le (all C).2))
    map_rel_iff' := AddSubgroup.map_le_map_iff_of_injective (subgroup K).subtype_injective }
  exact (QuotientAddGroup.comapMk'OrderIso ((subgroup L).addSubgroupOf (subgroup K))).trans e

end KDClosure.CompactCore
