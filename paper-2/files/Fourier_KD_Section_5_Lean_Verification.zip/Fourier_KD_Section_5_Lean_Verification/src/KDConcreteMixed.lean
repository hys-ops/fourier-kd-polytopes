import KDScaleWitness
import KDScheduledNull
import KDFiniteSparseKD
import KDOperatorTrace
import KDSparseTransfer

namespace KDClosure.ConcreteMixed
open Set Matrix Discrete PhysicalLift WaveSupport ScheduledNull
open scoped BigOperators ComplexOrder

variable {p q : ℕ} [Fact p.Prime] [Fact q.Prime]

private theorem budget_positive {m : ℕ} (hL : 1<p^m) :
    0 < (2*q:ℝ)*((p:ℝ)+∑' j,shellMass p (p^m) j) := by
  have posp : 0 < (p:ℝ) := Nat.cast_pos.mpr (Fact.out : p.Prime).pos
  have posq : 0 < (q:ℝ) := Nat.cast_pos.mpr (Fact.out : q.Prime).pos
  have hsum : 0 ≤ ∑' j, shellMass p (p^m) j := tsum_nonneg (fun j => (shell_bound (p:=p) hL j).1)
  exact mul_pos (by positivity) (add_pos_of_pos_of_nonneg posp hsum)


/-- The reindexed finite matrices to which exactly the same birth vectors,
frequency masks, and trace budget will be applied. -/
private def GoodPrefix (m l n : ℕ) (C : Matrix (Head p q (n*(m+1))) (Head p q (n*(m+1))) ℂ) : Prop :=
  let f := fresh p (p^m)
  let N := n*(m+1)
  let e := fun i => (cyclicMixedHead p q i : Head p q i → MixedD p q)
  let A := extendMatrix (e N) C
  C.PosSemidef ∧
    (∑ i, (C i i).re) ≤ (2*q:ℝ)*((p:ℝ)+∑' j, shellMass p (p^m) j) ∧
    (2 ≤ ∑ t, (C (0,t) (0,t)).re) ∧
    (∀ x t k v, 0 ≤ table (rowsOf (e N) A) x t k v) ∧
    (∀ x t k v, Protected (color (p:=p) N l) x t v → table (rowsOf (e N) A) x t k v=0) ∧
    ∀ x y, A (mixedRootHead p q m n x,mixedRootHead p q m n y) =
      1 * actualMatrix (q:=q) (originalWeight (p:=p) (L:=p^m) f n) (signFlag l n)
        (perturbation (L:=p^m) q (fun _ => negativeDigit p) f l n oddSign) x y

private theorem assemble (hpq : p ≠ q) (l : ℕ) (hl : 0<l) (hlt : l<p) (m : ℕ)
    (hL : 1<p^m) (family : ∀ n, ∃ C, GoodPrefix (p:=p) (q:=q) m l n C) :
    ∃ T ∈ (physicalTests p q).extremePoints ℝ, T.IsPositive ∧
      (∑' x : MixedD p q, (inner ℂ (lp.single 2 x (1:ℂ)) (T (lp.single 2 x (1:ℂ)))).re)=1 ∧
      ¬FiniteDimensional ℂ (LinearMap.range T.toLinearMap) := by
  classical
  let f := fresh p (p^m)
  obtain ⟨ha,ha1,_⟩ := a_properties (q:=q)
  have hr : (avgColor p l)^2 < 1 := SparseKD.r_bound hl hlt
  obtain ⟨W₁,w₁,d₁⟩ := realize (p:=p) (a₀:=a q) (by linarith) ha1 m l f fresh_props.1 fresh_props.2
  obtain ⟨W₂,w₂,d₂⟩ := realize (p:=p) (a₀:= -a q) (by linarith) (by linarith) m l f fresh_props.1 fresh_props.2
  apply unscaled_operator hpq l hl hlt (schedule m) (schedule_increasing m)
      (fun _ => negativeDigit p) (amp p q m l f) (amp_nonzero _ _ f fresh_props.1 fresh_props.2)
      (factor q (a q) W₁) (factor q (-a q) W₂)
      (factor_nonzero (by linarith) W₁ w₁) (factor_nonzero (by linarith) W₂ w₂)
      (ratio (a q) (avgColor p l)) (Complex.ofReal_ne_zero.mpr (ratio_positive l hr).ne')
      _ (budget_positive (q:=q) hL)
  intro K
  let n := K+1
  obtain ⟨C, ps,tr,visible,kd,mask,rep⟩ := family n
  refine ⟨n*(m+1), ?_, C,ps,tr,visible,kd,mask,?_⟩
  · exact le_trans (Nat.le_succ K) (Nat.le_mul_of_pos_right n (Nat.succ_pos _))
  · intro j hj
    exact original_birth_zero m l hlt hr f fresh_props.1 fresh_props.2 W₁ W₂ d₁ d₂ w₁ w₂
        n (⟨j,Nat.lt_succ_of_le hj⟩ : Fin n) 1 _ rep


/-- Every distinct pair of primes gives an infinite-rank extreme positive
operator of unit diagonal mass in the finite Fourier corner model. Both the
operator and its extremality are outputs. The common spacing is chosen
once before all finite cutoffs. -/
theorem mixed_prime_extreme (hpq : p ≠ q) :
    ∃ T ∈ (physicalTests p q).extremePoints ℝ, T.IsPositive ∧
      (∑' x : MixedD p q, (inner ℂ (lp.single 2 x (1:ℂ)) (T (lp.single 2 x (1:ℂ)))).re)=1 ∧
      ¬FiniteDimensional ℂ (LinearMap.range T.toLinearMap) := by
  have hl : 1<p := (Fact.out : p.Prime).one_lt
  obtain ⟨m,_,hL,kd⟩ := SparseKD.exists_sparse_KD (q:=q) Nat.zero_lt_one hl
  apply assemble hpq 1 Nat.zero_lt_one hl m hL
  intro n
  obtain ⟨ps,tr,fib,nonneg,mask,rep⟩ :=
    SparseTransfer.top_certificate Nat.zero_lt_one hl m n hL (kd n)
  exact ⟨SparseTransfer.topOriginal p q m 1 n,ps,tr,fib.ge,nonneg,mask,rep⟩

/-- Trace-one states in the finite Fourier corner model. The finite-frame
supremum is the basis-independent positive trace. -/
noncomputable def finiteFourierStates (p q : ℕ) [Fact p.Prime] [Fact q.Prime] :
    Set (L2 (MixedD p q) →L[ℂ] L2 (MixedD p q)) :=
  {T | T ∈ physicalTests p q ∧ T.IsPositive ∧ IsLUB (finiteFrameMass T) 1}

/-- Extremality also holds in the normalized physical state set with intrinsic
trace one. The ambient range has infinite algebraic dimension. -/
theorem mixed_prime_trace_one_state (hpq : p ≠ q) :
    ∃ T ∈ (finiteFourierStates p q).extremePoints ℝ, T.IsPositive ∧
      IsLUB (finiteFrameMass T) 1 ∧ ¬FiniteDimensional ℂ (LinearMap.range T.toLinearMap) := by
  obtain ⟨T,hE,ps,unit,rank⟩ := mixed_prime_extreme hpq
  have summ : Summable (fun x : MixedD p q => (entries T (x,x)).re) := by
    by_contra nonsumm
    change (∑' x : MixedD p q, (entries T (x,x)).re) = 1 at unit
    exact zero_ne_one ((tsum_eq_zero_of_not_summable nonsumm).symm.trans unit)
  have tr := realized_trace_one ps summ unit
  have mem : T ∈ finiteFourierStates p q := ⟨hE.1,ps,tr⟩
  have sub : finiteFourierStates p q ⊆ physicalTests p q := fun _ h => h.1
  exact ⟨T, inter_extremePoints_subset_extremePoints_of_subset sub ⟨mem,hE⟩,ps,tr,rank⟩

end KDClosure.ConcreteMixed
