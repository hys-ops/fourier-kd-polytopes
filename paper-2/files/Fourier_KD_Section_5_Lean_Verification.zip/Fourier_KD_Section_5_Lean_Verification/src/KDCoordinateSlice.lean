import KDClosedFace
import KDFiniteSummand

namespace KDClosure
open Set Matrix
open scoped ComplexOrder BigOperators

/-- The physical table of a finite cyclic corner expressed in the coordinates of
an arbitrary ambient kernel. n labels the size of the first cyclic factor. -/
def rowsOf {D : Type*} {m q : ℕ} (e : ZMod m × ZMod q → D)
    (A : D × D → ℂ) : Blocks m q := fun x h t u => A (e (x,t), e (x+h,u))

theorem continuous_table {D : Type*} {m q : ℕ} [NeZero m] [Fact q.Prime]
    (e : ZMod m × ZMod q → D) (x : ZMod m) (t : ZMod q) (k : ZMod m) (s : ZMod q) :
    Continuous (fun A : D×D → ℂ => table (rowsOf e A) x t k s) := by
  simp only [table,transRow,ZMod.dft_apply,rowsOf]
  fun_prop

private theorem closed_forall {I X : Type*} [TopologicalSpace X] {P : I → X → Prop}
    (h : ∀ i, IsClosed {x | P i x}) : IsClosed {x | ∀ i, P i x} := by
  rw [Set.ofPred_forall]; exact isClosed_iInter h

section
variable {D : Type*} {p q : ℕ} [Fact p.Prime] [Fact q.Prime]
abbrev Head (p q n : ℕ) := ZMod (p^(n+1)) × ZMod q
variable (e : ∀ n : ℕ, Head p q n → D)

noncomputable def cornerQ (n : ℕ) (u : Head p q n → ℂ) (A : D×D → ℂ) : ℂ :=
  ∑ i, ∑ j, star (u i) * A (e n i,e n j) * u j

noncomputable def cornerTrace (n : ℕ) (A : D×D → ℂ) : ℝ :=
  ∑ i, (A (e n i, e n i)).re

/-- Physical finite-corner substate tests in the coordinate product topology.
The unit entry bound is included explicitly. Normalization on the infinite
space and its identification with trace-class operators are separate. -/
def cornerSlice : Set (D×D → ℂ) := {A |
  (∀ i, ‖A i‖ ≤ 1) ∧ (∀ i j, star (A (i,j)) = A (j,i)) ∧
  (∀ n u, 0 ≤ (cornerQ e n u A).re) ∧ (∀ n, cornerTrace e n A ≤ 1) ∧
  (∀ n x t k s, 0 ≤ (table (rowsOf (e n) A) x t k s).re) ∧
  (∀ n x t k s, (table (rowsOf (e n) A) x t k s).im = 0)}

theorem compact_cornerSlice : IsCompact (cornerSlice e) := by
  have cl : IsClosed (cornerSlice e) := by
    unfold cornerSlice
    repeat' apply IsClosed.inter
    · exact closed_forall fun i =>
        isClosed_le (continuous_apply i).norm continuous_const
    · apply closed_forall; intro i
      apply closed_forall; intro j
      exact isClosed_eq (continuous_apply _).star (continuous_apply _)
    · apply closed_forall; intro n
      apply closed_forall; intro u
      apply isClosed_le continuous_const
      unfold cornerQ; fun_prop
    · apply closed_forall; intro n
      apply isClosed_le _ continuous_const
      unfold cornerTrace; fun_prop
    · repeat' (apply closed_forall; intro)
      exact isClosed_le continuous_const (Complex.continuous_re.comp (continuous_table ..))
    · repeat' (apply closed_forall; intro)
      exact isClosed_eq (Complex.continuous_im.comp (continuous_table ..)) continuous_const
  apply (isCompact_univ_pi (fun _ : D×D => isCompact_closedBall (0:ℂ) 1)).of_isClosed_subset cl
  intro A h i _
  simpa [Metric.mem_closedBall] using h.1 i

end
end KDClosure
