import KDActualCore
noncomputable section
namespace KDClosure.ActualCore
open Set CompactCore
variable (G : Type*) [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
variable [Nonempty (CO G)]

theorem block_surjective : Function.Surjective (block G) := by
  intro H
  obtain ⟨K,hK⟩ := compact_contained G H.property
  let S := (subgroup H).comap (π G)
  have small : S ≤ inside G K := by
    rw [←preimage_block]
    exact AddSubgroup.comap_mono hK
  have op : IsOpen (S : Set (base G)) := H.val.isOpen.preimage QuotientAddGroup.continuous_mk
  have cp := (inside_compact G K).of_isClosed_subset (S.isClosed_of_isOpen op) small
  let φ := (U G).toAddSubgroup.subtype
  have ope : IsOpenMap (fun x : base G => (x:G)) := (U G).isOpen.isOpenMap_subtype_val
  let A : CO G := ⟨⟨S.map φ,ope S op⟩, cp.image continuous_subtype_val⟩
  have eqn : inside G A = S := AddSubgroup.comap_map_eq_self_of_injective (U G).toAddSubgroup.subtype_injective S
  refine ⟨A,Subtype.ext (SetLike.ext' ?_)⟩
  change ((inside G A).map (π G) : Set (C G)) = (subgroup H : Set (C G))
  rw [eqn]
  exact congrArg SetLike.coe (AddSubgroup.map_comap_eq_self_of_surjective (QuotientAddGroup.mk'_surjective _) _)

def orderEquiv : CO G ≃o CO (C G) :=
  { Equiv.ofBijective (block G) ⟨fun x y h => le_antisymm ((block_le_iff G x y).mp h.le)
      ((block_le_iff G y x).mp h.ge),block_surjective G⟩ with
    map_rel_iff' := block_le_iff G _ _ }

theorem block_index (L K : CO G) : idx (block G L) (block G K) = idx L K := by
  have eqn : (inside G K).map (U G).toAddSubgroup.subtype = subgroup K := by
    apply le_antisymm
    · rintro x ⟨y,hy,rfl⟩; exact hy
    · intro x hx
      exact ⟨⟨x,⟨K,hx⟩⟩,hx,rfl⟩
  calc
    _ = (inside G L).relIndex (inside G K) := by
      rw [←preimage_block G L,AddSubgroup.relIndex_comap]
      rfl
    _ = idx L K := by
      change ((subgroup L).comap _).relIndex (inside G K) = _
      rw [AddSubgroup.relIndex_comap,eqn]

end KDClosure.ActualCore
