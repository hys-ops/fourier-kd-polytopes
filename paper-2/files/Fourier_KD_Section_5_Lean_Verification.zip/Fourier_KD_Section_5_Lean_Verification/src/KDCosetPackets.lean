import KDPackets
import Mathlib.NumberTheory.LegendreSymbol.AddCharacter

namespace KDClosure
open scoped BigOperators
variable {p : ℕ} [NeZero p] {I : Type*} [Fintype I]

/-- Fourier cancellation in the p cosets of one packet. Reciprocal weight and
signed reciprocal weight have separately fixed masses on every coset. -/
theorem child_cancellation (χ : AddChar (ZMod p) ℂ) (nontriv : χ ≠ 1)
    (d σ : ZMod p → I → ℂ) (w r a : ℂ)
    (mass : ∀ t, ∑ x, d t x = w)
    (signed : ∀ t, ∑ x, σ t x * d t x = r*w) :
    ∑ t, ∑ x, χ t * ((1-a*σ t x)*d t x) = 0 := by
  have h (t : ZMod p) : ∑ x, (1-a*σ t x)*d t x = w-a*(r*w) := by
    simp only [sub_mul,one_mul,mul_assoc,Finset.sum_sub_distrib,← Finset.mul_sum,mass,signed]
  simp_rw [← Finset.mul_sum,h]
  rw [← Finset.sum_mul, AddChar.sum_eq_zero_of_ne_one nontriv,zero_mul]

/-- Repeating the same signed coset average gives both channel masses. -/
theorem channel_mass (d σ : ZMod p → I → ℂ) (w r a : ℂ)
    (mass : ∀ t, ∑ x, d t x = w)
    (signed : ∀ t, ∑ x, σ t x*d t x = r*w) :
    (∑ t, ∑ x, (1-a*σ t x)*d t x) = (p:ℂ)*w*(1-a*r) := by
  simp only [sub_mul,one_mul,mul_assoc,Finset.sum_sub_distrib,← Finset.mul_sum,mass,signed]
  simp [nsmul_eq_mul]; ring

/-- Application to the actual infinite operator series on a column. Each
packet is a projection term. Weighted orthogonality removes all other indices. -/
theorem packet_column {J H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℂ H]
    (ψ : J → H) (y : J → ℂ) (j : J) (v : H) (h : ℂ)
    (self : inner ℂ (ψ j) v = h) (orth : ∀ i ≠ j, inner ℂ (ψ i) v = 0) :
    (∑' i, (y i * inner ℂ (ψ i) v) • ψ i) = (y j*h) • ψ j := by
  rw [tsum_eq_single j]
  · rw [self]
  · intro i hi; simp [orth i hi]

/-- The two diagonal multipliers and the two column identities imply the
actual null-vector equation for the two-by-two operator action. -/
theorem block_kernel {H : Type*} [AddCommGroup H] [Module ℂ H]
    (D₁ D₂ Y : H →ₗ[ℂ] H) (v w ψ : H) (b c α β : ℂ)
    (vrow : D₁ v = ψ) (wrow : D₂ w = ψ)
    (column₁ : Y v = α • ψ) (column₂ : Y w = β • ψ)
    (h₁ : b*α=c) (h₂ : b*β*c=1) :
    D₁ v + b • Y (-c • w) = 0 ∧ b • Y v + D₂ (-c • w) = 0 := by
  simp only [map_smul,vrow,wrow,column₁,column₂,smul_smul,h₁]
  constructor
  · have e : b*(-c*β) = -1 := by linear_combination -h₂
    rw [e]; simp
  · simp

end KDClosure
