import KDSubgroupMeasure

/-! On a countable space of positions, a genuine Fourier L² row is
nonnegative at almost every phase-space point exactly when each position
passes its own almost-everywhere frequency test. -/
noncomputable section
namespace KDClosure.CountRows
open MeasureTheory
open scoped ComplexOrder
variable {D X : Type*} [MeasurableSpace D] [MeasurableSingletonClass D]
  [Countable D] [MeasurableSpace X] {ν : Measure X} [SFinite ν]

theorem product_iff_rows (f : D → Lp ℂ 2 ν) :
    (∀ᵐ z ∂((Measure.count : Measure D).prod ν), 0 ≤ f z.1 z.2) ↔
    ∀ x, ∀ᵐ χ ∂ν, 0 ≤ f x χ := by
  let k (z : D × X) := f z.1 z.2
  have meas : Measurable k := measurable_from_prod_countable_right fun x =>
    (Lp.stronglyMeasurable (f x)).measurable
  have ms : MeasurableSet {z | 0≤k z} := by
    simp only [Complex.nonneg_iff]
    exact (measurableSet_le measurable_const (Complex.continuous_re.measurable.comp meas)).inter
      (measurableSet_eq_fun measurable_const (Complex.continuous_im.measurable.comp meas))
  change (∀ᵐ z ∂((Measure.count : Measure D).prod ν), 0≤k z) ↔ _
  rw [Measure.ae_prod_iff_ae_ae ms,Measure.ae_count_iff]

omit [SFinite ν] in
/-- A measure-preserving change of frequency coordinates also reflects the
a.e. real nonnegative cone, for actual complex L² rows. -/
theorem pull_nonneg {Y : Type*} [MeasurableSpace Y] {μ : Measure Y} {k : Y → X}
    (hk : MeasurePreserving k μ ν) (f : Lp ℂ 2 ν) :
    (∀ᵐ z ∂μ, 0 ≤ (Lp.compMeasurePreserving k hk f) z) ↔ ∀ᵐ z ∂ν, 0 ≤ f z := by
  have test : MeasurableSet {z : ℂ | 0 ≤ z} := by
    simp only [Complex.nonneg_iff,Set.ofPred_and]
    exact (measurableSet_le measurable_const Complex.continuous_re.measurable).inter
      (measurableSet_eq_fun measurable_const Complex.continuous_im.measurable)
  have h := SubgroupMeasure.ae_reflection hk
    (((Lp.stronglyMeasurable f).measurable test).nullMeasurableSet)
  change (∀ᵐ z ∂μ, 0 ≤ (Lp.compMeasurePreserving k hk f) z) ↔ _
  refine Iff.trans ?_ h
  apply Filter.eventually_congr
  filter_upwards [Lp.coeFn_compMeasurePreserving f hk] with z hz
  rw [hz]; rfl

end KDClosure.CountRows
