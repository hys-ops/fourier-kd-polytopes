module
public import Mathlib.GroupTheory.SpecificGroups.Cyclic
public import Mathlib.Algebra.Group.Subgroup.Finite
@[expose] public section
/-! Compatibility lemma replacing mathlib 4.34.1's addSubgroup_le_iff_card_dvd
by a direct proof in 4.33.1. -/
namespace KFS5KDCompat
theorem addSubgroup_le_iff_card_dvd {G : Type*} [AddCommGroup G] [Fintype G]
    [IsAddCyclic G] (H K : AddSubgroup G) : H≤K ↔ Nat.card H ∣ Nat.card K := by
  classical
  constructor
  · intro le
    exact AddSubgroup.card_dvd_of_le le
  · intro dvd
    let V := Finset.univ.filter (fun g : G => Nat.card K • g = 0)
    have killed (U : AddSubgroup G) (x : G) (hx : x∈U) : Nat.card U • x = 0 := by
      exact congrArg Subtype.val (show Nat.card U • (⟨x,hx⟩:U) = 0 by simp)
    have inc : (K:Set G).toFinset ⊆ V := by
      intro x hx
      exact Finset.mem_filter.mpr ⟨Finset.mem_univ _,killed K _ (Set.mem_toFinset.mp hx)⟩
    have small : V.card ≤ (K:Set G).toFinset.card := by
      have h := IsAddCyclic.card_nsmul_eq_zero_le (α:=G) (n:=Nat.card K) Nat.card_pos
      have card : (K:Set G).toFinset.card = Nat.card K := by
        rw [Set.toFinset_card, ← Nat.card_eq_fintype_card]; rfl
      rw [card]; exact h
    have eq := Finset.eq_of_subset_of_card_le inc small
    intro x hx
    apply Set.mem_toFinset.mp
    rw [eq]
    apply Finset.mem_filter.mpr
    refine ⟨Finset.mem_univ _,?_⟩
    obtain ⟨b,hb⟩ := dvd
    rw [hb,Nat.mul_comm,mul_smul,killed H x hx,smul_zero]
end KFS5KDCompat
