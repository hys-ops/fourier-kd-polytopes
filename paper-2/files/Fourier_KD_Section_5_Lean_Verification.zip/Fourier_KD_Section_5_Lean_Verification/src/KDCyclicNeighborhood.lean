import KDLCARealityEscape
import KDCompactOpenCore
import Mathlib.MeasureTheory.Measure.Haar.Basic
noncomputable section
namespace KDClosure.LCAReality
open Set Topology Filter MeasureTheory Pointwise
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
def cyclicElements : AddSubgroup G where
  carrier := {h | CompactCyclic h}
  zero_mem' := ⟨{0},isCompact_singleton,by simp⟩
  add_mem' := by
    rintro x y ⟨A,c,f⟩ ⟨B,d,g⟩
    exact ⟨A+B,c.add d,fun n => by rw [zsmul_add]; exact Set.add_mem_add (f n) (g n)⟩
  neg_mem' := by
    rintro x ⟨C,h,k⟩
    exact ⟨C,h,fun n => by simpa using k (-n)⟩

variable [T2Space G]
private theorem finite_contained {S : Set G} (fin : S.Finite) (sub : S ⊆ (cyclicElements (G:=G) : Set G)) :
    ∃ L : AddSubgroup G, IsCompact (L : Set G) ∧ S ⊆ L := by
  induction S,fin using Set.Finite.induction_on with
  | empty => exact ⟨⊥,by simp,empty_subset _⟩
  | @insert a S _ _ ih =>
    obtain ⟨L,cl,sl⟩ := ih (fun _ h => sub (mem_insert_of_mem _ h))
    obtain ⟨C,cc,orb⟩ := sub (mem_insert a S)
    let K := (AddSubgroup.zmultiples a).topologicalClosure
    have kc : IsCompact (K : Set G) := cc.of_isClosed_subset isClosed_closure
      (closure_minimal (fun x hx => by obtain ⟨n,rfl⟩ := AddSubgroup.mem_zmultiples_iff.mp hx; exact orb n) cc.isClosed)
    refine ⟨K ⊔ L,?_,insert_subset ?_ (sl.trans (le_sup_right : L ≤ K⊔L))⟩
    · have eqn : ((K ⊔ L : AddSubgroup G) : Set G) = (K : Set G) + (L : Set G) := Set.ext fun _ => AddSubgroup.mem_sup
      rw [eqn]; exact kc.add cl
    · exact (le_sup_left : K ≤ K⊔L) (subset_closure (AddSubgroup.mem_zmultiples a))

variable [LocallyCompactSpace G]
theorem compactOpen_of_cyclic_open (op : IsOpen (cyclicElements (G:=G) : Set G)) : Nonempty (CompactCore.CO G) := by
  classical
  obtain ⟨A,ac,z,sub⟩ := exists_compact_subset op ((cyclicElements (G:=G)).zero_mem : (0:G) ∈ _)
  let W := A ∩ -A
  have wc : IsCompact W := ac.inter_right ac.neg.isClosed
  have wa : W ⊆ (cyclicElements (G:=G) : Set G) := inter_subset_left.trans sub
  have wz : W ∈ 𝓝 (0:G) := by
    have n := mem_interior_iff_mem_nhds.mp z
    apply inter_mem n
    change ∀ᶠ x in 𝓝 (0:G), -x ∈ A
    exact (continuous_neg.tendsto (0:G)).eventually_mem (by simpa using n : A∈𝓝 (-(0:G)))
  have negw {x : G} (h : x ∈ W) : -x ∈ W := ⟨h.2,by simpa using h.1⟩
  let B := W+W
  let cv (a : G) := (fun x:G => x-a) ⁻¹' interior W
  have cov : B ⊆ ⋃ a ∈ B,cv a := fun x hx => mem_iUnion.mpr ⟨x, mem_iUnion.mpr
    ⟨hx,by simpa [cv] using (mem_interior_iff_mem_nhds.mpr wz)⟩⟩
  obtain ⟨F,fb,fin,fcover⟩ := (wc.add wc).elim_finite_subcover_image
    (fun (i:G) (_ : i ∈ B) => (isOpen_interior.preimage (continuous_id.sub continuous_const) : IsOpen (cv i))) cov
  have bc : B ⊆ (cyclicElements (G:=G) : Set G) := by
    rintro x ⟨a,ha,b,hb,rfl⟩; exact (cyclicElements (G:=G)).add_mem (wa ha) (wa hb)
  obtain ⟨L,lc,fl⟩ := finite_contained fin (fb.trans bc)
  have absorb : B ⊆ (L : Set G)+W := by
    intro x hx
    obtain ⟨i,hi⟩ := mem_iUnion.mp (fcover hx)
    obtain ⟨hf,hr⟩ := mem_iUnion.mp hi
    exact ⟨i,fl hf,x-i,interior_subset hr,by abel⟩
  have wz' := mem_of_mem_nhds wz
  let H : AddSubgroup G := {
    carrier := (L : Set G)+W
    zero_mem' := ⟨0,L.zero_mem,0,wz',zero_add _⟩
    neg_mem' := by rintro x ⟨a,ha,b,hb,rfl⟩; exact ⟨-a,L.neg_mem ha,-b,negw hb,by exact (neg_add a b).symm⟩
    add_mem' := by
      rintro x y ⟨a,ha,b,hb,rfl⟩ ⟨c,hc,d,hd,rfl⟩
      obtain ⟨l,hl,w,hw,eqn⟩ := absorb (Set.add_mem_add hb hd)
      exact ⟨a+c+l,L.add_mem (L.add_mem ha hc) hl,w,hw,by change a+c+l+w = a+b+(c+d); change l+w=b+d at eqn; rw [add_assoc (a+c),eqn]; abel⟩ }
  have ho : IsOpen (H : Set G) := H.isOpen_of_mem_nhds (g:=0)
    (mem_of_superset wz (fun x hx => ⟨0,L.zero_mem,x,hx,zero_add _⟩))
  exact ⟨⟨⟨H,ho⟩,lc.add wc⟩⟩

variable [SigmaCompactSpace G] [MeasurableSpace G] [BorelSpace G]
theorem measurable_cyclic : MeasurableSet (cyclicElements (G:=G) : Set G) := by
  let K := CompactExhaustion.choice G
  have eqn : (cyclicElements (G:=G) : Set G) = ⋃ n : ℕ, ⋂ m : ℤ, (fun x:G => m • x) ⁻¹' K n := by
    ext x
    simp only [mem_iUnion,mem_iInter,mem_preimage]
    constructor
    · rintro ⟨C,hc,f⟩
      obtain ⟨n,c⟩ := K.exists_superset_of_isCompact hc
      exact ⟨n,fun m => c (f m)⟩
    · rintro ⟨n, h⟩; exact ⟨K n,K.isCompact n,h⟩
  rw [eqn]
  exact MeasurableSet.iUnion fun n => MeasurableSet.iInter fun m =>
    ((K.isCompact n).isClosed.preimage (continuous_const_smul m)).measurableSet

theorem ae_escape_of_no_compactOpen (μ : Measure G) [μ.IsAddHaarMeasure] [Measure.InnerRegular μ]
    (empty : ¬Nonempty (CompactCore.CO G)) : ∀ᵐ x ∂μ, ¬CompactCyclic x := by
  apply ae_iff.mpr
  change μ {x : G | ¬¬ CompactCyclic x}=0
  simp only [not_not]
  by_contra h
  apply empty
  apply compactOpen_of_cyclic_open
  apply (cyclicElements (G:=G)).isOpen_of_mem_nhds (g:=0)
  have n := Measure.sub_mem_nhds_zero_of_addHaar_pos μ (cyclicElements (G:=G) : Set G) measurable_cyclic (pos_iff_ne_zero.mpr h)
  exact mem_of_superset n (by rintro _ ⟨a,ha,b,hb,rfl⟩; exact (cyclicElements (G:=G)).sub_mem ha hb)
end KDClosure.LCAReality
