import KDIsometricSupport
import KDOperatorTrace

noncomputable section
namespace KDClosure.DiscreteEmbedding
open Discrete Set Function ContinuousLinearMap
open scoped ENNReal InnerProductSpace BigOperators
variable {D E : Type*}

private def zeroPad (e : D ↪ E) (f : D → ℂ) : E → ℂ := Function.extend e f 0

private theorem zeroPad_on (e : D ↪ E) (f : D → ℂ) (i : D) : zeroPad e f (e i)=f i :=
  e.injective.extend_apply ..

private theorem zeroPad_off (e : D ↪ E) (f : D → ℂ) {y : E} (hy : y ∉ range e) :
    zeroPad e f y=0 := Function.extend_apply' _ _ y hy

private theorem padded_norm_sum (e : D ↪ E) (f : L2 D) :
    HasSum (fun y => ‖zeroPad e f y‖^2) (‖f‖^2) := by
  have hh := lp.hasSum_norm (by norm_num : 0 < (2:ℝ≥0∞).toReal) f
  apply (e.injective.hasSum_iff (fun y hy => by simp [zeroPad_off e f hy])).mp
  change HasSum (fun i => ‖zeroPad e f (e i)‖^2) (‖f‖^2)
  simp only [zeroPad_on]
  simpa only [ENNReal.toReal_ofNat,Real.rpow_two] using hh

private def paddedVector (e : D ↪ E) (f : L2 D) : L2 E :=
  ⟨zeroPad e f, memℓp_gen (by
    simpa only [ENNReal.toReal_ofNat,Real.rpow_two] using (padded_norm_sum e f).summable)⟩

/-- Honest linear isometry obtained by extending each square-summable
function by zero. No group law or countability of either index set is needed. -/
def inclusion (e : D ↪ E) : L2 D →ₗᵢ[ℂ] L2 E where
  toFun := paddedVector e
  map_add' f g := by
    apply lp.ext; funext y
    by_cases hy : y∈range e
    · obtain ⟨i,rfl⟩ := hy
      change zeroPad e _ _ = zeroPad e _ _+zeroPad e _ _
      simp only [zeroPad_on,lp.coeFn_add,Pi.add_apply]
    · change zeroPad e _ _ = zeroPad e _ _+zeroPad e _ _
      rw [zeroPad_off _ _ hy,zeroPad_off _ _ hy,zeroPad_off _ _ hy,zero_add]
  map_smul' c f := by
    apply lp.ext; funext y
    by_cases hy : y∈range e
    · obtain ⟨i,rfl⟩ := hy
      change zeroPad e _ _ = c • zeroPad e _ _
      simp only [zeroPad_on,lp.coeFn_smul,Pi.smul_apply]
    · change zeroPad e _ _ = c • zeroPad e _ _
      rw [zeroPad_off _ _ hy,zeroPad_off _ _ hy,smul_zero]
  norm_map' f := by
    have hs := lp.hasSum_norm (by norm_num : 0 < (2:ℝ≥0∞).toReal) (paddedVector e f)
    have h : ‖paddedVector e f‖^2=‖f‖^2 := by
      apply HasSum.unique _ (padded_norm_sum e f)
      simpa only [paddedVector,ENNReal.toReal_ofNat,Real.rpow_two] using hs
    change ‖paddedVector e f‖ = ‖f‖
    nlinarith [norm_nonneg f,norm_nonneg (paddedVector e f)]

theorem inclusion_on (e : D ↪ E) (f : L2 D) (i : D) : inclusion e f (e i)=f i := zeroPad_on ..

theorem inclusion_off (e : D ↪ E) (f : L2 D) {y : E} (hy : y ∉ range e) : inclusion e f y=0 :=
  zeroPad_off _ _ hy

def push (e : D ↪ E) (A : L2 D →L[ℂ] L2 D) : L2 E →L[ℂ] L2 E :=
  IsometricSupport.lift (inclusion e).toContinuousLinearMap A

theorem push_positive_iff (e : D ↪ E) (A : L2 D →L[ℂ] L2 D) :
    (push e A).IsPositive ↔ A.IsPositive := by
  constructor
  · intro pos
    have eq := IsometricSupport.compress_lift (inclusion e).toContinuousLinearMap (inclusion e).isometry A
    rw [←eq]
    exact pos.adjoint_conj _
  · exact fun ps => ps.conj_adjoint _

variable [DecidableEq D] [DecidableEq E]

theorem inclusion_single (e : D ↪ E) (i : D) (a : ℂ) :
    inclusion e (lp.single 2 i a)=lp.single 2 (e i) a := by
  apply lp.ext; funext y
  by_cases hy : y∈range e
  · obtain ⟨j,rfl⟩ := hy
    rw [inclusion_on]
    by_cases h : j=i
    · subst j; simp
    · simp [lp.single_apply,Pi.single_eq_of_ne h,Pi.single_eq_of_ne (fun h' => h (e.injective h'))]
  · rw [inclusion_off e _ hy]
    exact (lp.single_apply_ne (E:=fun _ : E => ℂ) 2 (e i) a (fun h => hy ⟨i,h.symm⟩)).symm

theorem adjoint_on (e : D ↪ E) (i : D) :
    (inclusion e).toContinuousLinearMap.adjoint (lp.single 2 (e i) 1)=lp.single 2 i (1:ℂ) := by
  apply ext_inner_left ℂ
  intro f
  rw [adjoint_inner_right,lp.inner_single_right,lp.inner_single_right]
  change inner ℂ (inclusion e f (e i)) (1:ℂ)=inner ℂ (f i) (1:ℂ)
  rw [inclusion_on]

omit [DecidableEq D] in
theorem adjoint_off (e : D ↪ E) (y : E) (hy : y ∉ range e) :
    (inclusion e).toContinuousLinearMap.adjoint (lp.single 2 y 1)=0 := by
  apply ext_inner_left ℂ
  intro f
  rw [adjoint_inner_right,inner_zero_right,lp.inner_single_right]
  change inner ℂ (inclusion e f y) (1:ℂ)=0
  rw [inclusion_off e f hy,inner_zero_left]

theorem entries_on (e : D ↪ E) (A : L2 D →L[ℂ] L2 D) (i j : D) :
    entries (push e A) (e i,e j) = entries A (i,j) := by
  change inner ℂ (lp.single 2 (e i) 1) (inclusion e (A ((inclusion e).toContinuousLinearMap.adjoint (lp.single 2 (e j) 1))))=_
  rw [adjoint_on,←inclusion_single e i]
  exact (inclusion e).inner_map_map _ _

omit [DecidableEq D] in
theorem entries_off_left (e : D ↪ E) (A : L2 D →L[ℂ] L2 D) (x y : E) (hx : x ∉ range e) :
    entries (push e A) (x,y)=0 := by
  change inner ℂ (lp.single 2 x 1) (inclusion e (A ((inclusion e).toContinuousLinearMap.adjoint (lp.single 2 y 1))))=0
  rw [lp.inner_single_left,inclusion_off e _ hx,inner_zero_right]

omit [DecidableEq D] in
theorem entries_off_right (e : D ↪ E) (A : L2 D →L[ℂ] L2 D) (x y : E) (hy : y ∉ range e) :
    entries (push e A) (x,y)=0 := by
  change inner ℂ (lp.single 2 x 1) (inclusion e (A ((inclusion e).toContinuousLinearMap.adjoint (lp.single 2 y 1))))=0
  rw [adjoint_off e y hy,map_zero,map_zero,inner_zero_right]

private theorem cert {I : Type*} [DecidableEq I] (T : L2 I →L[ℂ] L2 I) (positive : T.IsPositive) (t : ℝ) :
      IsLUB (finiteFrameMass T) t ↔ HasSum (fun i => (entries T (i,i)).re) t := by
    constructor
    · intro h
      have sum := (boundedFrames_iff_diagonal positive).mp ⟨t,h.1⟩
      exact (trace_isLUB positive sum).unique h ▸ sum.hasSum
    · intro h
      exact h.tsum_eq ▸ trace_isLUB positive h.summable

/-- The positive trace, characterized by the supremum over all orthonormal
frames, is preserved and reflected at every finite value, in particular at 1. -/
theorem trace_push_iff (e : D ↪ E) (A : L2 D →L[ℂ] L2 D) (ps : A.IsPositive) (t : ℝ) :
    IsLUB (finiteFrameMass (push e A)) t ↔ IsLUB (finiteFrameMass A) t := by
  rw [cert (push e A) ((push_positive_iff e A).mpr ps) t,cert A ps t]
  rw [←e.injective.hasSum_iff (fun y hy => by rw [entries_off_left e A y y hy,Complex.zero_re])]
  change HasSum (fun i => (entries (push e A) (e i,e i)).re) t ↔ HasSum _ t
  simp only [entries_on]

end KDClosure.DiscreteEmbedding
