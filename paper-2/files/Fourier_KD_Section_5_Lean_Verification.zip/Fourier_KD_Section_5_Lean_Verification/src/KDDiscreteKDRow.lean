import KDFourierSynthesis
import KDDiscreteOrtho
import KDInjectiveMeasure
import KDDiscreteEmbedding
import KDCountRows

/-! The discrete subgroup step, formulated for an arbitrary injective
homomorphism. The physical KD Fourier convention is χ(y/x). -/
noncomputable section
namespace KDClosure.DiscreteKDRow
open Set MeasureTheory Discrete FourierSynthesis
open scoped Topology BigOperators ComplexOrder KDClosure.SubgroupMeasure

private theorem transport_sum {D G Ω Ψ : Type*} [DecidableEq D] [DecidableEq G]
    [MeasurableSpace Ω] [MeasurableSpace Ψ] {μ : Measure Ω} {ν : Measure Ψ}
    (i : D ↪ G) (P : Lp ℂ 2 μ →ₗᵢ[ℂ] Lp ℂ 2 ν)
    (u : D → Lp ℂ 2 μ) (v : G → Lp ℂ 2 ν)
    (hu : Orthonormal ℂ u) (hv : Orthonormal ℂ v)
    (A : L2 D →L[ℂ] L2 D) (B : L2 G →L[ℂ] L2 G) (x : D)
    (onEntries : ∀ y, entries B (i x,i y) = entries A (x,y))
    (offEntries : ∀ y, y ∉ range i → entries B (i x,y)=0)
    (basis_agrees : ∀ y, P (u y)=v (i y)) :
    density v B (i x) = P (density u A x) := by
  let term (y : G) := entries B (i x,y) • v y
  have off (y : G) (h : y ∉ range i) : term y = 0 := by
    simp only [term,offEntries y h,zero_smul]
  have hsmall := P.toContinuousLinearMap.hasSum (row_hasSum u hu A x)
  have comp : HasSum (term ∘ i) (P (density u A x)) := by
    convert! hsmall using 1
    funext y
    change entries B (i x,i y) • v (i y) = P (entries A (x,y) • u y)
    rw [map_smul,basis_agrees,onEntries]
  exact (row_hasSum v hv B (i x)).unique ((i.injective.hasSum_iff off).mp comp)


open SubgroupMeasure DiscreteOrtho

section Operator
variable (G : Type*) [CommGroup G] [TopologicalSpace G] [DiscreteTopology G]

/-- The L² basis character evaluated at the displacement of a fixed physical row. -/
def phase (x y : G) : Lp ℂ 2 (dualHaar G) := basis G (y/x)

theorem phase_ae (x y : G) : (phase G x y : PontryaginDual G → ℂ) =ᵐ[dualHaar G]
    fun χ => (χ (y/x):ℂ) := basis_ae G (y/x)

theorem phase_orthonormal (x : G) : Orthonormal ℂ (phase G x) :=
  (basis_orthonormal G).comp (fun y => y/x) (fun _ _ h => by
    simpa only [div_mul_cancel] using congrArg (fun y : G => y*x) h)

variable [DecidableEq G]
/-- Physical position-row KD density in the dual's normalized Haar L² space. -/
def rowDensity (T : L2 G →L[ℂ] L2 G) (x : G) : Lp ℂ 2 (dualHaar G) :=
  density (phase G x) T x

theorem row_hasSum (T : L2 G →L[ℂ] L2 G) (x : G) :
    HasSum (fun y => entries T (x,y) • phase G x y) (rowDensity G T x) :=
  FourierSynthesis.row_hasSum _ (phase_orthonormal G x) T x

def RowNonneg (T : L2 G →L[ℂ] L2 G) : Prop :=
  ∀ x, ∀ᵐ χ ∂dualHaar G, 0 ≤ rowDensity G T x χ

local instance positionMeas : MeasurableSpace G := ⊤
local instance : MeasurableSingletonClass G := ⟨fun _ => MeasurableSpace.measurableSet_top⟩

theorem joint_ae_iff [Countable G] (T : L2 G →L[ℂ] L2 G) :
    (∀ᵐ z ∂((Measure.count : Measure G).prod (dualHaar G)), 0≤rowDensity G T z.1 z.2) ↔
    RowNonneg G T :=
  CountRows.product_iff_rows (rowDensity G T)

end Operator

section Embedding
variable {D G : Type*} [CommGroup D] [TopologicalSpace D] [DiscreteTopology D]
    [CommGroup G] [TopologicalSpace G] [DiscreteTopology G]

/-- Evaluations at e(y)/e(x) come from the restriction of the actual character.
The equality is between L² functions, and uses the law-preserving restriction. -/
theorem phase_along (e : D →* G) (he : Function.Injective e) (x y : D) :
    alongL2 e he (phase D x y) = phase G (e x) (e y) := by
  apply Lp.ext
  have a := alongL2_ae e he (phase D x y)
  have b := (along_measurePreserving e he).quasiMeasurePreserving.ae_eq_comp (phase_ae D x y)
  refine a.trans (b.trans ?_)
  filter_upwards [phase_ae G (e x) (e y)] with χ h
  rw [h]
  change (χ (e (y/x)):ℂ) = (χ (e y/e x):ℂ)
  rw [map_div]

variable [DecidableEq D] [DecidableEq G]

/-- Zero extension of the operator via the concrete ℓ² isometry. -/
abbrev push (e : D →* G) (he : Function.Injective e) (A : L2 D →L[ℂ] L2 D) :=
  DiscreteEmbedding.push (⟨e,he⟩ : D ↪ G) A

theorem row_on_image (e : D →* G) (he : Function.Injective e) (A : L2 D →L[ℂ] L2 D) (x : D) :
    rowDensity G (push e he A) (e x) = alongL2 e he (rowDensity D A x) := by
  let i : D ↪ G := ⟨e,he⟩
  exact transport_sum i (alongL2 e he) (phase D x) (phase G (e x))
    (phase_orthonormal D x) (phase_orthonormal G (e x)) A (push e he A) x
    (DiscreteEmbedding.entries_on i A x) (DiscreteEmbedding.entries_off_right i A (e x))
    (phase_along e he x)

omit [TopologicalSpace D] [DiscreteTopology D] [DecidableEq D] in
theorem row_off_image (e : D →* G) (he : Function.Injective e) (A : L2 D →L[ℂ] L2 D)
    (x : G) (hx : x ∉ range e) : rowDensity G (push e he A) x = 0 := by
  let i : D ↪ G := ⟨e,he⟩
  have coeff (y : G) : entries (push e he A) (x,y) = 0 :=
    DiscreteEmbedding.entries_off_left i A x y hx
  simp only [rowDensity,density,coeff,zero_smul,tsum_zero]

theorem nonnegative_push_iff (e : D →* G) (he : Function.Injective e) (A : L2 D →L[ℂ] L2 D) :
    RowNonneg G (push e he A) ↔ RowNonneg D A := by
  constructor
  · intro H x
    have h := H (e x)
    rw [row_on_image] at h
    exact (alongL2_nonneg_iff e he (rowDensity D A x)).mp h
  · intro H x
    by_cases hx : x ∈ range e
    · obtain ⟨z,rfl⟩ := hx
      rw [row_on_image]
      exact (alongL2_nonneg_iff e he (rowDensity D A z)).mpr (H z)
    · rw [row_off_image e he A x hx]
      exact (Lp.coeFn_zero ℂ 2 (dualHaar G)).mono fun χ hχ => hχ.ge

end Embedding
end KDClosure.DiscreteKDRow
