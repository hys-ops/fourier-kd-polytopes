import Mathlib.Analysis.InnerProductSpace.l2Space
import Mathlib.Analysis.InnerProductSpace.Positive
import Mathlib.Analysis.InnerProductSpace.Reproducing
import KDFaceExclusion

noncomputable section
namespace KDClosure
namespace Discrete
open scoped InnerProductSpace ComplexOrder ENNReal BigOperators
open ContinuousLinearMap
abbrev L2 (D : Type*) := lp (fun _ : D => ℂ) 2
variable {D H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℂ H]

private theorem analysis_bound (v : D → H) (hs : Summable fun i => ‖v i‖^2)
    (x : H) : Summable (fun i => ‖inner ℂ (v i) x‖^2) ∧
    (∑' i, ‖inner ℂ (v i) x‖^2) ≤ (∑' i, ‖v i‖^2)*‖x‖^2 := by
  have bound (i : D) : ‖inner ℂ (v i) x‖^2 ≤ ‖v i‖^2*‖x‖^2 := by
    rw [←mul_pow]
    exact pow_le_pow_left₀ (norm_nonneg _) (norm_inner_le_norm ..) _
  have sg := hs.mul_right (‖x‖^2)
  have sf := Summable.of_nonneg_of_le (fun i => sq_nonneg _) bound sg
  refine ⟨sf,?_⟩
  simpa only [tsum_mul_right] using sf.tsum_le_tsum bound sg

private def analysisVector (v : D → H) (hs : Summable fun i => ‖v i‖^2) (x : H) :
    L2 D := ⟨fun i => inner ℂ (v i) x, memℓp_gen (by
      norm_num
      exact (analysis_bound v hs x).1)⟩

private def analysisMap (v : D → H) (hs : Summable fun i => ‖v i‖^2)
    (htr : (∑' i, ‖v i‖^2) ≤ 1) : H →L[ℂ] L2 D :=
  LinearMap.mkContinuous
    ({toFun := analysisVector v hs
      map_add' := fun x y => lp.ext (by funext i; exact inner_add_right ..)
      map_smul' := fun c x => lp.ext (by funext i; exact inner_smul_right ..)} : H →ₗ[ℂ] L2 D)
    1 (fun x => by
      rw [one_mul]
      apply lp.norm_le_of_tsum_le (by norm_num) (norm_nonneg _)
      change (∑' i, ‖inner ℂ (v i) x‖ ^ (2:ℝ≥0∞).toReal) ≤ ‖x‖^(2:ℝ≥0∞).toReal
      norm_num
      calc
        _ ≤ _ := (analysis_bound v hs x).2
        _ ≤ _ := by simpa using (mul_le_mul_of_nonneg_right htr (sq_nonneg ‖x‖)))

theorem realizeGram [CompleteSpace H] [DecidableEq D] (v : D → H)
    (hs : Summable fun i => ‖v i‖^2) (htr : (∑' i, ‖v i‖^2) ≤ 1) :
    ∃ T : L2 D →L[ℂ] L2 D, T.IsPositive ∧
      ∀ i j : D, inner ℂ (lp.single 2 i (1:ℂ)) (T (lp.single 2 j (1:ℂ))) = inner ℂ (v i) (v j) := by
  let S := analysisMap v hs htr
  have adj (j : D) : S.adjoint (lp.single 2 j (1:ℂ)) = v j := by
    apply ext_inner_right ℂ
    intro x
    rw [S.adjoint_inner_left, lp.inner_single_left]
    simp only [RCLike.inner_apply, map_one, mul_one]
    rfl
  refine ⟨S.comp S.adjoint, isPositive_self_comp_adjoint S, fun i j => ?_⟩
  rw [comp_apply,adj,lp.inner_single_left]
  simp only [RCLike.inner_apply, map_one, mul_one]
  rfl

private def liftKernel (A : Matrix D D ℂ) : Matrix D D (ℂ →L[ℂ] ℂ) :=
  fun i j => A i j • ContinuousLinearMap.id ℂ ℂ

private theorem lift_pos {A : Matrix D D ℂ} (h : A.PosSemidef) : (liftKernel A).PosSemidef := by
  apply (RKHS.posSemidef_tfae.out 0 2).mpr
  constructor
  · apply Matrix.IsHermitian.ext
    intro i j
    change star (A j i • ContinuousLinearMap.id ℂ ℂ) = A i j • ContinuousLinearMap.id ℂ ℂ
    rw [star_smul, h.1.apply, star_eq_adjoint, adjoint_id]
  · intro f
    have pos := (Complex.nonneg_iff.mp (h.2 f)).1
    convert pos using 1
    apply congrArg Complex.re
    apply Finsupp.sum_congr
    intro i hi
    apply Finsupp.sum_congr
    intro j hj
    change inner ℂ (A j i * f i) (f j) = _
    rw [RCLike.inner_apply, map_mul]
    change _ * (star (A j i) * _) = _
    rw [h.1.apply, starRingEnd_apply]
    ring

/-- A positive scalar matrix with finite diagonal mass is realized exactly on the
ordinary coordinate Hilbert space, for an arbitrary discrete index set. -/
theorem realizePSD [DecidableEq D] (A : Matrix D D ℂ) (h : A.PosSemidef)
    (hs : Summable fun i => (A i i).re) (htr : (∑' i, (A i i).re) ≤ 1) :
    ∃ T : L2 D →L[ℂ] L2 D, T.IsPositive ∧
      ∀ i j : D, inner ℂ (lp.single 2 i (1:ℂ)) (T (lp.single 2 j (1:ℂ))) = A i j := by
  let K := liftKernel A
  let _ : Fact K.PosSemidef := ⟨lift_pos h⟩
  let v (i : D) := RKHS.kerFun (RKHS.OfKernel K) i (1:ℂ)
  have gram (i j : D) : inner ℂ (v i) (v j) = A i j := by
    change inner ℂ (RKHS.kerFun _ i 1) (RKHS.kerFun _ j 1) = _
    rw [RKHS.kerFun_inner, RKHS.kerFun_apply, RKHS.OfKernel.kernel_ofKernel]
    simp [K,liftKernel,RCLike.inner_apply]
  have diag (i : D) : ‖v i‖^2 = (A i i).re := by
    rw [norm_sq_eq_re_inner (𝕜 := ℂ),gram]
    rfl
  obtain ⟨T,hT,hcoeff⟩ := realizeGram v (by simpa only [diag] using hs)
    (by simpa only [diag] using htr)
  exact ⟨T,hT,fun i j => (hcoeff i j).trans (gram i j)⟩

/-- Bounded coordinate operators are uniquely determined by all of their matrix entries. -/
theorem ext_of_entries [DecidableEq D] {T U : L2 D →L[ℂ] L2 D}
    (h : ∀ i j : D, inner ℂ (lp.single 2 i (1:ℂ)) (T (lp.single 2 j (1:ℂ))) =
      inner ℂ (lp.single 2 i (1:ℂ)) (U (lp.single 2 j (1:ℂ)))) : T = U := by
  have col (j : D) : T (lp.single 2 j (1:ℂ)) = U (lp.single 2 j (1:ℂ)) := by
    apply lp.ext
    funext i
    simpa [lp.inner_single_left, RCLike.inner_apply] using h i j
  ext1 x
  have eqterm (j : D) : T (lp.single 2 j (x j)) = U (lp.single 2 j (x j)) := by
    have hs : lp.single 2 j (x j) = x j • (lp.single 2 j (1:ℂ) : L2 D) := by
      rw [← lp.single_smul]
      simp
    rw [hs, map_smul, map_smul, col]
  have hx := lp.hasSum_single (p := 2) (by norm_num) x
  have hT := T.hasSum hx
  have hU := U.hasSum hx
  simp_rw [eqterm] at hT
  exact hT.unique hU

section Corners
variable {p q : ℕ} [Fact p.Prime] [Fact q.Prime]
variable (e : ∀ n : ℕ, Head p q n → D) {A : D × D → ℂ}
variable (hA : A ∈ cornerSlice e)
include hA

/-- Finite-support positivity follows from positivity on every cofinal physical head. -/
theorem cornerPSD (hinj : ∀ n, Function.Injective (e n))
    (hcover : ∀ s : Finset D, (∃ n, (s : Set D) ⊆ Set.range (e n))) :
    Matrix.PosSemidef (Matrix.of fun i j => A (i,j)) := by
  classical
  constructor
  · exact Matrix.IsHermitian.ext fun i j => hA.2.1 j i
  · intro f
    obtain ⟨n,hn⟩ := hcover f.support
    let E : Head p q n ↪ D := ⟨e n,hinj n⟩
    let g := Finsupp.comapDomain E f E.injective.injOn
    have pull : Finsupp.embDomain E g = f := Finsupp.embDomain_comapDomain hn
    rw [←pull]
    simp only [Finsupp.embDomain_eq_mapDomain,Finsupp.sum_mapDomain_index_inj E.injective]
    simpa only [positionCorner,E,Matrix.of_apply,Function.Embedding.coeFn_mk] using
      (positionCorner_pos e hA n).2 g

/-- The diagonal is summable and its mass is bounded by the same finite-head budget. -/
theorem diagonalBudget (hinj : ∀ n, Function.Injective (e n))
    (hcover : ∀ s : Finset D, (∃ n, (s : Set D) ⊆ Set.range (e n))) :
    Summable (fun i => (A (i,i)).re) ∧ (∑' i, (A (i,i)).re) ≤ 1 := by
  classical
  have pos (i : D) : 0 ≤ (A (i,i)).re := (Complex.nonneg_iff.mp
    ((cornerPSD e hA hinj hcover).diag_nonneg (i := i))).1
  have budget (s : Finset D) : ∑ i ∈ s, (A (i,i)).re ≤ 1 := by
    obtain ⟨n,hn⟩ := hcover s
    let E : Head p q n ↪ D := ⟨e n,hinj n⟩
    have hsub : s ⊆ Finset.univ.map E := by
      intro i hi
      obtain ⟨j,hj⟩ := hn hi
      exact Finset.mem_map.mpr ⟨j,Finset.mem_univ _,hj⟩
    calc
      _ ≤ ∑ i ∈ Finset.univ.map E, (A (i,i)).re :=
        Finset.sum_le_sum_of_subset_of_nonneg hsub (fun i _ _ => pos i)
      _ = cornerTrace e n A := by simp [cornerTrace,E]
      _ ≤ 1 := hA.2.2.2.1 n
  exact ⟨summable_of_sum_le pos budget, Real.tsum_le_of_sum_le pos budget⟩

/-- No positive-operator or Gram factor is assumed in the physical corner realization.
The operator is unique among all bounded operators with the given matrix entries. -/
theorem realizeCorner [DecidableEq D] (hinj : ∀ n, Function.Injective (e n))
    (hcover : ∀ s : Finset D, (∃ n, (s : Set D) ⊆ Set.range (e n))) :
    ∃! T : L2 D →L[ℂ] L2 D, T.IsPositive ∧
      ∀ i j : D, inner ℂ (lp.single 2 i (1:ℂ)) (T (lp.single 2 j (1:ℂ))) = A (i,j) := by
  have budget := diagonalBudget e hA hinj hcover
  obtain ⟨T,hT,hco⟩ := realizePSD _ (cornerPSD e hA hinj hcover) budget.1 budget.2
  refine ⟨T,⟨hT,hco⟩,fun U hu => ext_of_entries fun i j => (hu.2 i j).trans (hco i j).symm⟩

/-- Each physical entry is bounded by the full diagonal mass. This controls
the entry constraint when a substate is normalized. -/
theorem norm_entry_le_diagonal (hinj : ∀ n, Function.Injective (e n))
    (hcover : ∀ s : Finset D, ∃ n, (s : Set D) ⊆ Set.range (e n)) (i j : D) :
    ‖A (i,j)‖ ≤ ∑' k, (A (k,k)).re := by
  classical
  let B := Matrix.of fun i j => A (i,j)
  have hB : B.PosSemidef := cornerPSD e hA hinj hcover
  let K := liftKernel B
  let _ : Fact K.PosSemidef := ⟨lift_pos hB⟩
  have cmp := RKHS.norm_kernel_le (RKHS.OfKernel K) i j
  simp [RKHS.OfKernel.kernel_ofKernel,K,liftKernel,B,norm_smul] at cmp
  have sr := (diagonalBudget e hA hinj hcover).1
  have nonneg (k : D) : 0 ≤ (A (k,k)).re :=
    (Complex.nonneg_iff.mp (hB.diag_nonneg (i := k))).1
  have diag (k : D) : ‖A (k,k)‖ = (A (k,k)).re := by
    have him := (Complex.nonneg_iff.mp (hB.diag_nonneg (i := k))).2
    have hr : A (k,k) = ((A (k,k)).re : ℂ) := by
      apply Complex.ext <;> simp_all [B]
    conv_lhs => rw [hr]
    simp [abs_of_nonneg (nonneg k)]
  have each (k : D) : ‖A (k,k)‖ ≤ ∑' t, (A (t,t)).re := by
    rw [diag]
    exact sr.le_tsum k (fun x _ => nonneg x)
  refine cmp.trans ?_
  exact (mul_le_mul (Real.sqrt_le_sqrt (each i)) (Real.sqrt_le_sqrt (each j))
    (Real.sqrt_nonneg _) (Real.sqrt_nonneg _)).trans_eq (Real.mul_self_sqrt (tsum_nonneg nonneg))

omit hA in
private theorem scale_table (c : ℝ) (n) (x t k s) :
    table (rowsOf (e n) (c • A)) x t k s = (c : ℂ)*table (rowsOf (e n) A) x t k s := by
  simp only [table,transRow,ZMod.dft_apply,rowsOf,Pi.smul_apply,Complex.real_smul,smul_eq_mul,Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro a _
  apply Finset.sum_congr rfl
  intro b _
  ring

/-- Stretching a substate up to its total diagonal budget preserves every test,
including the explicit unit bound on all entries. -/
theorem scaledCorner (hinj : ∀ n, Function.Injective (e n))
    (hcover : ∀ s : Finset D, ∃ n, (s : Set D) ⊆ Set.range (e n))
    (c : ℝ) (hc : 0 ≤ c) (hct : c*(∑' k, (A (k,k)).re) ≤ 1) :
    c • A ∈ cornerSlice e := by
  classical
  have sr := (diagonalBudget e hA hinj hcover).1
  have hn (k : D) : 0 ≤ (A (k,k)).re := (Complex.nonneg_iff.mp
    ((cornerPSD e hA hinj hcover).diag_nonneg (i := k))).1
  refine ⟨?_,?_,?_,?_,?_,?_⟩
  · intro ij
    change ‖c • A ij‖ ≤ 1
    rw [norm_smul, Real.norm_eq_abs, abs_of_nonneg hc]
    exact (mul_le_mul_of_nonneg_left (norm_entry_le_diagonal e hA hinj hcover ij.1 ij.2) hc).trans hct
  · intro i j
    change star (c • A (i,j)) = c • A (j,i)
    rw [star_smul,star_trivial,hA.2.1]
  · intro n u
    rw [← qTest_eval, map_smul]
    exact mul_nonneg hc (test_nonneg e _ A hA)
  · intro n
    let E : Head p q n ↪ D := ⟨e n,hinj n⟩
    have bound := sr.sum_le_tsum (Finset.univ.map E) (fun i _ => hn i)
    have sub : cornerTrace e n A ≤ ∑' k, (A (k,k)).re := by
      simpa [cornerTrace,E] using bound
    have eq : cornerTrace e n (c • A) = c*cornerTrace e n A := by
      simp [cornerTrace,Finset.mul_sum]
    rw [eq]
    exact (mul_le_mul_of_nonneg_left sub hc).trans hct
  · intro n x t k s
    rw [scale_table e c,Complex.re_ofReal_mul]
    exact mul_nonneg hc (hA.2.2.2.2.1 n x t k s)
  · intro n x t k s
    rw [scale_table e c,Complex.im_ofReal_mul,hA.2.2.2.2.2 n x t k s,mul_zero]

/-- A visible extreme substate has exactly unit diagonal mass. If the mass t
were strictly between zero and one, the point would lie on the open segment
from zero to its normalized dilation. -/
theorem extreme_mass_one (hinj : ∀ n, Function.Injective (e n))
    (hcover : ∀ s : Finset D, ∃ n, (s : Set D) ⊆ Set.range (e n))
    (he : A ∈ (cornerSlice e).extremePoints ℝ) (o : D) (ho : 0 < (A (o,o)).re) :
    (∑' k, (A (k,k)).re) = 1 := by
  let t := ∑' k, (A (k,k)).re
  have budget := diagonalBudget e hA hinj hcover
  have pos (i : D) : 0 ≤ (A (i,i)).re := (Complex.nonneg_iff.mp
    ((cornerPSD e hA hinj hcover).diag_nonneg (i := i))).1
  have ht : 0 < t := ho.trans_le (budget.1.le_tsum o (fun i _ => pos i))
  apply le_antisymm budget.2
  by_contra! hn
  change t < 1 at hn
  have hz : (0 : D × D → ℂ) ∈ cornerSlice e := by
    simpa using scaledCorner e hA hinj hcover 0 le_rfl (by simp)
  have hy : t⁻¹ • A ∈ cornerSlice e := scaledCorner e hA hinj hcover _ (inv_nonneg.mpr ht.le)
    (by change t⁻¹*t ≤ 1; rw [inv_mul_cancel₀ ht.ne'])
  have hs : A ∈ openSegment ℝ (0 : D × D → ℂ) (t⁻¹ • A) := by
    refine ⟨1-t,t,sub_pos.mpr hn,ht,by ring,?_⟩
    rw [smul_zero,zero_add,smul_smul,mul_inv_cancel₀ ht.ne',one_smul]
  have eq := he.2 hz hy hs
  rw [← eq] at ho
  simp at ho

end Corners

section Extreme
variable [DecidableEq D]

/-- The physical coordinate map on bounded operators is real linear. -/
def entries : (L2 D →L[ℂ] L2 D) →ₗ[ℝ] (D×D → ℂ) where
  toFun T ij := inner ℂ (lp.single 2 ij.1 (1:ℂ)) (T (lp.single 2 ij.2 (1:ℂ)))
  map_add' T U := by
    funext ij
    apply inner_add_right
  map_smul' c T := by
    funext ij
    change inner ℂ _ (c • T _) = c • inner ℂ _ (T _)
    rw [← algebraMap_smul ℂ c (T _)]
    exact inner_smul_real_right _ _ c

theorem entries_injective : Function.Injective (entries (D := D)) := by
  intro T U h
  exact ext_of_entries fun i j => congrFun h (i,j)

/-- Coordinate extremality transfers to actual bounded operators with the same
finite physical tests. The proof maps open segments to open segments. -/
theorem extreme_of_entries {C : Set (D×D → ℂ)} {T : L2 D →L[ℂ] L2 D}
    (hT : entries T ∈ C.extremePoints ℝ) :
    T ∈ (entries ⁻¹' C).extremePoints ℝ := by
  refine ⟨hT.1,?_⟩
  intro U hu V hv hs
  apply entries_injective
  apply hT.2 hu hv
  change entries.toAffineMap T ∈ openSegment ℝ (entries.toAffineMap U) (entries.toAffineMap V)
  rw [← image_openSegment ℝ entries.toAffineMap U V]
  exact ⟨T,hs,rfl⟩

/-- The extreme point of the physical array slice has a positive bounded
operator representative extreme in the full operator preimage of that slice. -/
theorem realizeExtreme {p q : ℕ} [Fact p.Prime] [Fact q.Prime]
    (e : ∀ n : ℕ, Head p q n → D) {A : D × D → ℂ}
    (hA : A ∈ (cornerSlice e).extremePoints ℝ)
    (hinj : ∀ n, Function.Injective (e n))
    (hcover : ∀ s : Finset D, (∃ n, (s : Set D) ⊆ Set.range (e n))) :
    ∃ T : L2 D →L[ℂ] L2 D, T.IsPositive ∧ entries T = A ∧
      T ∈ (entries ⁻¹' cornerSlice e).extremePoints ℝ := by
  obtain ⟨T,⟨hT,hco⟩,_⟩ := realizeCorner e hA.1 hinj hcover
  have he : entries T = A := funext fun ij => hco ij.1 ij.2
  refine ⟨T,hT,he,extreme_of_entries (he ▸ hA)⟩

end Extreme

end Discrete
end KDClosure
