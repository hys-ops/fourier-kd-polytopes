import KDSubgroupMeasure
import Mathlib.Analysis.SpecialFunctions.Complex.CircleAddChar
import Mathlib.MeasureTheory.Function.L2Space

noncomputable section
namespace KDClosure.DiscreteOrtho
open MeasureTheory Topology SubgroupMeasure
open scoped KDClosure.SubgroupMeasure

variable (G : Type*) [CommGroup G] [TopologicalSpace G] [DiscreteTopology G]

/-- The prime may divide zero: this includes the infinite-order case of the
cyclic subgroup as well as every nontrivial finite cyclic subgroup. -/
theorem separates_one {g : G} (hg : g ≠ 1) : ∃ χ : PontryaginDual G, χ g ≠ 1 := by
  classical
  obtain ⟨p,hp,hd⟩ := Nat.exists_prime_and_dvd (fun h : orderOf g = 1 => hg (orderOf_eq_one_iff.mp h))
  let _ : Fact p.Prime := ⟨hp⟩
  let H : OpenSubgroup G := ⟨Subgroup.zpowers g,isOpen_discrete _⟩
  have existsRep (a : H) : ∃ i : ℤ, g^i = a.val := a.property
  let r (a : H) : ℤ := (existsRep a).choose
  have r_spec (a : H) : g^(r a) = a.val := (existsRep a).choose_spec
  have congruent {i j : ℤ} (eqn : g^i=g^j) : (i : ZMod p) = (j : ZMod p) :=
    (ZMod.intCast_eq_intCast_iff i j p).mpr ((zpow_eq_zpow_iff_modEq.mp eqn).of_dvd (Int.natCast_dvd_natCast.mpr hd))
  let f : H →* Circle := {
    toFun := fun a => ZMod.toCircle (r a : ZMod p)
    map_one' := by
      have z := congruent (i:=r 1) (j:=0) (by simpa using r_spec 1)
      rw [z,Int.cast_zero,AddChar.map_zero_eq_one]
    map_mul' := by
      intro a b
      have add := congruent (i:=r (a*b)) (j:=r a+r b) (by rw [zpow_add,r_spec,r_spec,r_spec]; rfl)
      rw [add,Int.cast_add,AddChar.map_add_eq_mul] }
  let φ : PontryaginDual H := ⟨f,continuous_of_discreteTopology⟩
  obtain ⟨χ,hχ⟩ := OpenCharacter.extends_of_open H φ
  let a : H := ⟨g,Subgroup.mem_zpowers _⟩
  refine ⟨χ,?_⟩
  intro htrivial
  have he := (hχ a).symm.trans htrivial
  have one := congruent (i:=r a) (j:=1) (by simpa [a] using r_spec a)
  change ZMod.toCircle (r a : ZMod p) = 1 at he
  rw [one,Int.cast_one] at he
  exact one_ne_zero (ZMod.injective_toCircle (he.trans (AddChar.map_zero_eq_one _).symm))

theorem separates_points {g h : G} (hne : g ≠ h) : ∃ χ : PontryaginDual G, χ g ≠ χ h := by
  obtain ⟨χ,hχ⟩ := separates_one G (div_ne_one.mpr hne)
  exact ⟨χ,fun he => hχ (by rw [map_div,he]; simp)⟩

private theorem mem (g : G) : MemLp (fun χ : PontryaginDual G => (χ g : ℂ)) 2 (dualHaar G) := by
  have c : Continuous (fun χ : PontryaginDual G => (χ g : ℂ)) :=
    continuous_subtype_val.comp (continuous_eval_const (F:=ContinuousMonoidHom G Circle) g)
  apply MemLp.of_bound c.aestronglyMeasurable 1
  exact Filter.Eventually.of_forall fun χ => (Circle.norm_coe (χ g)).le

/-- Evaluation at a physical group element as a class of square-integrable
functions on the actual compact dual. -/
def basis (g : G) : Lp ℂ 2 (dualHaar G) := (mem G g).toLp _

theorem basis_ae (g : G) : ∀ᵐ χ ∂dualHaar G, basis G g χ = (χ g : ℂ) :=
  (mem G g).coeFn_toLp

/-- Orthogonality of a single character against the normalized Haar constant. -/
theorem integral_eval (g : G) [Decidable (g=1)] :
    ∫ χ : PontryaginDual G, (χ g : ℂ) ∂dualHaar G = if g=1 then 1 else 0 := by
  classical
  by_cases hg : g=1
  · subst g
    simp
  rw [if_neg hg]
  obtain ⟨ψ,hψ⟩ := separates_one G hg
  let a : ℂ := ψ g
  let I := ∫ χ : PontryaginDual G, (χ g : ℂ) ∂dualHaar G
  have eqn : a*I=I := by
    rw [show a*I = ∫ χ : PontryaginDual G, a*(χ g : ℂ) ∂dualHaar G from (integral_const_mul ..).symm]
    exact integral_mul_left_eq_self (μ:=dualHaar G) (fun χ : PontryaginDual G => (χ g : ℂ)) ψ
  have ha : a ≠ 1 := fun e => hψ (Subtype.ext e)
  by_contra hi
  exact ha ((mul_eq_right₀ (b:=I) hi).mp eqn)

/-- The Kronecker-delta cross integral for any two physical positions. -/
theorem cross_integral (x y : G) [Decidable (x=y)] :
    ∫ χ : PontryaginDual G, inner ℂ (χ x : ℂ) (χ y : ℂ) ∂dualHaar G =
      if x=y then 1 else 0 := by
  classical
  have simpl (χ : PontryaginDual G) : inner ℂ (χ x : ℂ) (χ y : ℂ) = (χ (y/x) : ℂ) := by
    rw [RCLike.inner_apply,map_div,div_eq_mul_inv,Circle.coe_mul,Circle.coe_inv_eq_conj]
  simp_rw [simpl]
  rw [integral_eval]
  by_cases h : x=y
  · simp [h]
  · simp [h,div_ne_one.mpr (Ne.symm h)]

theorem basis_orthonormal : Orthonormal ℂ (basis G) := by
  classical
  apply orthonormal_iff_ite.mpr
  intro x y
  rw [MeasureTheory.L2.inner_def,← cross_integral G]
  apply integral_congr_ae
  filter_upwards [basis_ae G x,basis_ae G y] with χ hx hy
  rw [hx,hy]

end KDClosure.DiscreteOrtho
