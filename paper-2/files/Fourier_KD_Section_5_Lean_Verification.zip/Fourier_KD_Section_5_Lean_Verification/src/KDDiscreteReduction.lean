import KDCompactOpenCore
import KDPrimaryCases

namespace KDClosure.DiscreteReduction
open CompactCore TopologicalSpace

variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]

/-- The quotient is taken in the original topological group, not in a finite corner. -/
abbrev D (N : CO G) := G ⧸ subgroup N
abbrev π (N : CO G) := QuotientAddGroup.mk' (subgroup N)
abbrev image (N A : CO G) := (subgroup A).map (π N)

theorem discrete (N : CO G) : DiscreteTopology (D N) :=
  QuotientAddGroup.discreteTopology N.val.isOpen

/-- The actual image of every compact open is finite in the discrete quotient. -/
theorem image_finite (N A : CO G) : ((image N A : AddSubgroup (D N)) : Set (D N)).Finite := by
  let _ := discrete N
  exact (A.property.image (QuotientAddGroup.continuous_mk (N:=subgroup N))).finite_of_discrete

theorem torsion (N : CO G) (cover : ∀ x : G, ∃ H : CO G, x ∈ subgroup H) :
    IsAddTorsion (D N) := by
  intro y
  obtain ⟨x,rfl⟩ := QuotientAddGroup.mk'_surjective (subgroup N) y
  obtain ⟨H,hx⟩ := cover x
  let _ : Finite (image N H) := Set.finite_coe_iff.mpr (image_finite N H)
  let z : image N H := ⟨π N x,⟨x,hx,rfl⟩⟩
  obtain ⟨a,ha,he⟩ := isOfFinAddOrder_iff_nsmul_eq_zero.mp (isOfFinAddOrder_of_finite z)
  exact isOfFinAddOrder_iff_nsmul_eq_zero.mpr ⟨a,ha,congrArg Subtype.val he⟩

/-- Each coset of N is a translate of the same compact set. Thus finiteness
of the entire quotient would force compactness of the original group. -/
theorem infinite_of_noncompact (N : CO G) (noncompact : ¬ IsCompact (Set.univ : Set G)) :
    Infinite (D N) := by
  classical
  apply not_finite_iff_infinite.mp
  intro fin
  let _ : Finite (D N) := fin
  let fiber (y : D N) : Set G := (π N) ⁻¹' {y}
  have compactFib (y : D N) : IsCompact (fiber y) := by
    obtain ⟨x,rfl⟩ := QuotientAddGroup.mk'_surjective (subgroup N) y
    have eqn : fiber (π N x) = (fun w : G => w+x) '' (subgroup N : Set G) := by
      ext w
      change (π N w = π N x) ↔ _
      constructor
      · intro hw
        exact ⟨w-x,QuotientAddGroup.eq_iff_sub_mem.mp hw,sub_add_cancel ..⟩
      · rintro ⟨b,hb,rfl⟩
        apply QuotientAddGroup.eq_iff_sub_mem.mpr
        simpa using hb
    rw [eqn]
    apply N.property.image (continuous_id.add continuous_const)
  have full : (⋃ y : D N, fiber y) = Set.univ := Set.eq_univ_of_forall fun x =>
    Set.mem_iUnion.mpr ⟨π N x,rfl⟩
  exact noncompact (full ▸ isCompact_iUnion compactFib)

omit [IsTopologicalAddGroup G] in
theorem image_le_iff (N A B : CO G) (hnA : N ≤ A) (hnB : N ≤ B) :
    image N A ≤ image N B ↔ A ≤ B := by
  constructor
  · intro him
    have h := AddSubgroup.comap_mono (f:=π N) him
    change ((subgroup A).map (π N)).comap (π N) ≤ ((subgroup B).map (π N)).comap (π N) at h
    have ha : subgroup N ≤ subgroup A := hnA
    have hb : subgroup N ≤ subgroup B := hnB
    change subgroup A ≤ subgroup B
    simpa only [π,QuotientAddGroup.comap_map_mk',sup_eq_right.mpr ha,sup_eq_right.mpr hb] using h
  · intro h x hx
    obtain ⟨y,hy,rfl⟩ := hx
    exact ⟨y,h hy,rfl⟩

theorem countable [SecondCountableTopology G] (N : CO G) : Countable (D N) := by
  let _ := discrete N
  exact separableSpace_iff_countable.mp inferInstance

/-- The noncompact branch with the two named images as actual finite,
incomparable subgroups of the quotient. Countability is conditional only on
second countability; Hausdorffness and the other LCA assumptions are unused here. -/
theorem noncompact_reduction (A B : CO G) (hab : ¬ A ≤ B) (hba : ¬ B ≤ A)
    (cover : ∀ x : G, ∃ H : CO G, x ∈ subgroup H)
    (noncompact : ¬ IsCompact (Set.univ : Set G)) :
    let N := meet A B
    DiscreteTopology (D N) ∧ Infinite (D N) ∧ IsAddTorsion (D N) ∧
      ((image N A : AddSubgroup (D N)) : Set (D N)).Finite ∧
      ((image N B : AddSubgroup (D N)) : Set (D N)).Finite ∧
      (¬ image N A ≤ image N B) ∧ (¬ image N B ≤ image N A) ∧
      (SecondCountableTopology G → Countable (D N)) := by
  let N := meet A B
  have na : N ≤ A := (inf_le_left : A.val ⊓ B.val ≤ A.val)
  have nb : N ≤ B := (inf_le_right : A.val ⊓ B.val ≤ B.val)
  exact ⟨discrete N,infinite_of_noncompact N noncompact,torsion N cover,image_finite N A,
    image_finite N B,fun h => hab ((image_le_iff N A B na nb).mp h),
    fun h => hba ((image_le_iff N B A nb na).mp h),fun _ => countable N⟩

end KDClosure.DiscreteReduction
