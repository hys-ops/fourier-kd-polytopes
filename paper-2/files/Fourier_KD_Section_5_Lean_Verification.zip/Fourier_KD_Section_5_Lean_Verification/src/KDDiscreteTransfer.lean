import KDDiscreteKDRow

/-! Subgroup transport for *actual* position–Fourier KD states, including
the full ambient extreme condition. No positivity, trace, row-transform,
isometric-section, or exposedness conclusion is assumed. -/
noncomputable section
namespace KDClosure.DiscreteTransfer
open Discrete DiscreteKDRow MeasureTheory
open scoped ComplexOrder KDClosure.SubgroupMeasure

variable (G : Type*) [CommGroup G] [TopologicalSpace G] [DiscreteTopology G] [DecidableEq G]

def states : Set (L2 G →L[ℂ] L2 G) :=
  {T | T.IsPositive ∧ IsLUB (finiteFrameMass T) 1 ∧ RowNonneg G T}

local instance : MeasurableSpace G := ⊤

/-- Under the second-countability hypothesis for a discrete group the
state definition agrees with positivity on the single product phase space. -/
theorem mem_states_iff_phase [Countable G] (T : L2 G →L[ℂ] L2 G) :
    T ∈ states G ↔ T.IsPositive ∧ IsLUB (finiteFrameMass T) 1 ∧
      ∀ᵐ z ∂((Measure.count : Measure G).prod (SubgroupMeasure.dualHaar G)),
        0 ≤ rowDensity G T z.1 z.2 := by
  change _ ∧ _ ∧ RowNonneg G T ↔ _
  rw [joint_ae_iff]

def HasInfiniteExtreme : Prop :=
  ∃ T ∈ (states G).extremePoints ℝ, ¬FiniteDimensional ℂ (LinearMap.range T.toLinearMap)

variable {G} {D : Type*} [CommGroup D] [TopologicalSpace D] [DiscreteTopology D] [DecidableEq D]

/-- Exact membership of the image in the large positive trace-one KD state set. -/
theorem push_mem_iff (e : D →* G) (he : Function.Injective e) (T : L2 D →L[ℂ] L2 D) :
    push e he T ∈ states G ↔ T ∈ states D := by
  let i : D ↪ G := ⟨e,he⟩
  have pos := DiscreteEmbedding.push_positive_iff i T
  have rows := nonnegative_push_iff e he T
  constructor
  · rintro ⟨pt,tr,k⟩
    exact ⟨pos.mp pt,(DiscreteEmbedding.trace_push_iff i T (pos.mp pt) 1).mp tr,rows.mp k⟩
  · rintro ⟨pt,tr,k⟩
    exact ⟨pos.mpr pt,(DiscreteEmbedding.trace_push_iff i T pt 1).mpr tr,rows.mpr k⟩

/-- An extreme state on any subgroup remains extreme among *all* ambient KD states. -/
theorem push_extreme (e : D →* G) (he : Function.Injective e) {T : L2 D →L[ℂ] L2 D}
    (extT : T ∈ (states D).extremePoints ℝ) :
    push e he T ∈ (states G).extremePoints ℝ := by
  let i : D ↪ G := ⟨e,he⟩
  exact IsometricSupport.extreme_lift (DiscreteEmbedding.inclusion i).toContinuousLinearMap
    (DiscreteEmbedding.inclusion i).isometry (states D) (states G)
    (fun _ h => h.1) (fun A => (push_mem_iff e he A).symm) extT

/-- The existence of an infinite-rank extreme is upward closed under any
algebraic embedding of discrete abelian groups. -/
theorem infinite_extreme_of_embedding (e : D →* G) (he : Function.Injective e)
    (h : HasInfiniteExtreme D) : HasInfiniteExtreme G := by
  obtain ⟨T,extT,inf⟩ := h
  refine ⟨push e he T,push_extreme e he extT,?_⟩
  let i : D ↪ G := ⟨e,he⟩
  let iso := IsometricSupport.rangeEquiv (DiscreteEmbedding.inclusion i).toContinuousLinearMap
    (DiscreteEmbedding.inclusion i).isometry T
  intro finite
  let _ : FiniteDimensional ℂ (LinearMap.range (IsometricSupport.lift
    (DiscreteEmbedding.inclusion i).toContinuousLinearMap T).toLinearMap) := finite
  exact inf (FiniteDimensional.of_injective iso.toLinearMap iso.injective)

end KDClosure.DiscreteTransfer
