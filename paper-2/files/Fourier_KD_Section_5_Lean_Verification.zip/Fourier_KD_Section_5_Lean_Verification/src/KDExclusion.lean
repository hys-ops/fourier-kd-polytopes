import KDFourierHead

namespace KDClosure
open Matrix
open scoped BigOperators
variable {m q : ℕ} [NeZero m] [Fact q.Prime]

theorem blockShape {F : Blocks m q} {pos : ZMod m → Prop}
    (cop : m.Coprime q) (per : Periodic F) (mix : Both pos)
    (hz : ∀ x t k s, Protected pos x t s → table F x t k s = 0)
    (x h : ZMod m) (hh : h ≠ 0) :
    ∃ a : ℂ, ∀ t u, F x h t u = a - (if t=0 ∧ u=0 then (q:ℂ)*a else 0) := by
  let C := F x h
  obtain ⟨hn,ho⟩ := blockConstraints cop per mix hz x h hh
  have constrow (t : ZMod q) (ht : t ≠ 0) (u w : ZMod q) : C t u = C t w := by
    simpa using const_of_dft_supported (fun v => C t (t+v)) (hn t ht) (u-t) (w-t)
  let a := C 0 1
  have neqrow (t : ZMod q) (ht : t ≠ 0) (u : ZMod q) : C t u = a :=
    (constrow t ht u (t+1)).trans (sameOff per cop x h t 1 one_ne_zero)
  have headrow (u : ZMod q) (hu : u ≠ 0) : C 0 u = a :=
    (sameOff per cop x h 1 u hu).symm.trans (neqrow 1 one_ne_zero (1+u))
  have hf (u : ZMod q) : C 0 u = a + (if u=0 then C 0 0-a else 0) := by
    by_cases e : u=0
    · subst u; simp
    · simp [e,headrow u e]
  have sum0 : ∑ u, C 0 u = 0 := by simpa [transRow,ZMod.dft_apply_zero,C] using ho
  rw [Finset.sum_congr rfl (fun u _ => hf u),Finset.sum_add_distrib] at sum0
  simp [nsmul_eq_mul] at sum0
  refine ⟨a, fun t u => ?_⟩
  change C t u = _
  by_cases et : t=0
  · subst t
    by_cases eu : u=0
    · subst u; simp only [and_self,if_true]; linear_combination sum0
    · simp [eu, headrow u eu]
  · simp [et,neqrow t et]

noncomputable def channel (q : ℕ) [NeZero q] (z : ℂ) (t : ZMod q) : ℂ :=
  (if t=0 then 1 else 0) + z

theorem sum_channel (z : ℂ) : ∑ t, channel q z t = 1 + (q:ℂ)*z := by
  simp [channel, Finset.sum_add_distrib, nsmul_eq_mul]

/-- Vanishing of both diagonal channel tests for the actual transverse block. -/
theorem shape_quad {C : Matrix (ZMod q) (ZMod q) ℂ} {a z : ℂ}
    (shape : ∀ t u, C t u = a - (if t=0 ∧ u=0 then (q:ℂ)*a else 0))
    (sz : (q:ℂ)*z^2 = 1) :
    channel q z ⬝ᵥ C *ᵥ channel q z = 0 := by
  have act (t : ZMod q) : (C *ᵥ channel q z) t =
      a*(1+(q:ℂ)*z) - (if t=0 then (q:ℂ)*a*(1+z) else 0) := by
    simp only [Matrix.mulVec, dotProduct, shape,sub_mul,Finset.sum_sub_distrib,
      ← Finset.mul_sum, sum_channel]
    by_cases ht : t=0
    · simp [ht,ite_mul,channel]
    · simp [ht]
  simp only [dotProduct,act,mul_sub,Finset.sum_sub_distrib,← Finset.sum_mul,sum_channel]
  simp [mul_ite,channel]
  linear_combination (q*a-a)*sz

noncomputable def physical (F : Blocks m q) :
    Matrix (ZMod m × ZMod q) (ZMod m × ZMod q) ℂ :=
  fun i j => F i.1 (j.1-i.1) i.2 j.2

noncomputable def headVec (d : ZMod m → ℂ) (z : ℂ) (i : ZMod m × ZMod q) : ℂ :=
  d i.1 * channel q z i.2

theorem blockAction (F : Blocks m q) (d : ZMod m → ℂ) (z : ℂ) (x : ZMod m)
    (t : ZMod q) :
    (physical F *ᵥ headVec d z) (x,t) =
      ∑ y, d y * ((F x (y-x)) *ᵥ channel q z) t := by
  simp only [Matrix.mulVec,dotProduct,Fintype.sum_prod_type,physical,headVec,Finset.mul_sum]
  apply Finset.sum_congr rfl; intro y _
  apply Finset.sum_congr rfl; intro u _
  ring

theorem headToDiag {F : Blocks m q} {d : ZMod m → ℂ} {z : ℂ}
    (dn : ∀ x, d x ≠ 0) (ker : physical F *ᵥ headVec d z = 0)
    (off : ∀ x h, h ≠ 0 → channel q z ⬝ᵥ (F x h) *ᵥ channel q z = 0)
    (x : ZMod m) : channel q z ⬝ᵥ (F x 0) *ᵥ channel q z = 0 := by
  have hh (t : ZMod q) : ∑ y, d y * (((F x (y-x)) *ᵥ channel q z) t) = 0 := by
    simpa only [←blockAction,Pi.zero_apply] using congrFun ker (x,t)
  have he : (∑ y, d y * (channel q z ⬝ᵥ (F x (y-x)) *ᵥ channel q z)) = 0 := by
    simp only [dotProduct,Finset.mul_sum]
    rw [Finset.sum_comm]
    apply Finset.sum_eq_zero
    intro t _
    calc
      _ = channel q z t * (∑ y, d y * (((F x (y-x)) *ᵥ channel q z) t)) := by
        rw [Finset.mul_sum]; apply Finset.sum_congr rfl; intro y _; ring
      _ = 0 := by rw [hh,mul_zero]
  rw [Finset.sum_eq_single x] at he
  · simpa [dn x] using he
  · intro y _ h; simp [off x (y-x) (sub_ne_zero.mpr h)]
  · simp

end KDClosure
