import KDMixedHead
import KDTowerFace

namespace KDClosure
open Set Matrix
open scoped BigOperators ComplexOrder

variable {D : Type*} {p q : ℕ} [Fact p.Prime] [Fact q.Prime]
variable (e : ∀ n : ℕ, Head p q n → D)

/-- The ordinary position matrix of the nth corner, not a matrix of Fourier coefficients. -/
def positionCorner (n : ℕ) (A : D×D → ℂ) : Matrix (Head p q n) (Head p q n) ℂ :=
  fun i j => A (e n i,e n j)

omit [Fact p.Prime] [Fact q.Prime] in
theorem physical_rows (n : ℕ) (A : D×D → ℂ) :
    physical (rowsOf (e n) A) = positionCorner e n A := by
  ext i j
  simp [physical,rowsOf,positionCorner]

theorem corner_form (n : ℕ) (u : Head p q n → ℂ) (A : D×D → ℂ) :
    star u ⬝ᵥ positionCorner e n A *ᵥ u = cornerQ e n u A := by
  simp only [Matrix.mulVec,dotProduct,cornerQ,positionCorner,Pi.star_apply,
    Finset.mul_sum,mul_assoc]

theorem positionCorner_pos {A : D×D → ℂ} (hA : A ∈ cornerSlice e) (n : ℕ) :
    (positionCorner e n A).PosSemidef := by
  have hh : (positionCorner e n A).IsHermitian := by
    ext i j
    exact hA.2.1 _ _
  apply Matrix.PosSemidef.of_dotProduct_mulVec_nonneg hh
  intro u
  have hi := hh.im_star_dotProduct_mulVec_self u
  apply Complex.nonneg_iff.mpr
  exact ⟨by rw [corner_form]; exact hA.2.2.1 _ _, hi.symm⟩

theorem null_of_quadTest {A : D×D → ℂ} (hA : A ∈ cornerSlice e) {n : ℕ}
    {v : Head p q n → ℂ} (ht : testValue e (.quad n v) A = 0) :
    positionCorner e n A *ᵥ v = 0 := by
  have ps := positionCorner_pos e hA n
  apply (ps.dotProduct_mulVec_zero_iff v).mp
  apply Complex.ext
  · rw [corner_form]; exact (qTest_eval e n v A).symm.trans ht
  · exact ps.isHermitian.im_star_dotProduct_mulVec_self v

def columnSupport (A : D×D → ℂ) := {j | ∃ i, A (i,j) ≠ 0}

/-- If the columns of an ambient kernel outside an embedded small head vanish,
the large corner action on its small rows is exactly the restricted action. -/
theorem restrict_action {A : D×D → ℂ} {n N : ℕ}
    (r : Head p q n ↪ Head p q N) (commutes : ∀ i, e N (r i) = e n i)
    (injN : Function.Injective (e N)) (hs : columnSupport A ⊆ range (e n))
    (v : Head p q N → ℂ) (i : Head p q n) :
    (positionCorner e N A *ᵥ v) (r i) =
    (positionCorner e n A *ᵥ (v ∘ r)) i := by
  classical
  let f (j : Head p q N) := A (e n i,e N j)*v j
  change (∑ j, A (e N (r i),e N j)*v j) = ∑ j, A (e n i,e n j)*v (r j)
  rw [commutes]
  change (∑ j, f j) = _
  calc
    _ = ∑ j ∈ Finset.univ.map r, f j := by
      symm
      apply Finset.sum_subset (Finset.subset_univ _)
      intro j _ hj
      have h : A (e n i,e N j) = 0 := by
        by_contra h
        obtain ⟨k,hk⟩ := hs ⟨e n i,h⟩
        exact hj (Finset.mem_map.mpr ⟨k,Finset.mem_univ _,injN ((commutes k).trans hk)⟩)
      simp [f,h]
    _ = _ := by simp [Finset.sum_map,f,commutes]

/-- Data of one prescribed later packet, independent of the tested state.
Its vector restricts to a nonzero scalar multiple of the prescribed head vector. -/
structure LaterPacket (τ : ℕ → TowerTest p q) (n : ℕ) (w : Head p q n → ℂ) where
  layer : ℕ
  inclusion : Head p q n ↪ Head p q layer
  agrees : ∀ i, e layer (inclusion i) = e n i
  vector : Head p q layer → ℂ
  listed : ∃ j, τ j = .quad layer vector
  factor : ℂ
  factor_ne : factor ≠ 0
  restricts : vector ∘ inclusion = factor • w

theorem LaterPacket.head_null {τ : ℕ → TowerTest p q} {n : ℕ} {w : Head p q n → ℂ}
    (packet : LaterPacket e τ n w)
    (einj : ∀ j, Function.Injective (e j)) {A : D×D → ℂ} (hA : A ∈ cornerSlice e)
    (hz : ∀ j, testValue e (τ j) A = 0) (hs : columnSupport A ⊆ range (e n)) :
    positionCorner e n A *ᵥ w = 0 := by
  obtain ⟨j,hj⟩ := packet.listed
  have h0 := null_of_quadTest e hA (hj ▸ hz j)
  funext i
  have h := congrFun h0 (packet.inclusion i)
  rw [restrict_action e packet.inclusion packet.agrees (einj _) hs,packet.restricts,
    Matrix.mulVec_smul] at h
  exact (mul_eq_zero.mp (show packet.factor * (positionCorner e n A *ᵥ w) i = 0 from h)).resolve_left
    packet.factor_ne



/-- Geometry of the two opposite later packets whose restrictions split the
two transverse channels. The data involve no unknown state A. -/
structure PairedPackets (τ : ℕ → TowerTest p q) (n : ℕ) where
  d₁ : ZMod (p^(n+1)) → ℂ
  d₂ : ZMod (p^(n+1)) → ℂ
  nonzero₁ : ∀ x, d₁ x ≠ 0
  nonzero₂ : ∀ x, d₂ x ≠ 0
  c : ℂ
  hc : c ≠ 0
  plus : LaterPacket e τ n (headVec d₁ ((Real.sqrt (q:ℝ) : ℂ)⁻¹) +
    c • headVec d₂ (-((Real.sqrt (q:ℝ) : ℂ)⁻¹)))
  minus : LaterPacket e τ n (headVec d₁ ((Real.sqrt (q:ℝ) : ℂ)⁻¹) -
    c • headVec d₂ (-((Real.sqrt (q:ℝ) : ℂ)⁻¹)))

/-- Old-head support and all listed face zeros force the full ambient array to
vanish. Finite period is the separate finite Fourier reality interface. -/
theorem supported_face_zero {τ : ℕ → TowerTest p q} (pq : p ≠ q)
    {l : ℕ} (hl : 0<l) (hlt : l<p) {n : ℕ}
    (einj : ∀ j, Function.Injective (e j))
    (packets : PairedPackets e τ n)
    (mask : ∀ x t k s, Protected (color (p:=p) n l) x t s →
      ∃ j, τ j = .kd n x t k s)
    {A : D×D → ℂ} (hA : A ∈ cornerSlice e) (hz : ∀ j, testValue e (τ j) A = 0)
    (per : Periodic (rowsOf (e n) A)) (hs : columnSupport A ⊆ range (e n)) :
    A = 0 := by
  have masked (x t k s) (h : Protected (color (p:=p) n l) x t s) :
      table (rowsOf (e n) A) x t k s = 0 := by
    obtain ⟨j,hj⟩ := mask x t k s h
    apply Complex.ext
    · exact (kdTest_eval e n x t k s A).symm.trans (hj ▸ hz j)
    · exact hA.2.2.2.2.2 n x t k s
  have hp := packets.plus.head_null e einj hA hz hs
  have hm := packets.minus.head_null e einj hA hz hs
  have he := mixed_head_vanish pq n l hl hlt (rowsOf (e n) A) per masked
    (physical_rows e n A ▸ positionCorner_pos e hA n) packets.d₁ packets.d₂
    packets.nonzero₁ packets.nonzero₂ packets.c packets.hc
    (by rwa [physical_rows]) (by rwa [physical_rows])
  rw [physical_rows] at he
  funext ij
  by_contra hn
  obtain ⟨i,j⟩ := ij
  change A (i,j) ≠ 0 at hn
  obtain ⟨yj,ry⟩ := hs ⟨i,hn⟩
  have hn' : A (j,i) ≠ 0 := by
    rw [← hA.2.1 i j]; simpa using hn
  obtain ⟨xi,rx⟩ := hs ⟨j,hn'⟩
  exact hn (rx ▸ ry ▸ congrFun (congrFun he xi) yj)

omit [Fact p.Prime] [Fact q.Prime] in
/-- Increasing exhaustive heads contain every finite position support. -/
theorem finite_in_head (increasing : Monotone (fun j => range (e j)))
    (exhaust : ∀ x, ∃ j, x ∈ range (e j)) {S : Set D} (fs : S.Finite) :
    ∃ n, S ⊆ range (e n) := by
  classical
  induction S, fs using Set.Finite.induction_on with
  | empty => exact ⟨0, empty_subset _⟩
  | @insert x S _ _ ih =>
    obtain ⟨j,hx⟩ := exhaust x
    obtain ⟨k,hk⟩ := ih
    refine ⟨max j k, Set.insert_subset (increasing (le_max_left _ _) hx)
      (hk.trans (increasing (le_max_right _ _)))⟩

/-- Ambient extreme with genuinely infinite column support, in the bounded
coordinate model. It is obtained by uniformly visible finite-prefix witnesses.
No unknown extremizer, no annihilation conclusion, and no no-finite-support
hypothesis is supplied. Identification with trace-one operators is separate. -/
theorem mixed_tower_extreme_infinite_support
    (τ : ℕ → TowerTest p q) (pq : p ≠ q) {l : ℕ} (hl : 0<l) (hlt : l<p)
    (einj : ∀ j, Function.Injective (e j)) (increasing : Monotone (fun j => range (e j)))
    (exhaust : ∀ x, ∃ j, x ∈ range (e j))
    (packets : ∀ n, PairedPackets e τ n)
    (mask : ∀ n x t k s, Protected (color (p:=p) n l) x t s →
      ∃ j, τ j = .kd n x t k s)
    (periodOfSlice : ∀ A ∈ cornerSlice e, ∀ n, Periodic (rowsOf (e n) A))
    (o : D) (δ : ℝ) (hδ : 0<δ)
    (feasible : ∀ k : ℕ, ∃ A ∈ cornerSlice e,
      δ ≤ (A (o,o)).re ∧ ∀ j ≤ k, testValue e (τ j) A = 0) :
    ∃ B ∈ (cornerSlice e).extremePoints ℝ, 0 < (B (o,o)).re ∧
      (columnSupport B).Infinite ∧ ∀ j, testValue e (τ j) B = 0 := by
  obtain ⟨B,hB,hpos,hz⟩ := towerExtreme e τ o δ hδ feasible
  refine ⟨B,hB,hpos,?_,hz⟩
  intro hf
  obtain ⟨n,hn⟩ := finite_in_head e increasing exhaust hf
  have member := extremePoints_subset hB
  have eq := supported_face_zero e pq hl hlt einj (packets n) (mask n) member hz
    (periodOfSlice B member n) hn
  simp [eq] at hpos

end KDClosure
