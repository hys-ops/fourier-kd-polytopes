import KDTraceCompression
import Mathlib.Analysis.InnerProductSpace.Projection.FiniteDimensional
import Mathlib.Analysis.InnerProductSpace.Orthonormal

/-! Dimension-independent finite-coordinate estimate for the middle block in
positive trace tightness. No unspecified boundedness of the trace norm. -/
noncomputable section
set_option linter.unusedSectionVars false
namespace KDClosure.Hull.Head
open Set Filter
open scoped ComplexConjugate InnerProductSpace Topology
variable {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℂ X] [CompleteSpace X]

/-- Bessel in both frame coordinates, plus 2ab ≤ a²+b². -/
theorem pair_sum {n : ℕ} {u v : Fin n → X} (hu : Orthonormal ℂ u) (hv : Orthonormal ℂ v)
    (x y : X) (hx : ‖x‖=1) (hy : ‖y‖=1) :
    ∑ j, ‖inner ℂ (v j) x‖ * ‖inner ℂ (u j) y‖ ≤ 1 := by
  have vu := hv.sum_inner_products_le (s:=Finset.univ) x
  have uu := hu.sum_inner_products_le (s:=Finset.univ) y
  rw [hx,one_pow] at vu
  rw [hy,one_pow] at uu
  have sq : 2*(∑ j, ‖inner ℂ (v j) x‖ * ‖inner ℂ (u j) y‖) ≤
      ∑ j, ‖inner ℂ (v j) x‖^2 + ∑ j, ‖inner ℂ (u j) y‖^2 := by
    rw [Finset.mul_sum,←Finset.sum_add_distrib]
    apply Finset.sum_le_sum
    intro i _
    nlinarith [sq_nonneg (‖inner ℂ (v i) x‖-‖inner ℂ (u i) y‖)]
  linarith

theorem finite_head {I : Type*} (b : I → X) (hb : Orthonormal ℂ b) (s : Finset I)
    (A : X →L[ℂ] X) {n : ℕ} {u v : Fin n → X} (hu : Orthonormal ℂ u) (hv : Orthonormal ℂ v) :
    ∑ t, ‖inner ℂ (∑ i ∈ s, inner ℂ (b i) (v t) • b i)
      (A (∑ j ∈ s, inner ℂ (b j) (u t) • b j))‖ ≤
    ∑ i ∈ s, ∑ j ∈ s, ‖inner ℂ (b i) (A (b j))‖ := by
  classical
  let e := fun i j => ‖inner ℂ (b i) (A (b j))‖
  let term := fun (t : Fin n) i j => e i j * (‖inner ℂ (v t) (b i)‖*‖inner ℂ (u t) (b j)‖)
  have single (t : Fin n) : ‖inner ℂ (∑ i ∈ s, inner ℂ (b i) (v t) • b i)
      (A (∑ j ∈ s, inner ℂ (b j) (u t) • b j))‖ ≤ ∑ i ∈ s, ∑ j ∈ s, term t i j := by
    rw [sum_inner]
    simp only [map_sum,map_smul,inner_smul_left,inner_sum,inner_smul_right]
    apply (norm_sum_le _ _).trans
    apply Finset.sum_le_sum
    intro i _
    apply (norm_sum_le _ _).trans
    apply Finset.sum_le_sum
    intro j _
    simp [term,e]
    rw [norm_inner_symm (𝕜:=ℂ) (b j) (u t)]
    exact le_of_eq (by ring)
  calc
    _ ≤ ∑ t, ∑ i ∈ s, ∑ j ∈ s, term t i j := Finset.sum_le_sum fun t _ => single t
    _ = ∑ i ∈ s, ∑ j ∈ s, ∑ t, term t i j := by
      rw [Finset.sum_comm]
      exact Finset.sum_congr rfl fun _ _ => Finset.sum_comm
    _ ≤ _ := by
      apply Finset.sum_le_sum
      intro i _
      apply Finset.sum_le_sum
      intro j _
      change ∑ t, e i j * (‖inner ℂ (v t) (b i)‖ * ‖inner ℂ (u t) (b j)‖) ≤ e i j
      rw [←Finset.mul_sum]
      have a := pair_sum hu hv (b i) (b j) (hb.norm_eq_one i) (hb.norm_eq_one j)
      simpa only [mul_one] using mul_le_mul_of_nonneg_left a (show 0≤e i j from norm_nonneg _)

theorem entries_tendsto {I J : Type*} (b : I→X) (s : Finset I) {l : Filter J}
    (A : J → X →L[ℂ] X) (T : X →L[ℂ] X)
    (h : ∀ x y, Tendsto (fun j => inner ℂ x (A j y)) l (𝓝 (inner ℂ x (T y)))) :
    Tendsto (fun t => ∑ i ∈ s, ∑ j ∈ s, ‖inner ℂ (b i) ((A t-T) (b j))‖) l (𝓝 0) := by
  have small (i j : I) : Tendsto (fun t => ‖inner ℂ (b i) (A t (b j)) - inner ℂ (b i) (T (b j))‖) l (𝓝 0) := by
    simpa using ((h (b i) (b j)).sub (tendsto_const_nhds (x:=inner ℂ (b i) (T (b j))))).norm
  simpa only [sub_apply,inner_sub_right,Finset.sum_const_zero] using tendsto_finsetSum s fun i _ => tendsto_finsetSum s fun j _ => small i j
end KDClosure.Hull.Head
