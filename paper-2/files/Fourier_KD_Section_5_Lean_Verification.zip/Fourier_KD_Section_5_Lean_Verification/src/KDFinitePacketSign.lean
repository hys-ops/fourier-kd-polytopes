import KDPacketCompression
import Mathlib.Analysis.Fourier.FiniteAbelian.Orthogonality
import Mathlib.Analysis.Complex.Order

noncomputable section
namespace KDClosure.Hull
open Classical BigOperators
open scoped ComplexOrder ComplexConjugate
variable {D : Type*} [AddCommGroup D] [Fintype D]

/-- The finite physical row used in Paper 1, with outer matrix (star v_i) v_j
(i.e. v is the conjugate of the ket in that convention). -/
def rowOfVector (v : D → ℂ) (x : D) (k : AddChar D ℂ) :=
  ∑ y : D, (conj (v x) * v y) * k (y-x)

/-- A subgroup-coset character packet has nonnegative Fourier KD rows. No
classification of finite pure states is assumed. It also holds for c=0. -/
theorem finite_packet_positive (W : AddSubgroup D) (b : D) (γ : AddChar D ℂ) (c : ℂ)
    (v : D → ℂ) (vs : ∀ i, v i = if i-b ∈ W then c * γ (i-b) else 0)
    (x : D) (k : AddChar D ℂ) : 0 ≤ rowOfVector v x k := by
  classical
  by_cases hx : x-b ∈ W
  · let χ := (γ*k).compAddMonoidHom W.subtype
    have move (h : D) : v (x+h) = if h ∈ W then v x * γ h else 0 := by
      have ha : x+h-b = (x-b)+h := by abel
      rw [vs,ha]
      by_cases hh : h ∈ W
      · rw [if_pos (W.add_mem hx hh),if_pos hh,vs x,if_pos hx,AddChar.map_add_eq_mul,mul_assoc]
      · have no : x-b+h ∉ W := fun e => hh (by simpa using W.sub_mem e hx)
        rw [if_neg no,if_neg hh]
    have sumχ : (∑ h : D, if h∈W then γ h * k h else 0) = ∑ t : W, χ t := by
      rw [← Fintype.sum_subtype_add_sum_subtype (fun z => z∈W) (fun h => if h∈W then γ h * k h else 0)]
      have pos : (∑ t : W, if (t:D) ∈ W then γ (t:D) * k (t:D) else 0) = ∑ t : W, χ t := by
        refine Finset.sum_congr rfl (fun t _ => ?_)
        rw [if_pos t.property]
        rfl
      have neg : (∑ t : {d : D // d ∉ W}, if (t:D) ∈ W then γ (t:D) * k (t:D) else 0) = 0 :=
        Finset.sum_eq_zero (fun t _ => if_neg t.property)
      rw [pos,neg,add_zero]
    have formula : rowOfVector v x k =
        (Complex.normSq (v x) : ℂ) * (if χ = 0 then (Fintype.card W : ℂ) else 0) := by
      rw [← AddChar.sum_eq_ite χ, ← sumχ, Finset.mul_sum]
      unfold rowOfVector
      symm
      apply Fintype.sum_equiv (Equiv.addLeft x)
      intro h
      change _ = conj (v x) * v (x+h) * k (x+h-x)
      rw [move,add_sub_cancel_left,Complex.normSq_eq_conj_mul_self]
      split_ifs <;> ring
    rw [formula]
    by_cases hz : χ = 0
    · rw [if_pos hz]
      exact mul_nonneg (Complex.zero_le_real.mpr (Complex.normSq_nonneg _)) (by exact_mod_cast (Nat.zero_le _))
    · simp [hz]
  · simp [rowOfVector,vs x, hx]

end KDClosure.Hull
