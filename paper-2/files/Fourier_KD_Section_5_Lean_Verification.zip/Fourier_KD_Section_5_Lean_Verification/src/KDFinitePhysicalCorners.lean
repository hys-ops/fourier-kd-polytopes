import KDDiscreteKDRow
import KDHeadCompression

noncomputable section
namespace KDClosure.PhysicalCorner
open MeasureTheory Discrete DiscreteKDRow DiscreteOrtho SubgroupMeasure
open scoped ComplexOrder KDClosure.SubgroupMeasure BigOperators

variable {G : Type*} [CommGroup G] [TopologicalSpace G] [DiscreteTopology G] [DecidableEq G]

/-- Recover an individual operator entry from its actual Haar Fourier row. -/
theorem coefficient (T : L2 G →L[ℂ] L2 G) (x y : G) :
    inner ℂ (phase G x y) (rowDensity G T x) = entries T (x,y) := by
  classical
  have hs := (innerSL ℂ (phase G x y)).hasSum (row_hasSum G T x)
  have eval (z : G) : inner ℂ (phase G x y) (entries T (x,z) • phase G x z) =
      if z=y then entries T (x,y) else 0 := by
    rw [inner_smul_right,(orthonormal_iff_ite.mp (phase_orthonormal G x))]
    by_cases e : z=y
    · simp [e]
    · simp [e,Ne.symm e]
  apply hs.unique
  change HasSum (fun z => inner ℂ _ (entries T (x,z) • phase G x z)) _
  simp_rw [eval]
  exact hasSum_ite_eq _ _

private theorem pos_integral {X : Type*} [MeasurableSpace X] (μ : Measure X) (f : X → ℂ)
    (h : ∀ᵐ z ∂μ, 0 ≤ f z) : 0 ≤ ∫ z, f z ∂μ := by
  have eqn : (∫ z, f z ∂μ) = ∫ z, ((f z).re:ℂ) ∂μ := by
    apply integral_congr_ae
    filter_upwards [h] with z hz
    apply Complex.ext
    · rfl
    · exact (Complex.nonneg_iff.mp hz).2.symm
  rw [eqn,integral_complex_ofReal]
  apply Complex.nonneg_iff.mpr
  refine ⟨?_,rfl⟩
  exact integral_nonneg_of_ae (h.mono fun z hz => (Complex.nonneg_iff.mp hz).1)

variable {D : Type*} [AddCommGroup D] [Fintype D]

/-- The row may be centered at ANY ambient x, including outside e(D).
The Fourier fiber tests all displacements in the same subgroup. -/
theorem finite_symbol_nonneg (e : Multiplicative D →* G) (T : L2 G →L[ℂ] L2 G)
    (nonneg : RowNonneg G T) (x : G) (γ : AddChar D ℂ) :
    0 ≤ ∑ d : D, entries T (x,x*e (Multiplicative.ofAdd d)) * γ d := by
  classical
  let v (d : D) := basis G (e (Multiplicative.ofAdd d))
  let a (d : D) := star (γ d)
  let w := ∑ d : D, a d • v d
  have first (d : D) : inner ℂ (v d) (rowDensity G T x) = entries T (x,x*e (Multiplicative.ofAdd d)) := by
    have h := coefficient T x (x*e (Multiplicative.ofAdd d))
    simpa only [phase,mul_div_cancel_left, v] using h
  have eqn : inner ℂ w (rowDensity G T x) = ∑ d : D, entries T (x,x*e (Multiplicative.ofAdd d)) * γ d := by
    simp only [w,sum_inner, inner_smul_left,first,a,starRingEnd_apply,star_star,mul_comm]
  have w_ae : ∀ᵐ χ ∂dualHaar G, w χ = ∑ d : D, star (γ d)*(χ (e (Multiplicative.ofAdd d)):ℂ) := by
    have hs := Lp.coeFn_fun_finsetSum (p:=2) (μ:=dualHaar G) Finset.univ (fun d => a d • v d)
    have term (d : D) : ∀ᵐ χ ∂dualHaar G, (a d • v d) χ = star (γ d)*(χ (e (Multiplicative.ofAdd d)):ℂ) := by
      filter_upwards [Lp.coeFn_smul (a d) (v d), basis_ae G (e (Multiplicative.ofAdd d))] with χ h₁ h₂
      change _ = a d * _
      rw [h₁,Pi.smul_apply,smul_eq_mul]
      exact congrArg (a d * ·) h₂
    filter_upwards [hs,ae_all_iff.mpr term] with χ h h'
    exact h.trans (Finset.sum_congr rfl (fun d _ => h' d))
  have w_pos : ∀ᵐ χ ∂dualHaar G, 0 ≤ w χ := by
    filter_upwards [w_ae] with χ hh
    let k : AddChar D ℂ := {
      toFun := fun d => star (γ d)*(χ (e (Multiplicative.ofAdd d)):ℂ)
      map_zero_eq_one' := by simp
      map_add_eq_mul' := by
        intro a b
        rw [show Multiplicative.ofAdd (a+b) = Multiplicative.ofAdd a * Multiplicative.ofAdd b from rfl]
        simp only [AddChar.map_add_eq_mul,star_mul,map_mul,Circle.coe_mul]; ring }
    change w χ = ∑ d, k d at hh
    rw [hh,AddChar.sum_eq_ite]
    split_ifs <;> positivity
  rw [←eqn,MeasureTheory.L2.inner_def]
  apply pos_integral
  filter_upwards [w_pos, nonneg x] with χ hw hr
  rw [RCLike.inner_apply]
  apply mul_nonneg hr
  obtain ⟨hre,him⟩ := Complex.nonneg_iff.mp hw
  exact Complex.nonneg_iff.mpr ⟨hre,by simp [←him]⟩

end KDClosure.PhysicalCorner
