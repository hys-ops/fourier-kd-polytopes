import KDPacketRays
import KDChainLimitFinite
import Mathlib.Analysis.Matrix.PosDef
/-! Bridge to the actual archived finite pure-state classification. The proofs
marked below are source excerpts from Paper 1, replayed in 4.33.1 using the
unchanged archived Frame, outer, reconstruction and symbol declarations. -/
noncomputable section
set_option autoImplicit false
set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false
namespace KDClosure.Hull.FinitePort
open KDOperator KDPure KDFourier Matrix Classical
open scoped ComplexOrder ComplexConjugate MatrixOrder
variable {G I : Type*} [AddCommGroup G] [Fintype G] [DecidableEq G] [Fintype I]
-- FiniteFourierKD/src/KDPure.lean, pure_product (75–86) and common_phase through pure_vector_form (91–138).
theorem pure_product (u : G → ℂ) (positive : ∀ x k, 0 ≤ symbol (outer u) x k)
    (x : G) (k : AddChar G ℂ) :
    symbol (outer u) x k = (‖u x‖ : ℂ) * (‖amp u k‖ : ℂ) := by
  have hn := positive x k
  obtain ⟨r,hr,he⟩ := (RCLike.nonneg_iff_exists_ofReal.mp hn)
  have habs : ‖symbol (outer u) x k‖ = ‖u x‖ * ‖amp u k‖ := by
    simp [symbol_outer,norm_mul,AddChar.norm_apply]
  change (r : ℂ) = symbol (outer u) x k at he
  rw [← he] at habs
  have hh : ‖(r : ℂ)‖ = r := by simpa using (abs_of_nonneg hr)
  rw [hh] at habs
  rw [← he, habs, Complex.ofReal_mul]
theorem common_phase (u : G → ℂ) (positive : ∀ x k, 0 ≤ symbol (outer u) x k)
    {a x : G} {b k : AddChar G ℂ} (ha : u a ≠ 0) (hx : u x ≠ 0)
    (hb : amp u b ≠ 0) (hk : amp u k ≠ 0) : k (x-a) = b (x-a) := by
  have cross : symbol (outer u) x k * symbol (outer u) a b =
      symbol (outer u) x b * symbol (outer u) a k := by
    simp only [pure_product u positive]; ring
  simp only [symbol_outer] at cross
  have e : k (-x)*b (-a)=b (-x)*k (-a) := by
    apply mul_left_cancel₀ (a := star (u x)*star (u a)*amp u k*amp u b)
      (mul_ne_zero (mul_ne_zero (mul_ne_zero (by simpa using hx) (by simpa using ha)) hk) hb)
    linear_combination cross
  have ep := congrArg Inv.inv e
  simp only [AddChar.map_neg_eq_inv,_root_.mul_inv_rev,inv_inv] at ep
  rw [AddChar.map_sub_eq_div,AddChar.map_sub_eq_div]
  exact (div_eq_div_iff (char_ne _ _) (char_ne _ _)).mpr (by linear_combination ep)

def compatible (u : G → ℂ) (b : AddChar G ℂ) : AddSubgroup G where
  carrier := {h | ∀ k, amp u k ≠ 0 → k h = b h}
  zero_mem' := by simp
  add_mem' := by intro x y hx hy k hk; rw [k.map_add_eq_mul,b.map_add_eq_mul,hx k hk,hy k hk]
  neg_mem' := by intro x hx k hk; rw [k.map_neg_eq_inv,b.map_neg_eq_inv,hx k hk]

theorem translated (F : Frame G I) (u : G → ℂ) (b : AddChar G ℂ) (x h : G) (hh : h ∈ compatible u b) :
    u (x+h) = u x * b (-h) := by
  have he : ∀ k : AddChar G ℂ, amp u k * k (-(x+h)) = (amp u k * k (-x)) * b (-h) := by
    intro k; by_cases hk : amp u k = 0
    · simp [hk]
    · rw [neg_add,k.map_add_eq_mul,k.map_neg_eq_inv h,b.map_neg_eq_inv h,hh k hk,mul_assoc]
  apply mul_left_cancel₀ (a := (Fintype.card G:ℂ)) (Nat.cast_ne_zero.mpr Fintype.card_ne_zero)
  rw [← mul_assoc,← reconstruct F u (x+h),← reconstruct F u x,Finset.sum_mul]
  exact Finset.sum_congr rfl (fun i _ => he (F.char i))

/-- In a KD-positive pure state the support is a single coset, and the phase is a character. -/
theorem pure_vector_form (F : Frame G I) (u : G → ℂ) (hu : u ≠ 0)
    (positive : ∀ x k, 0 ≤ symbol (outer u) x k) :
    ∃ (a : G) (j : I), u a ≠ 0 ∧ amp u (F.char j) ≠ 0 ∧
      ∀ x, u x = if x-a ∈ compatible u (F.char j) then u a*F.char j (-(x-a)) else 0 := by
  classical
  obtain ⟨a,ha⟩ : ∃ a, u a ≠ 0 := by
    by_contra! hn; exact hu (funext hn)
  obtain ⟨j,hb⟩ : ∃ j, amp u (F.char j) ≠ 0 := by
    by_contra! hn
    have hh := reconstruct F u a
    simp [hn,Fintype.card_ne_zero,ha] at hh
  refine ⟨a,j,ha,hb,?_⟩
  intro x; split_ifs with h
  · simpa using translated F u (F.char j) a (x-a) h
  · exact Classical.byContradiction (fun hne => h (fun k hk => common_phase u positive ha hne hb hk))

-- FiniteFourierKD/src/KDRank.lean, hasEig and outer_iff_rank (13–50).
theorem hasEig {A : Op G} (her : A.IsHermitian) (tr : A.trace=1) :
    ∃ i, her.eigenvalues i ≠ 0 := by
  by_contra! hn; rw [her.trace_eq_sum_eigenvalues] at tr; simp [hn] at tr

theorem outer_iff_rank {A : Op G} (ps : A.PosSemidef) (tr : A.trace=1) :
    (∃ u : G → ℂ, A=outer u) ↔ A.rank=1 := by
  classical
  let h := ps.isHermitian
  obtain ⟨j,hj⟩ := hasEig h tr
  constructor
  · rintro ⟨u,hu⟩
    have le : A.rank ≤ 1 := hu ▸ Matrix.rank_vecMulVec_le (star u) u
    have : Nonempty {i // h.eigenvalues i ≠ 0} := ⟨⟨j,hj⟩⟩
    have pos : 0 < A.rank := h.rank_eq_card_non_zero_eigs ▸ Fintype.card_pos
    omega
  · intro hr
    have card : Fintype.card {i // h.eigenvalues i ≠ 0}=1 := h.rank_eq_card_non_zero_eigs.symm.trans hr
    have sub : Subsingleton {i // h.eigenvalues i ≠ 0} := Fintype.card_le_one_iff_subsingleton.mp card.le
    have oth (i:G) (hi:i≠j) : h.eigenvalues i=0 := by
      by_contra hn; exact hi (congrArg Subtype.val (sub.elim ⟨i,hn⟩ ⟨j,hj⟩))
    have e1 : (h.eigenvalues j : ℂ)=1 := by
      have s := h.trace_eq_sum_eigenvalues
      rw [Finset.sum_eq_single j] at s
      · exact s.symm.trans tr
      · intro i _ hn; simp [oth i hn]
      · simp
    let U : Op G := h.eigenvectorUnitary
    refine ⟨fun x => star (U x j),?_⟩
    have spec := h.spectral_theorem
    rw [Unitary.conjStarAlgAut_apply] at spec
    ext x y
    rw [spec]
    change (U * diagonal (fun i : G => (h.eigenvalues i : ℂ)) * Uᴴ) x y =
      star (star (U x j)) * star (U y j)
    rw [Matrix.mul_apply,Finset.sum_eq_single j]
    · simp [Matrix.mul_diagonal,Matrix.conjTranspose_apply,e1,RCLike.ofReal]
    · intro i _ ne; simp [Matrix.mul_diagonal,oth i ne]
    · simp

-- FiniteFourierKD/src/KDFrame.lean, representative and finite_pure (63–85).
open KDClosure.ChainLimit.Finite
def representative (F : Frame G I) (t : G × I × AddSubgroup G) : Op G :=
  let v : G → ℂ := fun x => if x-t.1 ∈ t.2.2 then F.char t.2.1 (-(x-t.1)) else 0
  (outer v).trace⁻¹ • outer v

theorem finite_pure (F : Frame G I) : (pureSet G).Finite := by
  let : Finite (AddSubgroup G) := Finite.of_injective (fun H : AddSubgroup G => (H:Set G))
    SetLike.coe_injective
  apply (Set.finite_range (representative F)).subset
  rintro _ ⟨u,rfl,ht,hp⟩
  have hu : u ≠ 0 := by rintro rfl; simp [outer,trace,Matrix.diag,Matrix.of_apply] at ht
  obtain ⟨a,j,ha,hb,hform⟩ := pure_vector_form F u hu hp
  let H := compatible u (F.char j)
  let v : G → ℂ := fun x => if x-a ∈ H then F.char j (-(x-a)) else 0
  have uv (x : G) : u x = u a * v x := by rw [hform x]; by_cases h : x-a ∈ H <;> simp [v,h,H] at *
  let c := star (u a)*u a
  have m : outer u = c • outer v := by
    ext x y
    change star (u x)*u y=c*(star (v x)*v y)
    rw [uv x,uv y,star_mul]; dsimp [c]; ring
  have ht' : c*(outer v).trace=1 := by simpa [m,trace_smul] using ht
  refine ⟨(a,j,H),?_⟩
  change (outer v).trace⁻¹ • outer v=outer u
  rw [m,← inv_eq_of_mul_eq_one_right ht',inv_inv]

theorem full_finitePure_finite : (finitePure G).Finite := by
  let F : Frame G (AddChar G ℂ) := ⟨id,AddChar.sum_apply_eq_ite⟩
  refine (finite_pure F).subset ?_
  rintro A ⟨p,t,r,kd⟩
  obtain ⟨u,hu⟩ := (outer_iff_rank p t).mpr r
  exact ⟨u,hu,t,kd⟩
end KDClosure.Hull.FinitePort
