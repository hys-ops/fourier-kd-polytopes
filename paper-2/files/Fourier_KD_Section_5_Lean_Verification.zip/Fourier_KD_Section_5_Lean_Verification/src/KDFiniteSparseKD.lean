import KDAmplitudeMatch
import KDSparseBudget
import KDGap

namespace KDClosure.SparseKD
open PhysicalLift WaveSupport AmbientFourier AtomBridge Classical
open scoped BigOperators ComplexOrder
variable {p q : ℕ} [Fact p.Prime] [Fact q.Prime]

/-- Transport dense Fourier coordinates to precisely the cardinality expression
used by finiteOriginalPSD. Coordinates, sums and all matrix entries are preserved. -/
def back (p m n : ℕ) (x : ZMod (p^(1+n*(m+1)))) : ZMod (levelSize p (p^m) n) :=
  (reindex (size_prime_power p m n)).symm x

noncomputable def localD (p m n : ℕ) [Fact p.Prime] (f : ℕ → ℝ)
    (x : ZMod (p^(1+n*(m+1)))) := originalWeight f n (back p m n x)

noncomputable def localSign (p m l n : ℕ) [Fact p.Prime] (x : ZMod (p^(1+n*(m+1)))) : Prop :=
  signFlag l n (back p m n x) = true

noncomputable def originalRows (p q : ℕ) [Fact p.Prime] [Fact q.Prime] (m l n : ℕ) (f : ℕ → ℝ) :
    Blocks (p^(1+n*(m+1))) q :=
  fun x h t u => actualMatrix
    (originalWeight (p:=p) (L:=p^m) f n) (signFlag l n)
    (perturbation q (fun _ => negativeDigit p) f l n (fun i => plus i.val))
    (back p m n x,t) (back p m n (x+h),u)

theorem original_perturbation {l : ℕ} (hl : 0<l) (hlt : l<p) (m n : ℕ)
    (f : ℕ → ℝ) (hf : ∀ i,0<f i) (hm : Monotone f) (x z : ZMod (p^(1+n*(m+1)))) :
    perturbation q (fun _ => negativeDigit p) f l n (fun i => plus i.val)
      (back p m n x) (back p m n z) =
      ∑ j ∈ Finset.range n, (amplitude p q (p^m) l f j:ℂ) * sparseKet p m j n x *
          star (sparseKet p m j n z) := by
  change (b q:ℂ)⁻¹ * (∑ j : Fin n, _ * _ * _) = _
  rw [Finset.mul_sum,← Fin.sum_univ_eq_sum_range]
  apply Finset.sum_congr rfl
  intro j _
  exact (mul_assoc _ _ _).symm.trans (by
    rw [← mul_assoc,complex_scale (q:=q) (L:=p^m) hl hlt f hf hm]
    rfl)

/-- Exact equality of the two independently defined full physical matrices,
including their signed relative coefficients and the diagonal transverse blocks. -/
theorem original_rows_eq {l : ℕ} (hl : 0<l) (hlt : l<p) (m n : ℕ)
    (f : ℕ → ℝ) (hf : ∀ i,0<f i) (hm : Monotone f) :
    originalRows p q m l n f =
      Frequency.finiteWitness (birthIndices m (Finset.range n))
        (birthAmplitude m (amplitude p q (p^m) l f)) (localD p m n f) (localSign p m l n) := by
  funext x h t u
  rw [witness_eq_physical_sparse _ _ _ (fun j hj => Finset.mem_range.mp hj)]
  simp only [originalRows,actualMatrix,original_perturbation hl hlt m n f hf hm,Matrix.sub_apply]
  have eq0 : back p m n x = back p m n (x+h) ↔ h=0 := by
    simp [back]
  by_cases e : h=0 <;> by_cases flag : signFlag l n (back p m n x)=true <;>
    simp [eq0,e,localD,localSign,Frequency.baseBlock,flag]

/-- Exactly the physical finite PSD witness on every sparse head, tested by
the ordinary dense cyclic Fourier table. The gap is a scalar schedule condition,
and can be attained for every pair of primes by uniform_prime_gap. -/
theorem finite_sparse_KD {l : ℕ} (hl : 0<l) (hlt : l<p) (m : ℕ) (hL : 1<p^m)
    (gap : ∀ j, kappa p q l / reciprocalMean (1/((p^m:ℕ):ℝ)) (fresh p (p^m)) j <
      1/fresh p (p^m) j) (n : ℕ) (x k : ZMod (p^(1+n*(m+1)))) (t s : ZMod q) :
    let z := table (originalRows p q m l n (fresh p (p^m))) x t k s
    0≤z.re ∧ z.im=0 ∧ (z=0 ↔ Protected (localSign p m l n) x t s) := by
  let f := fresh p (p^m)
  obtain ⟨d,hd,_,hweight,_,hmargin⟩ := global_baseline m (kappa p q l) hL gap
  have dmatch (v : ZMod (p^(1+n*(m+1)))) : localD p m n f v = d (powerChart p (1+n*(m+1)) v) := by
    let u := (encodeLevel p (p^m) n).symm (back p m n v)
    have eqn := chart_sparsePoint m n u
    have h := hweight n u
    simp [u,back] at eqn
    rw [eqn]
    change localD p m n f v = d (sparsePoint p m n u)
    rw [h]
    simp [localD,originalWeight,u,f,one_div]
  dsimp only
  rw [original_rows_eq hl hlt m n f fresh_props.1 fresh_props.2]
  apply Frequency.finite_witness_KD
  · intro b hb
    obtain ⟨i,hi,rfl⟩ := Finset.mem_image.mp hb
    have h := Nat.mul_le_mul_right (m+1) (Nat.succ_le_of_lt (Finset.mem_range.mp hi))
    rw [Nat.add_comm 1]
    exact Nat.lt_succ_of_le h
  · intro v; rw [dmatch]; exact hd _
  · intro b hb v hv
    obtain ⟨i,_,rfl⟩ := Finset.mem_image.mp hb
    simp only [birthAmplitude,Nat.mul_div_cancel _ (Nat.succ_pos m),Nat.add_sub_cancel,
      abs_amplitude hl hlt f fresh_props.1 fresh_props.2,dmatch]
    apply hmargin
    exact (chart_inside ..).2 (by simpa [Nat.add_comm 1] using hv)

/-- A single stage spacing suffices simultaneously on all sparse prefixes. -/
theorem exists_sparse_KD {l : ℕ} (hl : 0<l) (hlt : l<p) :
    ∃ m : ℕ, 0<m ∧ 1<p^m ∧
      ∀ n (x k : ZMod (p^(1+n*(m+1)))) (t s : ZMod q),
        let z := table (originalRows p q m l n (fresh p (p^m))) x t k s
        0≤z.re ∧ z.im=0 ∧ (z=0 ↔ Protected (localSign p m l n) x t s) := by
  obtain ⟨_,m,hm,hL,hgap⟩ := uniform_prime_gap p q l Fact.out Fact.out hl hlt
  exact ⟨m,hm,hL,finite_sparse_KD hl hlt m hL hgap⟩

end KDClosure.SparseKD
