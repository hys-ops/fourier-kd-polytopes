import KDAllAmbientPure
import KDReducedCellLift

/-! Generalize the archived pad_pure_state proof to every finite physical
KD state; identify the embedded state's tested matrix exactly. -/
noncomputable section
set_option linter.unusedSectionVars false
namespace KDClosure.Hull
open Classical Set Matrix Discrete DiscreteKDRow DiscreteTransfer ChainLimit
open scoped ComplexOrder ComplexConjugate InnerProductSpace BigOperators ENNReal
section Pad
variable {G : Type*} [CommGroup G] [TopologicalSpace G] [DiscreteTopology G] [DecidableEq G]
variable {I : Type*} [AddCommGroup I] [Fintype I] [DecidableEq I]
theorem pad_arbitrary_state (e : Multiplicative I →* G) (he : Function.Injective e)
    (P : Matrix I I ℂ) (ps : P.PosSemidef) (tr : P.trace=1)
    (kd : ∀ x γ, 0 ≤ KDFourier.symbol P x γ) :
    ∃ T ∈ states G, entries T = pad (⟨fun i => e (.ofAdd i),he⟩ : I ↪ G) P := by
  let _ : TopologicalSpace (Multiplicative I) := ⊥
  let _ : DiscreteTopology (Multiplicative I) := ⟨rfl⟩
  have diag : (∑' i : I, (P i i).re)=1 := by
    rw [tsum_fintype,←Complex.re_sum]; exact congrArg Complex.re tr
  obtain ⟨A,pos,coeff⟩ := realizePSD P ps ((hasSum_fintype _).summable) diag.le
  have htr : IsLUB (finiteFrameMass A) 1 := (trace_hasSum pos).mpr (by
    convert! ((hasSum_fintype (fun i : I => (P i i).re)).summable).hasSum using 1
    · funext i; exact congrArg Complex.re (coeff i i)
    · exact diag.symm)
  have hkd : RowNonneg (Multiplicative I) A := by
    let j := fun _ : ℕ => MonoidHom.id (Multiplicative I)
    apply (PhysicalCorner.exhaustion_iff (I:=fun _ => I) j (fun _ => Function.injective_id)
      (fun _ _ _ => Subset.rfl) (fun z => ⟨0,z,rfl⟩) A).mpr
    intro _ x γ
    have v := kd x γ
    rw [←KDAtoms.row_amp] at v
    change 0 ≤ ∑ d : I, entries A (x,x+d)*γ d
    simpa only [show ∀ x y:I, entries A (x,y)=P x y from coeff,KDPure.amp,KDAtoms.row] using v
  have st : A∈states (Multiplicative I) := ⟨pos,htr,hkd⟩
  let i : I ↪ G := ⟨fun t => e (.ofAdd t),he⟩
  refine ⟨DiscreteKDRow.push e he A,(push_mem_iff e he A).mpr st,?_⟩
  funext z
  obtain ⟨x,y⟩ := z
  by_cases xmem : x∈range i
  · obtain ⟨x,rfl⟩ := xmem
    by_cases ymem : y∈range i
    · obtain ⟨y,rfl⟩ := ymem
      exact ((DiscreteEmbedding.entries_on i A x y).trans (coeff _ _)).trans (pad_on i P x y).symm
    · exact (DiscreteEmbedding.entries_off_right i A _ _ ymem).trans (pad_off_right i P _ _ ymem).symm
  · exact (DiscreteEmbedding.entries_off_left i A _ _ xmem).trans (pad_off_left i P _ _ xmem).symm

end Pad
open MeasureTheory CompactCore LCAReality LCAQuotient ReducedWindows
open scoped KDClosure.SubgroupMeasure
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
    [T2Space G] [LocallyCompactSpace G] [SecondCountableTopology G] [MeasurableSpace G] [BorelSpace G]
variable (μ : Measure G) [μ.IsAddHaarMeasure] (ν : Measure (LCAReality.Dual G)) [SFinite ν] [ν.IsHaarMeasure]
variable (F : FourierRealization μ ν)
local instance (L K : CO G) : Fintype (CoreQuot L K) := @Fintype.ofFinite _ (finite_core L K)
local instance (L : CO G) : DiscreteTopology (Qm L) := QuotientGroup.discreteTopology (openMul L).isOpen
local instance (L : CO G) : Countable (Qm L) := DiscreteReduction.countable L

theorem lift_physical (L K : CO G)
    (C : Matrix (CoreQuot L K) (CoreQuot L K) ℂ) (ps : C.PosSemidef) (tr : C.trace=1)
    (kd : ∀ x γ, 0 ≤ KDFourier.symbol C x γ) :
    ∃ T ∈ ambientStates μ ν F, normalizedBlock L K μ T 0 1=C := by
  classical
  obtain ⟨R,st,entry⟩ := pad_arbitrary_state (mEmb L K) (sectionEmb_inj L K) C ps tr kd
  refine ⟨LCAQuotient.push μ L R, (LCAQuotient.push_mem_iff μ ν L F R).mp st,?_⟩
  let J : Discrete.L2 (Qm L) →L[ℂ] Lp ℂ 2 μ := (LCAQuotient.inclusion μ L).toContinuousLinearMap
  let b : CoreQuot L K → Qm L := fun i => mEmb L K (.ofAdd i)
  let w := fun i : CoreQuot L K => (lp.single 2 (b i) 1 : Discrete.L2 (Qm L))
  have hcell (i : CoreQuot L K) : normalizedCell L K μ 0 1 i = J (w i) := by
    rw [←embed_single L K μ i]
    change J (DiscreteEmbedding.inclusion (ixEmb L K) (lp.single 2 (.ofAdd i) 1)) = _
    rw [DiscreteEmbedding.inclusion_single]
    rfl
  have adj (v : Discrete.L2 (Qm L)) : J.adjoint (J v)=v :=
    DFunLike.congr_fun ((ContinuousLinearMap.isometry_iff_adjoint_comp_self J).mp
    (LCAQuotient.inclusion μ L).isometry) v
  ext i j
  change inner ℂ (normalizedCell L K μ 0 1 i) (J (R (J.adjoint (normalizedCell L K μ 0 1 j)))) = _
  rw [hcell i,hcell j,adj]
  calc
    _ = inner ℂ (w i) (R (w j)) := (LCAQuotient.inclusion μ L).inner_map_map _ _
    _ = C i j := (congrFun entry (b i,b j)).trans (pad_on _ C i j)

theorem finite_section_violates_equality (L K : CO G) (le : L≤K)
    (C : Matrix (CoreQuot L K) (CoreQuot L K) ℂ) (ps : C.PosSemidef) (tr : C.trace=1)
    (kd : ∀ x γ, 0 ≤ KDFourier.symbol C x γ) (outside : C ∉ convexHull ℝ (finitePure (CoreQuot L K))) :
    ambientStates μ ν F ≠ traceClosure (convexHull ℝ (ambientPure μ ν F)) := by
  obtain ⟨T,st,block⟩ := lift_physical μ ν F L K C ps tr kd
  have out := finite_witness_excludes_ALL_ambient_pure_of_tests μ ν F L K le 0 1 T C block tr outside
  intro eq; exact out (eq ▸ st)
end KDClosure.Hull
