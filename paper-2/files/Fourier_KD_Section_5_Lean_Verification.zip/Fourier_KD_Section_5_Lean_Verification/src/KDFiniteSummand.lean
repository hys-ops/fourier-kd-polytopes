import KDExclusion

namespace KDClosure
open Matrix
open scoped BigOperators ComplexOrder
variable {m q : ℕ} [NeZero m] [Fact q.Prime]

theorem separate {ι : Type*} [Fintype ι] (B : Matrix ι ι ℂ) (v w : ι → ℂ) {c : ℂ}
    (hc : c ≠ 0) (hp : B *ᵥ (v + c • w) = 0) (hm : B *ᵥ (v - c • w) = 0) :
    B *ᵥ v = 0 ∧ B *ᵥ w = 0 := by
  rw [Matrix.mulVec_add,Matrix.mulVec_smul] at hp
  rw [Matrix.mulVec_sub,Matrix.mulVec_smul] at hm
  have hh (i : ι) : (B *ᵥ v) i = 0 ∧ (B *ᵥ w) i = 0 := by
    have a := congrFun hp i
    have b := congrFun hm i
    change (B *ᵥ v) i + c * (B *ᵥ w) i = 0 at a
    change (B *ᵥ v) i - c * (B *ᵥ w) i = 0 at b
    constructor
    · linear_combination (a+b)/2
    · apply (mul_eq_zero.mp _).resolve_left hc
      linear_combination (a-b)/2
  exact ⟨funext fun i => (hh i).1, funext fun i => (hh i).2⟩

theorem mulChannel (C : Matrix (ZMod q) (ZMod q) ℂ) (z : ℂ) (t : ZMod q) :
    (C *ᵥ channel q z) t = C t 0 + (∑ u, C t u)*z := by
  simp [Matrix.mulVec,dotProduct,channel,mul_add,Finset.sum_add_distrib,
    mul_ite,←Finset.sum_mul]

theorem killDiagonal {F : Blocks m q} (per : Periodic F) (cop : m.Coprime q)
    (x : ZMod m) (pos : (F x 0).PosSemidef) {z : ℂ} (zn : z ≠ 0)
    (a : (F x 0) *ᵥ channel q z = 0) (b : (F x 0) *ᵥ channel q (-z) = 0) :
    F x 0 = 0 := by
  let C := F x 0
  have diag (t : ZMod q) : C t 0 = 0 ∧ ∑ u, C t u = 0 := by
    have a' := congrFun a t
    have b' := congrFun b t
    rw [mulChannel] at a' b'
    change C t 0 + (∑ u, C t u)*z = 0 at a'
    change C t 0 + (∑ u, C t u)*(-z) = 0 at b'
    constructor
    · linear_combination (a'+b')/2
    · apply (mul_eq_zero.mp _).resolve_right zn
      linear_combination (a'-b')/2
  have off (t u : ZMod q) (ne : u ≠ t) : C t u = 0 := by
    have eq := sameOff per cop x 0 t (u-t) (sub_ne_zero.mpr ne)
    have hr := pos.isHermitian.apply 0 (u-t)
    change star (C (u-t) 0) = C 0 (u-t) at hr
    simpa [C] using (show C t (t+(u-t)) = 0 from eq.trans (hr.symm.trans (by simp [(diag _).1])))
  ext t u
  by_cases eq : u=t
  · subst u
    have sumt := (diag t).2
    rw [Finset.sum_eq_single t] at sumt
    · exact sumt
    · intro u _ hu; exact off t u hu
    · simp
  · exact off t u eq

/-- User-facing finite-head elimination. F is the physical kernel of the putative summand.
The input conditions are precisely the inherited ones stated in the theorem's documentation. -/
theorem finiteHeadVanish {F : Blocks m q} {pos : ZMod m → Prop}
    (cop : m.Coprime q) (per : Periodic F) (mix : Both pos)
    (hz : ∀ x t k s, Protected pos x t s → table F x t k s = 0)
    (ps : (physical F).PosSemidef) {d₁ d₂ : ZMod m → ℂ}
    (dn₁ : ∀ x, d₁ x ≠ 0) (dn₂ : ∀ x, d₂ x ≠ 0)
    {z c : ℂ} (zr : star z = z) (sz : (q:ℂ)*z^2=1) (hc : c ≠ 0)
    (kp : physical F *ᵥ (headVec d₁ z + c • headVec d₂ (-z)) = 0)
    (km : physical F *ᵥ (headVec d₁ z - c • headVec d₂ (-z)) = 0) :
    physical F = 0 := by
  obtain ⟨k₁,k₂⟩ := separate (physical F) _ _ hc kp km
  have qoff (w : ℂ) (sw : (q:ℂ)*w^2=1) (x h : ZMod m) (hh : h ≠ 0) :
      channel q w ⬝ᵥ (F x h) *ᵥ channel q w = 0 := by
    obtain ⟨a,ha⟩ := blockShape cop per mix hz x h hh
    exact shape_quad ha sw
  have diagps (x : ZMod m) : (F x 0).PosSemidef := by
    have h := ps.submatrix (fun t : ZMod q => (x,t))
    have he : (physical F).submatrix (fun t : ZMod q => (x,t)) (fun t : ZMod q => (x,t)) = F x 0 := by
      ext t u; simp [physical,Matrix.submatrix]
    rwa [he] at h
  have toKer (x : ZMod m) (w : ℂ) (wr : star w = w)
      (hw : channel q w ⬝ᵥ (F x 0) *ᵥ channel q w = 0) :
      (F x 0) *ᵥ channel q w = 0 := by
    apply ((diagps x).dotProduct_mulVec_zero_iff _).mp
    have hs : star (channel q w) = channel q w := by
      funext t
      by_cases ht : t = 0 <;> simp [channel,Pi.star_apply,ht,wr]
    rwa [hs]
  have zn : z ≠ 0 := by intro h; simp [h] at sz
  have hdiag (x : ZMod m) : F x 0 = 0 :=
    killDiagonal per cop x (diagps x) zn
      (toKer x z zr (headToDiag dn₁ k₁ (qoff _ sz) x))
      (toKer x (-z) (by simp [zr]) (headToDiag dn₂ k₂ (qoff _ (by simpa using sz)) x))
  have hd (i : ZMod m × ZMod q) : physical F i i = 0 := by
    simp [physical,hdiag]
  ext i j
  have hj : physical F *ᵥ Pi.single j 1 = 0 := by
    apply (ps.dotProduct_mulVec_zero_iff _).mp
    simp [hd]
  simpa [Matrix.mulVec_single_one] using congrFun hj i

end KDClosure
