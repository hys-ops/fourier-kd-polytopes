import KDLocalFeasibility
import KDMixedOperator
import KDPeriodPort

namespace KDClosure
open Matrix Set Discrete

/-- On the mixed Prüfer-by-prime group, a uniformly visible sequence of finite
matrix certificates gives a positive unit-diagonal-mass, infinite-rank extreme
bounded operator in the physical finite Fourier test model. The hypothesis
requires all displayed tests through each finite cutoff. No infinite witness,
period assertion, null equations, rank, or extremality is an input. -/
theorem finite_witness_operator (p q : ℕ) [Fact p.Prime] [Fact q.Prime] (pq : p≠q)
    (l : ℕ) (hl : 0<l) (hlt : l<p) (s : ℕ → ℕ) (hs : StrictMono s)
    (χ : ℕ → AddChar (ZMod p) ℂ) (a : ℕ → ℂ) (ha : ∀ j, a j ≠ 0)
    (d₁ d₂ : Additive (pRoots p) → ℂ) (h₁ : ∀ x, d₁ x ≠ 0) (h₂ : ∀ x, d₂ x ≠ 0)
    (c : ℂ) (hc : c ≠ 0) (o : MixedD p q) (δ : ℝ) (hδ : 0<δ)
    (finiteWitnesses : ∀ K, ∃ N, ∃ C : Matrix (Head p q N) (Head p q N) ℂ,
      (∀ i j, ‖C i j‖ ≤ 1) ∧ C.IsHermitian ∧
      let A := extendMatrix (cyclicMixedHead p q N) C
      δ ≤ (A (o,o)).re ∧ ∀ n≤K,
        HeadTests (fun i => cyclicMixedHead p q i) n A ∧ LayerZeros l s χ a d₁ d₂ c n A) :
    ∃ T ∈ (physicalTests p q).extremePoints ℝ, T.IsPositive ∧
      (∑' x : MixedD p q, (inner ℂ (lp.single 2 x (1:ℂ)) (T (lp.single 2 x (1:ℂ)))).re) = 1 ∧
      ¬ FiniteDimensional ℂ (LinearMap.range T.toLinearMap) := by
  let V (n : ℕ) := {A | δ ≤ (A (o,o)).re ∧ LayerZeros l s χ a d₁ d₂ c n A}
  have closed (n) : IsClosed (V n) := (isClosed_le continuous_const
    (Complex.continuous_re.comp (continuous_apply _))).inter (layerZeros_closed l s χ a d₁ d₂ c n)
  obtain ⟨A,hA,all⟩ := compact_limit_finite_matrices (fun i => cyclicMixedHead p q i) V closed (fun K => by
    obtain ⟨N,C,b,herm,pos,tests⟩ := finiteWitnesses K
    exact ⟨N,C,b,herm,fun n hn => ⟨(tests n hn).1,pos,(tests n hn).2⟩⟩)
  exact scheduled_operator p q pq l hl hlt s hs χ a ha d₁ d₂ h₁ h₂ c hc o δ hδ
    (fun _ h n => cornerSlice_periodic _ h n) (fun K => ⟨A,hA,(all K).1,(all K).2⟩)

end KDClosure
