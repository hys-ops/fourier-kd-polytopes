import Mathlib.Analysis.Fourier.ZMod
import Mathlib.Analysis.Matrix.Order
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.FieldSimp

/-! Fourier convention: the negative DFT just relabels both dual variables by negation.
The index h denotes a displacement throughout. -/
namespace KDClosure
open Matrix
open scoped BigOperators

variable {m q : ℕ} [NeZero m] [Fact q.Prime]

abbrev Blocks (m q : ℕ) := ZMod m → ZMod m → Matrix (ZMod q) (ZMod q) ℂ

noncomputable def transRow (C : Matrix (ZMod q) (ZMod q) ℂ) (t : ZMod q) :=
  ZMod.dft (fun v => C t (t+v))

noncomputable def table (F : Blocks m q) (x : ZMod m) (t : ZMod q)
    (k : ZMod m) (s : ZMod q) : ℂ :=
  ZMod.dft (fun h => transRow (F x h) t s) k

def Protected (pos : ZMod m → Prop) (x : ZMod m) (t s : ZMod q) : Prop :=
  (pos x ∧ t ≠ 0 ∧ s ≠ 0) ∨ (¬ pos x ∧ t = 0 ∧ s = 0)

/-- Precisely the one-displacement conclusion of the previous finite KD period theorem. -/
def Periodic (F : Blocks m q) : Prop :=
  ∀ x h t v, F (x+h) h (t+v) ((t+v)+v) = F x h t (t+v)

theorem inheritedZeros {F : Blocks m q} {pos : ZMod m → Prop}
    (hz : ∀ x t k s, Protected pos x t s → table F x t k s = 0)
    (x h : ZMod m) (t s : ZMod q) (ht : Protected pos x t s) :
    transRow (F x h) t s = 0 := by
  have he : ZMod.dft (fun i => transRow (F x i) t s) = 0 := funext fun k => hz x t k s ht
  have hz' : (fun i => transRow (F x i) t s) = 0 := ZMod.dft.injective (by simpa using he)
  exact congrFun hz' h

omit [NeZero m] in
theorem periodNat {F : Blocks m q} (per : Periodic F) (x h : ZMod m) (t v : ZMod q)
    (k : ℕ) : F (x+k•h) h (t+k•v) ((t+k•v)+v) = F x h t (t+v) := by
  induction k with
  | zero => simp
  | succ k ih =>
    simpa only [succ_nsmul, ← add_assoc] using
      (per (x+k•h) h (t+k•v) v).trans ih

theorem simultaneous (cop : m.Coprime q) (a : ZMod m) (b : ZMod q) :
    ∃ k : ℕ, (k : ZMod m) = a ∧ (k : ZMod q) = b := by
  let e := ZMod.chineseRemainder cop
  let w := e.symm (a,b)
  have hw : e (w.val : ZMod (m*q)) = (a,b) := by simp [w]
  rw [map_natCast] at hw
  exact ⟨w.val, congrArg Prod.fst hw, congrArg Prod.snd hw⟩

theorem pshift {F : Blocks m q} (per : Periodic F) (cop : m.Coprime q)
    (x h i : ZMod m) : F (x+i*h) h = F x h := by
  obtain ⟨k,hk,hl⟩ := simultaneous cop i 0
  ext t u
  have ha := periodNat per x h t (u-t) k
  simpa [nsmul_eq_mul,hk,hl] using ha

theorem sameOff {F : Blocks m q} (per : Periodic F) (cop : m.Coprime q)
    (x h : ZMod m) (t v : ZMod q) (hv : v ≠ 0) :
    F x h t (t+v) = F x h 0 v := by
  obtain ⟨k,hk,hl⟩ := simultaneous cop 0 (t/v)
  have ha := periodNat per x h 0 v k
  simpa [nsmul_eq_mul,hk,hl,div_mul_cancel₀ _ hv] using ha

theorem const_of_dft_supported (g : ZMod q → ℂ)
    (hz : ∀ s ≠ 0, ZMod.dft g s = 0) (u v : ZMod q) : g u = g v := by
  have ev (i : ZMod q) : g i = (q : ℂ)⁻¹ * ZMod.dft g 0 := by
    have hi := congrFun (ZMod.dft.symm_apply_apply g) i
    rw [ZMod.invDFT_apply] at hi
    rw [Finset.sum_eq_single (0 : ZMod q)] at hi
    · simpa using hi.symm
    · intro b _ hb
      simp [hz b hb]
    · simp
  exact (ev u).trans (ev v).symm

/-- Every nonzero displacement sees both protected zero patterns along its orbit. -/
def Both (pos : ZMod m → Prop) := ∀ x h, h ≠ 0 →
    (∃ i, pos (x+i*h)) ∧ (∃ i, ¬ pos (x+i*h))

theorem blockConstraints {F : Blocks m q} {pos : ZMod m → Prop}
    (cop : m.Coprime q) (per : Periodic F) (mix : Both pos)
    (hz : ∀ x t k s, Protected pos x t s → table F x t k s = 0)
    (x h : ZMod m) (hh : h ≠ 0) :
    (∀ t ≠ 0, ∀ s ≠ 0, transRow (F x h) t s = 0) ∧ transRow (F x h) 0 0 = 0 := by
  obtain ⟨⟨i,hi⟩,⟨j,hj⟩⟩ := mix x h hh
  constructor
  · intro t ht s hs
    simpa only [pshift per cop] using inheritedZeros hz (x+i*h) h t s (Or.inl ⟨hi,ht,hs⟩)
  · simpa only [pshift per cop] using inheritedZeros hz (x+j*h) h 0 0 (Or.inr ⟨hj,rfl,rfl⟩)

end KDClosure
