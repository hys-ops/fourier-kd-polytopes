import KDDiscreteOperator
import Mathlib.MeasureTheory.Function.L2Space
import Mathlib.Order.Filter.AtTopBot.Finset

/-! Strong L² synthesis of actual operator rows and convergence of their
integrals over finite-measure sets. The character-side input is orthonormality;
neither a complete character basis nor absolute summability of a row is assumed. -/
noncomputable section
namespace KDClosure.FourierSynthesis
open MeasureTheory Filter Set
open scoped ENNReal Topology BigOperators
variable {D Ω : Type*} [DecidableEq D] [MeasurableSpace Ω] {μ : Measure Ω}

/-- The row is an actual square-summable vector for every bounded operator. -/
def row (T : Discrete.L2 D →L[ℂ] Discrete.L2 D) (x : D) : Discrete.L2 D :=
  star (T.adjoint (lp.single 2 x (1:ℂ)))

theorem row_entry (T : Discrete.L2 D →L[ℂ] Discrete.L2 D) (x y : D) :
    row T x y = Discrete.entries T (x,y) := by
  change _ = inner ℂ (lp.single 2 x (1:ℂ)) (T (lp.single 2 y (1:ℂ)))
  rw [← T.adjoint_inner_left, lp.inner_single_right]
  simp [row,RCLike.inner_apply]

/-- Each fixed row may use its own shifted orthonormal family, as needed for
the genuine Fourier convention y ↦ χ(y−x). -/
def density (v : D → Lp ℂ 2 μ) (T : Discrete.L2 D →L[ℂ] Discrete.L2 D) (x : D) :
    Lp ℂ 2 μ := ∑' y, Discrete.entries T (x,y) • v y

theorem row_hasSum (v : D → Lp ℂ 2 μ) (hv : Orthonormal ℂ v)
    (T : Discrete.L2 D →L[ℂ] Discrete.L2 D) (x : D) :
    HasSum (fun y => Discrete.entries T (x,y) • v y) (density v T x) := by
  have h := hv.orthogonalFamily.summable_of_lp (row T x)
  change Summable (fun y => row T x y • v y) at h
  simpa only [row_entry,density] using h.hasSum

/-- The squared norm of the synthesized row is accounted for without loss. -/
theorem norm_density (v : D → Lp ℂ 2 μ) (hv : Orthonormal ℂ v)
    (T : Discrete.L2 D →L[ℂ] Discrete.L2 D) (x : D) :
    ‖density v T x‖ = ‖T.adjoint (lp.single 2 x (1:ℂ))‖ := by
  have h := hv.orthogonalFamily.linearIsometry.norm_map (row T x)
  change ‖∑' y, row T x y • v y‖ = _ at h
  simp_rw [row_entry] at h
  simpa only [density,row,norm_star] using h

section Heads
variable {I : ℕ → Type*} [∀ n, Fintype (I n)] (e : ∀ n, I n → D)
    (hinj : ∀ n, Function.Injective (e n))
    (inc : Monotone (fun n => range (e n))) (exh : ∀ y, ∃ n, y ∈ range (e n))

def poly (v : D → Lp ℂ 2 μ) (T : Discrete.L2 D →L[ℂ] Discrete.L2 D) (x : D) (n : ℕ) :
    Lp ℂ 2 μ := ∑ i, Discrete.entries T (x,e n i) • v (e n i)

include hinj inc exh in
theorem head_synthesis (v : D → Lp ℂ 2 μ) (hv : Orthonormal ℂ v)
    (T : Discrete.L2 D →L[ℂ] Discrete.L2 D) (x : D) :
    Tendsto (poly e v T x) atTop (𝓝 (density v T x)) := by
  let E (n : ℕ) := Finset.univ.image (e n)
  have hh (n : ℕ) (y : D) : y ∈ E n ↔ y ∈ range (e n) := by simp [E,Set.mem_range]
  have mg : Monotone E := fun i j ij _ hy => (hh j _).mpr (inc ij ((hh i _).mp hy))
  have ex (y : D) : ∃ n, y ∈ E n := by obtain ⟨n,h⟩ := exh y; exact ⟨n,(hh n y).mpr h⟩
  have lim := (row_hasSum v hv T x).comp (mg.tendsto_atTop_finset ex)
  change Tendsto (fun n => ∑ y ∈ E n, Discrete.entries T (x,y) • v y) atTop _ at lim
  change Tendsto (fun n => ∑ i : I n, Discrete.entries T (x,e n i) • v (e n i)) atTop _
  simpa only [E, Finset.sum_image (fun a _ b _ h => hinj _ h)] using lim

/-- A continuous L² test is the integral over any measurable set with finite
measure. The ambient measure itself need not be finite. -/
theorem continuous_integral (S : Set Ω) (meas : MeasurableSet S) (fin : μ S≠∞) :
    Continuous (fun f : Lp ℂ 2 μ => ∫ z in S, f z ∂μ) := by
  have e (f : Lp ℂ 2 μ) := MeasureTheory.L2.inner_indicatorConstLp_one meas fin f
  simp_rw [←e]
  exact continuous_const.inner continuous_id

include hinj inc exh in
theorem head_setIntegral (v : D → Lp ℂ 2 μ) (hv : Orthonormal ℂ v)
    (T : Discrete.L2 D →L[ℂ] Discrete.L2 D) (x : D) (S : Set Ω)
    (meas : MeasurableSet S) (fin : μ S≠∞) :
    Tendsto (fun n => ∫ z in S, poly e v T x n z ∂μ) atTop (𝓝 (∫ z in S, density v T x z ∂μ)) :=
  (continuous_integral S meas fin).continuousAt.tendsto.comp (head_synthesis e hinj inc exh v hv T x)

/-- Explicit pointwise character representatives of the finite physical head
polynomial agree a.e. with the finite L² sum, including the row coefficient. -/
theorem poly_ae (v : D → Lp ℂ 2 μ) (χ : D → Ω → ℂ)
    (rep : ∀ y, (v y : Ω → ℂ) =ᵐ[μ] χ y)
    (T : Discrete.L2 D →L[ℂ] Discrete.L2 D) (x : D) (n : ℕ) :
    (poly e v T x n : Ω → ℂ) =ᵐ[μ] fun z => ∑ i, Discrete.entries T (x,e n i) * χ (e n i) z := by
  have each (i : I n) : (⇑(Discrete.entries T (x,e n i) • v (e n i)) : Ω → ℂ) =ᵐ[μ]
      fun z => Discrete.entries T (x,e n i) * χ (e n i) z := by
    filter_upwards [Lp.coeFn_smul (Discrete.entries T (x,e n i)) (v (e n i)), rep (e n i)] with z hz hrep
    rw [hz,Pi.smul_apply,hrep,smul_eq_mul]
  have base := Lp.coeFn_fun_finsetSum (p:=2) (μ:=μ) Finset.univ (fun i : I n => Discrete.entries T (x,e n i) • v (e n i))
  filter_upwards [base, ae_all_iff.mpr each] with z hz hz'
  exact hz.trans (Finset.sum_congr rfl (fun i _ => hz' i))

include hinj inc exh in
/-- An eventual cylinder identity for the finite physical row polynomials is
an identity for the synthesized genuine Fourier row. -/
theorem integral_density_of_eventually (v : D → Lp ℂ 2 μ) (hv : Orthonormal ℂ v)
    (χ : D → Ω → ℂ) (rep : ∀ y, (v y : Ω → ℂ) =ᵐ[μ] χ y)
    (T : Discrete.L2 D →L[ℂ] Discrete.L2 D) (x : D) (S : Set Ω)
    (meas : MeasurableSet S) (fin : μ S≠∞) (v₀ : ℂ)
    (eventual : ∀ᶠ n in atTop, (∫ z in S, ∑ i, Discrete.entries T (x,e n i) * χ (e n i) z ∂μ) = v₀) :
    (∫ z in S, density v T x z ∂μ) = v₀ := by
  apply tendsto_nhds_unique (head_setIntegral e hinj inc exh v hv T x S meas fin)
  apply tendsto_const_nhds.congr'
  filter_upwards [eventual] with n h
  exact h.symm.trans (integral_congr_ae (ae_restrict_of_ae (poly_ae e v χ rep T x n).symm))

end Heads
end KDClosure.FourierSynthesis
