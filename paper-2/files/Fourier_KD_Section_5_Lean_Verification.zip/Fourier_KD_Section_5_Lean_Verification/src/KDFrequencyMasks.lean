import KDFourierHead
import Mathlib.NumberTheory.LegendreSymbol.AddCharacter
import Mathlib.Tactic.Positivity

/-! Finite physical Fourier masks on the cyclic p-primary towers. -/
namespace KDClosure.Frequency
open scoped BigOperators
variable {p N q : ℕ} [Fact p.Prime] [Fact q.Prime]

/-- The subgroup H_j inside the physical cyclic ambient group H_N. -/
def inside (p j : ℕ) {N : ℕ} (x : ZMod (p^N)) := (p:ZMod (p^N))^j * x = 0

/-- With KDClosure.table's negative DFT, use the child character with label p^j.
The support is the cylinder of characters that agree on H_{j+1}. -/
def cylinder (p j : ℕ) {N : ℕ} [NeZero p] (k : ZMod (p^N)) := ∀ x, inside p (j+1) x →
    ZMod.stdAddChar (-(x*k)) = ZMod.stdAddChar (-(x*(p:ZMod (p^N))^j))

omit [Fact p.Prime] in
theorem inner_mono {i j : ℕ} (hij : i ≤ j) {x : ZMod (p^N)} (hx : inside p i x) :
    inside p j x := by
  obtain ⟨b,rfl⟩ := Nat.exists_eq_add_of_le hij
  change (_:ZMod (p^N))^_ * x = 0
  change (_:ZMod (p^N))^i * x = 0 at hx
  rw [pow_add,mul_right_comm,hx,zero_mul]

theorem child_nontrivial (j : ℕ) (hj : j<N) :
    ∃ x : ZMod (p^N), inside p (j+1) x ∧ ¬ inside p j x := by
  have hp : p.Prime := Fact.out
  let b := N-(j+1)
  have hb : j+1+b=N := by dsimp [b]; omega
  have hb' : j+b<N := by omega
  refine ⟨(p:ZMod (p^N))^b, ?_, ?_⟩
  · change (_:ZMod (p^N))^_ * _^_ = 0
    rw [← pow_add,hb,← Nat.cast_pow,ZMod.natCast_self]
  · change ¬ (_:ZMod (p^N))^_ * _^_ = 0
    rw [← pow_add,← Nat.cast_pow,ZMod.natCast_eq_zero_iff]
    exact Nat.not_dvd_of_pos_of_lt (pow_pos hp.pos _) (Nat.pow_lt_pow_right hp.one_lt hb')

theorem cylinder_unique {i j : ℕ} (hi : i<N) (hj : j<N) {k : ZMod (p^N)}
    (ci : cylinder p i k) (cj : cylinder p j k) : i=j := by
  suffices lt_false : ∀ a b, a < b → b < N → cylinder p a k → cylinder p b k → False by
    rcases lt_trichotomy i j with h|h|h
    · exact False.elim (lt_false _ _ h hj ci cj)
    · exact h
    · exact False.elim (lt_false _ _ h hi cj ci)
  intro a b hab hb ca cb
  obtain ⟨x, hax, hn⟩ := child_nontrivial (p:=p) a (hab.trans hb)
  have hbx := inner_mono (Nat.succ_le_of_lt hab) hax
  have he := (ca x hax).symm.trans (cb x (inner_mono (Nat.le_succ b) hbx))
  have he' := neg_inj.mp (ZMod.injective_stdAddChar he)
  apply hn
  change _ * x = 0
  rw [mul_comm, he', mul_comm]
  exact hbx

noncomputable def tile (j : ℕ) (x k : ZMod (p^N)) : ℝ := by
  classical
  exact if inside p (j+1) x ∧ cylinder p j k then 1 else 0

/-- Pointwise control of the perturbation, uniform in the number of packets. -/
theorem margin (J : Finset ℕ) (levels : ∀ j ∈ J, j < N) (y : ℕ → ℝ)
    (d : ZMod (p^N) → ℝ) (hd : ∀ x, 0 < d x)
    (amp : ∀ j ∈ J, ∀ x, inside p (j+1) x → |y j| < d x)
    (x k : ZMod (p^N)) : |∑ j ∈ J, y j * tile j x k| < d x := by
  classical
  by_cases hit : ∃ j ∈ J, inside p (j+1) x ∧ cylinder p j k
  · obtain ⟨j,hj,hx,ck⟩ := hit
    rw [Finset.sum_eq_single j]
    · simpa [tile,hx,ck] using amp j hj x hx
    · intro i hi hij
      have no : ¬ cylinder p i k := fun h => hij (cylinder_unique (levels i hi) (levels j hj) h ck)
      simp [tile,no]
    · simp [hj]
  · rw [Finset.sum_eq_zero (fun j hj => ?_)]
    · simpa using hd x
    · have no : ¬ (inside p (j+1) x ∧ cylinder p j k) := fun h => hit ⟨j,hj,h⟩
      simp [tile,no]

noncomputable def bit {α : Type*} [Zero α] [DecidableEq α] (x : α) : ℝ :=
  if x=0 then 1 else 0

noncomputable def baseline (pos : Prop) [Decidable pos] (t s : ZMod q) : ℝ :=
  if pos then bit t + bit s else 2 - bit t - bit s

omit [Fact p.Prime] in
theorem mask_signs (pos : ZMod (p^N) → Prop) [DecidablePred pos] (x : ZMod (p^N))
    (t s : ZMod q) (d b : ℝ) (hd : 0 < d) (hb : |b|<d) :
    let z := d*baseline (pos x) t s + b*(bit t-bit s)
    0 ≤ z ∧ (z=0 ↔ Protected pos x t s) := by
  obtain ⟨h1,h2⟩ := abs_lt.mp hb
  by_cases h : pos x <;> by_cases ht : t=0 <;> by_cases hs : s=0 <;>
    norm_num [Protected,baseline,bit,h,ht,hs] <;> (try constructor) <;> linarith

noncomputable def U (q : ℕ) : Matrix (ZMod q) (ZMod q) ℂ := fun t u =>
  if t=0 ∧ u=0 then 1 else 0
noncomputable def V (q : ℕ) : Matrix (ZMod q) (ZMod q) ℂ := fun _ _ => (q:ℂ)⁻¹
noncomputable def ident (q : ℕ) : Matrix (ZMod q) (ZMod q) ℂ := fun t u =>
  if t=u then 1 else 0

theorem U_row (t s : ZMod q) : transRow (U q) t s = (bit t : ℂ) := by
  by_cases ht : t=0
  · subst t; simp [transRow,U,ZMod.dft_apply,bit]
  · simp [transRow,U,ZMod.dft_apply,bit,ht]

theorem V_row (t s : ZMod q) : transRow (V q) t s = (bit s : ℂ) := by
  have h := AddChar.sum_mulShift (-s) (ZMod.isPrimitive_stdAddChar q)
  simp only [mul_neg] at h
  simp only [transRow,ZMod.dft_apply,V,smul_eq_mul, ← Finset.sum_mul,h, ZMod.card]
  have hq : (q:ℂ) ≠ 0 := Nat.cast_ne_zero.mpr (Fact.out : Nat.Prime q).ne_zero
  by_cases hs : s=0 <;> simp [bit,hs,hq]

theorem I_row (t s : ZMod q) : transRow (ident q) t s = 1 := by
  simp [transRow,ident,ZMod.dft_apply]

theorem trans_add (A B : Matrix (ZMod q) (ZMod q) ℂ) (t s : ZMod q) :
    transRow (A+B) t s = transRow A t s + transRow B t s :=
  congrFun (ZMod.dft.map_add (fun h => A t (t+h)) (fun h => B t (t+h))) s

theorem trans_sub (A B : Matrix (ZMod q) (ZMod q) ℂ) (t s : ZMod q) :
    transRow (A-B) t s = transRow A t s - transRow B t s :=
  congrFun (ZMod.dft.map_sub (fun h => A t (t+h)) (fun h => B t (t+h))) s

noncomputable def baseBlock (q : ℕ) (sign : Prop) [Decidable sign] :
    Matrix (ZMod q) (ZMod q) ℂ :=
  if sign then U q + V q else ident q + ident q - U q - V q

theorem base_symbol (sign : Prop) [Decidable sign] (t s : ZMod q) :
    transRow (baseBlock q sign) t s = (baseline sign t s : ℂ) := by
  by_cases hs : sign <;>
    simp [baseBlock,baseline,hs,trans_add,trans_sub,U_row,V_row,I_row] 
  ring

noncomputable def factored (R : ZMod (p^N) → ZMod (p^N) → ℂ)
    (A : ZMod (p^N) → Matrix (ZMod q) (ZMod q) ℂ) : Blocks (p^N) q :=
  fun x h t u => R x h * A x t u

theorem factor_table (R : ZMod (p^N) → ZMod (p^N) → ℂ)
    (A : ZMod (p^N) → Matrix (ZMod q) (ZMod q) ℂ)
    (x : ZMod (p^N)) (t : ZMod q) (k : ZMod (p^N)) (s : ZMod q) :
    table (factored R A) x t k s = ZMod.dft (R x) k * transRow (A x) t s := by
  have ht (h : ZMod (p^N)) : transRow (factored R A x h) t s = R x h * transRow (A x) t s :=
    congrFun (ZMod.dft_const_mul (R x h) (fun v => A x t (t+v))) s
  simp only [table,ht]
  exact congrFun (ZMod.dft_mul_const (R x) (transRow (A x) t s)) k

theorem table_add (A B : Blocks (p^N) q)
    (x : ZMod (p^N)) (t : ZMod q) (k : ZMod (p^N)) (s : ZMod q) :
    table (A+B) x t k s = table A x t k s + table B x t k s := by
  unfold table
  have ht (h : ZMod (p^N)) : transRow ((A+B) x h) t s =
      transRow (A x h) t s + transRow (B x h) t s := trans_add _ _ _ _
  simp only [ht]
  exact congrFun (ZMod.dft.map_add _ _) k

/-- Inversion uniquely imports the earlier single-atom table into these DFT
coordinates. Thus the summation proof never requires another proof of the atom formula. -/
noncomputable def rowFromTile (j : ℕ) (x : ZMod (p^N)) : ZMod (p^N) → ℂ :=
  ZMod.dft.symm (fun k => (tile j x k : ℂ))

theorem old_atom_identification (j : ℕ) (R : ZMod (p^N) → ZMod (p^N) → ℂ)
    (singleAtom : ∀ x k, ZMod.dft (R x) k = (tile j x k : ℂ)) :
    R = rowFromTile j := by
  funext x
  apply ZMod.dft.injective
  simpa [rowFromTile] using funext (singleAtom x)

/-- The original atom uses the physical column u, while the row DFT takes the
displacement h=u-x. This translation preserves the unnormalised character sum. -/
theorem physical_symbol_dft (A : Matrix (ZMod (p^N)) (ZMod (p^N)) ℂ)
    (x k : ZMod (p^N)) :
    ZMod.dft (fun h => A x (x+h)) k =
        ∑ u, A x u * ZMod.stdAddChar (-((u-x)*k)) := by
  rw [ZMod.dft_apply]
  simpa [mul_comm,smul_eq_mul] using
    Equiv.sum_comp (Equiv.addLeft x) (fun u => A x u * ZMod.stdAddChar (-((u-x)*k)))

theorem legacy_physical_atom (j : ℕ) (A : Matrix (ZMod (p^N)) (ZMod (p^N)) ℂ)
    (atomTable : ∀ x k, ∑ u, A x u * ZMod.stdAddChar (-((u-x)*k)) =
        (tile j x k : ℂ)) : (fun x h => A x (x+h)) = rowFromTile j :=
  old_atom_identification j _ (fun x k => (physical_symbol_dft A x k).trans (atomTable x k))

noncomputable def perturbRow (J : Finset ℕ) (y : ℕ → ℝ) (x : ZMod (p^N)) :
    ZMod (p^N) → ℂ := ∑ j ∈ J, (y j : ℂ) • rowFromTile j x

theorem perturb_symbol (J : Finset ℕ) (y : ℕ → ℝ) (x k : ZMod (p^N)) :
    ZMod.dft (perturbRow J y x) k = ((∑ j ∈ J, y j * tile j x k : ℝ) : ℂ) := by
  have h (j : ℕ) : ZMod.dft ((y j : ℂ) • rowFromTile j x) k = (y j:ℂ)*(tile j x k:ℂ) := by
    rw [map_smul]
    simp [rowFromTile]
  simp only [perturbRow,map_sum,Finset.sum_apply,h,Complex.ofReal_sum,Complex.ofReal_mul]

noncomputable def finiteWitness (J : Finset ℕ) (y : ℕ → ℝ) (d : ZMod (p^N) → ℝ)
    (pos : ZMod (p^N) → Prop) [DecidablePred pos] : Blocks (p^N) q :=
  factored (fun x h => if h=0 then (d x : ℂ) else 0) (fun x => baseBlock q (pos x)) +
    factored (perturbRow J y) (fun _ => U q - V q)

theorem witness_table (J : Finset ℕ) (y : ℕ → ℝ) (d : ZMod (p^N) → ℝ)
    (pos : ZMod (p^N) → Prop) [DecidablePred pos] (x k : ZMod (p^N)) (t s : ZMod q) :
    table (finiteWitness J y d pos) x t k s =
      ((d x*baseline (pos x) t s +
          (∑ j ∈ J, y j*tile j x k)*(bit t-bit s) : ℝ):ℂ) := by
  have hz : ZMod.dft (fun h : ZMod (p^N) => if h=0 then (d x:ℂ) else 0) k = (d x:ℂ) := by
    simp [ZMod.dft_apply]
  rw [finiteWitness,table_add,factor_table,factor_table,hz,base_symbol,perturb_symbol,
    trans_sub,U_row,V_row]
  push_cast
  rfl

theorem finite_witness_KD (J : Finset ℕ) (levels : ∀ j ∈ J, j < N)
    (y : ℕ → ℝ) (d : ZMod (p^N) → ℝ) (hd : ∀ x, 0 < d x)
    (amp : ∀ j ∈ J, ∀ x, inside p (j+1) x → |y j| < d x)
    (pos : ZMod (p^N) → Prop) [DecidablePred pos] (x k : ZMod (p^N)) (t s : ZMod q) :
    let z := table (finiteWitness J y d pos) x t k s
    0 ≤ z.re ∧ z.im=0 ∧ (z=0 ↔ Protected pos x t s) := by
  obtain ⟨hn,hz⟩ := mask_signs pos x t s (d x) _ (hd x) (margin J levels y d hd amp x k)
  simp only [witness_table,Complex.ofReal_re,Complex.ofReal_im,Complex.ofReal_eq_zero]
  exact ⟨hn,True.intro,hz⟩

end KDClosure.Frequency
