import KDTraceBudget

namespace KDClosure
/-- The strict amplitude gap is achievable for every pair of primes using
the paper's base colour count; all subsequent reciprocal means then work. -/
theorem uniform_prime_gap (p q l : ℕ) (hp : p.Prime) (hq : q.Prime)
    (hl : 0<l) (hlt : l<p) :
    let a := (Real.sqrt (q:ℝ))⁻¹
    let r := 2*(l:ℝ)/p-1
    let κ := Real.sqrt (1-a^2) / Real.sqrt (1-(a*r)^2)
    0<κ ∧ ∃ m : ℕ, 0<m ∧ 1<p^m ∧
      ∀ j : ℕ, κ / reciprocalMean (1/((p^m:ℕ):ℝ)) (fresh p (p^m)) j <
        1 / fresh p (p^m) j := by
  dsimp only
  let a := (Real.sqrt (q:ℝ))⁻¹
  let r := 2*(l:ℝ)/p-1
  let κ := Real.sqrt (1-a^2) / Real.sqrt (1-(a*r)^2)
  have hp1 : 1<(p:ℝ) := by exact_mod_cast hp.one_lt
  have hq1 : 1<(q:ℝ) := by exact_mod_cast hq.one_lt
  have ha : 0<a := by dsimp [a]; positivity
  have ha1 : a<1 := by
    apply inv_lt_one_of_one_lt₀
    have hh := Real.sq_sqrt (by positivity : (0:ℝ) ≤ q)
    nlinarith [Real.sqrt_nonneg (q:ℝ)]
  have hpp : 0<(p:ℝ) := by linarith
  have hll : 0<(l:ℝ) := by exact_mod_cast hl
  have hlp : (l:ℝ)<p := by exact_mod_cast hlt
  have hr1 : -1<r := by dsimp [r]; linarith [div_pos (by positivity : 0<2*(l:ℝ)) hpp]
  have hr2 : r<1 := by
    have h := (div_lt_iff₀ hpp).mpr (by linarith : 2*(l:ℝ)<2*(p:ℝ))
    dsimp [r]; linarith
  have hr : r^2<1 := by nlinarith [mul_pos (sub_pos.mpr hr2) (sub_pos.mpr hr1)]
  have hk := packetConstants (μ:=1) ha ha1 hr zero_lt_one
  change 0<κ ∧ κ<1 ∧ _ at hk
  have invlt : (p:ℝ)⁻¹ < 1 := inv_lt_one_of_one_lt₀ hp1
  obtain ⟨k,hkpow⟩ := exists_pow_lt_of_lt_one (sub_pos.mpr hk.2.1) invlt
  have mpos : k≠0 := by
    intro eq
    subst k
    simp only [pow_zero] at hkpow
    linarith [hk.1]
  have hl1 : 1<p^k := one_lt_pow₀ hp.one_lt mpos
  let _ : NeZero p := ⟨hp.ne_zero⟩
  let _ : NeZero (p^k) := ⟨pow_ne_zero _ hp.ne_zero⟩
  refine ⟨hk.1,k,Nat.pos_of_ne_zero mpos,hl1,?_⟩
  intro j
  have gap : κ < 1-1/((p^k:ℕ):ℝ) := by
    push_cast
    rw [one_div,←inv_pow]
    linarith
  have hL : (1:ℝ) ≤ ((p^k:ℕ):ℝ) := by exact_mod_cast hl1.le
  exact packet_margin _ _ _ (by positivity) ((div_le_one (by positivity)).mpr hL) gap
    fresh_props.1 fresh_props.2 j

end KDClosure
