import KDChainLimitJointSector
import KDLCAPhaseNormalize
import KDLCARealityWindowCells
import KDReducedPartial
import KDReducedRankExact
import KDLCAUnitaryRank
import KDLCANoOpen
noncomputable section
namespace KDClosure.GeneralAbelian
open Set MeasureTheory Filter Topology CompactCore LCAReality LCAQuotient Phase CompactFourier
open scoped KDClosure.SubgroupMeasure
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
    [T2Space G] [LocallyCompactSpace G] [SecondCountableTopology G] [MeasurableSpace G] [BorelSpace G]
variable (μ : Measure G) [μ.IsAddHaarMeasure] (ν : Measure (LCAReality.Dual G)) [SFinite ν] [ν.IsHaarMeasure]

/-- The original, unrestricted physical rank bound for a chain of compact opens.
Both the position and the character of the occupied sector are derived from the state. -/
theorem ambient_chain_rank_le_one (F : FourierRealization μ ν) (chain : ∀ H K : CO G, H≤K ∨ K≤H)
    (T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ) (e : T∈(ambientStates μ ν F).extremePoints ℝ) :
    Module.rank ℂ (LinearMap.range T.toLinearMap) ≤ 1 := by
  by_cases h : Nonempty (CO G)
  · let _ : Nonempty (CO G) := h
    obtain ⟨u,ψ,support,mode⟩ := extreme_one_sector μ ν F T e
    let W : ManyOpen.Windows G := ManyOpen.windows.some
    let V := weyl μ u ψ
    let S := unitaryPush V.symm T
    have state : S ∈ (ambientStates μ ν F).extremePoints ℝ := unit_back_extreme μ ν u ψ F e
    apply (UnitaryRank.rank_le_one_iff V.symm T).mp
    change Module.rank ℂ (LinearMap.range S.toLinearMap) ≤ 1
    apply ReducedWindows.partial_rank_le_one μ ν F W chain state
    intro x
    let f := V x
    change Tendsto (fun n => (ReducedWindows.cellSpace μ (W.L n) (W.K n)).starProjection (V.symm (T f))) atTop (𝓝 (V.symm (T f)))
    apply physical_window_strong μ W _
    · filter_upwards [back_support μ (ActualCore.U G).toAddSubgroup u ψ (T f) (support f)] with y hy
      intro no
      exact hy (fun inside => no ((W.upper_iff y).mpr inside))
    · intro l hl
      exact back_fixed μ u l ψ (T f) (mode l ((W.lower_iff l).mp hl) f)
  · have bad := e.1
    rw [LCAReality.ambient_states_empty μ ν F h] at bad
    exact bad.elim

/-- Extremes are actual trace-one states, so the chain bound is sharp for every extreme. -/
theorem ambient_chain_rank_eq_one (F : FourierRealization μ ν) (chain : ∀ H K : CO G, H≤K ∨ K≤H)
    (T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ) (e : T∈(ambientStates μ ν F).extremePoints ℝ) :
    Module.rank ℂ (LinearMap.range T.toLinearMap) = 1 :=
  (ambient_chain_rank_le_one μ ν F chain T e).antisymm (ReducedWindows.state_one_le_rank μ ν F e.1)

end KDClosure.GeneralAbelian
