import KDFaceExclusion
import KDOperatorSupport

namespace KDClosure
open Set
open scoped InnerProductSpace

variable {D : Type*} [AddCommGroup D] {p q : ℕ}

/-- Finite displacement identities transport across an increasing exhaustive
tower of additive charts. The two tested locations occupy one common chart. -/
theorem chart_periodic_global [Fact p.Prime] [Fact q.Prime] (e : ∀ n : ℕ, Head p q n →+ D)
    (increasing : Monotone (fun n => range (e n)))
    (exhaust : ∀ x, ∃ n, x ∈ range (e n)) {A : D×D → ℂ}
    (per : ∀ n, Periodic (rowsOf (e n) A)) (x y : D) :
    A (x,y) = A (y,y+y-x) := by
  obtain ⟨i,hi⟩ := exhaust x
  obtain ⟨j,hj⟩ := exhaust y
  let n := max i j
  obtain ⟨⟨a,t⟩,rfl⟩ := increasing (show i≤n from le_max_left _ _) hi
  obtain ⟨⟨b,s⟩,rfl⟩ := increasing (show j≤n from le_max_right _ _) hj
  have hp := (per n a (b-a) t (s-t)).symm
  have h₁ : a+(b-a)=b := by abel
  have h₂ : t+(s-t)=s := by abel
  have h₃ : b+(b-a)=b+b-a := by abel
  have h₄ : s+(s-t)=s+s-t := by abel
  rw [show (e n (b,s) + e n (b,s) - e n (a,t)) =
      e n ((b,s)+(b,s)-(a,t)) by rw [map_sub,map_add]]
  simpa only [rowsOf,h₁,h₂,h₃,h₄,Prod.mk_add_mk,Prod.mk_sub_mk] using hp

/-- Once the array is realized as matrix entries of a positive operator, the
previous finite-rank localization theorem upgrades infinite column support to
infinite operator rank. The finite two-torsion, trace and period hypotheses are explicit. -/
theorem infinite_rank_of_realized_columnSupport
    {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℂ H] [CompleteSpace H]
    (T : H →L[ℂ] H) (pos : T.IsPositive) (b : D → H)
    {A : D×D → ℂ} (entries : ∀ x y, A (x,y) = inner ℂ (b x) (T (b y)))
    (traceFinite : Summable (fun x => (A (x,x)).re))
    (period : ∀ x y, A (x,y) = A (y,y+y-x))
    (two : {y : D | y+y=0}.Finite) (inf : (columnSupport A).Infinite) :
    ¬ FiniteDimensional ℂ (LinearMap.range T.toLinearMap) := by
  intro h
  let _ := h
  apply inf
  have ft := finite_operator_support T pos b (by simpa only [entries] using traceFinite)
    (fun x y => by simpa only [entries] using period x y) two
  apply ft.subset
  rintro y ⟨x,hx⟩ he
  apply hx
  simp [entries,he]

end KDClosure
