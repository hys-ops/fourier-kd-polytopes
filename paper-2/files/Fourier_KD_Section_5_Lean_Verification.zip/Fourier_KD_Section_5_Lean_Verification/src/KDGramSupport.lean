import Mathlib.Analysis.InnerProductSpace.Orthonormal
import Mathlib.Analysis.Normed.Module.FiniteDimension
import Mathlib.Topology.Sequences
import Mathlib.Tactic.Linarith

namespace KDClosure
open Filter Set
open scoped Topology InnerProductSpace
variable {D E : Type*} [AddCommGroup D] [NormedAddCommGroup E]
    [InnerProductSpace ℂ E] [FiniteDimensional ℂ E]

/-- The doubled occupied set of a finite-dimensional Gram kernel is finite.
The symmetry is equation (1) evaluated at (x,y); the summability is the trace. -/
theorem finite_double_support (v : D → E)
    (traceFinite : Summable (fun x => ‖v x‖^2))
    (period : ∀ x y, inner ℂ (v x) (v y) = inner ℂ (v y) (v (y+y-x))) :
    ((fun y => y+y) '' {y | v y ≠ 0}).Finite := by
  classical
  by_contra hfin
  let w := Set.Infinite.natEmbedding _ hfin
  have pre (n : ℕ) : ∃ y, v y ≠ 0 ∧ y+y = (w n).val := (w n).property
  choose y hy he using pre
  have inj : Function.Injective (fun n => y n+y n) := by
    intro n k a
    apply w.injective
    exact Subtype.ext ((he n).symm.trans (a.trans (he k)))
  let scale (n : ℕ) : ℂ := ((‖v (y n)‖ : ℝ) : ℂ)⁻¹
  let u (n : ℕ) : E := scale n • v (y n)
  have unitn (n : ℕ) : ‖u n‖ = 1 := by
    simp [u,scale,norm_smul, hy n]
  let _ : ProperSpace E := FiniteDimensional.proper ℂ E
  obtain ⟨L,hL,k,hk,hlim⟩ := (isCompact_sphere (0:E) 1).tendsto_subseq
    (x:=u) (fun n => by simpa [Metric.mem_sphere,dist_zero_right] using unitn n)
  have oneL : ‖L‖ = 1 := by simpa [Metric.mem_sphere] using hL
  have orth (x : D) : inner ℂ (v x) L = 0 := by
    have esc : Tendsto (fun n => y n+y n-x) atTop cofinite := by
      have ii : Function.Injective (fun n => y n+y n-x) :=
        fun i j a => inj (sub_left_inj.mp a)
      simpa [Nat.cofinite_eq_atTop] using ii.tendsto_cofinite
    have hs := traceFinite.tendsto_cofinite_zero.comp esc
    have hn : Tendsto (fun n => ‖v (y n+y n-x)‖) atTop (𝓝 0) := by
      simpa [Function.comp_def, Real.sqrt_sq (norm_nonneg _)] using
        (Real.continuous_sqrt.tendsto 0).comp hs
    have bound (n : ℕ) : ‖inner ℂ (v x) (u n)‖ ≤ ‖v (y n+y n-x)‖ := by
      rw [show inner ℂ (v x) (u n) = scale n * inner ℂ (v x) (v (y n)) from inner_smul_right ..,
        norm_mul,period]
      calc
        _ ≤ ‖scale n‖ * (‖v (y n)‖ * ‖v (y n+y n-x)‖) :=
          mul_le_mul_of_nonneg_left (norm_inner_le_norm _ _) (norm_nonneg _)
        _ = _ := by rw [← mul_assoc, ← norm_smul]; change ‖u n‖ * _ = _; rw [unitn,one_mul] 
    have hz : Tendsto (fun n => inner ℂ (v x) (u n)) atTop (𝓝 0) := by
      apply tendsto_zero_iff_norm_tendsto_zero.mpr
      exact squeeze_zero (fun _ => norm_nonneg _) bound hn
    have ht : Tendsto (fun n => inner ℂ (v x) (u (k n))) atTop (𝓝 (inner ℂ (v x) L)) :=
      tendsto_const_nhds.inner hlim
    exact tendsto_nhds_unique ht (hz.comp hk.tendsto_atTop)
  have hz (n : ℕ) : inner ℂ (u (k n)) L = 0 := by simp [u,inner_smul_left,orth]
  have hself : inner ℂ L L = 0 := by
    have ht : Tendsto (fun n => inner ℂ (u (k n)) L) atTop (𝓝 (inner ℂ L L)) :=
      hlim.inner tendsto_const_nhds
    simp_rw [hz] at ht
    exact tendsto_nhds_unique ht tendsto_const_nhds
  have : L = 0 := inner_self_eq_zero.mp hself
  simp [this] at oneL

/-- A finite doubling kernel suffices to recover ordinary finite support. -/
theorem finite_gram_support (v : D → E) (traceFinite : Summable (fun x => ‖v x‖^2))
    (period : ∀ x y, inner ℂ (v x) (v y) = inner ℂ (v y) (v (y+y-x)))
    (two : {y : D | y+y=0}.Finite) : {y | v y ≠ 0}.Finite := by
  classical
  let dbl : D → D := fun y => y+y
  let S := {y | v y ≠ 0}
  have hd : (dbl '' S).Finite := finite_double_support v traceFinite period
  have hf (z : D) (_ : z ∈ dbl '' S) : (dbl ⁻¹' {z}).Finite := by
    rcases Set.eq_empty_or_nonempty (dbl ⁻¹' {z}) with h | ⟨a,ha⟩
    · simp [h]
    · change a+a=z at ha
      apply (two.image (fun t => t+a)).subset
      intro y hy
      change y+y=z at hy
      refine ⟨y-a, ?_, sub_add_cancel _ _⟩
      change y-a+(y-a)=0
      calc
        _ = (y+y)-(a+a) := by abel
        _ = 0 := by rw [hy,ha,sub_self]
  exact (hd.preimage' hf).subset (Set.subset_preimage_image dbl S)

end KDClosure
