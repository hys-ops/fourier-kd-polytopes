import KDTwoTorsion
import KDLayerMap
import Mathlib.Analysis.SpecialFunctions.Complex.CircleAddChar

namespace KDClosure

/-- Insert the cyclic frequency label k as exp(2πik/N) in the specified group of roots. -/
noncomputable def rootHead {p N : ℕ} [NeZero N] (h : rootsOfUnity N ℂ ≤ pRoots p) :
    ZMod N →+ Additive (pRoots p) where
  toFun x := Additive.ofMul ⟨(rootsOfUnityCircleEquiv N (ZMod.rootsOfUnityAddChar N x)).val,
    h (rootsOfUnityCircleEquiv N (ZMod.rootsOfUnityAddChar N x)).property⟩
  map_zero' := by
    apply Additive.toMul.injective
    apply Subtype.ext
    change (rootsOfUnityCircleEquiv N (ZMod.rootsOfUnityAddChar N 0)).val = 1
    simp
  map_add' x y := by
    apply Additive.toMul.injective
    apply Subtype.ext
    change (rootsOfUnityCircleEquiv N (ZMod.rootsOfUnityAddChar N (x+y))).val = _
    simp [AddChar.map_add_eq_mul]

theorem rootHead_injective {p N : ℕ} [NeZero N] (h : rootsOfUnity N ℂ ≤ pRoots p) :
    Function.Injective (rootHead h) := by
  intro x y he
  apply (bijective_rootsOfUnityAddChar N).injective
  apply (rootsOfUnityCircleEquiv N).injective
  apply Subtype.ext
  exact congrArg (fun z : Additive (pRoots p) => z.toMul.val) he

theorem range_rootHead {p N : ℕ} [NeZero N] (h : rootsOfUnity N ℂ ≤ pRoots p)
    (x : Additive (pRoots p)) :
    x ∈ Set.range (rootHead h) ↔ x.toMul.val ∈ rootsOfUnity N ℂ := by
  constructor
  · rintro ⟨k,rfl⟩
    exact (rootsOfUnityCircleEquiv N (ZMod.rootsOfUnityAddChar N k)).property
  · intro hx
    obtain ⟨k,hk⟩ := surjective_rootsOfUnityCircleEquiv_comp_rootsOfUnityAddChar N ⟨x.toMul.val,hx⟩
    refine ⟨k, Additive.toMul.injective (Subtype.ext ?_)⟩
    exact congrArg (fun z : rootsOfUnity N ℂ => z.val) hk

theorem rootsMonotone (p : ℕ) : Monotone (fun n : ℕ => rootsOfUnity (p^n) ℂ) :=
  fun _ _ e => rootsOfUnity_le_of_dvd (pow_dvd_pow _ e)

theorem mem_pRoots_iff (p : ℕ) (u : ℂˣ) :
    u ∈ pRoots p ↔ ∃ n : ℕ, u ∈ rootsOfUnity (p^n) ℂ :=
  Subgroup.mem_iSup_of_directed (rootsMonotone p).directed_le

/-- Changing a denominator by a factor b and the numerator by the same
factor represents the identical element of the infinite group. -/
theorem compatible_rootHead {p N M b : ℕ} [NeZero N] [NeZero M]
    (hn : rootsOfUnity N ℂ ≤ pRoots p) (hm : rootsOfUnity M ℂ ≤ pRoots p)
    (hb : 0 < b) (hNM : M=N*b) (x : ZMod N) (y : ZMod M)
    (hxy : y.val=b*x.val) : rootHead hm y = rootHead hn x := by
  apply Additive.toMul.injective
  apply Subtype.ext
  apply Units.ext
  change ((rootsOfUnityCircleEquiv M (ZMod.rootsOfUnityAddChar M y)).val : ℂ) =
    ((rootsOfUnityCircleEquiv N (ZMod.rootsOfUnityAddChar N x)).val : ℂ)
  rw [rootsOfUnityCircleEquiv_comp_rootsOfUnityAddChar_val,
      rootsOfUnityCircleEquiv_comp_rootsOfUnityAddChar_val,hxy,hNM]
  congr 1
  push_cast
  have hb' : (b:ℂ) ≠ 0 := Nat.cast_ne_zero.mpr hb.ne'
  field_simp

variable (p : ℕ) [NeZero p]

omit [NeZero p] in
private theorem levelRoots (m j : ℕ) : rootsOfUnity (levelSize p (p^m) j) ℂ ≤ pRoots p := by
  rw [size_prime_power]
  exact le_iSup (fun n : ℕ => rootsOfUnity (p^n) ℂ) _

/-- The exact sparse cyclic head at n_j=1+j(m+1), viewed as an additive subgroup. -/
noncomputable def sparseRootHead (m j : ℕ) :
    ZMod (levelSize p (p^m) j) →+ Additive (pRoots p) := rootHead (levelRoots p m j)

theorem sparseRootHead_injective (m j : ℕ) : Function.Injective (sparseRootHead p m j) :=
  rootHead_injective _

/-- The zero/zero child of the weighted recursive array embeds as the old
position in the actual group; addition on digits is not componentwise. -/
theorem sparse_old_compatible (m j : ℕ) (x : Level p (p^m) j) :
    sparseRootHead p m (j+1) (encodeLevel p (p^m) (j+1) (0,0,x)) =
    sparseRootHead p m j (encodeLevel p (p^m) j x) := by
  apply compatible_rootHead _ _ (b:=p*(p^m)) (Nat.mul_pos (Nat.pos_of_ne_zero (NeZero.ne p)) (pow_pos (Nat.pos_of_ne_zero (NeZero.ne p)) _)) _ _ _ (old_head_image j x)
  change (levelSize p (p^m) j * p^m) * p = _
  ring

theorem sparseRootHead_mono (m : ℕ) : Monotone (fun j => Set.range (sparseRootHead p m j)) := by
  intro j k hjk x hx
  apply (range_rootHead (levelRoots p m k) x).mpr
  have ho := (range_rootHead (levelRoots p m j) x).mp hx
  rw [size_prime_power] at ho ⊢
  exact rootsMonotone p (Nat.add_le_add_left (Nat.mul_le_mul_right _ hjk) _) ho

/-- Every element occurs already in one of the sparse cyclic heads. -/
theorem sparseRootHead_exhausts (m : ℕ) (x : Additive (pRoots p)) :
    ∃ j, x ∈ Set.range (sparseRootHead p m j) := by
  obtain ⟨n,hn⟩ := (mem_pRoots_iff _ _).mp x.toMul.property
  refine ⟨n,(range_rootHead (levelRoots p m n) x).mpr ?_⟩
  rw [size_prime_power]
  apply rootsMonotone p (show n ≤ 1+n*(m+1) by
    calc n = n*1 := (Nat.mul_one n).symm
         _ ≤ n*(m+1) := Nat.mul_le_mul_left _ (Nat.succ_le_succ (Nat.zero_le _))
         _ ≤ 1+n*(m+1) := Nat.le_add_left _ _) hn

/-- The actual p-primary/finite-transverse embedding. -/
noncomputable def mixedRootHead (q m j : ℕ) :
    ZMod (levelSize p (p^m) j) × ZMod q →+ Additive (pRoots p) × ZMod q :=
  (sparseRootHead p m j).prodMap (AddMonoidHom.id _)

theorem mixedRootHead_injective (q m j : ℕ) : Function.Injective (mixedRootHead p q m j) := by
  intro x y h
  have h₁ := congrArg Prod.fst h
  have h₂ := congrArg Prod.snd h
  exact Prod.ext (sparseRootHead_injective p m j h₁) h₂

theorem mixedRootHead_mono (q m : ℕ) : Monotone (fun j => Set.range (mixedRootHead p q m j)) := by
  intro j k hj x hx
  obtain ⟨⟨a,b⟩,rfl⟩ := hx
  obtain ⟨a',ha'⟩ := sparseRootHead_mono p m hj (Set.mem_range_self a)
  exact ⟨(a',b),Prod.ext ha' rfl⟩

theorem mixedRootHead_exhausts (q m : ℕ) (x : Additive (pRoots p) × ZMod q) :
    ∃ j, x ∈ Set.range (mixedRootHead p q m j) := by
  obtain ⟨j,a,ha⟩ := sparseRootHead_exhausts p m x.1
  exact ⟨j,(a,x.2), Prod.ext ha rfl⟩

/-- A single common packet head supports any given finite set of group positions. -/
theorem finite_support_in_mixed_head (q m : ℕ) {s : Set (Additive (pRoots p) × ZMod q)}
    (hs : s.Finite) : ∃ j, s ⊆ Set.range (mixedRootHead p q m j) := by
  classical
  have step (f : Finset (Additive (pRoots p) × ZMod q)) :
      ∃ j, ∀ x ∈ f, x ∈ Set.range (mixedRootHead p q m j) := by
    induction f using Finset.induction_on with
    | empty => exact ⟨0,by simp⟩
    | insert a f _ ih =>
      obtain ⟨i,hi⟩ := mixedRootHead_exhausts p q m a
      obtain ⟨k,hk⟩ := ih
      refine ⟨max i k,fun x hx => ?_⟩
      rcases Finset.mem_insert.mp hx with rfl | h
      · exact mixedRootHead_mono p q m (le_max_left _ _) hi
      · exact mixedRootHead_mono p q m (le_max_right _ _) (hk _ h)
  obtain ⟨j,hj⟩ := step hs.toFinset
  exact ⟨j,fun x hx => hj x (hs.mem_toFinset.mpr hx)⟩

/-- Direct consequence for the group and finite-rank operator hypotheses of §4. -/
theorem finite_rank_one_mixed_head (q m : ℕ) [NeZero q]
    {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℂ H] [CompleteSpace H]
    (T : H →L[ℂ] H) [FiniteDimensional ℂ (LinearMap.range T.toLinearMap)] (pos : T.IsPositive)
    (e : Additive (pRoots p) × ZMod q → H)
    (traceFinite : Summable fun x => (inner ℂ (e x) (T (e x))).re)
    (period : ∀ x y, inner ℂ (e x) (T (e y)) = inner ℂ (e y) (T (e (y+y-x)))) :
    ∃ j, ∀ y, T (e y) ≠ 0 → y ∈ Set.range (mixedRootHead p q m j) :=
  finite_support_in_mixed_head p q m (mixed_operator_support p q T pos e traceFinite period)

/-- All cyclic heads used in the coordinate slice (not only packet heads). -/
noncomputable def cyclicMixedHead (q n : ℕ) :
    ZMod (p^(n+1)) × ZMod q →+ Additive (pRoots p) × ZMod q :=
  (rootHead (le_iSup (fun j : ℕ => rootsOfUnity (p^j) ℂ) (n+1))).prodMap (AddMonoidHom.id _)

theorem cyclicMixedHead_injective (q n : ℕ) : Function.Injective (cyclicMixedHead p q n) := by
  intro x y h
  have h₁ := congrArg Prod.fst h
  have h₂ := congrArg Prod.snd h
  exact Prod.ext (rootHead_injective (le_iSup (fun j : ℕ => rootsOfUnity (p^j) ℂ) (n+1)) h₁) h₂

/-- Every finite Fourier test frequency extends concretely to the discrete mixed group:
raise the root coordinate to the integer representative of -k and multiply by
the transverse character. The sign agrees with the negative DFT in the slice. -/
noncomputable def rootFrequency (a : ℕ) : AddChar (Additive (pRoots p)) ℂ where
  toFun x := (x.toMul.val : ℂ)^a
  map_zero_eq_one' := by change (1:ℂ)^a=1; simp
  map_add_eq_mul' x y := by
    change ((x.toMul.val : ℂ)*(y.toMul.val : ℂ))^a = _
    exact mul_pow _ _ _

omit [NeZero p] in
theorem rootFrequency_eval {N : ℕ} [NeZero N] (h : rootsOfUnity N ℂ ≤ pRoots p)
    (x k : ZMod N) :
    rootFrequency p (-k).val (rootHead h x) = ZMod.stdAddChar (-(x*k)) := by
  change (ZMod.stdAddChar x)^(-k).val = _
  rw [← AddChar.map_nsmul_eq_pow, nsmul_eq_mul, ZMod.natCast_zmod_val]
  congr 1
  ring

noncomputable def mixedFrequency (q a : ℕ) [NeZero q] (s : ZMod q) :
    AddChar (Additive (pRoots p) × ZMod q) ℂ where
  toFun z := rootFrequency p a z.1 * ZMod.stdAddChar (-(z.2*s))
  map_zero_eq_one' := by simp
  map_add_eq_mul' x y := by
    simp [add_mul, AddChar.map_add_eq_mul]
    ring

theorem cyclicMixedHead_frequency (q n : ℕ) [NeZero q] (k x : ZMod (p^(n+1)))
    (s t : ZMod q) :
    mixedFrequency p q (-k).val s (cyclicMixedHead p q n (x,t)) =
      ZMod.stdAddChar (-(x*k)) * ZMod.stdAddChar (-(t*s)) := by
  change rootFrequency p (-k).val (rootHead (le_iSup (fun j : ℕ => rootsOfUnity (p^j) ℂ) (n+1)) x) * ZMod.stdAddChar (-(t*s)) = _
  exact congrArg (fun z : ℂ => z * ZMod.stdAddChar (-(t*s))) (rootFrequency_eval p (le_iSup (fun j : ℕ => rootsOfUnity (p^j) ℂ) (n+1)) x k)

end KDClosure
