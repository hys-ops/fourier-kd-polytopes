import KDPeriodPort
import KDLocalFeasibility
import Mathlib.NumberTheory.LegendreSymbol.AddCharacter

namespace KDClosure
open Matrix Set KDFourier KDPure
open scoped ComplexOrder BigOperators

section Restrict
variable {G H I : Type*} [AddCommGroup G] [AddCommGroup H]
  [Fintype G] [Fintype H] [Fintype I] [DecidableEq G] [DecidableEq H]

omit [DecidableEq H] in
private theorem character_pairing (θ χ : AddChar H ℂ) :
    (∑ h, θ (-h) * χ h) = if χ=θ then (Fintype.card H:ℂ) else 0 := by
  classical
  have ev (h : H) : θ (-h)*χ h=(χ/θ) h := by rw [AddChar.div_apply]; ring
  simp_rw [ev]
  by_cases eq : χ=θ
  · simp [eq]
  · rw [if_neg eq,AddChar.sum_eq_zero_of_ne_one (div_ne_one.mpr eq)]

/-- Exact character-fiber formula for restricting a finite matrix to a
subgroup chart. The right side adds the full-head symbols whose characters
restrict to the tested small-head character, times the subgroup cardinality. -/
theorem compression_symbol (F : Frame G I) (f : H →+ G) (A : Matrix G G ℂ)
    (x : H) (χ : AddChar H ℂ) :
    (Fintype.card G:ℂ) * symbol (A.submatrix f f) x χ =
    ∑ i, (if χ = (F.char i).compAddMonoidHom f then
      (Fintype.card H:ℂ) * symbol A (f x) (F.char i) else 0) := by
  classical
  let row := KDAtoms.row A (f x)
  have rr (h : H) := reconstruct F row (f h)
  rw [←KDAtoms.row_amp]
  change (Fintype.card G:ℂ) * (∑ h, A (f x) (f (x+h)) * χ h) = _
  simp only [map_add]
  change (Fintype.card G:ℂ) * (∑ h, row (f h) * χ h) = _
  calc
    _ = ∑ h, ∑ i, amp row (F.char i) * ((F.char i) (-(f h)) * χ h) := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl; intro h _
      rw [←mul_assoc,←rr,Finset.sum_mul]
      apply Finset.sum_congr rfl; intro i _; ring
    _ = ∑ i, amp row (F.char i) * (∑ h, (F.char i) (-(f h)) * χ h) := by
      rw [Finset.sum_comm]; simp only [Finset.mul_sum]
    _ = _ := by
      apply Finset.sum_congr rfl; intro i _
      have eq := character_pairing ((F.char i).compAddMonoidHom f) χ
      simp only [AddChar.compAddMonoidHom_apply,map_neg] at eq
      rw [eq,KDAtoms.row_amp]
      split_ifs <;> ring

/-- Nonnegative real (in the complex order) KD entries remain so on every
subgroup corner; in particular this establishes reality on the smaller head. -/
theorem compression_nonneg (F : Frame G I) (f : H →+ G) (A : Matrix G G ℂ)
    (pos : ∀ x i, 0 ≤ symbol A x (F.char i)) (x : H) (χ : AddChar H ℂ) :
    0 ≤ symbol (A.submatrix f f) x χ := by
  classical
  have h := compression_symbol F f A x χ
  have s : 0 ≤ (Fintype.card G : ℂ)*symbol (A.submatrix f f) x χ := by
    rw [h]
    apply Finset.sum_nonneg; intro i _
    split_ifs
    · exact mul_nonneg (Nat.cast_nonneg _) (pos _ _)
    · exact le_rfl
  have hr : 0 < (Fintype.card G : ℝ) := Nat.cast_pos.mpr Fintype.card_pos
  obtain ⟨rs,isr⟩ := Complex.nonneg_iff.mp s
  have eq : (Fintype.card G : ℂ) = ((Fintype.card G : ℝ):ℂ) := by norm_cast
  rw [eq, Complex.re_ofReal_mul] at rs
  rw [eq, Complex.im_ofReal_mul] at isr
  exact Complex.nonneg_iff.mpr ⟨nonneg_of_mul_nonneg_right rs hr,
    (mul_eq_zero.mp isr.symm).resolve_left hr.ne' |>.symm⟩

/-- Vanishing is also inherited, provided that the large-row mask vanishes
on every extension of this small-row frequency. -/
theorem compression_zero (F : Frame G I) (f : H →+ G) (A : Matrix G G ℂ)
    (x : H) (χ : AddChar H ℂ)
    (zero : ∀ i, χ=(F.char i).compAddMonoidHom f → symbol A (f x) (F.char i)=0) :
    symbol (A.submatrix f f) x χ=0 := by
  classical
  apply (mul_eq_zero.mp _).resolve_left (Nat.cast_ne_zero.mpr Fintype.card_ne_zero : (Fintype.card G:ℂ) ≠ 0)
  rw [compression_symbol F f]
  apply Finset.sum_eq_zero
  intro i _
  split_ifs with h
  · rw [zero i h,mul_zero]
  · rfl

end Restrict

section NestedCyclic
variable {p q : ℕ} [Fact p.Prime] [Fact q.Prime]

omit [Fact p.Prime] in
private theorem ratio_size {n N : ℕ} (hle : n≤N) :
    p^(N+1)=p^(n+1)*p^(N-n) := by rw [←pow_add]; congr 1; omega

/-- The literal numerator of an old p-power root on a larger cyclic head. -/
def liftedNumerator {n N : ℕ} (x : ZMod (p^(n+1))) : ZMod (p^(N+1)) :=
  ((p^(N-n)*x.val : ℕ) : ZMod (p^(N+1)))

theorem liftedNumerator_val {n N : ℕ} (h : n≤N) (x : ZMod (p^(n+1))) :
    (liftedNumerator (N:=N) x).val=p^(N-n)*x.val := by
  apply ZMod.val_natCast_of_lt
  rw [ratio_size (p:=p) h,mul_comm (p^(n+1))]
  exact Nat.mul_lt_mul_of_pos_left x.val_lt (pow_pos (Fact.out : Nat.Prime p).pos _)

omit [Fact q.Prime] in
theorem lift_head_point {n N : ℕ} (h : n≤N) (x : ZMod (p^(n+1))) (t : ZMod q) :
    cyclicMixedHead p q N (liftedNumerator x,t) = cyclicMixedHead p q n (x,t) := by
  apply Prod.ext
  · exact compatible_rootHead (le_iSup (fun j : ℕ => rootsOfUnity (p^j) ℂ) (n+1))
      (le_iSup (fun j : ℕ => rootsOfUnity (p^j) ℂ) (N+1))
      (pow_pos (Fact.out : Nat.Prime p).pos _) (ratio_size h) _ _ (liftedNumerator_val h x)
  · rfl

def lift_head {n N : ℕ} (h : n≤N) : Head p q n →+ Head p q N where
  toFun i := (liftedNumerator i.1,i.2)
  map_zero' := by
    apply cyclicMixedHead_injective p q N
    exact (lift_head_point h 0 (0:ZMod q)).trans ((map_zero _).trans (map_zero _).symm)
  map_add' x y := by
    apply cyclicMixedHead_injective p q N
    rw [map_add, lift_head_point h, lift_head_point h,lift_head_point h]
    exact map_add _ x y

theorem lift_same_color {n N : ℕ} (h : n≤N) (l : ℕ) (x : ZMod (p^(n+1))) :
    color (p:=p) N l (liftedNumerator x) ↔ color n l x := by
  unfold color
  rw [liftedNumerator_val h]
  have ratio : p^N=p^(N-n)*p^n := by rw [←pow_add]; congr 1; omega
  rw [ratio,←mul_assoc,mul_comm l (p^(N-n)),mul_assoc]
  exact Nat.mul_lt_mul_left (pow_pos (Fact.out : Nat.Prime p).pos _)

private theorem lift_transverse_frequency {n N : ℕ} (h : n≤N)
    (k : Head p q n) (k' : Head p q N) (eq : frequency k=(frequency k').compAddMonoidHom (lift_head h)) :
    k.2=k'.2 := by
  have at1 := congrArg (fun φ : AddChar (Head p q n) ℂ => φ (0,1)) eq
  have zero : liftedNumerator (N:=N) (0 : ZMod (p^(n+1)))=0 := by
    apply ZMod.val_injective (p^(N+1)); simp [liftedNumerator_val h]
  simpa [frequency, lift_head,zero,ZMod.injective_stdAddChar.eq_iff] using at1

/-- Inherited positivity and the same position/transverse zero mask on all
earlier cyclic heads, for the actual zero-extension of one finite matrix. -/
theorem earlier_table_nonneg_mask {n N : ℕ} (h : n≤N) (l : ℕ)
    (C : Matrix (Head p q N) (Head p q N) ℂ)
    (A : (Additive (pRoots p) × ZMod q) × (Additive (pRoots p) × ZMod q) → ℂ)
    (rep : ∀ i j, A (cyclicMixedHead p q N i,cyclicMixedHead p q N j) = C i j)
    (pos : ∀ x t k v, 0 ≤ table (rowsOf (cyclicMixedHead p q N) A) x t k v)
    (zero : ∀ x t k v, Protected (color (p:=p) N l) x t v →
       table (rowsOf (cyclicMixedHead p q N) A) x t k v=0)
    (x : ZMod (p^(n+1))) (t : ZMod q) (k : ZMod (p^(n+1))) (v : ZMod q) :
    0 ≤ table (rowsOf (cyclicMixedHead p q n) A) x t k v ∧
    (Protected (color (p:=p) n l) x t v →
       table (rowsOf (cyclicMixedHead p q n) A) x t k v=0) := by
  let e := fun i => (cyclicMixedHead p q i : Head p q i → _)
  have big : physical (rowsOf (e N) A) = C := by rw [physical_rows (e:=e) N]; ext i j; exact rep i j
  have small : physical (rowsOf (e n) A) = C.submatrix (lift_head h) (lift_head h) := by
    rw [physical_rows (e:=e) n]
    ext i j
    change A (cyclicMixedHead p q n i,cyclicMixedHead p q n j) = C _ _
    exact ((congrArg₂ (fun i j => A (i,j)) (lift_head_point h i.1 i.2)
      (lift_head_point h j.1 j.2)).symm).trans (rep _ _)
  have formula (i j : Head p q N) : symbol C i (frequency j) =
      table (rowsOf (e N) A) i.1 i.2 j.1 j.2 := by
    rw [table_old_symbol,←big]; rfl
  let F : Frame (Head p q N) (Head p q N) := productDFTFrame
  have smallFormula : table (rowsOf (cyclicMixedHead p q n) A) x t k v =
      symbol (C.submatrix (lift_head h) (lift_head h)) (x,t) (frequency (k,v)) := by
    change table (rowsOf (e n) A) x t k v = _
    rw [table_old_symbol,small]
    rfl
  have posC (i j : Head p q N) : 0 ≤ symbol C i (F.char j) := by
    change 0 ≤ symbol C i (frequency j)
    rw [formula]
    exact pos .. 
  rw [smallFormula]
  constructor
  · exact compression_nonneg F (lift_head h) C posC (x,t) (frequency (k,v))
  · intro mask
    apply compression_zero F (lift_head h) C (x,t) (frequency (k,v))
    intro j eq
    have hv : v=j.2 := lift_transverse_frequency h (k,v) j eq
    change symbol C (liftedNumerator x,t) (frequency j)=0
    rw [formula]
    apply zero
    change Protected (color N l) (liftedNumerator x) t j.2
    simpa only [Protected,lift_same_color h,hv] using mask

end NestedCyclic
end KDClosure
