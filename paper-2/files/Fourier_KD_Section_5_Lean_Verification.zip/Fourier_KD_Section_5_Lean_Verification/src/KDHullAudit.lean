import KDHullTraceNorm
import KDHullIntrinsic
import KDTraceTightLimit
import KDHullNonchain
import KDTraceCompression
import KDPacketRays
import KDPacketExclusion
import KDPacketCompression
import KDClosedHullSeparation
import KDPhysicalCompression
import KDFinitePacketSign
#check KDClosure.Hull.compressed_packet
#print axioms KDClosure.Hull.compatible_character
#print axioms KDClosure.Hull.compressed_packet
#print axioms KDClosure.Hull.rays_closed
#print axioms KDClosure.Hull.trace_one_slice
#check KDClosure.Hull.obstruction_of_compression
#print axioms KDClosure.Hull.obstruction_of_compression

#check KDClosure.Hull.adjoint_packet_shape
#print axioms KDClosure.Hull.adjoint_packet_shape
#print axioms KDClosure.Hull.compression_rankOne
#print axioms KDClosure.Hull.finite_packet_positive

#check KDClosure.Hull.traceVariational_compress_dist
#print axioms KDClosure.Hull.traceVariational_compress_dist
#print axioms KDClosure.Hull.finitePackets_subset
#check KDClosure.Hull.ambient_packet_to_finite_ray
#print axioms KDClosure.Hull.ambient_packet_to_finite_ray
#check KDClosure.Hull.finite_witness_lift_excludes_packets
#print axioms KDClosure.Hull.finite_witness_lift_excludes_packets

#check KDClosure.Hull.FinitePort.full_finitePure_finite
#print axioms KDClosure.Hull.FinitePort.full_finitePure_finite
#check KDClosure.Hull.all_ambient_pure_ray
#print axioms KDClosure.Hull.all_ambient_pure_ray
#check KDClosure.Hull.no_compact_open_equality
#print axioms KDClosure.Hull.no_compact_open_equality
#check KDClosure.Hull.lift_physical
#print axioms KDClosure.Hull.lift_physical
#check KFS5KDBasis.paper_strict_converse
#print axioms KFS5KDBasis.paper_strict_converse
#check KDClosure.Hull.incomparable_counterexample
#print axioms KDClosure.Hull.incomparable_counterexample
#check KDClosure.Hull.hull_equality_implies_chain
#print axioms KDClosure.Hull.hull_equality_implies_chain

-- Fully concrete positive/negative directions + independent generic norm upgrade.
#check KDClosure.Hull.chain_state_wot_hull
#print axioms KDClosure.Hull.chain_state_wot_hull
#check KDClosure.Hull.closed_hull_ambientPure_subset
#print axioms KDClosure.Hull.closed_hull_ambientPure_subset
#check KDClosure.Hull.Tight.wot_tendsto_trace
#print axioms KDClosure.Hull.Tight.wot_tendsto_trace
#check KDClosure.Hull.pure_state_hull_iff_chain
#print axioms KDClosure.Hull.pure_state_hull_iff_chain
#check KDClosure.Hull.pure_generating_iff_all_compact_opens_comparable
#print axioms KDClosure.Hull.pure_generating_iff_all_compact_opens_comparable
#check KDClosure.Hull.incomparable_canonical_witness
#print axioms KDClosure.Hull.incomparable_canonical_witness

-- Conventional Schatten norm, without an assumed trace-norm identification.
#check KDClosure.Hull.traceVariational_compact_singular_sum
#print axioms KDClosure.Hull.traceVariational_compact_singular_sum
#check KDClosure.Hull.physical_trace_distance_is_trace_abs
#print axioms KDClosure.Hull.physical_trace_distance_is_trace_abs
#check KDClosure.Hull.physical_trace_distance_is_singular_sum
#print axioms KDClosure.Hull.physical_trace_distance_is_singular_sum
#check KDClosure.Hull.traceNormClosure_eq_variational_of_states
#print axioms KDClosure.Hull.traceNormClosure_eq_variational_of_states
#check KDClosure.Hull.pure_hull_classical_traceNorm_iff_chain
#print axioms KDClosure.Hull.pure_hull_classical_traceNorm_iff_chain
