import KDHullCriterion
import KDCompactFourierGeneral

/-! Group-level formulation. If a compact open subgroup is given, use its
actual (constructed) dual Haar measures and Fourier isometry. This prevents
the negative direction 'for every realization' from being vacuous. When the
family is empty the state space is physically empty for *every* realization. -/
noncomputable section
namespace KDClosure.Hull
open MeasureTheory Set CompactCore LCAReality LCAQuotient
open scoped KDClosure.SubgroupMeasure
variable (G : Type*) [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
  [T2Space G] [LocallyCompactSpace G] [SecondCountableTopology G] [MeasurableSpace G] [BorelSpace G]

def PureGenerating : Prop :=
  ∀ (μ : Measure G) [μ.IsAddHaarMeasure] (ν : Measure (LCAReality.Dual G)) [SFinite ν] [ν.IsHaarMeasure]
    (F : FourierRealization μ ν), ambientStates μ ν F = traceClosure (convexHull ℝ (ambientPure μ ν F))

theorem pure_generating_iff_all_compact_opens_comparable :
    PureGenerating G ↔ ∀ A B : CO G, A≤B ∨ B≤A := by
  constructor
  · intro allF A B
    let μ := CompactFourier.General.positionHaar A
    let ν := CompactFourier.General.frequencyHaar A
    let F := CompactFourier.General.realization A
    exact hull_equality_implies_chain μ ν F (allF μ ν F) A B
  · intro chain μ hμ ν hsn hν F
    exact chain_implies_hull_equality μ ν F chain

/-- With no external realization or finite operator witness supplied, an
incomparable pair produces a concrete counterexample on the actual group. -/
theorem incomparable_canonical_witness (A B : CO G) (ab : ¬ A ≤ B) (ba : ¬ B ≤ A) :
    let μ := CompactFourier.General.positionHaar A
    let ν := CompactFourier.General.frequencyHaar A
    let F := CompactFourier.General.realization A
    ∃ T ∈ ambientStates μ ν F, T ∉ traceClosure (convexHull ℝ (ambientPure μ ν F)) :=
  incomparable_counterexample _ _ (CompactFourier.General.realization A) A B ab ba
end KDClosure.Hull
#print axioms KDClosure.Hull.pure_generating_iff_all_compact_opens_comparable
#print axioms KDClosure.Hull.incomparable_canonical_witness
