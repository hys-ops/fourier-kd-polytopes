import KDChainWeakHull
import KDStateClosed

/-! The WOT approximation here uses the actual net of pure mixtures rather
than silently assuming first countability of an unbounded operator space. -/
noncomputable section
namespace KDClosure.Hull
open MeasureTheory Filter Set CompactCore LCAReality LCAQuotient ChainLimit.Kernel
open scoped Topology KDClosure.SubgroupMeasure
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
  [T2Space G] [LocallyCompactSpace G] [SecondCountableTopology G] [MeasurableSpace G] [BorelSpace G]
variable (μ : Measure G) [μ.IsAddHaarMeasure] (ν : Measure (LCAReality.Dual G)) [SFinite ν] [ν.IsHaarMeasure]
variable (F : FourierRealization μ ν)

abbrev pureMixtures := convexHull ℝ (ambientPure μ ν F)

set_option linter.unusedSectionVars false in
theorem pure_mixture_state (U : pureMixtures μ ν F) : U.val ∈ ambientStates μ ν F :=
  (convexHull_min (fun _ h => h.1) (ambientStates_convex μ ν F)) U.property

def mixtureFilter (T : H μ →L[ℂ] H μ) : Filter (pureMixtures μ ν F) :=
  comap (fun U : pureMixtures μ ν F => coord μ U.val) (𝓝 (coord μ T))

theorem mixtureFilter_neBot (chain : ∀ A B : CO G, A≤B ∨ B≤A)
    {T : H μ →L[ℂ] H μ} (st : T∈ambientStates μ ν F) :
    NeBot (mixtureFilter μ ν F T) := by
  have near := chain_state_wot_hull μ ν F chain st
  rw [←(coord μ).image_convexHull] at near
  apply comap_neBot_iff.mpr
  intro t ht
  obtain ⟨z,zt,U,hu,rfl⟩ := mem_closure_iff_nhds.mp near t ht
  exact ⟨⟨U,hu⟩,zt⟩

set_option linter.unusedSectionVars false in
theorem mixtureFilter_wot (T : H μ →L[ℂ] H μ) (x y : H μ) :
    Tendsto (fun U : pureMixtures μ ν F => inner ℂ x (U.val y))
      (mixtureFilter μ ν F T) (𝓝 (inner ℂ x (T y))) := by
  have f : Tendsto (fun U : pureMixtures μ ν F => coord μ U.val) (mixtureFilter μ ν F T) (𝓝 (coord μ T)) :=
    tendsto_comap
  exact tendsto_pi_nhds.mp f (x,y)
end KDClosure.Hull
