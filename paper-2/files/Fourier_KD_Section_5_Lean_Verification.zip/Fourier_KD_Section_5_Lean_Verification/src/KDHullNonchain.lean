import KDFiniteStateLift
import KFKDBasis

/-! Construct a *physical* counterexample in the full ambient space for
every incomparable pair, with no finite witness or pure-state description
postulated. The quotient-incomparability proof is adapted from
FiniteSection/KDBranchSection (Paper 2, unchanged argument). -/
noncomputable section
set_option linter.unusedSectionVars false
namespace KDClosure.Hull
open Set MeasureTheory Matrix CompactCore LCAReality LCAQuotient ChainLimit
open scoped KDClosure.SubgroupMeasure ComplexOrder
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
local instance (L K : CO G) : Fintype (CoreQuot L K) := @Fintype.ofFinite _ (finite_core L K)

theorem nonexceptional (A B : CO G) (ab : ¬ A ≤ B) (ba : ¬ B ≤ A) :
    ¬ KFS5KDGroup.exceptional (CoreQuot (meet A B) (join A B)) := by
  classical
  let L := meet A B
  let K := join A B
  let N := (subgroup L).addSubgroupOf (subgroup K)
  let X : {S : AddSubgroup (subgroup K) // N ≤ S} :=
      ⟨(subgroup A).addSubgroupOf (subgroup K), fun _ hx => hx.1⟩
  let Y : {S : AddSubgroup (subgroup K) // N ≤ S} :=
      ⟨(subgroup B).addSubgroupOf (subgroup K), fun _ hx => hx.2⟩
  let e := QuotientAddGroup.comapMk'OrderIso N
  intro exc
  rcases KFS5KDClassification.chain_of_exceptional _ exc (e.symm X) (e.symm Y) with h | h
  · have sm : X ≤ Y := e.symm.le_iff_le.mp h
    apply ab
    intro x hx
    have hxK : x ∈ subgroup K := (show A.val ≤ A.val ⊔ B.val from le_sup_left) hx
    exact sm (show (⟨x,hxK⟩ : subgroup K) ∈ X.1 from hx)
  · have sm : Y ≤ X := e.symm.le_iff_le.mp h
    apply ba
    intro x hx
    have hxK : x ∈ subgroup K := (show B.val ≤ A.val ⊔ B.val from le_sup_right) hx
    exact sm (show (⟨x,hxK⟩ : subgroup K) ∈ Y.1 from hx)


variable [T2Space G] [LocallyCompactSpace G] [SecondCountableTopology G] [MeasurableSpace G] [BorelSpace G]
variable (μ : Measure G) [μ.IsAddHaarMeasure] (ν : Measure (LCAReality.Dual G)) [SFinite ν] [ν.IsHaarMeasure]
variable (F : FourierRealization μ ν)

/-- A counterexample is an actual normalized physical ambient operator,
not merely a formally decoded finite symbol or a mixed extreme point. -/
theorem incomparable_counterexample (A B : CO G) (ab : ¬ A ≤ B) (ba : ¬ B ≤ A) :
    ∃ T ∈ ambientStates μ ν F, T ∉ traceClosure (convexHull ℝ (ambientPure μ ν F)) := by
  classical
  let L := meet A B
  let K := join A B
  let D := CoreQuot L K
  have le : L≤K := (show A.val ⊓ B.val ≤ A.val ⊔ B.val from inf_le_left.trans le_sup_left)
  obtain ⟨C,hd,ht,hk,outside⟩ := KFS5KDBasis.paper_strict_converse (nonexceptional A B ab ba)
  have pos : ∀ (x : D) (γ : AddChar D ℂ), 0 ≤ KDFourier.symbol C x γ := fun x γ =>
    (KFS5KDBasis.same_positivity C x γ).mp (le_of_lt (hk x γ))
  have contains : finitePure D ⊆ {M : KFS5KDOperator.Op D | M∈KFS5KDBasis.paperStates D ∧ M.rank=1} := by
    rintro M ⟨ps,t,r,k⟩
    exact ⟨⟨ps,t,fun x γ => (KFS5KDBasis.same_positivity M x γ).mpr (k x γ)⟩,r⟩
  have hout : C ∉ convexHull ℝ (finitePure D) := fun h => outside ((convexHull_mono contains) h)
  obtain ⟨T,st,block⟩ := lift_physical μ ν F L K C hd.posSemidef ht pos
  exact ⟨T,st,finite_witness_excludes_ALL_ambient_pure_of_tests μ ν F L K le 0 1 T C block ht hout⟩

/-- The necessity implication of Section 5, with no external classification
hypothesis: equality in trace norm forces all compact opens to be comparable. -/
theorem hull_equality_implies_chain
    (eqn : ambientStates μ ν F = traceClosure (convexHull ℝ (ambientPure μ ν F))) :
    ∀ A B : CO G, A≤B ∨ B≤A := by
  intro A B
  by_contra! h
  obtain ⟨T,st,out⟩ := incomparable_counterexample μ ν F A B h.1 h.2
  exact out (eqn ▸ st)
end KDClosure.Hull
#print axioms KDClosure.Hull.incomparable_counterexample
#print axioms KDClosure.Hull.hull_equality_implies_chain
