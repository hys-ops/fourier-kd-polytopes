import KDHullIntrinsic
import KDPhysicalTraceNorm

/-! The criterion in literal Schatten-1 terminology, independent of the
variational formula used by the proof.  An approximating difference has
finite Schatten-1 norm iff compact with finite positive trace of |D|.
The distance used here is precisely Tr(sqrt(D† D)), not half of it. -/
noncomputable section
namespace KDClosure.Hull
open MeasureTheory Set CompactCore LCAReality LCAQuotient
open scoped ENNReal KDClosure.SubgroupMeasure
variable {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℂ H] [CompleteSpace H]

def traceNormClosure (S : Set (H →L[ℂ] H)) : Set (H →L[ℂ] H) :=
  {T | ∀ ε : ℝ, 0<ε → ∃ A∈S, IsCompactOperator (A-T) ∧
    ∃ t : ℝ, IsLUB (Tight.Mass (traceAbs (A-T))) t ∧ t<ε}

variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
  [T2Space G] [LocallyCompactSpace G] [SecondCountableTopology G] [MeasurableSpace G] [BorelSpace G]
variable (μ : Measure G) [μ.IsAddHaarMeasure] (ν : Measure (LCAReality.Dual G)) [SFinite ν]
variable (F : FourierRealization μ ν)

set_option linter.unusedSectionVars false in
theorem traceNormClosure_eq_variational_of_states {S : Set (Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ)}
    (phys : S⊆ambientStates μ ν F) : traceNormClosure S=traceClosure S := by
  ext T
  constructor
  · intro h ε pos
    obtain ⟨A,ha,cp,t,ht,hlt⟩ := h ε pos
    refine ⟨A,ha,?_⟩
    rw [traceVariational_eq_traceVariational_abs_of_compact _ cp,
      traceVariational_eq_intrinsic_positive_trace (traceAbs_pos _) ht]
    exact (ENNReal.ofReal_lt_ofReal_iff pos).mpr hlt
  · intro near ε pos
    obtain ⟨A,ha,small⟩ := near ε pos
    have st := traceClosure_subset_ambientStates μ ν F phys near
    have hA := phys ha
    obtain ⟨t,ht,eqn⟩ := physical_trace_distance_is_trace_abs μ ν F hA st
    have compact := (state_difference_compact_symmetric A T hA.1 st.1 hA.2.1 st.2.1).1
    exact ⟨A,ha,compact,t,ht,(ENNReal.ofReal_lt_ofReal_iff pos).mp (eqn ▸ small)⟩

variable [ν.IsHaarMeasure]
/-- The manuscript equality in the usual trace norm, without a variational
closure or any norm-equivalence hypothesis in the statement. -/
theorem pure_hull_classical_traceNorm_iff_chain :
    ambientStates μ ν F = traceNormClosure (convexHull ℝ (ambientPure μ ν F)) ↔
    ∀ A B : CO G, A≤B ∨ B≤A := by
  have ps : convexHull ℝ (ambientPure μ ν F) ⊆ ambientStates μ ν F :=
    convexHull_min (fun _ h => h.1) (ambientStates_convex μ ν F)
  rw [traceNormClosure_eq_variational_of_states μ ν F ps]
  exact pure_state_hull_iff_chain μ ν F
end KDClosure.Hull
#print axioms KDClosure.Hull.pure_hull_classical_traceNorm_iff_chain
