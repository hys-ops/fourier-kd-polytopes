import KDSubgroupMeasure
import Mathlib.Algebra.Group.Subgroup.Ker

/-! An arbitrary embedding of discrete abelian groups transports normalized
dual Haar. The concrete source is retained, even if it is not literally a
subgroup subtype of the ambient group. -/
noncomputable section
namespace KDClosure.SubgroupMeasure
open MeasureTheory Set
open scoped Topology ComplexOrder

variable {D G : Type*} [CommGroup D] [TopologicalSpace D] [DiscreteTopology D]
    [CommGroup G] [TopologicalSpace G] [DiscreteTopology G]

/-- Pull characters back through the specified map, preserving its source
group and therefore its source coordinate and character conventions. -/
def along (e : D →* G) : PontryaginDual G →ₜ* PontryaginDual D :=
  PontryaginDual.map (⟨e,continuous_of_discreteTopology⟩ : D →ₜ* G)

omit [DiscreteTopology G] in
@[simp] theorem along_apply (e : D →* G) (χ : PontryaginDual G) (x : D) :
    along e χ x = χ (e x) := rfl

theorem along_onto (e : D →* G) (inj : Function.Injective e) :
    Function.Surjective (along e) := by
  intro φ
  let E : D ≃* e.range := MonoidHom.ofInjective inj
  let r : PontryaginDual e.range :=
    ⟨φ.toMonoidHom.comp E.symm.toMonoidHom,continuous_of_discreteTopology⟩
  obtain ⟨χ,hχ⟩ := restriction_onto e.range r
  refine ⟨χ, PontryaginDual.ext fun x => ?_⟩
  have h := DFunLike.congr_fun hχ (E x)
  change χ (e x) = φ (E.symm (E x)) at h
  change χ (e x) = φ x
  simpa only [E.symm_apply_apply] using h

theorem along_measurePreserving (e : D →* G) (inj : Function.Injective e) :
    MeasurePreserving (along e) (dualHaar G) (dualHaar D) :=
  MonoidHom.measurePreserving (f := (along e).toMonoidHom) (along e).continuous (along_onto e inj)
    (by simp)

theorem along_ae_iff (e : D →* G) (inj : Function.Injective e) {P : PontryaginDual D → Prop}
    (hp : NullMeasurableSet {χ | P χ} (dualHaar D)) :
    (∀ᵐ χ ∂dualHaar G, P (along e χ)) ↔ ∀ᵐ φ ∂dualHaar D, P φ :=
  ae_reflection (along_measurePreserving e inj) hp

def alongL2 (e : D →* G) (inj : Function.Injective e) :
    Lp ℂ 2 (dualHaar D) →ₗᵢ[ℂ] Lp ℂ 2 (dualHaar G) :=
  Lp.compMeasurePreservingₗᵢ ℂ (along e) (along_measurePreserving e inj)

theorem alongL2_ae (e : D →* G) (inj : Function.Injective e) (f : Lp ℂ 2 (dualHaar D)) :
    ⇑(alongL2 e inj f) =ᵐ[dualHaar G] (f ∘ along e) :=
  Lp.coeFn_compMeasurePreserving f (along_measurePreserving e inj)

/-- Transport preserves and reflects reality and nonnegativity of L² rows. -/
theorem alongL2_nonneg_iff (e : D →* G) (inj : Function.Injective e) (f : Lp ℂ 2 (dualHaar D)) :
    (∀ᵐ χ ∂dualHaar G, 0 ≤ alongL2 e inj f χ) ↔ ∀ᵐ φ ∂dualHaar D, 0 ≤ f φ := by
  have hset : MeasurableSet {z : ℂ | 0 ≤ z} := by
    simp only [Complex.nonneg_iff,Set.ofPred_and]
    exact (measurableSet_le measurable_const Complex.continuous_re.measurable).inter
      (measurableSet_eq_fun measurable_const Complex.continuous_im.measurable)
  have hp : NullMeasurableSet {φ | 0 ≤ f φ} (dualHaar D) :=
    ((Lp.stronglyMeasurable f).measurable hset).nullMeasurableSet
  rw [← along_ae_iff e inj hp]
  apply Filter.eventually_congr
  filter_upwards [alongL2_ae e inj f] with χ hχ
  rw [hχ]
  rfl

end KDClosure.SubgroupMeasure
