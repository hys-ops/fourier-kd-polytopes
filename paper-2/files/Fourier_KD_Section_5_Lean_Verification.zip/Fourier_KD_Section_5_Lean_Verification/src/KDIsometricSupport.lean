import Mathlib.Analysis.InnerProductSpace.StarOrder
import Mathlib.Analysis.SpecialFunctions.ContinuousFunctionalCalculus.Rpow.Basic
import Mathlib.Analysis.Convex.Extreme

noncomputable section
namespace KDClosure.IsometricSupport
open ContinuousLinearMap Set
open scoped InnerProductSpace ComplexOrder
variable {H K : Type*} [NormedAddCommGroup H] [InnerProductSpace ℂ H] [CompleteSpace H]
  [NormedAddCommGroup K] [InnerProductSpace ℂ K] [CompleteSpace K]

def lift (J : H →L[ℂ] K) (A : H →L[ℂ] H) : K →L[ℂ] K := J ∘L A ∘L J.adjoint
def compress (J : H →L[ℂ] K) (B : K →L[ℂ] K) : H →L[ℂ] H := J.adjoint ∘L B ∘L J

private theorem adjoint_left (J : H →L[ℂ] K) (iso : Isometry J) (x : H) :
    J.adjoint (J x) = x :=
  DFunLike.congr_fun ((isometry_iff_adjoint_comp_self J).mp iso) x

theorem compress_lift (J : H →L[ℂ] K) (iso : Isometry J) (A : H →L[ℂ] H) :
    compress J (lift J A) = A := by
  ext x; change J.adjoint (J (A (J.adjoint (J x))))=A x
  rw [adjoint_left J iso,adjoint_left J iso]

private theorem null_of_energy {U : K →L[ℂ] K} (pos : U.IsPositive) (x : K)
    (hx : (inner ℂ x (U x)).re=0) : U x=0 := by
  obtain ⟨S,hS⟩ := CStarAlgebra.nonneg_iff_eq_star_mul_self.mp ((nonneg_iff_isPositive U).mpr pos)
  have fact (y) : U y=S.adjoint (S y) := by rw [hS]; rfl
  rw [fact,S.adjoint_inner_right] at hx
  have sq : ‖S x‖^2=0 := (norm_sq_eq_re_inner (𝕜:=ℂ) (S x)).trans hx
  have hs : S x=0 := norm_eq_zero.mp (by nlinarith [norm_nonneg (S x)])
  rw [fact,hs,map_zero]

/-- Annihilation on the orthogonal complement, expressed as ker J*, is
equivalent for a positive operator to having no rows or columns off J(H).
This implication yields the actual reconstructed embedded operator. -/
theorem lift_compress_of_kills (J : H →L[ℂ] K) (iso : Isometry J)
    (U : K →L[ℂ] K) (pos : U.IsPositive) (kills : ∀ x, J.adjoint x=0 → U x=0) :
    lift J (compress J U)=U := by
  let P := J ∘L J.adjoint
  have right : U ∘L P=U := by
    ext x
    have h := kills (x-P x) (by change J.adjoint (x-J (J.adjoint x))=0; rw [map_sub,adjoint_left J iso,sub_self])
    change U (P x)=U x
    exact (sub_eq_zero.mp (by rwa [map_sub] at h)).symm
  have sa : U.adjoint=U := pos.isSelfAdjoint.star_eq
  have sp : P.adjoint=P := by simp [P,adjoint_comp]
  have left : P ∘L U=U := by
    have eq := congrArg ContinuousLinearMap.adjoint right
    rwa [adjoint_comp,sa,sp] at eq
  ext x
  change P (U (P x))=U x
  rw [show U (P x)=U x from DFunLike.congr_fun right x]
  exact DFunLike.congr_fun left x

/-- Positive summands of an operator supported on J(H) are supported on the
same subspace. This holds at every strictly positive pair of real weights,
including a=b=1, with no normalization or KD hypotheses. -/
theorem positive_summands_supported (J : H →L[ℂ] K) (iso : Isometry J)
    (A : H →L[ℂ] H) (U V : K →L[ℂ] K) (pu : U.IsPositive) (pv : V.IsPositive)
    (a b : ℝ) (ha : 0<a) (hb : 0<b) (sum : a • U + b • V=lift J A) :
    lift J (compress J U)=U ∧ lift J (compress J V)=V := by
  have both (x : K) (outside : J.adjoint x=0) : U x=0 ∧ V x=0 := by
    have hs := DFunLike.congr_fun sum x
    change a • U x+b • V x=J (A (J.adjoint x)) at hs
    rw [outside,map_zero,map_zero] at hs
    have h := congrArg (fun z : K => (inner ℂ x z).re) hs
    have ofr (t : ℝ) (z : K) : t • z = (t:ℂ) • z := (algebraMap_smul ℂ t z).symm
    simp only [ofr,inner_add_right,inner_smul_right,Complex.add_re,Complex.re_ofReal_mul,
      inner_zero_right,Complex.zero_re] at h
    have hu : 0≤(inner ℂ x (U x)).re := pu.re_inner_nonneg_right x
    have hv : 0≤(inner ℂ x (V x)).re := pv.re_inner_nonneg_right x
    exact ⟨null_of_energy pu x (by nlinarith [mul_nonneg hb.le hv]),
      null_of_energy pv x (by nlinarith [mul_nonneg ha.le hu])⟩
  exact ⟨lift_compress_of_kills J iso U pu (fun x h => (both x h).1),
    lift_compress_of_kills J iso V pv (fun x h => (both x h).2)⟩

/-- Transfer from an exact section of a positive state set. The only
application-specific input is the membership equivalence for embedded
operators (e.g. the Fourier/KD and normalization test on a subgroup). -/
theorem extreme_lift (J : H →L[ℂ] K) (iso : Isometry J)
    (small : Set (H →L[ℂ] H)) (large : Set (K →L[ℂ] K))
    (positive : ∀ U∈large, U.IsPositive)
    (section_eq : ∀ A, A ∈ small ↔ lift J A ∈ large)
    {A : H →L[ℂ] H} (extA : A ∈ small.extremePoints ℝ) :
    lift J A ∈ large.extremePoints ℝ := by
  refine ⟨(section_eq A).mp extA.1,?_⟩
  intro U hU V hV seg
  obtain ⟨a,b,ha,hb,hs,blend⟩ := seg
  obtain ⟨rU,rV⟩ := positive_summands_supported J iso A U V (positive U hU) (positive V hV) a b ha hb blend
  have subU : compress J U ∈ small := (section_eq _).mpr (rU.symm ▸ hU)
  have subV : compress J V ∈ small := (section_eq _).mpr (rV.symm ▸ hV)
  have cblend : a • compress J U+b • compress J V = A := by
    rw [←compress_lift J iso A,←blend]
    ext x
    change a • J.adjoint (U (J x))+b • J.adjoint (V (J x))=J.adjoint (a • U (J x)+b • V (J x))
    rw [map_add,J.adjoint.map_smul_of_tower a,J.adjoint.map_smul_of_tower b]
  have eq := extA.2 subU subV ⟨a,b,ha,hb,hs,cblend⟩
  calc
    U = lift J (compress J U) := rU.symm
    _ = lift J A := congrArg (lift J) eq

/-- The isometry induces an actual linear equivalence of the two (algebraic)
operator ranges, so both finite and infinite rank survive the support lift. -/
def rangeEquiv (J : H →L[ℂ] K) (iso : Isometry J) (A : H →L[ℂ] H) :
    LinearMap.range A.toLinearMap ≃ₗ[ℂ] LinearMap.range (lift J A).toLinearMap :=
  LinearEquiv.ofBijective
    { toFun := fun x => ⟨J x.val,by
        obtain ⟨y,hy⟩ := x.property
        exact ⟨J y,by change J (A (J.adjoint (J y)))=J x.val; rw [adjoint_left J iso]; exact congrArg J hy⟩⟩
      map_add' := fun x y => Subtype.ext (map_add J x.val y.val)
      map_smul' := fun c x => Subtype.ext (map_smul J c x.val) }
    ⟨fun _ _ h => Subtype.ext (iso.injective (congrArg Subtype.val h)),fun x => by
      obtain ⟨z,hz⟩ := x.property
      exact ⟨⟨A (J.adjoint z),_,rfl⟩,Subtype.ext hz⟩⟩

end KDClosure.IsometricSupport
