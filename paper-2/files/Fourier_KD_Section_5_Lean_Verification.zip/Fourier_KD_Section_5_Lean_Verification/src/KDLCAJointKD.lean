import KDLCAJointLinear
import KDCofinalCorners
noncomputable section
namespace KDClosure.Joint
open MeasureTheory Set Filter Topology LCAQuotient LCAReality
open scoped ComplexOrder KDClosure.SubgroupMeasure ENNReal
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
    [MeasurableSpace G] [BorelSpace G] [SecondCountableTopology G]
variable (μ : Measure G) [SFinite μ] [μ.IsAddLeftInvariant] (ν : Measure (Dual G)) [SFinite ν]
local instance : Fact ((2:ℝ≥0∞)≠∞) := ⟨by norm_num⟩
def sheared : Space (μ.prod μ) →ₗᵢ[ℂ] Space (μ.prod μ) :=
  Lp.compMeasurePreservingₗᵢ ℂ _ (measurePreserving_prod_add μ μ)
def KDTransform (F : FourierRealization μ ν) : Space (μ.prod μ) →ₗᵢ[ℂ] Space (μ.prod ν) :=
  (partialIsometry μ μ ν F.isometry).comp (sheared μ)
theorem KD_rows (F : FourierRealization μ ν) (k : Space (μ.prod μ)) :
    ∀ᵐ x ∂μ, (fun χ => KDTransform μ ν F k (x,χ)) =ᵐ[ν] (F.isometry (rowAt μ k x) : Dual G → ℂ) := by
  have sh : ∀ᵐ x ∂μ, ∀ᵐ y ∂μ, sheared μ k (x,y)=k (x,x+y) :=
    Measure.ae_ae_of_ae_prod (Lp.coeFn_compMeasurePreserving k (measurePreserving_prod_add μ μ))
  filter_upwards [partial_rows μ μ ν F.isometry (sheared μ k), rowAt_ae μ k,
    section_rows μ μ (sheared μ k),sh] with x q r a s
  exact (Lp.ext ((a.trans s).trans r.symm)) ▸ q

theorem kd_iff_sign (F : FourierRealization μ ν) (k : Space (μ.prod μ)) :
    ambientKD μ ν F k ↔ ∀ᵐ z ∂μ.prod ν, 0 ≤ KDTransform μ ν F k z := by
  constructor
  · rintro ⟨q,qm,eqn,pos⟩
    have global : q =ᵐ[μ.prod ν] (KDTransform μ ν F k : _ → ℂ) :=
      (Measure.ae_prod_iff_ae_ae (measurableSet_eq_fun qm (Lp.stronglyMeasurable _).measurable)).mpr
        (by filter_upwards [eqn,KD_rows μ ν F k] with x h g using h.trans g.symm)
    exact pos.congr (global.mono fun _ e => by rw [e])
  · intro h; exact ⟨_,(Lp.stronglyMeasurable _).measurable,KD_rows μ ν F k,h⟩

theorem kd_closed (F : FourierRealization μ ν) : IsClosed {k | ambientKD μ ν F k} := by
  apply IsSeqClosed.isClosed
  intro f g hs h
  exact (kd_iff_sign μ ν F g).mpr (PhysicalCorner.ae_nonneg_limit ((KDTransform μ ν F).continuous.continuousAt.tendsto.comp h)
    (Eventually.of_forall fun n => (kd_iff_sign μ ν F _).mp (hs n)))

theorem kd_convex (F : FourierRealization μ ν) : Convex ℝ {k | ambientKD μ ν F k} := by
  intro k hk l hl a b ha hb _
  apply (kd_iff_sign μ ν F _).mpr
  let P := (KDTransform μ ν F).restrictScalars ℝ
  change ∀ᵐ z ∂μ.prod ν, 0 ≤ P (a • k + b • l) z
  rw [map_add,map_smul,map_smul]
  filter_upwards [(kd_iff_sign μ ν F k).mp hk,(kd_iff_sign μ ν F l).mp hl,
    Lp.coeFn_add (a • P k) (b • P l), Lp.coeFn_smul a (P k),Lp.coeFn_smul b (P l)] with z p q h x y
  rw [h]; change 0≤ (a • P k) z + (b • P l) z
  rw [x,y]; exact add_nonneg (by exact mul_nonneg (Complex.zero_le_real.mpr ha) p) (by exact mul_nonneg (Complex.zero_le_real.mpr hb) q)
end KDClosure.Joint
