import KDLCAJointTransform
noncomputable section
namespace KDClosure.Joint
open Set MeasureTheory Topology Filter TopologicalSpace
open scoped ComplexOrder ENNReal
variable {X Y Z : Type*} [MeasurableSpace X] [MeasurableSpace Y] [MeasurableSpace Z]
variable (μ : Measure X) (η : Measure Y) (ν : Measure Z) [SFinite μ] [SFinite η] [SFinite ν]
variable [SeparableSpace (Space η)] (U : Space η →ₗᵢ[ℂ] Space ν)
omit [SeparableSpace (Space η)] in
theorem section_rows (k : Space (μ.prod η)) : ∀ᵐ x ∂μ,
    (sectionOf (η:=η) (fun z => k z) x : Y→ℂ) =ᵐ[η] fun y => k (x,y) := by
  filter_upwards [section_mem μ η k] with x h
  rw [sectionOf,dif_pos h]
  exact h.coeFn_toLp

omit [SeparableSpace (Space η)] in
private theorem add_sections (k l : Space (μ.prod η)) :
    ∀ᵐ x ∂μ, sectionOf (η:=η) (fun z => (k+l) z) x = sectionOf (fun z => k z) x + sectionOf (fun z => l z) x := by
  have eqn : ∀ᵐ x ∂μ, ∀ᵐ y ∂η, (k+l) (x,y)=k (x,y)+l (x,y) :=
    Measure.ae_ae_of_ae_prod (Lp.coeFn_add k l)
  filter_upwards [section_rows μ η (k+l),section_rows μ η k,section_rows μ η l,eqn] with x h a b e
  apply Lp.ext
  filter_upwards [h,a,b,e,Lp.coeFn_add (sectionOf (η:=η) (fun z => k z) x) (sectionOf (fun z => l z) x)] with y hy ay by1 ey sy
  rw [hy,ey,sy]; exact congrArg₂ (·+·) ay.symm by1.symm

omit [SeparableSpace (Space η)] in
private theorem smul_sections (c : ℂ) (k : Space (μ.prod η)) :
    ∀ᵐ x ∂μ, sectionOf (η:=η) (fun z => (c • k) z) x = c • sectionOf (fun z => k z) x := by
  have eqn : ∀ᵐ x ∂μ, ∀ᵐ y ∂η, (c•k) (x,y)=c•k (x,y) :=
    Measure.ae_ae_of_ae_prod (Lp.coeFn_smul c k)
  filter_upwards [section_rows μ η (c•k),section_rows μ η k,eqn] with x h a e
  apply Lp.ext
  filter_upwards [h,a,e,Lp.coeFn_smul c (sectionOf (η:=η) (fun z => k z) x)] with y hy ay ey sy
  rw [hy,ey,sy]; exact congrArg (c • ·) ay.symm

private theorem lift_add (k l : Space (μ.prod η)) :
    liftRows μ η ν U (k+l)=liftRows μ η ν U k + liftRows μ η ν U l := by
  let q := liftRows μ η ν U
  apply unique μ η ν U (k+l) _ _ (partial_rows ..)
  have eqn : ∀ᵐ x ∂μ, ∀ᵐ y ∂ν, (q k+q l) (x,y)=q k (x,y)+q l (x,y) := Measure.ae_ae_of_ae_prod (Lp.coeFn_add _ _)
  filter_upwards [eqn,add_sections μ η k l,partial_rows μ η ν U k,partial_rows μ η ν U l] with x e s a b
  rw [s,map_add]
  filter_upwards [e,a,b,Lp.coeFn_add (U (sectionOf (η:=η) (fun z => k z) x)) (U (sectionOf (η:=η) (fun z => l z) x))] with y ey ay by1 sy
  rw [ey,ay,by1]; exact sy.symm

private theorem lift_smul (c : ℂ) (k : Space (μ.prod η)) :
    liftRows μ η ν U (c•k)=c•liftRows μ η ν U k := by
  let q := liftRows μ η ν U
  apply unique μ η ν U (c•k) _ _ (partial_rows ..)
  have eqn : ∀ᵐ x ∂μ, ∀ᵐ y ∂ν, (c•q k) (x,y)=c•q k (x,y) := Measure.ae_ae_of_ae_prod (Lp.coeFn_smul c (q k))
  filter_upwards [eqn,smul_sections μ η c k,partial_rows μ η ν U k] with x e s a
  rw [s,map_smul]
  filter_upwards [e,a,Lp.coeFn_smul c (U (sectionOf (η:=η) (fun z => k z) x))] with y hy ay sy
  rw [hy,ay]; exact sy.symm

def partialIsometry : Space (μ.prod η) →ₗᵢ[ℂ] Space (μ.prod ν) where
  toFun := liftRows μ η ν U
  map_add' := lift_add μ η ν U
  map_smul' c k := lift_smul μ η ν U c k
  norm_map' := partial_norm μ η ν U

end KDClosure.Joint
