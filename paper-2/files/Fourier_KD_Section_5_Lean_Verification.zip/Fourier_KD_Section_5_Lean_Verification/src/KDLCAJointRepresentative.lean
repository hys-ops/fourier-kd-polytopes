import KDCompactFourierRepresent
import KDLCAQuotientState
import Mathlib.MeasureTheory.Function.LpSpace.InfiniteSum
import Mathlib.MeasureTheory.Constructions.Polish.StronglyMeasurable

noncomputable section
namespace KDClosure.Joint
open Set MeasureTheory Topology Filter TopologicalSpace
open scoped ENNReal NNReal
variable {X Y Z : Type*} [MeasurableSpace X] [MeasurableSpace Y] [MeasurableSpace Z]
variable {η : Measure Y} {ν : Measure Z}
abbrev Space {X : Type*} [MeasurableSpace X] (μ : Measure X) := Lp ℂ 2 μ

/-- Countable L² approximants of geometric accuracy give one measurable
representative after a linear isometry. No measurability of the pointwise
coercion of an uncountable family of L² equivalence classes is assumed. -/
theorem represent [SeparableSpace (Space η)] (U : Space η →ₗᵢ[ℂ] Space ν)
    (a : X → Space η) (md : ∀ b, Measurable fun x => dist (a x) b) :
    ∃ q : X×Z → ℂ, Measurable q ∧ ∀ x, (fun z => q (x,z)) =ᵐ[ν] (U (a x) : Z → ℂ) := by
  classical
  obtain ⟨d,hd⟩ := exists_dense_seq (Space η)
  let r (n : ℕ) := (1/2:ℝ)^n
  have ex (n) (x:X) : ∃ i, dist (a x) (d i) < r n := by
    obtain ⟨i,hi⟩ := hd.exists_dist_lt (a x) (show 0<r n by dsimp [r]; positivity)
    exact ⟨i,by simpa [dist_comm] using hi⟩
  let ix (n) (x:X) := Nat.find (ex n x)
  have im (n) : Measurable (ix n) := measurable_find (ex n) (fun i => measurableSet_lt (md (d i)) measurable_const)
  let out (n : ℕ) (z : X×Z) := U (d (ix n z.1)) z.2
  have meas (n) : Measurable (out n) := by
    have mm : Measurable (fun z:ℕ×Z => U (d z.1) z.2) := measurable_from_prod_countable_right (fun i => (Lp.stronglyMeasurable (U (d i))).measurable)
    exact mm.comp (((im n).comp measurable_fst).prodMk measurable_snd)
  refine ⟨fun z => limUnder atTop (fun n => out n z),(StronglyMeasurable.limUnder (fun n => (meas n).stronglyMeasurable)).measurable,?_⟩
  intro x
  let err (n : ℕ) := U (d (ix n x))-U (a x)
  have summ : Summable fun n => ‖err n‖ := by
    apply Summable.of_nonneg_of_le (fun n => norm_nonneg _) _ (summable_geometric_of_lt_one (by norm_num : 0≤(1/2:ℝ)) (by norm_num))
    intro n
    simpa only [err,←dist_eq_norm,U.isometry.dist_eq,dist_comm (d _) (a x)] using (Nat.find_spec (ex n x)).le
  have bound : ∑' n, eLpNorm (err n : Z→ℂ) 2 ν ≠ ∞ := by
    simpa only [←Lp.enorm_def] using tsum_enorm_ne_top_iff_summable_norm.mpr summ
  have asum := summable_norm_of_tsum_eLpNorm_ne_top (by norm_num : (1:ℝ≥0∞)≤2)
    (fun n => Lp.aestronglyMeasurable (err n)) bound
  have dif (n) : (err n : Z→ℂ) =ᵐ[ν] fun z => out n (x,z)-U (a x) z := Lp.coeFn_sub _ _
  filter_upwards [asum,ae_all_iff.mpr dif] with z hz hr
  apply Filter.Tendsto.limUnder_eq
  apply tendsto_iff_norm_sub_tendsto_zero.mpr
  simpa only [←hr] using hz.tendsto_atTop_zero

variable {μ : Measure X} [SFinite η]
theorem measurable_section_norm (k : X×Y → ℂ) (m : Measurable k) :
    Measurable fun x => eLpNorm (fun y => k (x,y)) 2 η := by
  simp only [eLpNorm_eq_lintegral_rpow_enorm_toReal (by norm_num : (2:ℝ≥0∞)≠0) (by norm_num : (2:ℝ≥0∞)≠∞)]
  exact (m.enorm.pow_const _).lintegral_prod_right'.pow_const _

def sectionOf (k : X×Y → ℂ) (x : X) : Space η :=
  open Classical in if h : MemLp (fun y => k (x,y)) 2 η then h.toLp _ else 0

theorem sectionOf_dist (k : X×Y → ℂ) (m : Measurable k) (b : Space η) :
    Measurable fun x => dist (sectionOf k x) b := by
  classical
  let good := {x | MemLp (fun y => k (x,y)) 2 η}
  have isgood : MeasurableSet good := by
    have e : good = {x | eLpNorm (fun y => k (x,y)) 2 η < ∞} := by
      ext x
      exact ⟨fun h => h.2, fun h => ⟨(m.comp measurable_prodMk_left).aestronglyMeasurable,h⟩⟩
    rw [e]; exact measurableSet_lt (measurable_section_norm k m) measurable_const
  let diff (z : X×Y) := k z-b z.2
  have m2 := (measurable_section_norm (η:=η) diff (m.sub ((Lp.stronglyMeasurable b).measurable.comp measurable_snd))).ennreal_toReal
  have eqn : (fun x => dist (sectionOf k x) b) = good.piecewise (fun x =>
      (eLpNorm (fun y => diff (x,y)) 2 η).toReal) (fun _ => dist 0 b) := by
    funext x
    by_cases h : x∈good
    · rw [Set.piecewise_eq_of_mem _ _ _ h]
      change MemLp (fun y => k (x,y)) 2 η at h
      rw [sectionOf,dif_pos h,Lp.dist_def]
      apply congrArg ENNReal.toReal
      apply eLpNorm_congr_ae
      filter_upwards [h.coeFn_toLp] with y hy
      exact congrArg (· - b y) hy
    · rw [Set.piecewise_eq_of_notMem _ _ _ h]
      change ¬MemLp (fun y => k (x,y)) 2 η at h
      rw [sectionOf,dif_neg h]
  rw [eqn]; exact m2.piecewise isgood measurable_const

theorem for_kernel [SeparableSpace (Space η)] (U : Space η →ₗᵢ[ℂ] Space ν)
    (k : X×Y → ℂ) (m : Measurable k) :
    ∃ q : X×Z → ℂ, Measurable q ∧ ∀ x, (fun z => q (x,z)) =ᵐ[ν] (U (sectionOf k x) : Z→ℂ) :=
  represent U _ (sectionOf_dist k m)
end KDClosure.Joint
