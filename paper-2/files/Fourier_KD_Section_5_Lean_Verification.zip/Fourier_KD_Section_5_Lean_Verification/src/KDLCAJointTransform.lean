import KDLCAJointRepresentative
noncomputable section
namespace KDClosure.Joint
open Set MeasureTheory Topology Filter TopologicalSpace
open scoped ENNReal NNReal
variable {X Y Z : Type*} [MeasurableSpace X] [MeasurableSpace Y] [MeasurableSpace Z]
variable (μ : Measure X) (η : Measure Y) (ν : Measure Z) [SFinite η] [SFinite ν]
theorem norm_prod (k : X×Y → ℂ) (m : Measurable k) :
    eLpNorm k 2 (μ.prod η) = (∫⁻ x, (eLpNorm (fun y => k (x,y)) 2 η) ^ (2:ℕ) ∂μ) ^ (1/2:ℝ) := by
  simp only [eLpNorm_eq_lintegral_rpow_enorm_toReal (by norm_num : (2:ℝ≥0∞)≠0) (by norm_num : (2:ℝ≥0∞)≠∞),
    ENNReal.toReal_ofNat]
  rw [lintegral_prod _ ((m.enorm.pow_const _).aemeasurable)]
  congr 1
  apply lintegral_congr
  intro x
  rw [←ENNReal.rpow_natCast,←ENNReal.rpow_mul]
  norm_num

variable [SFinite μ]
theorem section_mem (k : Space (μ.prod η)) : ∀ᵐ x ∂μ, MemLp (fun y => k (x,y)) 2 η := by
  have m := (Lp.stronglyMeasurable k).measurable
  have fin := (memLp_two_iff_integrable_sq_norm (Lp.aestronglyMeasurable k)).mp (Lp.memLp k)
  filter_upwards [fin.prod_right_ae] with x hx
  exact (memLp_two_iff_integrable_sq_norm (m.comp measurable_prodMk_left).aestronglyMeasurable).mpr hx

variable [SeparableSpace (Space η)] (U : Space η →ₗᵢ[ℂ] Space ν)
def Represents (k : Space (μ.prod η)) (q : Space (μ.prod ν)) : Prop :=
  ∀ᵐ x ∂μ, (fun z => q (x,z)) =ᵐ[ν] (U (sectionOf (fun z => k z) x) : Z→ℂ)

theorem build (k : Space (μ.prod η)) : ∃ q : Space (μ.prod ν), Represents μ η ν U k q ∧ ‖q‖=‖k‖ := by
  obtain ⟨q,m,rep⟩ := for_kernel U (fun z => k z) (Lp.stronglyMeasurable k).measurable
  have eqn : eLpNorm q 2 (μ.prod ν)=eLpNorm (fun z => k z) 2 (μ.prod η) := by
    rw [norm_prod μ ν q m,norm_prod μ η _ (Lp.stronglyMeasurable k).measurable]
    congr 1
    apply lintegral_congr_ae
    filter_upwards [section_mem μ η k] with x hx
    have he := eLpNorm_congr_ae (rep x) (p:=2)
    rw [←Lp.enorm_def,U.enorm_map,sectionOf,dif_pos hx,Lp.enorm_def,eLpNorm_congr_ae hx.coeFn_toLp] at he
    rw [he]
  have mq : MemLp q 2 (μ.prod ν) := ⟨m.aestronglyMeasurable,eqn ▸ (Lp.memLp k).2⟩
  refine ⟨mq.toLp q,?_,?_⟩
  · change ∀ᵐ x ∂μ, (fun z => mq.toLp q (x,z)) =ᵐ[ν] _
    have joint : ∀ᵐ x ∂μ, (fun z => mq.toLp q (x,z)) =ᵐ[ν] fun z => q (x,z) := Measure.ae_ae_of_ae_prod mq.coeFn_toLp
    filter_upwards [joint] with x h
    exact h.trans (rep x)
  · rw [Lp.norm_def,Lp.norm_def,eLpNorm_congr_ae mq.coeFn_toLp,eqn]

omit [SeparableSpace (Space η)] [SFinite η] [SFinite μ] in
theorem unique (k : Space (μ.prod η)) (q r : Space (μ.prod ν)) (h : Represents μ η ν U k q)
    (s : Represents μ η ν U k r) : q=r := by
  apply Lp.ext
  apply (Measure.ae_prod_iff_ae_ae (measurableSet_eq_fun (Lp.stronglyMeasurable q).measurable (Lp.stronglyMeasurable r).measurable)).mpr
  filter_upwards [h,s] with x hx hy using hx.trans hy.symm

def liftRows (k : Space (μ.prod η)) : Space (μ.prod ν) := (build μ η ν U k).choose
theorem partial_rows (k : Space (μ.prod η)) : Represents μ η ν U k (liftRows μ η ν U k) :=
  (build μ η ν U k).choose_spec.1
theorem partial_norm (k : Space (μ.prod η)) : ‖liftRows μ η ν U k‖=‖k‖ :=
  (build μ η ν U k).choose_spec.2
end KDClosure.Joint
