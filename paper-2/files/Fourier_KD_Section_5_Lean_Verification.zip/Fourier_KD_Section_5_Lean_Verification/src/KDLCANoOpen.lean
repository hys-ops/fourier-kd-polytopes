import KDCyclicNeighborhood
import KDLCAQuotientState
noncomputable section
namespace KDClosure.LCAReality
open MeasureTheory Set CompactCore LCAQuotient Filter
open scoped KDClosure.SubgroupMeasure ENNReal ComplexConjugate ComplexOrder
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
  [T2Space G] [LocallyCompactSpace G] [SecondCountableTopology G] [MeasurableSpace G] [BorelSpace G]
variable (μ : Measure G) [μ.IsAddHaarMeasure] (ν : Measure (Dual G)) [SFinite ν]
theorem ambient_states_empty (F : FourierRealization μ ν)
    (none : ¬Nonempty (CO G)) : ambientStates μ ν F = ∅ := by
  apply Set.eq_empty_iff_forall_notMem.mpr
  rintro T ⟨p,t,k,act,herm,kd⟩
  have zero : k=0 := kernel_zero_of_ae_escape μ k herm
    (kernel_row_involution_of_rows μ ν F k (ambientKD_rows μ ν F k kd)) (ae_escape_of_no_compactOpen μ none)
  subst k
  have z : T=0 := by
    ext f : 1
    apply Lp.ext
    have ker := Measure.ae_ae_of_ae_prod (Lp.coeFn_zero ℂ 2 (μ.prod μ))
    filter_upwards [act f,ker,Lp.coeFn_zero ℂ 2 μ] with x hx hk hr
    change T f x = (0 : Lp ℂ 2 μ) x
    rw [hr,hx]
    have ok : (fun y => (0 : Lp ℂ 2 (μ.prod μ)) (x,y) * f y) =ᵐ[μ] fun _ => (0:ℂ) :=
      hk.mono fun y hy => by change _ * _ = 0; rw [hy]; exact zero_mul _
    rw [integral_congr_ae ok,integral_zero]; rfl
  subst T
  have bd : (0:ℝ) ∈ upperBounds (LCAQuotientTrace.frameMass (0 : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ)) := by
    rintro r ⟨n,v,_,rfl⟩; simp
  exact (not_le_of_gt zero_lt_one) (t.2 bd)
end KDClosure.LCAReality
