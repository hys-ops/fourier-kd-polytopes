import KDLCAQuotientTranslate
noncomputable section
namespace KDClosure.Phase
open MeasureTheory Set Filter LCAQuotient LCAReality
open scoped ENNReal ComplexOrder ComplexConjugate KDClosure.SubgroupMeasure
local instance : MeasurableSpace Circle := borel _
local instance : BorelSpace Circle := ⟨rfl⟩
section Multiplier
variable {X : Type*} [MeasurableSpace X] (μ : Measure X) (φ : X → Circle) (m : Measurable φ)
include m in
private theorem bound : MemLp (fun x => (φ x:ℂ)) ∞ μ :=
  memLp_top_of_bound ((show Continuous (fun w : Circle => (w:ℂ)) from continuous_subtype_val).measurable.comp m).aestronglyMeasurable 1 (.of_forall fun x => (Circle.norm_coe (φ x)).le)
def mulOp : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ :=
  ((ContinuousLinearMap.mul ℂ ℂ).holderL μ ∞ 2 2) ((bound μ φ m).toLp _)
theorem mul_ae (f : Lp ℂ 2 μ) :
    (mulOp μ φ m f : X→ℂ) =ᵐ[μ] fun x => (φ x:ℂ)*f x := by
  have eqn := (ContinuousLinearMap.mul ℂ ℂ).coeFn_holder (r:=2) ((bound μ φ m).toLp _) f
  filter_upwards [eqn,(bound μ φ m).coeFn_toLp] with x a b
  exact a.trans (by rw [b]; rfl)
theorem inv_composition (f : Lp ℂ 2 μ) : mulOp μ φ m (mulOp μ (fun x => (φ x)⁻¹) m.inv f)=f := by
  apply Lp.ext
  filter_upwards [mul_ae μ φ m (mulOp μ (fun x => (φ x)⁻¹) m.inv f),mul_ae μ (fun x => (φ x)⁻¹) m.inv f] with x a b
  rw [a,b,Circle.coe_inv,←mul_assoc,mul_inv_cancel₀ (Circle.coe_ne_zero _),one_mul]
def unitary : Lp ℂ 2 μ ≃ₗᵢ[ℂ] Lp ℂ 2 μ :=
  let U : Lp ℂ 2 μ →ₗᵢ[ℂ] Lp ℂ 2 μ :=
    { toLinearMap := (mulOp μ φ m).toLinearMap
      norm_map' := fun f => by
        rw [Lp.norm_def,Lp.norm_def]
        congr 1
        apply eLpNorm_congr_norm_ae
        filter_upwards [mul_ae μ φ m f] with x h
        change ‖mulOp μ φ m f x‖=‖f x‖
        rw [h,norm_mul,Circle.norm_coe,one_mul] }
  LinearIsometryEquiv.ofSurjective U (fun f => ⟨_,inv_composition μ φ m f⟩)
theorem unitary_ae (f : Lp ℂ 2 μ) :
    (unitary μ φ m f : X→ℂ) =ᵐ[μ] fun x => (φ x:ℂ)*f x := mul_ae μ φ m f
theorem unitary_symm_ae (f : Lp ℂ 2 μ) :
    ((unitary μ φ m).symm f : X→ℂ) =ᵐ[μ] fun x => ((φ x)⁻¹:Circle)*f x := by
  have e : (unitary μ φ m).symm f = mulOp μ _ m.inv f :=
    (unitary μ φ m).toEquiv.symm_apply_eq.mpr (inv_composition μ φ m f).symm
  rw [e]
  exact mul_ae μ _ m.inv f
end Multiplier
end KDClosure.Phase
