import KDLCAPhase
noncomputable section
namespace KDClosure.Phase
open MeasureTheory Set Filter LCAReality
open scoped ENNReal ComplexOrder ComplexConjugate KDClosure.SubgroupMeasure
local instance : MeasurableSpace Circle := borel _
local instance : BorelSpace Circle := ⟨rfl⟩
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
  [MeasurableSpace G] [BorelSpace G]
variable (μ : Measure G) (ν : Measure (Dual G)) [ν.IsMulLeftInvariant]
def ch (ψ : Dual G) : G → Circle := fun x => ψ (Multiplicative.ofAdd x)
omit [IsTopologicalAddGroup G] in
theorem mch (ψ : Dual G) : Measurable (ch ψ) := (show Continuous (ch ψ) from ψ.continuous).measurable
def rotate (ψ : Dual G) := unitary μ (ch ψ) (mch ψ)
omit [IsTopologicalAddGroup G] in
theorem rotate_ae (ψ : Dual G) (f : Lp ℂ 2 μ) :
    (rotate μ ψ f : G→ℂ) =ᵐ[μ] fun x => phase ψ x*f x := unitary_ae μ (ch ψ) (mch ψ) f
omit [IsTopologicalAddGroup G] in
theorem rotate_symm (ψ : Dual G) : (rotate μ ψ).symm=rotate μ ψ⁻¹ := by
  ext f : 1
  apply Lp.ext
  exact (unitary_symm_ae μ (ch ψ) (mch ψ) f).trans (rotate_ae μ ψ⁻¹ f).symm

def dualMove (ψ : Dual G) : Lp ℂ 2 ν →ₗᵢ[ℂ] Lp ℂ 2 ν :=
  Lp.compMeasurePreservingₗᵢ ℂ (ψ*·) (measurePreserving_mul_left ν ψ)
omit [IsTopologicalAddGroup G] in
theorem fourier_rotate (F : FourierRealization μ ν) (ψ : Dual G) (f : Lp ℂ 2 μ) :
    F.isometry (rotate μ ψ f) = dualMove ν ψ (F.isometry f) := by
  have small (g : Lp ℂ 2 μ) (ig : Integrable (g : G→ℂ) μ) :
      F.isometry (rotate μ ψ g) = dualMove ν ψ (F.isometry g) := by
    have ig' : Integrable (rotate μ ψ g : G→ℂ) μ := by
      apply ig.norm.mono' (Lp.aestronglyMeasurable _)
      filter_upwards [rotate_ae μ ψ g] with x hx
      rw [hx,norm_mul,show ‖phase ψ x‖=1 from Circle.norm_coe _,one_mul]
    have orig := (measurePreserving_mul_left ν ψ).quasiMeasurePreserving.ae_eq_comp (F.integral_ae g ig)
    apply Lp.ext
    filter_upwards [F.integral_ae (rotate μ ψ g) ig', Lp.coeFn_compMeasurePreserving (F.isometry g) (measurePreserving_mul_left ν ψ),orig] with χ hy hz hw
    change dualMove ν ψ (F.isometry g) χ = F.isometry g (ψ*χ) at hz
    change F.isometry g (ψ*χ) = ∫ x, g x * phase (ψ*χ) x ∂μ at hw
    rw [hy,hz,hw]
    apply integral_congr_ae
    filter_upwards [rotate_ae μ ψ g] with x hx
    rw [hx]; change _ = g x * (phase ψ x * phase χ x)
    ring
  apply Lp.induction (by norm_num : (2:ℝ≥0∞)≠∞)
    (fun g => F.isometry (rotate μ ψ g) = dualMove ν ψ (F.isometry g)) _ _ _ f
  · intro c s hs hm; exact small _ (integrable_indicatorConstLp hs hm.ne c)
  · intro a b ha hb _ q r; simp only [map_add,q,r]
  · exact isClosed_eq (F.isometry.continuous.comp (rotate μ ψ).continuous) ((dualMove ν ψ).continuous.comp F.isometry.continuous)
end KDClosure.Phase
