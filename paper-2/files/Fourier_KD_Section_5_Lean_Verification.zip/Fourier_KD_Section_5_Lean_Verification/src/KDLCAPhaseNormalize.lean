import KDLCAPhaseWeyl
import KDLCARealitySingleSector
import KDActualCore
noncomputable section
namespace KDClosure.Phase
open MeasureTheory Set Filter LCAQuotient LCAReality CompactFourier CompactCore
open scoped ENNReal ComplexOrder ComplexConjugate KDClosure.SubgroupMeasure
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
  [T2Space G] [LocallyCompactSpace G] [MeasurableSpace G] [BorelSpace G] [SecondCountableTopology G]
variable (μ : Measure G) [μ.IsAddHaarMeasure] (ν : Measure (Dual G)) [SFinite ν] [ν.IsHaarMeasure]
/- Pullback by the occupied displacement and character is a central-sector wave function. -/
omit [T2Space G] [LocallyCompactSpace G] [SecondCountableTopology G] in
theorem back_ae (u : G) (ψ : Dual G) (v : Lp ℂ 2 μ) :
    ((weyl μ u ψ).symm v : G→ℂ) =ᵐ[μ] fun x => phase ψ⁻¹ (u+x)*v (u+x) := by
  change ((move μ (-u)).symm ((rotate μ ψ).symm v) : G→ℂ) =ᵐ[μ] _
  rw [move_symm,neg_neg,rotate_symm]
  exact (move_ae μ u (rotate μ ψ⁻¹ v)).trans ((measurePreserving_add_left μ u).quasiMeasurePreserving.ae_eq_comp (rotate_ae μ ψ⁻¹ v))
omit [T2Space G] [LocallyCompactSpace G] [SecondCountableTopology G] in
theorem back_support (D : AddSubgroup G) (u : G) (ψ : Dual G) (v : Lp ℂ 2 μ)
    (s : ∀ᵐ y ∂μ, y-u∉D → v y=0) :
    ∀ᵐ x ∂μ, x∉D → (weyl μ u ψ).symm v x=0 := by
  filter_upwards [back_ae μ u ψ v,(measurePreserving_add_left μ u).quasiMeasurePreserving.ae s] with x h g
  change u+x-u∉D → v (u+x)=0 at g
  intro nx
  rw [h,g (by simpa only [add_sub_cancel_left] using nx),mul_zero]
omit [T2Space G] [LocallyCompactSpace G] [SecondCountableTopology G] in
theorem back_fixed (u l : G) (ψ : Dual G) (v : Lp ℂ 2 μ)
    (fix : LCAReality.shift μ l v=phase ψ l • v) :
    LCAReality.shift μ l ((weyl μ u ψ).symm v)=(weyl μ u ψ).symm v := by
  have law : ∀ᵐ y ∂μ, v (l+y)=phase ψ l*v y := by
    have eqn := LCAReality.shift_ae μ l v
    rw [fix] at eqn
    exact eqn.symm.trans (Lp.coeFn_smul (phase ψ l) v)
  apply Lp.ext
  have a := back_ae μ u ψ v
  filter_upwards [LCAReality.shift_ae μ l ((weyl μ u ψ).symm v),a,(measurePreserving_add_left μ l).quasiMeasurePreserving.ae_eq_comp a,
      (measurePreserving_add_left μ u).quasiMeasurePreserving.ae law] with x h r rl g
  change (weyl μ u ψ).symm v (l+x)=phase ψ⁻¹ (u+(l+x))*v (u+(l+x)) at rl
  change v (l+(u+x))=phase ψ l*v (u+x) at g
  rw [h,r,rl,show u+(l+x)=l+(u+x) by abel,g,phase_add]
  have e : phase ψ⁻¹ l * phase ψ l=1 := by
    change (((ch ψ l)⁻¹:Circle):ℂ)*(ch ψ l:ℂ)=1
    rw [Circle.coe_inv,inv_mul_cancel₀ (Circle.coe_ne_zero _)]
  calc
    _ = (phase ψ⁻¹ l * phase ψ l) * (phase ψ⁻¹ (u+x)*v (u+x)) := by ring
    _ = _ := by rw [e,one_mul]
omit [T2Space G] in
theorem unit_back_extreme (u : G) (ψ : Dual G) (F : FourierRealization μ ν) {T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ}
    (e : T∈(ambientStates μ ν F).extremePoints ℝ) :
    unitaryPush (weyl μ u ψ).symm T∈(ambientStates μ ν F).extremePoints ℝ := by
  refine ⟨weyl_back μ ν F u ψ e.1,?_⟩
  let W := weyl μ u ψ
  intro A ha B hb seg
  obtain ⟨a,b,ap,bp,ab,eqn⟩ := seg
  have blend : a • unitaryPush W A+b • unitaryPush W B=T := by
    calc
      _ = unitaryPush W (a • A+b • B) := by ext x : 1; simp [unitaryPush]
      _ = T := by rw [eqn]; ext x : 1; simp [unitaryPush,W]
  have eq := e.2 (weyl_mem μ ν F u ψ ha) (weyl_mem μ ν F u ψ hb) ⟨a,b,ap,bp,ab,blend⟩
  calc A = unitaryPush W.symm (unitaryPush W A) := by ext x : 1; simp [unitaryPush,W]
       _ = unitaryPush W.symm T := congrArg _ eq
end KDClosure.Phase
