import KDLCAPhaseFourier
noncomputable section
namespace KDClosure.Phase
open MeasureTheory Set Filter LCAQuotient LCAReality
open scoped ENNReal ComplexOrder ComplexConjugate KDClosure.SubgroupMeasure
local instance : MeasurableSpace Circle := borel _
local instance : BorelSpace Circle := ⟨rfl⟩
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
  [MeasurableSpace G] [BorelSpace G] [SecondCountableTopology G]
variable (μ : Measure G) [μ.IsAddLeftInvariant] [SFinite μ] (ν : Measure (Dual G)) [ν.IsMulLeftInvariant] [SFinite ν]
def rotateOp (ψ : Dual G) (T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ) := CompactFourier.unitaryPush (rotate μ ψ) T
private def cmul (ψ : Dual G) (z : G×G) : Circle := ch ψ z.1 * (ch ψ z.2)⁻¹
omit [IsTopologicalAddGroup G] [SecondCountableTopology G] in
private theorem mcmul (ψ : Dual G) : Measurable (cmul ψ) :=
  ((mch ψ).comp measurable_fst).mul ((mch ψ).comp measurable_snd).inv
def rotateKernel (ψ : Dual G) (k : Lp ℂ 2 (μ.prod μ)) :=
  unitary (μ.prod μ) (cmul ψ) (mcmul ψ) k
omit [IsTopologicalAddGroup G] [SecondCountableTopology G] [μ.IsAddLeftInvariant] [SFinite μ] in
theorem kernel_ae (ψ : Dual G) (k : Lp ℂ 2 (μ.prod μ)) :
    (rotateKernel μ ψ k : G×G→ℂ) =ᵐ[μ.prod μ] fun z => (phase ψ z.1 * phase ψ⁻¹ z.2)*k z :=
  unitary_ae (μ.prod μ) (cmul ψ) (mcmul ψ) k
omit [IsTopologicalAddGroup G] [SecondCountableTopology G] [μ.IsAddLeftInvariant] in
theorem rotate_act (ψ : Dual G) {T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ} {k : Lp ℂ 2 (μ.prod μ)}
    (h : ActsBy μ T k) : ActsBy μ (rotateOp μ ψ T) (rotateKernel μ ψ k) := by
  intro f
  let v := (rotate μ ψ).symm f
  have vt : (v:G→ℂ) =ᵐ[μ] fun x => phase ψ⁻¹ x*f x := by
    dsimp [v]; rw [rotate_symm]; exact rotate_ae μ _ _
  filter_upwards [rotate_ae μ ψ (T v),h v,Measure.ae_ae_of_ae_prod (kernel_ae μ ψ k)] with x a b c
  change rotate μ ψ (T v) x=_
  rw [a,b,←integral_const_mul]
  apply integral_congr_ae
  filter_upwards [vt,c] with y vy cy
  rw [vy,cy]; ring
theorem rotate_rows (ψ : Dual G) (k : Lp ℂ 2 (μ.prod μ)) :
    ∀ᵐ x ∂μ, rowAt μ (rotateKernel μ ψ k) x=rotate μ ψ⁻¹ (rowAt μ k x) := by
  have shear := (measurePreserving_prod_add μ μ).quasiMeasurePreserving.ae_eq_comp (kernel_ae μ ψ k)
  filter_upwards [rowAt_ae μ (rotateKernel μ ψ k),rowAt_ae μ k,Measure.ae_ae_of_ae_prod shear] with x a b c
  apply Lp.ext
  filter_upwards [a,b,c,rotate_ae μ ψ⁻¹ (rowAt μ k x)] with y ay by1 cy dy
  change rotateKernel μ ψ k (x,x+y) = (phase ψ x*phase ψ⁻¹ (x+y))*k (x,x+y) at cy
  rw [ay,dy,by1,cy,phase_add]
  have e : phase ψ x * phase ψ⁻¹ x =1 := by
    change ((ch ψ x:Circle):ℂ) * (((ch ψ x)⁻¹:Circle):ℂ)=1
    rw [Circle.coe_inv,mul_inv_cancel₀ (Circle.coe_ne_zero _)]
  rw [←mul_assoc,e,one_mul]
theorem rotate_kd (F : FourierRealization μ ν) (ψ : Dual G) {k : Lp ℂ 2 (μ.prod μ)}
    (kd : ambientKD μ ν F k) : ambientKD μ ν F (rotateKernel μ ψ k) := by
  obtain ⟨q,m,r,pos⟩ := kd
  let M := measurePreserving_mul_left ν ψ⁻¹
  refine ⟨fun z => q (z.1,ψ⁻¹*z.2),m.comp (measurable_fst.prodMk (M.measurable.comp measurable_snd)),?_,
    ((MeasurePreserving.id μ).prod M).quasiMeasurePreserving.ae pos⟩
  filter_upwards [r,rotate_rows μ ψ k] with x a b
  rw [b,fourier_rotate]
  exact (M.quasiMeasurePreserving.ae_eq_comp a).trans (Lp.coeFn_compMeasurePreserving _ M).symm

theorem rotate_mem (F : FourierRealization μ ν) (ψ : Dual G) {T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ}
    (s : T∈ambientStates μ ν F) : rotateOp μ ψ T∈ambientStates μ ν F := by
  obtain ⟨p,tr,k,a,_,kd⟩ := s
  have p' := (CompactFourier.positive_unitary_iff (rotate μ ψ) T).mpr p
  have tr' : IsLUB (mass (rotateOp μ ψ T)) 1 := by
    change IsLUB (CompactFourier.frameMass (CompactFourier.unitaryPush (rotate μ ψ) T)) 1
    rwa [CompactFourier.frameMass_unitary]
  have ac := rotate_act μ ψ a
  exact ⟨p',tr',_,ac,hermitian_of_acts μ _ p' ⟨1,tr'.1⟩ ac,rotate_kd μ ν F ψ kd⟩

end KDClosure.Phase
