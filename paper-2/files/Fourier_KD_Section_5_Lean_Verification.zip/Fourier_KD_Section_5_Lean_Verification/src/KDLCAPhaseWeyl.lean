import KDLCAPhaseStates
import KDReducedLiftsHull
noncomputable section
namespace KDClosure.Phase
open MeasureTheory Set Filter LCAQuotient LCAReality CompactFourier ChainLimit ReducedWindows CompactCore CompactCoset
open scoped ENNReal ComplexOrder ComplexConjugate KDClosure.SubgroupMeasure
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
  [T2Space G] [LocallyCompactSpace G] [MeasurableSpace G] [BorelSpace G] [SecondCountableTopology G]
variable (μ : Measure G) [μ.IsAddHaarMeasure] (ν : Measure (LCAReality.Dual G)) [SFinite ν] [ν.IsHaarMeasure]
def weyl (u : G) (ψ : LCAReality.Dual G) := (move μ (-u)).trans (rotate μ ψ)
omit [T2Space G] in
theorem weyl_mem (F : FourierRealization μ ν) (u : G) (ψ : LCAReality.Dual G) {T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ}
    (s : T∈ambientStates μ ν F) : unitaryPush (weyl μ u ψ) T∈ambientStates μ ν F := by
  have eqn : unitaryPush (weyl μ u ψ) T=rotateOp μ ψ (moveOp μ (-u) T) := by ext x : 1; rfl
  rw [eqn]
  exact rotate_mem μ ν F ψ (move_mem μ ν (-u) F s)

omit [T2Space G] in
theorem weyl_back (F : FourierRealization μ ν) (u : G) (ψ : LCAReality.Dual G) {T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ}
    (s : T∈ambientStates μ ν F) : unitaryPush (weyl μ u ψ).symm T∈ambientStates μ ν F := by
  have eq : unitaryPush (weyl μ u ψ).symm T=moveOp μ u (rotateOp μ ψ⁻¹ T) := by
    ext f : 1
    change (move μ (-u)).symm ((rotate μ ψ).symm (T (rotate μ ψ (move μ (-u) f))))=move μ u (rotate μ ψ⁻¹ (T ((rotate μ ψ⁻¹).symm ((move μ u).symm f))))
    rw [move_symm,neg_neg,rotate_symm,rotate_symm,inv_inv,move_symm]
  rw [eq]
  exact move_mem μ ν u F (rotate_mem μ ν F ψ⁻¹ s)

omit [T2Space G] [LocallyCompactSpace G] [SecondCountableTopology G] in
theorem weyl_cell (H K : CO G) (u : G) (ψ : LCAReality.Dual G) (i : CoreQuot H K) :
    weyl μ u ψ (normalizedCell H K μ 0 1 i)=normalizedCell H K μ u ψ i := by
  let w := normalizedCell H K μ 0 1 i
  apply Lp.ext
  have ini : (w:G→ℂ) =ᵐ[μ] fun x => (scale μ H:ℂ) * (region H K 0 i).indicator (fun _ => (1:ℂ)) x := by
    filter_upwards [Lp.coeFn_smul (scale μ H:ℂ) (cellVector H K μ 0 1 i),cellVector_ae H K μ 0 1 i] with x sc v
    change ((scale μ H:ℂ) • cellVector H K μ 0 1 i) x=_
    rw [sc]; change (scale μ H:ℂ) * cellVector H K μ 0 1 i x=_
    rw [v]; rfl
  have moved := (measurePreserving_add_left μ (-u)).quasiMeasurePreserving.ae_eq_comp ini
  filter_upwards [rotate_ae μ ψ (move μ (-u) w),move_ae μ (-u) w,moved,
    Lp.coeFn_smul (scale μ H:ℂ) (cellVector H K μ u ψ i),cellVector_ae H K μ u ψ i] with x rot mv orig sc v
  change rotate μ ψ (move μ (-u) w) x = ((scale μ H:ℂ) • cellVector H K μ u ψ i) x
  change w (-u+x)=(scale μ H:ℂ) * (region H K 0 i).indicator (fun _ => (1:ℂ)) (-u+x) at orig
  rw [rot,mv,orig,sc]; change _=(scale μ H:ℂ)*cellVector H K μ u ψ i x
  rw [v]
  have eqn : (-u+x)∈region H K 0 i ↔ x∈region H K u i := by
    change -u+x-(0+(representative H K i:G))∈subgroup H ↔ x-(u+(representative H K i:G))∈subgroup H
    rw [show -u+x-(0+(representative H K i:G))=x-(u+(representative H K i:G)) by abel]
  by_cases hx : x∈region H K u i
  · simp [Set.indicator_of_mem hx,Set.indicator_of_mem (eqn.mpr hx),mul_comm]
  · simp [Set.indicator_of_notMem hx,Set.indicator_of_notMem (fun z => hx (eqn.mp z))]
end KDClosure.Phase
