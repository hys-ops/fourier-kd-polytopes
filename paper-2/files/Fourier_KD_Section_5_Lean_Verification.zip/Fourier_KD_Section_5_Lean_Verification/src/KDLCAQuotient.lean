import KDCompactCosetRow
import KDIsometricSupport
import KDDiscreteOperator
import Mathlib.MeasureTheory.Function.L2Space

/-! Physical support embedding for a compact-open quotient. The quotient may
be infinite. Haar measure on the ambient group need not be normalized. -/
noncomputable section
namespace KDClosure.LCAQuotient
open MeasureTheory Set CompactCore CompactCoset
open scoped BigOperators InnerProductSpace ENNReal
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
    [MeasurableSpace G] [BorelSpace G] [MeasurableAdd G]

abbrev Q (N : CO G) := G ⧸ (subgroup N)
def π (N : CO G) : G →+ Q N := QuotientAddGroup.mk' _
def fiber (N : CO G) (q : Q N) : Set G := {x | π N x = q}
omit [IsTopologicalAddGroup G] [MeasurableSpace G] [BorelSpace G] [MeasurableAdd G] in
theorem fiber_coset (N : CO G) (x : G) : fiber N (π N x) = coset N x := by
  ext y
  exact QuotientAddGroup.eq_iff_sub_mem

omit [MeasurableAdd G] in
theorem fiber_meas (N : CO G) (q : Q N) : MeasurableSet (fiber N q) := by
  obtain ⟨x,rfl⟩ := QuotientAddGroup.mk'_surjective (subgroup N) q
  change MeasurableSet (fiber N (π N x))
  rw [fiber_coset]; exact coset_meas N x

variable (μ : Measure G) [μ.IsAddHaarMeasure]

omit [IsTopologicalAddGroup G] [BorelSpace G] in
theorem fiber_mass (N : CO G) (q : Q N) : μ (fiber N q) = μ (N.val : Set G) := by
  obtain ⟨x,rfl⟩ := QuotientAddGroup.mk'_surjective (subgroup N) q
  change μ (fiber N (π N x)) = _
  rw [fiber_coset]
  change μ ((fun y : G => y - x) ⁻¹' (N.val : Set G)) = μ _
  simpa only [sub_eq_add_neg,add_comm] using measure_preimage_add μ (-x) (N.val : Set G)

omit [IsTopologicalAddGroup G] [BorelSpace G] [MeasurableAdd G] in
private theorem mass_pos (N : CO G) : 0 < μ.real (N.val : Set G) :=
  ENNReal.toReal_pos (N.val.isOpen.measure_pos μ ⟨0,N.val.zero_mem⟩).ne' N.property.measure_ne_top

omit [IsTopologicalAddGroup G] [BorelSpace G] in
private theorem fin (N : CO G) (q : Q N) : μ (fiber N q) ≠ ∞ := by
  rw [fiber_mass]; exact N.property.measure_ne_top

def scale (N : CO G) : ℝ := (Real.sqrt (μ.real (N.val : Set G)))⁻¹

def atom (N : CO G) (q : Q N) : Lp ℂ 2 μ :=
  indicatorConstLp 2 (fiber_meas N q) (fin μ N q) (scale μ N : ℂ)

theorem atom_ae (N : CO G) (q : Q N) : (atom μ N q : G → ℂ) =ᵐ[μ]
    (fiber N q).indicator (fun _ => (scale μ N : ℂ)) := indicatorConstLp_coeFn

theorem atom_orthonormal (N : CO G) : Orthonormal ℂ (atom μ N) := by
  classical
  rw [orthonormal_iff_ite]; intro i j
  rw [atom,atom,MeasureTheory.L2.inner_indicatorConstLp_indicatorConstLp (fiber_meas N i) (fiber_meas N j) (fin μ N i) (fin μ N j)]
  by_cases h : i=j
  · subst j
    rw [if_pos rfl,Set.inter_self,Measure.real, fiber_mass]
    have hp := mass_pos μ N
    have hs := Real.sq_sqrt hp.le
    have hpos := Real.sqrt_pos.mpr hp
    simp only [scale, RCLike.inner_apply, Complex.conj_ofReal,Complex.real_smul,
      ←Complex.ofReal_mul,Complex.ofReal_inj,←Complex.ofReal_one]
    change (μ (N.val : Set G)).toReal * ((Real.sqrt (μ.real (N.val : Set G)))⁻¹ *
        (Real.sqrt (μ.real (N.val : Set G)))⁻¹) = 1
    change μ.real (N.val : Set G) * _ = 1
    field_simp
    nlinarith
  · have eq : fiber N i ∩ fiber N j = ∅ := Set.eq_empty_iff_forall_notMem.mpr fun _ ⟨a,b⟩ =>
        h (a.symm.trans b)
    simp [eq,h]

def inclusion (N : CO G) : Discrete.L2 (Q N) →ₗᵢ[ℂ] Lp ℂ 2 μ :=
  (atom_orthonormal μ N).orthogonalFamily.linearIsometry

theorem inclusion_single (N : CO G) [DecidableEq (Q N)] (q : Q N) (a : ℂ) :
    inclusion μ N (lp.single 2 q a) = a • atom μ N q := by
  exact (atom_orthonormal μ N).orthogonalFamily.linearIsometry_apply_single a

theorem inclusion_hasSum (N : CO G) (f : Discrete.L2 (Q N)) :
    HasSum (fun q => f q • atom μ N q) (inclusion μ N f) :=
  (atom_orthonormal μ N).orthogonalFamily.hasSum_linearIsometry f

end KDClosure.LCAQuotient
