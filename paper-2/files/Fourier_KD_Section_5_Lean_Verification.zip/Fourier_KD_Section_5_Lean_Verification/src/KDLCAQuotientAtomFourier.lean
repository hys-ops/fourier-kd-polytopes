import KDLCAQuotientRows

/-! Identification with the actual ambient Fourier integrals. -/
noncomputable section
namespace KDClosure.LCAQuotient
open Classical Set MeasureTheory CompactCoset CompactCore Filter
open scoped KDClosure.SubgroupMeasure ComplexOrder ENNReal InnerProductSpace BigOperators
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
    [MeasurableSpace G] [BorelSpace G] [MeasurableAdd G] [T2Space G]
variable (N : CO G)
local instance : DiscreteTopology (Qm N) := QuotientGroup.discreteTopology (openMul N).isOpen
variable (μ : Measure G) [μ.IsAddHaarMeasure] (ν : Measure (Dual G)) [ν.IsHaarMeasure]

def representative (j : Qm N) : G := (QuotientGroup.mk'_surjective (openMul N).toSubgroup j).choose.toAdd

omit [IsTopologicalAddGroup G] [MeasurableSpace G] [BorelSpace G] [MeasurableAdd G] [T2Space G] in
theorem qmap_rep (j : Qm N) : qmap N (representative N j) = j :=
  (QuotientGroup.mk'_surjective (openMul N).toSubgroup j).choose_spec

def rowAtom (j : Qm N) (y : G) : ℂ :=
  (CompactCoset.coset N (representative N j)).indicator (fun _ => (μ.real (N.val : Set G) : ℂ)⁻¹) y

omit [T2Space G] in
/-- Exact raw transform on one coset of the displacement Fourier integral. -/
theorem atom_integral (x : G) (j : Qm N) (χ : Dual G) :
    (∫ y, rowAtom N μ j y * complexChar χ (y-x) ∂μ) =
    if χ∈CompactDualReduction.ann (openMul N) then complexChar χ (representative N j-x) else 0 := by
  let a := representative N j
  let m := (μ.real (N.val : Set G) : ℂ)
  let θ := complexChar χ
  have same (y : G) : rowAtom N μ j y * θ (y-x) = (m⁻¹ * θ (-x)) * (coset N a).indicator θ y := by
    by_cases h : y∈coset N a
    · simp [rowAtom,a,m,Set.indicator_of_mem h,sub_eq_add_neg,AddChar.map_add_eq_mul,mul_comm,mul_left_comm]
    · simp [rowAtom,a,Set.indicator_of_notMem h]
  change (∫ y, rowAtom N μ j y * θ (y-x) ∂μ)=_
  simp_rw [same]
  rw [integral_const_mul,integral_indicator (coset_meas N a),coset_character_integral]
  have iff_ann : annihilates N θ ↔ χ∈CompactDualReduction.ann (openMul N) := by
    constructor
    · intro h u hu
      exact Subtype.ext (h u.toAdd hu)
    · intro h z hz
      exact congrArg (fun u : Circle => (u:ℂ)) (h (Multiplicative.ofAdd z) hz)
  by_cases hp : χ∈CompactDualReduction.ann (openMul N)
  · rw [if_pos (iff_ann.mpr hp),if_pos hp]
    have hm : m≠0 := by
      exact Complex.ofReal_ne_zero.mpr <| ENNReal.toReal_ne_zero.mpr
        ⟨(N.val.isOpen.measure_pos μ ⟨0,N.val.zero_mem⟩).ne',N.property.measure_ne_top⟩
    change m⁻¹ * θ (-x) * (m * θ a) = θ (a-x)
    rw [sub_eq_add_neg,AddChar.map_add_eq_mul]
    field_simp
  · rw [if_neg (fun h => hp (iff_ann.mp h)),if_neg hp,mul_zero]

omit [T2Space G] in
theorem physicalPhase_integral_ae (x : G) (j : Qm N) :
    (physicalPhase N ν x j : Dual G → ℂ) =ᵐ[ν]
      fun χ => ∫ y, rowAtom N μ j y * complexChar χ (y-x) ∂μ := by
  let f := DiscreteKDRow.phase (Qm N) (qmap N x) j
  have a := LCAQuotientDual.vector_ae (openMul N) ν f
  change (physicalPhase N ν x j : Dual G → ℂ) =ᵐ[ν] _ at a
  refine a.trans ?_
  apply (LCAQuotientDual.everywhere_from_range (openMul N) ν N.property _ ?_).mpr
  · filter_upwards [DiscreteKDRow.phase_ae (Qm N) (qmap N x) j] with φ hφ
    change LCAQuotientDual.zeroExtend (openMul N) f (CompactDualReduction.pull (openMul N) φ) = (∫ y, rowAtom N μ j y * complexChar (CompactDualReduction.pull (openMul N) φ) (y-x) ∂μ)
    rw [LCAQuotientDual.zeroExtend_on,atom_integral N μ x j]
    have ht : CompactDualReduction.pull (openMul N) φ∈CompactDualReduction.ann (openMul N) := by
      show CompactDualReduction.pull (openMul N) φ ∈ ((CompactDualReduction.ann (openMul N) : Subgroup (Dual G)) : Set (Dual G))
      rw [CompactDualReduction.ann_range]; exact ⟨φ,rfl⟩
    rw [if_pos ht]
    change f φ = (φ (qmap N (representative N j-x)):ℂ)
    rw [show qmap N (representative N j-x) = j / qmap N x from
      (map_div (QuotientGroup.mk' (openMul N).toSubgroup) _ _).trans
        (congrArg (· / qmap N x) (qmap_rep N j))]
    exact hφ
  · intro χ hc
    change LCAQuotientDual.zeroExtend (openMul N) f χ = (∫ y, rowAtom N μ j y * complexChar χ (y-x) ∂μ)
    rw [LCAQuotientDual.zeroExtend_off _ _ hc,atom_integral N μ x j χ,if_neg hc]

end KDClosure.LCAQuotient
