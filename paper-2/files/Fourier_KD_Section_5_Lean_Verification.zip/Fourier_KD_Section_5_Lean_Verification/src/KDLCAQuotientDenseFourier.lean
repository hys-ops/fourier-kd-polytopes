import KDLCARealityFourier
import Mathlib.Analysis.Normed.Operator.Extend

/-! A scalar L¹∩L² Parseval identity on the raw Fourier integral constructs
a genuine FourierRealization on the entire physical Hilbert space. -/
noncomputable section
namespace KDClosure.LCAReality
open Set MeasureTheory Filter
open scoped ENNReal
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [MeasurableSpace G] [BorelSpace G]
variable (μ : Measure G) [MeasurableSpace (Dual G)] (ν : Measure (Dual G))

def integrableDomain : Submodule ℂ (Lp ℂ 2 μ) where
  carrier := {f | Integrable (f:G→ℂ) μ}
  zero_mem' := (integrable_zero _ _ _).congr (Lp.coeFn_zero ℂ 2 μ).symm
  add_mem' := fun ha hb => (ha.add hb).congr (Lp.coeFn_add _ _).symm
  smul_mem' := fun c f hf => (hf.smul c).congr (Lp.coeFn_smul c f).symm

omit [AddCommGroup G] [TopologicalSpace G] [BorelSpace G] [MeasurableSpace (Dual G)] in
theorem integrableDomain_dense : DenseRange (integrableDomain μ).subtype := by
  intro f
  change f∈closure (range (fun x : integrableDomain μ => (x:Lp ℂ 2 μ)))
  have re : range (fun x : integrableDomain μ => (x : Lp ℂ 2 μ)) = (integrableDomain μ : Set (Lp ℂ 2 μ)) := by
    ext x
    exact ⟨fun ⟨v,e⟩ => e ▸ v.property,fun h => ⟨⟨x,h⟩,rfl⟩⟩
  rw [re]
  change f∈(integrableDomain μ).topologicalClosure
  apply Lp.induction (by norm_num : (2:ℝ≥0∞)≠∞) (fun g => g∈(integrableDomain μ).topologicalClosure) _ _ _ f
  · intro c s hs hm
    exact (integrableDomain μ).le_topologicalClosure (integrable_indicatorConstLp hs hm.ne c)
  · intro _ _ _ _ _ h₁ h₂
    exact (integrableDomain μ).topologicalClosure.add_mem h₁ h₂
  · exact (integrableDomain μ).isClosed_topologicalClosure

def rawFourier (f : Lp ℂ 2 μ) (χ : Dual G) : ℂ := ∫ y, f y * phase χ y ∂μ

omit [MeasurableSpace (Dual G)] in
private theorem wave_int (f : Lp ℂ 2 μ) (hf : Integrable (f:G→ℂ) μ) (χ : Dual G) :
    Integrable (fun y => f y * phase χ y) μ := by
  have ph : Continuous (phase χ) := continuous_subtype_val.comp χ.continuous
  apply hf.norm.mono' ((Lp.aestronglyMeasurable f).mul ph.aestronglyMeasurable)
  apply Eventually.of_forall
  intro y
  change ‖f y * (χ (Multiplicative.ofAdd y):ℂ)‖≤‖f y‖
  simp only [norm_mul,Circle.norm_coe,mul_one,le_refl]

omit [MeasurableSpace (Dual G)] in
theorem rawFourier_add (f g : integrableDomain μ) (χ : Dual G) :
    rawFourier μ (f+g) χ=rawFourier μ f χ+rawFourier μ g χ := by
  unfold rawFourier
  rw [← integral_add (wave_int μ f f.property χ) (wave_int μ g g.property χ)]
  apply integral_congr_ae
  filter_upwards [Lp.coeFn_add (f:Lp ℂ 2 μ) g] with y hy
  rw [hy,Pi.add_apply,add_mul]

omit [BorelSpace G] [MeasurableSpace (Dual G)] in
theorem rawFourier_smul (c : ℂ) (f : integrableDomain μ) (χ : Dual G) :
    rawFourier μ (c • (f:Lp ℂ 2 μ)) χ=c * rawFourier μ f χ := by
  unfold rawFourier
  rw [←integral_const_mul]
  apply integral_congr_ae
  filter_upwards [Lp.coeFn_smul c (f:Lp ℂ 2 μ)] with y hy
  rw [hy,Pi.smul_apply,smul_eq_mul,mul_assoc]

/-- The normalization of ν is fixed by the scalar norm identity. The input
concerns only ordinary character integrals of integrable functions. -/
def fourierOfParseval
    (P : ∀ f : Lp ℂ 2 μ, Integrable (f:G→ℂ) μ →
      ∃ m : MemLp (rawFourier μ f) 2 ν, ‖m.toLp (rawFourier μ f)‖=‖f‖) :
    FourierRealization μ ν := by
  let m (f : integrableDomain μ) := (P f f.property).choose
  let v (f : integrableDomain μ) := (m f).toLp _
  have spec (f : integrableDomain μ) : ‖v f‖=‖(f:Lp ℂ 2 μ)‖ := (P f f.property).choose_spec
  have vae (f : integrableDomain μ) : (v f : Dual G → ℂ)=ᵐ[ν] rawFourier μ f := (m f).coeFn_toLp
  let l : integrableDomain μ →ₗ[ℂ] Lp ℂ 2 ν := {
    toFun := v
    map_add' := fun a b => by
      apply Lp.ext
      filter_upwards [vae (a+b),vae a,vae b,Lp.coeFn_add (v a) (v b)] with χ hab ha hb hsum
      rw [hab,hsum,Pi.add_apply,ha,hb]
      exact rawFourier_add μ a b χ
    map_smul' := fun c a => by
      apply Lp.ext
      filter_upwards [vae (c • a),vae a,Lp.coeFn_smul c (v a)] with χ hc ha hout
      change v (c • a) χ=(c • v a : Lp ℂ 2 ν) χ
      rw [hc,hout,Pi.smul_apply,ha]
      exact rawFourier_smul μ c a χ }
  let j := (integrableDomain μ).subtype
  let E := l.extendOfNorm j
  have on (f : integrableDomain μ) : E (j f)=v f :=
    LinearMap.extendOfNorm_eq (integrableDomain_dense μ) ⟨1,fun g => by change ‖v g‖≤1 * ‖(g:Lp ℂ 2 μ)‖; rw [one_mul]; exact (spec g).le⟩ f
  have norm (f : Lp ℂ 2 μ) : ‖E f‖=‖f‖ :=
    (integrableDomain_dense μ).induction_on f (isClosed_eq E.continuous.norm continuous_norm)
      (fun g => by change ‖E (j g)‖=‖(g:Lp ℂ 2 μ)‖; rw [on,spec])
  refine ⟨⟨E.toLinearMap,norm⟩,?_⟩
  intro f h
  have eqn : E f=v ⟨f,h⟩ := on ⟨f,h⟩
  change (E f : Dual G→ℂ)=ᵐ[ν] rawFourier μ f
  rw [eqn]
  exact vae ⟨f,h⟩

omit [BorelSpace G] in
/-- An isometry satisfying the integral agreement on the dense domain is
unique for the fixed pair of physical Haar measures. -/
theorem realization_unique (F₁ F₂ : FourierRealization μ ν) : F₁=F₂ := by
  have same (f : Lp ℂ 2 μ) : F₁.isometry f=F₂.isometry f :=
    (integrableDomain_dense μ).induction_on f (isClosed_eq F₁.isometry.continuous F₂.isometry.continuous)
      (fun g => Lp.ext ((F₁.integral_ae g g.property).trans (F₂.integral_ae g g.property).symm))
  have maps : F₁.isometry=F₂.isometry := by ext x : 1; exact same x
  cases F₁; cases F₂; congr
end KDClosure.LCAReality
