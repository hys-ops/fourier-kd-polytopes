import KDCompactDualReduction
import KDSubgroupMeasure

/-! The actual normalized Haar measure on the annihilator of a compact open
subgroup, measured inside the ambient Pontryagin dual. -/
noncomputable section
namespace KDClosure.LCAQuotientDual
open Topology MeasureTheory Set CompactDualReduction
open scoped Topology KDClosure.SubgroupMeasure

variable {G : Type*} [CommGroup G] [TopologicalSpace G] [IsTopologicalGroup G]
variable (N : OpenSubgroup G)

local instance : DiscreteTopology (Q N) := QuotientGroup.discreteTopology N.isOpen

omit [IsTopologicalGroup G] in
theorem pull_injective : Function.Injective (pull N) := by
  intro φ ψ eqn
  apply PontryaginDual.ext
  intro u
  obtain ⟨x,rfl⟩ := QuotientGroup.mk'_surjective N.toSubgroup u
  exact congrArg (fun χ : PontryaginDual G => χ x) eqn

theorem pull_closed : IsClosedEmbedding (pull N) :=
  (pull N).continuous.isClosedEmbedding (pull_injective N)

theorem pull_me : MeasurableEmbedding (pull N) := (pull_closed N).measurableEmbedding

omit [IsTopologicalGroup G] in
theorem ann_open (compactN : IsCompact (N : Set G)) : IsOpen (ann N : Set (PontryaginDual G)) := by
  let _ : CompactSpace N := isCompact_iff_compactSpace.mp compactN
  let r := SubgroupMeasure.restrictChar N.toSubgroup
  have same : (ann N : Set (PontryaginDual G)) = r ⁻¹' {1} := by
    ext φ
    constructor
    · intro ht
      exact PontryaginDual.ext fun h => ht _ h.property
    · intro ht x hx
      exact congrArg (fun z : PontryaginDual N => z ⟨x,hx⟩) ht
  rw [same]
  exact (isOpen_discrete _).preimage r.continuous

theorem ann_compact : IsCompact (ann N : Set (PontryaginDual G)) := by
  rw [ann_range]
  exact isCompact_range (pull N).continuous

variable (ν : Measure (PontryaginDual G)) [ν.IsHaarMeasure]

omit [ν.IsHaarMeasure] in
private theorem comap_value (s : Set (PontryaginDual (Q N))) (hs : MeasurableSet s) :
    ν.comap (pull N) s = ν (pull N '' s) :=
  Measure.comap_apply _ (pull_injective N) (fun _ ht => (pull_me N).measurableSet_image.mpr ht) _ hs

omit [ν.IsHaarMeasure] in
theorem comap_mass : ν.comap (pull N) univ = ν (ann N : Set (PontryaginDual G)) := by
  rw [comap_value N ν _ MeasurableSet.univ, image_univ, ←ann_range]

theorem comap_invariant : Measure.IsMulLeftInvariant (ν.comap (pull N)) := by
  apply (forall_measure_preimage_mul_iff _).mp
  intro a s hs
  have ma : Measurable (fun b : PontryaginDual (Q N) => a*b) := (continuous_const.mul continuous_id).measurable
  rw [comap_value N ν _ (hs.preimage ma),
      comap_value N ν _ hs]
  have seteq : pull N '' ((a * ·) ⁻¹' s) = (pull N a * ·) ⁻¹' (pull N '' s) := by
    ext z
    constructor
    · rintro ⟨y,hy,rfl⟩
      exact ⟨a*y,hy,map_mul ..⟩
    · rintro ⟨y,hy,eqn⟩
      refine ⟨a⁻¹*y,?_,?_⟩
      · change a*(a⁻¹*y)∈s
        simpa using hy
      · rw [map_mul, map_inv, eqn]; group
  rw [seteq,measure_preimage_mul]

/-- Pulling ambient Haar back along the quotient-dual embedding gives exactly
the ambient mass of the annihilator times its normalized Haar probability. -/
theorem comap_eq_mass :
    ν.comap (pull N) = ν (ann N : Set (PontryaginDual G)) • SubgroupMeasure.dualHaar (Q N) := by
  let M := ν.comap (pull N)
  let _ : Measure.IsMulLeftInvariant M := comap_invariant N ν
  let _ : IsFiniteMeasure M := ⟨(comap_mass N ν).trans_lt (ann_compact N).measure_lt_top⟩
  have h := Measure.isMulInvariant_eq_smul_of_compactSpace M (SubgroupMeasure.dualHaar (Q N))
  have c := congrArg (fun m : Measure (PontryaginDual (Q N)) => m univ) h
  simp only [Measure.smul_apply, ENNReal.smul_def, smul_eq_mul,measure_univ,mul_one] at c
  change ν.comap (pull N) univ = _ at c
  rw [comap_mass] at c
  exact h.trans (by rw [c,ENNReal.smul_def])

theorem map_mass_eq_restrict : (ν (ann N : Set (PontryaginDual G)) •
    SubgroupMeasure.dualHaar (Q N)).map (pull N) = ν.restrict (ann N : Set (PontryaginDual G)) := by
  rw [←comap_eq_mass,ann_range]
  exact (pull_me N).map_comap _

end KDClosure.LCAQuotientDual
