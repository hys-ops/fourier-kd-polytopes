import KDLCAQuotientDual
import Mathlib.MeasureTheory.Function.LpSpace.Basic
import Mathlib.MeasureTheory.Function.LpSeminorm.Indicator

/-! Continuous zero extension in L² through the actual annihilator. -/
noncomputable section
namespace KDClosure.LCAQuotientDual
open MeasureTheory Set CompactDualReduction Function
open scoped Topology KDClosure.SubgroupMeasure ComplexOrder ENNReal
variable {G : Type*} [CommGroup G] [TopologicalSpace G] [IsTopologicalGroup G]
variable (N : OpenSubgroup G)
local instance : DiscreteTopology (Q N) := QuotientGroup.discreteTopology N.isOpen
variable (ν : Measure (PontryaginDual G)) [ν.IsHaarMeasure]

def zeroExtend (f : PontryaginDual (Q N) → ℂ) : PontryaginDual G → ℂ := extend (pull N) f 0

omit [IsTopologicalGroup G] in
theorem zeroExtend_on (f : PontryaginDual (Q N) → ℂ) (φ : PontryaginDual (Q N)) :
    zeroExtend N f (pull N φ) = f φ := (pull_injective N).extend_apply ..

theorem zeroExtend_off (f : PontryaginDual (Q N) → ℂ) {χ : PontryaginDual G} (h : χ ∉ ann N) :
    zeroExtend N f χ = 0 := by
  have h' : χ ∉ Set.range (pull N) := by rwa [←ann_range]
  exact extend_apply' _ _ χ h'

theorem everywhere_from_range (compactN : IsCompact (N : Set G)) (P : PontryaginDual G → Prop)
    (off : ∀ χ ∉ ann N, P χ) :
    (∀ᵐ χ ∂ν, P χ) ↔ ∀ᵐ φ ∂SubgroupMeasure.dualHaar (Q N), P (pull N φ) := by
  have mass : ν (ann N : Set (PontryaginDual G)) ≠ 0 :=
    ((ann_open N compactN).measure_pos ν ⟨1,(ann N).one_mem⟩).ne'
  have hit : (∀ᵐ χ ∂ν.restrict (ann N : Set _), P χ) ↔ ∀ᵐ φ ∂SubgroupMeasure.dualHaar (Q N), P (pull N φ) := by
    rw [←map_mass_eq_restrict N ν,(pull_me N).ae_map_iff,Measure.ae_ennreal_smul_measure_iff mass]
  refine Iff.trans ?_ hit
  constructor
  · exact fun h => ae_restrict_of_ae h
  · intro h
    filter_upwards [(ae_restrict_iff' (ann_open N compactN).measurableSet).mp h] with χ ht
    exact (em (χ∈ann N)).elim ht (off χ)

theorem zeroExtend_norm (f : PontryaginDual (Q N) → ℂ) :
    eLpNorm (zeroExtend N f) 2 ν = (ν (ann N : Set _)) ^ ((1/(2:ℝ≥0∞)).toReal) *
      eLpNorm f 2 (SubgroupMeasure.dualHaar (Q N)) := by
  have hs : support (zeroExtend N f) ⊆ (ann N : Set _) := fun χ hχ => by
    by_contra h
    exact hχ (zeroExtend_off N f h)
  rw [←eLpNorm_restrict_eq_of_support_subset hs, ←map_mass_eq_restrict N ν,
    (pull_me N).eLpNorm_map_measure,eLpNorm_smul_measure_of_ne_top (by norm_num : (2:ℝ≥0∞)≠∞)]
  have eq : zeroExtend N f ∘ pull N = f := funext (zeroExtend_on N f)
  rw [eq]; rfl

def vector (f : Lp ℂ 2 (SubgroupMeasure.dualHaar (Q N))) : Lp ℂ 2 ν :=
  MemLp.toLp (zeroExtend N f) ⟨((pull_me N).measurable_extend
    (Lp.stronglyMeasurable f).measurable measurable_const).aestronglyMeasurable,by
      rw [zeroExtend_norm]
      apply ENNReal.mul_lt_top _ (Lp.eLpNorm_lt_top f)
      exact (ENNReal.rpow_ne_top_of_nonneg ENNReal.toReal_nonneg (ann_compact N).measure_ne_top).lt_top⟩

theorem vector_ae (f : Lp ℂ 2 (SubgroupMeasure.dualHaar (Q N))) :
    (vector N ν f : PontryaginDual G → ℂ) =ᵐ[ν] zeroExtend N f := MemLp.coeFn_toLp _

theorem vector_norm (f : Lp ℂ 2 (SubgroupMeasure.dualHaar (Q N))) :
    ‖vector N ν f‖ = ((ν (ann N : Set _)) ^ ((1/(2:ℝ≥0∞)).toReal)).toReal * ‖f‖ := by
  rw [Lp.norm_def,eLpNorm_congr_ae (vector_ae N ν f),zeroExtend_norm,ENNReal.toReal_mul,Lp.norm_def]

def extension (compactN : IsCompact (N : Set G)) :
    Lp ℂ 2 (SubgroupMeasure.dualHaar (Q N)) →L[ℂ] Lp ℂ 2 ν :=
  LinearMap.mkContinuous {
    toFun := vector N ν
    map_add' := fun f g => by
      apply Lp.ext
      have a : zeroExtend N (f+g : Lp ℂ 2 _) =ᵐ[ν] fun χ =>
          zeroExtend N f χ + zeroExtend N g χ := by
        apply (everywhere_from_range N ν compactN _ ?_).mpr
        · simp only [zeroExtend_on]
          exact (Lp.coeFn_add f g).mono fun _ h => h
        · intro χ h; simp only [zeroExtend_off N _ h,add_zero]
      filter_upwards [a,vector_ae N ν (f+g),vector_ae N ν f,vector_ae N ν g,
        Lp.coeFn_add (vector N ν f) (vector N ν g)] with χ ha h1 h2 h3 h4
      change vector N ν (f+g) χ = _
      rw [h1,ha,h4,Pi.add_apply,h2,h3]
    map_smul' := fun c f => by
      apply Lp.ext
      have a : zeroExtend N (c • f : Lp ℂ 2 _) =ᵐ[ν] fun χ => c • zeroExtend N f χ := by
        apply (everywhere_from_range N ν compactN _ ?_).mpr
        · simp only [zeroExtend_on]
          exact (Lp.coeFn_smul c f).mono fun _ h => h
        · intro χ h; simp only [zeroExtend_off N _ h,smul_zero]
      filter_upwards [a,vector_ae N ν (c • f),vector_ae N ν f,
        Lp.coeFn_smul c (vector N ν f)] with χ ha h1 h2 h3
      change vector N ν (c • f) χ = _
      rw [h1,ha]; exact (h3.trans (congrArg (c • ·) h2)).symm }
    _ (fun f => (vector_norm N ν f).le)

theorem extension_nonneg (compactN : IsCompact (N : Set G)) (f : Lp ℂ 2 (SubgroupMeasure.dualHaar (Q N))) :
    (∀ᵐ χ ∂ν, 0 ≤ extension N ν compactN f χ) ↔ ∀ᵐ φ ∂SubgroupMeasure.dualHaar (Q N), 0 ≤ f φ := by
  change (∀ᵐ χ ∂ν, 0 ≤ vector N ν f χ) ↔ _
  have h : (∀ᵐ χ ∂ν, 0 ≤ vector N ν f χ) ↔ ∀ᵐ χ ∂ν, 0 ≤ zeroExtend N f χ :=
    Filter.eventually_congr ((vector_ae N ν f).mono fun _ hh => hh ▸ Iff.rfl)
  rw [h,everywhere_from_range N ν compactN _ (fun χ hc => (zeroExtend_off N _ hc).ge)]
  simp only [zeroExtend_on]

end KDClosure.LCAQuotientDual
