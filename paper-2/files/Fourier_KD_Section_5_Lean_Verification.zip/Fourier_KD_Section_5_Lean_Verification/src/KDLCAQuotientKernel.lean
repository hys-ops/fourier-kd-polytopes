import KDLCAQuotient
import KDFourierSynthesis
import Mathlib.MeasureTheory.Function.ConvergenceInMeasure

noncomputable section
namespace KDClosure.LCAQuotient
open MeasureTheory Set CompactCore Filter
open scoped Topology BigOperators InnerProductSpace ENNReal
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
    [MeasurableSpace G] [BorelSpace G] [MeasurableAdd G]
variable (μ : Measure G) [μ.IsAddHaarMeasure] (N : CO G)

/-- An arbitrary lifted vector is literally the normalized pullback of
its coordinates along the quotient map, interpreted almost everywhere. -/
theorem inclusion_ae [Countable (Q N)] (v : Discrete.L2 (Q N)) :
    (inclusion μ N v : G → ℂ) =ᵐ[μ] fun x => v (π N x) * (scale μ N : ℂ) := by
  classical
  let terms (F : Finset (Q N)) := ∑ q ∈ F, v q • atom μ N q
  have summ : Tendsto terms atTop (𝓝 (inclusion μ N v)) := inclusion_hasSum μ N v
  obtain ⟨seq,cofin,limit⟩ := (tendstoInMeasure_of_tendsto_Lp summ).exists_seq_tendsto_ae'
  have each (F : Finset (Q N)) : (terms F : G → ℂ) =ᵐ[μ] fun x =>
      if π N x ∈ F then v (π N x) * (scale μ N : ℂ) else 0 := by
    have component (q : Q N) : ((v q • atom μ N q : Lp ℂ 2 μ) : G → ℂ) =ᵐ[μ]
        fun x => if π N x=q then v q * (scale μ N : ℂ) else 0 := by
      filter_upwards [Lp.coeFn_smul (v q) (atom μ N q),atom_ae μ N q] with x h h'
      rw [h,Pi.smul_apply,h']
      by_cases hx : π N x = q
      · simp [fiber,hx,smul_eq_mul]
      · simp [fiber,hx]
    filter_upwards [Lp.coeFn_fun_finsetSum (p:=2) (μ:=μ) F (fun q => v q • atom μ N q),
      ae_all_iff.mpr component] with x h hc
    change (∑ q ∈ F, v q • atom μ N q) x = _
    rw [h]
    simp only [hc, Finset.sum_ite_eq]
  filter_upwards [limit,ae_all_iff.mpr fun n => each (seq n)] with x hx hx'
  have eventually : ∀ᶠ n in atTop, π N x ∈ seq n :=
    cofin.eventually (eventually_ge_atTop ({π N x} : Finset (Q N)) |>.mono fun s hs =>
      hs (Finset.mem_singleton_self _))
  have constval : (fun n => terms (seq n) x) =ᶠ[atTop] fun _ => v (π N x) * (scale μ N : ℂ) :=
    eventually.mono fun n hn => (hx' n).trans (if_pos hn)
  exact tendsto_nhds_unique hx (tendsto_const_nhds.congr' constval.symm)

def push (A : Discrete.L2 (Q N) →L[ℂ] Discrete.L2 (Q N)) : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ :=
  IsometricSupport.lift (inclusion μ N).toContinuousLinearMap A

theorem push_positive_iff (A : Discrete.L2 (Q N) →L[ℂ] Discrete.L2 (Q N)) :
    (push μ N A).IsPositive ↔ A.IsPositive := by
  constructor
  · intro h
    have hl := IsometricSupport.compress_lift (inclusion μ N).toContinuousLinearMap (inclusion μ N).isometry A
    rw [←hl]; exact h.adjoint_conj _
  · exact fun h => h.conj_adjoint _


variable [Countable (Q N)] [DecidableEq (Q N)]

/-- The kernel is the quotient matrix evaluated on its two cosets with
the two factors coming from Haar normalization. -/
def kernel (A : Discrete.L2 (Q N) →L[ℂ] Discrete.L2 (Q N)) (x y : G) : ℂ :=
  (scale μ N : ℂ)^2 * Discrete.entries A (π N x, π N y)

omit [IsTopologicalAddGroup G] [MeasurableSpace G] [BorelSpace G] [MeasurableAdd G] [Countable (Q N)] in
theorem atom_adjoint_coeff (A : Discrete.L2 (Q N) →L[ℂ] Discrete.L2 (Q N)) (i j : Q N) :
    star ((A.adjoint (lp.single 2 i 1)) j) = Discrete.entries A (i,j) :=
  FourierSynthesis.row_entry A i j

set_option maxHeartbeats 700000 in
/-- For every input in ambient Haar L², integrating the identified kernel
does give the action of the actual lifted continuous operator. -/
theorem push_apply_integral (A : Discrete.L2 (Q N) →L[ℂ] Discrete.L2 (Q N)) (g : Lp ℂ 2 μ) :
    (push μ N A g : G → ℂ) =ᵐ[μ] fun x => ∫ y, kernel μ N A x y * g y ∂μ := by
  let J := (inclusion μ N).toContinuousLinearMap
  have row (x : G) : (∫ y, kernel μ N A x y * g y ∂μ) =
      (scale μ N:ℂ) * inner ℂ (J (A.adjoint (lp.single 2 (π N x) 1))) g := by
    let v := A.adjoint (lp.single 2 (π N x) 1)
    rw [MeasureTheory.L2.inner_def, ←integral_const_mul]
    apply integral_congr_ae
    filter_upwards [inclusion_ae μ N v] with y hy
    change inclusion μ N v y = _ at hy
    change kernel μ N A x y * g y = (scale μ N:ℂ) * inner ℂ (inclusion μ N v y) (g y)
    rw [hy,RCLike.inner_apply, map_mul, Complex.conj_ofReal]
    change (scale μ N:ℂ)^2 * _ * _ = _ * (_ * (star (v (π N y)) * _))
    rw [show star (v (π N y))= _ from atom_adjoint_coeff N A (π N x) (π N y)]
    ring
  filter_upwards [inclusion_ae μ N (A (J.adjoint g))] with x hx
  change inclusion μ N (A (J.adjoint g)) x = _
  rw [hx,row,←J.adjoint_inner_right,A.adjoint_inner_left,lp.inner_single_left]
  simp [RCLike.inner_apply,mul_comm]

end KDClosure.LCAQuotient
