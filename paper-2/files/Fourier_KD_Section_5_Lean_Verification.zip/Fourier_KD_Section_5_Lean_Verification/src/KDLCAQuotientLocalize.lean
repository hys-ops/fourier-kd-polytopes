import KDLCAQuotientSplit
import KDLCARealityCut

/-! The upper-bound position step: an extreme of the *full* physical state
space is supported in a single coset of a maximal compact-open subgroup. -/
noncomputable section
namespace KDClosure.LCAQuotient
open MeasureTheory Filter Set CompactCore LCAReality
open scoped KDClosure.SubgroupMeasure ComplexOrder ENNReal
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
  [T2Space G] [LocallyCompactSpace G] [MeasurableSpace G] [BorelSpace G] [SecondCountableTopology G]
variable (μ : Measure G) [μ.IsAddHaarMeasure] (ν : Measure (Dual G)) [SFinite ν]

theorem position_dichotomy (K : CO G) (F : FourierRealization μ ν) (T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ)
    (e : T∈(ambientStates μ ν F).extremePoints ℝ)
    (S : Set G) (hs : MeasurableSet S) (stable : ∀ x y, (∃ H : CO G, y-x∈subgroup H) → (x∈S ↔ y∈S)) :
    (mask μ S hs).comp T=0 ∨ (mask μ S hs).comp T=T := by
  obtain ⟨pt,_,k,act,h,kd⟩ := e.1
  obtain ⟨sum,part⟩ := cut_pair μ S hs k ν K F T pt act h kd stable
  let P := mask μ S hs
  let U := P.comp T
  let V := (mask μ Sᶜ hs.compl).comp T
  have us := part S hs (Or.inl rfl)
  have vs := part Sᶜ hs.compl (Or.inr rfl)
  have us' : kdCone μ ν F U := ⟨us.1,_,us.2.1,us.2.2.2⟩
  have vs' : kdCone μ ν F V := ⟨vs.1,_,vs.2.1,vs.2.2.2⟩
  have uv : U+V=T := sum
  obtain ⟨a,eqn⟩ := split_proportional μ ν F us' vs' (uv.symm ▸ e)
  rw [uv] at eqn
  have pU : P.comp U=U := by
    have idem := (mask_isStarProjection μ S hs).isIdempotentElem
    ext x : 1
    exact DFunLike.congr_fun idem.eq (T x)
  have ea : a • U=U := by
    calc
      a • U=P.comp (a • T) := by ext x : 1; exact (P.map_smul_of_tower a (T x)).symm
      _ = P.comp U := congrArg P.comp eqn.symm
      _ = U := pU
  by_cases az : a=1
  · exact Or.inr (by simpa only [az,one_smul] using eqn)
  · apply Or.inl
    have zz : (a-1) • U=0 := by rw [sub_smul,ea,one_smul,sub_self]
    exact (smul_eq_zero.mp zz).resolve_left (sub_ne_zero.mpr az)

theorem extreme_one_coset (K : CO G) (maxK : ∀ H : CO G, subgroup H ≤ subgroup K)
    (F : FourierRealization μ ν) (T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ)
    (e : T∈(ambientStates μ ν F).extremePoints ℝ) :
    ∃ i : Q K, (mask μ (fiber K i) (fiber_meas K i)).comp T=T := by
  classical
  let _ : DiscreteTopology (Q K) := QuotientAddGroup.discreteTopology K.val.isOpen
  let _ : Countable (Q K) := countable_of_Lindelof_of_discrete
  have cut (i : Q K) := position_dichotomy μ ν K F T e (fiber K i) (fiber_meas K i) (fun x y h => by
    obtain ⟨H,h⟩ := h
    have eqn : π K x=π K y := (QuotientAddGroup.eq_iff_sub_mem.mpr (maxK H h)).symm
    change π K x=i ↔ π K y=i
    rw [eqn])
  by_contra contra
  push Not at contra
  have zero (i : Q K) := (cut i).resolve_right (contra i)
  have op : T=0 := by
    ext f : 1
    apply Lp.ext
    have member (i : Q K) : ∀ᵐ x ∂μ, x∈fiber K i → T f x=0 := by
      have z : mask μ (fiber K i) (fiber_meas K i) (T f)=0 := DFunLike.congr_fun (zero i) f
      filter_upwards [mask_ae μ (fiber K i) (fiber_meas K i) (T f),Lp.coeFn_zero ℂ 2 μ] with x hx ho
      intro hi
      rw [z,ho,Set.indicator_of_mem hi] at hx
      exact hx.symm
    filter_upwards [ae_all_iff.mpr member,Lp.coeFn_zero ℂ 2 μ] with x hx ho
    exact (hx (π K x) rfl).trans ho.symm
  let tr := e.1.2.1
  have t0 : IsLUB (mass T) 0 := by
    rw [op]
    constructor
    · rintro _ ⟨_,_,_,rfl⟩; simp
    · intro v hv
      apply hv
      exact ⟨0,Fin.elim0,(orthonormal_subsingleton_iff.mpr (fun i : Fin 0 => i.elim0)),by simp⟩
  exact zero_ne_one (t0.unique tr)
end KDClosure.LCAQuotient
