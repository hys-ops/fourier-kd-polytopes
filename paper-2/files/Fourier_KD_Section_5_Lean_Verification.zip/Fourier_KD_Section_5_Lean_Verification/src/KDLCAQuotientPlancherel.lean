import KDLCAQuotientAtomFourier
import KDLCAQuotientTrace
import KDDiscreteTransfer
import KDLCARealitySymbol

/-! On the compact-open quotient sector the genuine Plancherel transform
of the actual displacement row is the quotient KD density extended by zero.
Only the common definition of a Plancherel transform is used. -/
noncomputable section
namespace KDClosure.LCAQuotient
open Set MeasureTheory CompactCoset CompactCore Filter
open scoped KDClosure.SubgroupMeasure ComplexOrder ENNReal InnerProductSpace BigOperators
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
    [MeasurableSpace G] [BorelSpace G] [MeasurableAdd G]
variable (N : CO G)
local instance : DiscreteTopology (Qm N) := QuotientGroup.discreteTopology (openMul N).isOpen
variable (μ : Measure G) [μ.IsAddHaarMeasure] (ν : Measure (Dual G)) [ν.IsHaarMeasure]

omit [IsTopologicalAddGroup G] [BorelSpace G] [MeasurableAdd G] [μ.IsAddHaarMeasure] in
private theorem scale_sq : (scale μ N : ℂ) * (scale μ N : ℂ) = (μ.real (N.val : Set G) : ℂ)⁻¹ := by
  norm_cast
  simp only [scale,←mul_inv_rev,Real.mul_self_sqrt (measureReal_nonneg)]

def normalizedAtom (j : Qm N) : Lp ℂ 2 μ := (scale μ N : ℂ) • atom μ N j

theorem normalizedAtom_ae (j : Qm N) :
    (normalizedAtom N μ j : G → ℂ) =ᵐ[μ] rowAtom N μ j := by
  have hf : fiber N j=coset N (representative N j) := by
    have p : π N (representative N j)=j := qmap_rep N j
    rw [←fiber_coset,p]
  filter_upwards [Lp.coeFn_smul (scale μ N:ℂ) (atom μ N j),atom_ae μ N j] with y h hy
  change ((scale μ N : ℂ) • atom μ N j : Lp ℂ 2 μ) y=_
  rw [h,Pi.smul_apply,hy,hf]
  by_cases b : y∈coset N (representative N j)
  · simpa only [rowAtom,Set.indicator_of_mem b,smul_eq_mul] using scale_sq N μ
  · simp [rowAtom,Set.indicator_of_notMem b]

def shift (x : G) : Lp ℂ 2 μ →ₗᵢ[ℂ] Lp ℂ 2 μ :=
  Lp.compMeasurePreservingₗᵢ ℂ (x+·) (measurePreserving_add_left μ x)

omit [IsTopologicalAddGroup G] [BorelSpace G] in
private theorem shift_ae (x : G) (f : Lp ℂ 2 μ) :
    (shift μ x f : G → ℂ) =ᵐ[μ] fun h => f (x+h) :=
  Lp.coeFn_compMeasurePreserving f (measurePreserving_add_left μ x)

variable [DecidableEq (Qm N)]
local instance : DecidableEq (Q N) := (inferInstance : DecidableEq (Qm N))
local instance [Countable (Qm N)] : Countable (Q N) := (inferInstance : Countable (Qm N))

def displacement (A : Discrete.L2 (Qm N) →L[ℂ] Discrete.L2 (Qm N)) (x : G) : Lp ℂ 2 μ :=
  shift μ x ((scale μ N : ℂ) • inclusion μ N (FourierSynthesis.row A (qmap N x)))

theorem displacement_ae [Countable (Qm N)] (A : Discrete.L2 (Qm N) →L[ℂ] Discrete.L2 (Qm N)) (x : G) :
    (displacement N μ A x : G→ℂ) =ᵐ[μ] fun h => kernel μ N A x (x+h) := by
  let v := FourierSynthesis.row A (qmap N x)
  have raw : (((scale μ N : ℂ) • inclusion μ N v : Lp ℂ 2 μ) : G→ℂ) =ᵐ[μ] fun y => kernel μ N A x y := by
    filter_upwards [Lp.coeFn_smul (scale μ N:ℂ) (inclusion μ N v),inclusion_ae μ N v] with y h h'
    rw [h,Pi.smul_apply,h']
    change _ * (FourierSynthesis.row A (qmap N x) (qmap N y) * _) = _^2 * Discrete.entries A (qmap N x,qmap N y)
    rw [FourierSynthesis.row_entry A (qmap N x) (qmap N y)]
    ring
  exact (shift_ae μ x _).trans ((measurePreserving_add_left μ x).quasiMeasurePreserving.ae_eq_comp raw)

theorem displacement_hasSum (A : Discrete.L2 (Qm N) →L[ℂ] Discrete.L2 (Qm N)) (x : G) :
    HasSum (fun j => Discrete.entries A (qmap N x,j) • shift μ x (normalizedAtom N μ j)) (displacement N μ A x) := by
  let v := FourierSynthesis.row A (qmap N x)
  have summ := (shift μ x).toContinuousLinearMap.hasSum ((inclusion_hasSum μ N v).const_smul (scale μ N : ℂ))
  convert! summ using 1
  ext j : 1
  change Discrete.entries A (qmap N x,j) • shift μ x ((scale μ N : ℂ) • atom μ N j) =
    shift μ x ((scale μ N : ℂ) • (v j • atom μ N j))
  rw [←map_smul,smul_comm, FourierSynthesis.row_entry]

omit [DecidableEq (Qm N)] in
theorem fourier_atom (F : LCAReality.FourierRealization μ ν) (x : G) (j : Qm N) :
    F.isometry (shift μ x (normalizedAtom N μ j))=physicalPhase N ν x j := by
  let t := shift μ x (normalizedAtom N μ j)
  have rep : (t : G → ℂ)=ᵐ[μ] fun h => rowAtom N μ j (x+h) :=
    (shift_ae μ x _).trans ((measurePreserving_add_left μ x).quasiMeasurePreserving.ae_eq_comp (normalizedAtom_ae N μ j))
  have intRaw : Integrable (rowAtom N μ j) μ := by
    have h := coset_meas N (representative N j)
    exact (integrable_indicator_iff h).mpr (integrableOn_const ((coset_compact N _).measure_ne_top))
  have intT : Integrable (t : G → ℂ) μ :=
    ((measurePreserving_add_left μ x).integrable_comp_of_integrable intRaw).congr rep.symm
  apply Lp.ext
  refine (F.integral_ae t intT).trans (Filter.EventuallyEq.trans ?_ (physicalPhase_integral_ae N μ ν x j).symm)
  apply Eventually.of_forall
  intro χ
  calc
    _ = ∫ h, rowAtom N μ j (x+h) * complexChar χ h ∂μ :=
      integral_congr_ae (rep.mono fun h hh => congrArg (· * complexChar χ h) hh)
    _ = ∫ y, rowAtom N μ j y * complexChar χ (y-x) ∂μ := by
      conv_rhs => rw [← integral_add_left_eq_self (μ:=μ) (fun y => rowAtom N μ j y * complexChar χ (y-x)) x]
      simp

theorem transform_displacement (F : LCAReality.FourierRealization μ ν)
    (A : Discrete.L2 (Qm N) →L[ℂ] Discrete.L2 (Qm N)) (x : G) :
    F.isometry (displacement N μ A x) = physicalRow N ν A x := by
  have h := F.isometry.toContinuousLinearMap.hasSum (displacement_hasSum N μ A x)
  exact (show HasSum (fun j => Discrete.entries A (qmap N x,j) • physicalPhase N ν x j) _ by
    simpa only [LinearIsometry.coe_toContinuousLinearMap,map_smul,fourier_atom] using h).unique (row_hasSum N ν A x)

theorem section_state_iff [Countable (Qm N)] [SFinite ν] (F : LCAReality.FourierRealization μ ν)
    (A : Discrete.L2 (Qm N) →L[ℂ] Discrete.L2 (Qm N)) :
    A ∈ DiscreteTransfer.states (Qm N) ↔ (push μ N A).IsPositive ∧
      IsLUB (LCAQuotientTrace.frameMass (push μ N A)) 1 ∧
      ∀ᵐ z ∂μ.prod ν, 0 ≤ F.isometry (displacement N μ A z.1) z.2 := by
  simp_rw [transform_displacement]
  rw [product_ae_iff N ν μ A, push_positive_iff μ N A]
  change _ ∧ _ ∧ _ ↔ _
  exact and_congr_right fun p => and_congr_left fun _ =>
    (LCAQuotientTrace.trace_iff (inclusion μ N) A p 1).symm

end KDClosure.LCAQuotient
