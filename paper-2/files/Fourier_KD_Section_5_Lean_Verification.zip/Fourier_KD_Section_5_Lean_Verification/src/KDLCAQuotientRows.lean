import KDLCAQuotientExtension
import KDLCAQuotientKernel
import KDDiscreteKDRow
import KDCompactCosetAE

/-! The genuine Fourier KD row of a quotient lift, given as the L² sum
of transforms of the normalized finite coset atoms in its matrix kernel. -/
noncomputable section
set_option maxHeartbeats 350000
namespace KDClosure.LCAQuotient
open MeasureTheory Set CompactCore CompactCoset Filter
open scoped Topology KDClosure.SubgroupMeasure ComplexOrder ENNReal BigOperators
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
    [MeasurableSpace G] [BorelSpace G] [MeasurableAdd G] [T2Space G]
variable (N : CO G)
abbrev openMul : OpenSubgroup (Multiplicative G) := ⟨(subgroup N).toSubgroup,N.val.isOpen⟩
abbrev Qm := CompactDualReduction.Q (openMul N)
local instance : DiscreteTopology (Qm N) := QuotientGroup.discreteTopology (openMul N).isOpen
def qmap (x : G) : Qm N := QuotientGroup.mk' (openMul N).toSubgroup (Multiplicative.ofAdd x)

variable (ν : Measure (Dual G)) [ν.IsHaarMeasure] [DecidableEq (Qm N)]

def physicalPhase (x : G) (j : Qm N) : Lp ℂ 2 ν :=
  LCAQuotientDual.extension (openMul N) ν N.property (DiscreteKDRow.phase (Qm N) (qmap N x) j)

def physicalRow (A : Discrete.L2 (Qm N) →L[ℂ] Discrete.L2 (Qm N)) (x : G) : Lp ℂ 2 ν :=
  LCAQuotientDual.extension (openMul N) ν N.property (DiscreteKDRow.rowDensity (Qm N) A (qmap N x))

omit [MeasurableSpace G] [BorelSpace G] [MeasurableAdd G] [T2Space G] in
theorem row_hasSum (A : Discrete.L2 (Qm N) →L[ℂ] Discrete.L2 (Qm N)) (x : G) :
    HasSum (fun j => Discrete.entries A (qmap N x,j) • physicalPhase N ν x j) (physicalRow N ν A x) := by
  have hs := (LCAQuotientDual.extension (openMul N) ν N.property).hasSum
    (DiscreteKDRow.row_hasSum (Qm N) A (qmap N x))
  simpa only [physicalPhase,physicalRow,map_smul] using hs

omit [MeasurableSpace G] [BorelSpace G] [MeasurableAdd G] [T2Space G] in
/-- Row positivity is exactly reflected in quotient frequency coordinates. -/
theorem row_nonneg_iff (A : Discrete.L2 (Qm N) →L[ℂ] Discrete.L2 (Qm N)) (x : G) :
    (∀ᵐ χ ∂ν, 0≤physicalRow N ν A x χ) ↔
    ∀ᵐ φ ∂SubgroupMeasure.dualHaar (Qm N), 0≤DiscreteKDRow.rowDensity (Qm N) A (qmap N x) φ :=
  LCAQuotientDual.extension_nonneg (openMul N) ν N.property _

variable (μ : Measure G) [μ.IsAddHaarMeasure]

omit [T2Space G] [DecidableEq (Qm N)] [BorelSpace G] [IsTopologicalAddGroup G] in
private theorem qmap_ae_all (P : Qm N → Prop) :
    (∀ᵐ x ∂μ, P (qmap N x)) ↔ ∀ i, P i := by
  constructor
  · intro h i
    by_contra hn
    have s : fiber N i ⊆ {x | ¬P (qmap N x)} := by
      intro x hx
      have eq : qmap N x=i := hx
      change ¬P (qmap N x)
      rwa [eq]
    have z := measure_mono_null s (ae_iff.mp h)
    have zm := (fiber_mass μ N (show Q N from i)).symm.trans z
    exact (N.val.isOpen.measure_pos μ ⟨0,N.val.zero_mem⟩).ne' zm
  · exact fun h => Filter.Eventually.of_forall fun x => h _

private theorem product_by_label {X I Y : Type*} [MeasurableSpace X] [MeasurableSpace I]
    [MeasurableSpace Y] [Countable I] [MeasurableSingletonClass I]
    (m : Measure X) (n : Measure Y) [SFinite n] (p : X → I) (mp : Measurable p)
    (allp : ∀ P : I → Prop, (∀ᵐ x ∂m, P (p x)) ↔ ∀ i, P i) (g : I → Lp ℂ 2 n) :
    (∀ᵐ z ∂m.prod n, 0≤g (p z.1) z.2) ↔ ∀ i, ∀ᵐ y ∂n, 0≤g i y := by
  have gm : Measurable (fun z : I × Y => g z.1 z.2) :=
    measurable_from_prod_countable_right fun i => (Lp.stronglyMeasurable (g i)).measurable
  have k : Measurable (fun z : X × Y => g (p z.1) z.2) := gm.comp (mp.prodMap measurable_id)
  have ms : MeasurableSet {z : X × Y | 0≤g (p z.1) z.2} := by
    simp only [Complex.nonneg_iff,Set.ofPred_and]
    exact (measurableSet_le measurable_const (Complex.continuous_re.measurable.comp k)).inter
      (measurableSet_eq_fun measurable_const (Complex.continuous_im.measurable.comp k))
  exact (Measure.ae_prod_iff_ae_ae ms).trans (allp (fun i => ∀ᵐ y ∂n, 0≤g i y))

omit [T2Space G] in
/-- Arbitrary square-summable matrix rows and an arbitrary countable quotient.
The left side is positivity on actual ambient position × dual Haar. -/
theorem product_ae_iff [Countable (Qm N)] [SFinite ν]
    (A : Discrete.L2 (Qm N) →L[ℂ] Discrete.L2 (Qm N)) :
    (∀ᵐ z ∂μ.prod ν, 0≤physicalRow N ν A z.1 z.2) ↔ DiscreteKDRow.RowNonneg (Qm N) A := by
  let _ : MeasurableSpace (Qm N) := ⊤
  let _ : MeasurableSingletonClass (Qm N) := ⟨fun _ => MeasurableSpace.measurableSet_top⟩
  let g (i : Qm N) := LCAQuotientDual.extension (openMul N) ν N.property (DiscreteKDRow.rowDensity (Qm N) A i)
  have pm : Measurable (qmap N) := measurable_to_countable' fun i => fiber_meas N i
  exact (product_by_label μ ν (qmap N) pm (qmap_ae_all N μ) g).trans
    (forall_congr' fun i => LCAQuotientDual.extension_nonneg (openMul N) ν N.property _)

end KDClosure.LCAQuotient
