import KDLCAQuotientSplitTrace

noncomputable section
namespace KDClosure.LCAQuotient
open MeasureTheory Filter Set CompactCore CompactCoset
open scoped KDClosure.SubgroupMeasure ComplexOrder ENNReal ComplexConjugate
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
  [MeasurableSpace G] [BorelSpace G] [SecondCountableTopology G]
variable (μ : Measure G) [SFinite μ] [μ.IsAddLeftInvariant]
variable (ν : Measure (Dual G)) [SFinite ν]

def kdCone (F : LCAReality.FourierRealization μ ν) (S : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ) : Prop :=
  S.IsPositive ∧ ∃ k, ActsBy μ S k ∧ ambientKD μ ν F k

omit [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G] [BorelSpace G] [SecondCountableTopology G] [μ.IsAddLeftInvariant] in
theorem acts_smul {S : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ} {k : Lp ℂ 2 (μ.prod μ)}
    (act : ActsBy μ S k) (c : ℝ) : ActsBy μ (c • S) (c • k) := by
  intro f
  filter_upwards [act f,Lp.coeFn_smul c (S f),Measure.ae_ae_of_ae_prod (Lp.coeFn_smul c k)] with x ha hb hc
  change (c • S f : Lp ℂ 2 μ) x = _
  rw [hb,Pi.smul_apply,ha,←integral_smul]
  apply integral_congr_ae
  filter_upwards [hc] with y hy
  change (c • k : Lp ℂ 2 (μ.prod μ)) (x,y)=c • k (x,y) at hy
  rw [hy,smul_mul_assoc]

theorem rowAt_smul (k : Lp ℂ 2 (μ.prod μ)) (c : ℝ) :
    ∀ᵐ x ∂μ, LCAReality.rowAt μ (c • k) x=c • LCAReality.rowAt μ k x := by
  have eqn := (measurePreserving_prod_add μ μ).quasiMeasurePreserving.ae (Lp.coeFn_smul c k)
  filter_upwards [LCAReality.rowAt_ae μ (c • k),LCAReality.rowAt_ae μ k,Measure.ae_ae_of_ae_prod eqn] with x hs h ha
  apply Lp.ext
  filter_upwards [hs,h,ha,Lp.coeFn_smul c (LCAReality.rowAt μ k x)] with y es e ea er
  rw [es,er,Pi.smul_apply,e]
  exact ea

private theorem pos_real_smul {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℂ X] [CompleteSpace X]
    {S : X →L[ℂ] X} (p : S.IsPositive) {a : ℝ} (h : 0 ≤ a) : (a • S).IsPositive :=
  (ContinuousLinearMap.nonneg_iff_isPositive _).mp (smul_nonneg h ((ContinuousLinearMap.nonneg_iff_isPositive _).mpr p))

omit [SFinite ν] in
theorem cone_rescale (F : LCAReality.FourierRealization μ ν) {S : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ}
    (m : kdCone μ ν F S) {a : ℝ} (p : 0<a) (t : IsLUB (mass S) a) :
    a⁻¹ • S ∈ ambientStates μ ν F := by
  obtain ⟨pos,k,act,kd⟩ := m
  have pos' := pos_real_smul pos (inv_nonneg.mpr p.le)
  have tr := trace_rescale pos p t
  have act' := acts_smul μ act a⁻¹
  refine ⟨pos',tr,_,act',hermitian_of_acts μ _ pos' ⟨_,tr.1⟩ act',?_⟩
  obtain ⟨q,mq,rows,sign⟩ := kd
  refine ⟨fun z => a⁻¹ • q z,mq.const_smul (a⁻¹ : ℝ),?_,sign.mono (fun _ h => smul_nonneg (inv_nonneg.mpr p.le) h)⟩
  filter_upwards [rows,rowAt_smul μ k a⁻¹] with x hx he
  rw [he,show F.isometry (a⁻¹ • LCAReality.rowAt μ k x) = a⁻¹ • F.isometry (LCAReality.rowAt μ k x) from
    F.isometry.toLinearMap.map_smul_of_tower a⁻¹ _]
  filter_upwards [hx,Lp.coeFn_smul a⁻¹ (F.isometry (LCAReality.rowAt μ k x))] with χ hq hs
  rw [hs,Pi.smul_apply,hq]

omit [SFinite ν] in
theorem split_proportional (F : LCAReality.FourierRealization μ ν)
    {S U : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ} (s : kdCone μ ν F S) (u : kdCone μ ν F U)
    (ext : (S+U)∈(ambientStates μ ν F).extremePoints ℝ) :
    ∃ a : ℝ, S=a • (S+U) := by
  obtain ⟨a,b,na,nb,ab,ta,tb⟩ := trace_split s.1 u.1 ext.1.2.1
  rcases na.eq_or_lt with z|pa
  · rw [←z] at ta
    exact ⟨0,by rw [trace_zero s.1 ta,zero_smul]⟩
  rcases nb.eq_or_lt with z|pb
  · rw [←z] at tb
    exact ⟨1,by rw [trace_zero u.1 tb,add_zero,one_smul]⟩
  have sa := cone_rescale μ ν F s pa ta
  have sb := cone_rescale μ ν F u pb tb
  have e := ext.2 sa sb ⟨a,b,pa,pb,ab,by simp [smul_smul,pa.ne',pb.ne']⟩
  exact ⟨a,by rw [←e,smul_smul,mul_inv_cancel₀ pa.ne',one_smul]⟩
end KDClosure.LCAQuotient
