import KDLCAQuotientState
import KDCompactFourierTransfer
/-! Intrinsic positive trace splitting and normalization of positive summands. -/
noncomputable section
namespace KDClosure.LCAQuotient
open CompactFourier Set Discrete
open scoped InnerProductSpace BigOperators ComplexOrder ENNReal
variable {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℂ H] [CompleteSpace H]
abbrev mass (T : H→L[ℂ]H) := LCAQuotientTrace.frameMass T

omit [CompleteSpace H] in
private theorem frameDom {S T : H→L[ℂ]H} (p : (T-S).IsPositive) (h : BddAbove (mass T)) :
    BddAbove (mass S) := by
  obtain ⟨v,hv⟩ := h
  refine ⟨v,?_⟩
  rintro r ⟨n,e,on,rfl⟩
  apply le_trans _ (hv ⟨n,e,on,rfl⟩)
  apply Finset.sum_le_sum
  intro i _
  have t := p.re_inner_nonneg_right (e i)
  change 0 ≤ (inner ℂ (e i) (T (e i) - S (e i))).re at t
  simpa only [inner_sub_right,Complex.sub_re,sub_nonneg] using t

private def coords {I : Type*} (b : HilbertBasis I ℂ H) (T : H→L[ℂ]H) :=
  CompactFourier.unitaryPush b.repr T

private theorem spec {I : Type*} [DecidableEq I] (b : HilbertBasis I ℂ H) {T : H→L[ℂ]H}
    (p : T.IsPositive) (bd : BddAbove (mass T)) :
    Summable (fun i => (entries (coords b T) (i,i)).re) ∧
    IsLUB (mass T) (∑' i, (entries (coords b T) (i,i)).re) := by
  have pos := (CompactFourier.positive_unitary_iff b.repr T).mpr p
  have eqn : finiteFrameMass (coords b T)=mass T := CompactFourier.frameMass_unitary b.repr T
  have hs := (boundedFrames_iff_diagonal pos).mp (eqn.symm ▸ bd)
  exact ⟨hs,eqn ▸ trace_isLUB pos hs⟩

private theorem diag_nn {I : Type*} [DecidableEq I] (b : HilbertBasis I ℂ H) {T : H→L[ℂ]H}
    (p : T.IsPositive) (i : I) : 0 ≤ (entries (coords b T) (i,i)).re :=
  ((CompactFourier.positive_unitary_iff b.repr T).mpr p).re_inner_nonneg_right _

private theorem pos_root (T : H →L[ℂ] H) (p : T.IsPositive) :
    ∃ S : H →L[ℂ] H, ∀ v, T v=S.adjoint (S v) := by
  let S := CFC.sqrt T
  have sa : S.adjoint = S := (CFC.sqrt_nonneg T).star_eq
  refine ⟨S,fun v => ?_⟩
  rw [sa]
  exact DFunLike.congr_fun (CFC.sqrt_mul_sqrt_self T ((ContinuousLinearMap.nonneg_iff_isPositive T).mpr p)).symm v

private theorem coordinate_zero {I : Type*} [DecidableEq I] {A : Discrete.L2 I →L[ℂ] Discrete.L2 I}
    (p : A.IsPositive) (h : ∀ i, (entries A (i,i)).re=0) : A=0 := by
  obtain ⟨S,fact⟩ := pos_root A p
  apply entries_injective
  ext ⟨i,j⟩ : 1
  have z := h j
  change (inner ℂ (lp.single 2 j 1) (A (lp.single 2 j 1))).re=0 at z
  rw [fact,S.adjoint_inner_right] at z
  have zs := (norm_sq_eq_re_inner (𝕜:=ℂ) (S (lp.single 2 j (1:ℂ)))).trans z
  have nul : S (lp.single 2 j (1:ℂ))=0 := norm_eq_zero.mp (by nlinarith [norm_nonneg (S (lp.single 2 j (1:ℂ)))])
  change inner ℂ _ (A (lp.single 2 j 1))=inner ℂ (lp.single 2 i (1:ℂ)) (0 : Discrete.L2 I)
  rw [fact,nul,map_zero]

theorem trace_zero {T : H→L[ℂ]H} (p : T.IsPositive) (h : IsLUB (mass T) 0) : T=0 := by
  classical
  obtain ⟨I,b,_⟩ := exists_hilbertBasis ℂ H
  obtain ⟨s,t⟩ := spec b p ⟨0,h.1⟩
  have eqn := t.unique h
  have z : coords b T=0 := coordinate_zero ((CompactFourier.positive_unitary_iff b.repr T).mpr p) (fun i =>
    le_antisymm ((s.le_tsum i (fun j _ => diag_nn b p j)).trans_eq eqn) (diag_nn b p i))
  ext x : 1
  apply b.repr.injective
  have e := DFunLike.congr_fun z (b.repr x)
  change b.repr (T (b.repr.symm (b.repr x)))=0 at e
  rw [b.repr.symm_apply_apply] at e
  simpa only [zero_apply,map_zero] using e


theorem trace_split {S U : H→L[ℂ]H} (p : S.IsPositive) (q : U.IsPositive) (t : IsLUB (mass (S+U)) 1) :
    ∃ a b : ℝ, 0≤a ∧ 0≤b ∧ a+b=1 ∧ IsLUB (mass S) a ∧ IsLUB (mass U) b := by
  classical
  obtain ⟨I,e,_⟩ := exists_hilbertBasis ℂ H
  have bd : BddAbove (mass (S+U)) := ⟨1,t.1⟩
  obtain ⟨sa,ta⟩ := spec e p (frameDom (S:=S) (by simpa using q : (S+U-S).IsPositive) bd)
  obtain ⟨sb,tb⟩ := spec e q (frameDom (S:=U) (by simpa using p : (S+U-U).IsPositive) bd)
  obtain ⟨_,tc⟩ := spec e (p.add q) bd
  refine ⟨_,_,tsum_nonneg (diag_nn e p),tsum_nonneg (diag_nn e q),?_,ta,tb⟩
  rw [←sa.tsum_add sb,←tc.unique t]
  apply tsum_congr
  intro i
  have eqn : coords e (S+U)=coords e S+coords e U := by ext x : 1; simp [coords,unitaryPush]
  rw [eqn,map_add]
  rfl

theorem trace_rescale {T : H→L[ℂ]H} {a : ℝ} (p : T.IsPositive) (pos : 0<a) (t : IsLUB (mass T) a) :
    IsLUB (mass (a⁻¹ • T)) 1 := by
  classical
  obtain ⟨I,b,_⟩ := exists_hilbertBasis ℂ H
  obtain ⟨s,ts⟩ := spec b p ⟨a,t.1⟩
  have e : coords b (a⁻¹ • T) = a⁻¹ • coords b T := by ext x : 1; simp [coords,unitaryPush]
  have ep (i : I) : (entries (coords b (a⁻¹ • T)) (i,i)).re = a⁻¹ * (entries (coords b T) (i,i)).re := by
    rw [e,map_smul,Pi.smul_apply,Complex.smul_re,smul_eq_mul]
  have tot : HasSum (fun i => (entries (coords b (a⁻¹ • T)) (i,i)).re) 1 := by
    simp only [ep]
    simpa only [ts.unique t,inv_mul_cancel₀ pos.ne'] using s.hasSum.mul_left a⁻¹
  have ps : (a⁻¹ • T).IsPositive := by
    apply (ContinuousLinearMap.nonneg_iff_isPositive _).mp
    exact smul_nonneg (inv_nonneg.mpr pos.le) ((ContinuousLinearMap.nonneg_iff_isPositive _).mpr p)
  have tr := trace_isLUB ((CompactFourier.positive_unitary_iff b.repr (a⁻¹ • T)).mpr ps) tot.summable
  change IsLUB (finiteFrameMass (coords b (a⁻¹ • T))) _ at tr
  change IsLUB _ (∑' i, (entries (coords b (a⁻¹ • T)) (i,i)).re) at tr
  rw [tot.tsum_eq] at tr
  have eqn : finiteFrameMass (coords b (a⁻¹ • T))=mass (a⁻¹ • T) := CompactFourier.frameMass_unitary b.repr _
  exact eqn ▸ tr
end KDClosure.LCAQuotient
