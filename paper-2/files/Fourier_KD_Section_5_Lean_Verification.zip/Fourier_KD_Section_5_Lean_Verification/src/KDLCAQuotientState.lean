import KDLCAQuotientPlancherel
import KDLCAQuotientUniqueness

/-! Full ambient states. The test quantifies over every position-space state,
not just operators in the image of the quotient isometry. -/
noncomputable section
set_option maxHeartbeats 800000
namespace KDClosure.LCAQuotient
open MeasureTheory Set CompactCoset CompactCore Filter
open scoped KDClosure.SubgroupMeasure ComplexOrder ENNReal InnerProductSpace ComplexConjugate
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
    [MeasurableSpace G] [BorelSpace G] [MeasurableAdd G] [MeasurableNeg G]
    [SecondCountableTopology G]
variable (μ : Measure G) [SFinite μ] (ν : Measure (Dual G)) [SFinite ν]

def ambientKD (F : LCAReality.FourierRealization μ ν) (k : Lp ℂ 2 (μ.prod μ)) : Prop :=
  ∃ q : G × Dual G → ℂ, Measurable q ∧
    (∀ᵐ x ∂μ, (fun χ => q (x,χ)) =ᵐ[ν] (F.isometry (LCAReality.rowAt μ k x) : Dual G → ℂ)) ∧
    ∀ᵐ z ∂μ.prod ν, 0 ≤ q z

omit [IsTopologicalAddGroup G] [BorelSpace G] [MeasurableAdd G] [MeasurableNeg G] [SecondCountableTopology G] [SFinite μ] in
theorem ambientKD_rows (F : LCAReality.FourierRealization μ ν) (k : Lp ℂ 2 (μ.prod μ))
    (kd : ambientKD μ ν F k) :
    ∀ᵐ x ∂μ, ∀ᵐ χ ∂ν, 0≤F.isometry (LCAReality.rowAt μ k x) χ := by
  obtain ⟨_,_,row,sign⟩ := kd
  filter_upwards [row,Measure.ae_ae_of_ae_prod sign] with x hx hs
  filter_upwards [hx,hs] with χ eqn ge
  exact eqn ▸ ge

def ambientStates (F : LCAReality.FourierRealization μ ν) :
    Set (Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ) :=
  {T | T.IsPositive ∧ IsLUB (LCAQuotientTrace.frameMass T) 1 ∧
    ∃ k : Lp ℂ 2 (μ.prod μ), ActsBy μ T k ∧
      (∀ᵐ z ∂μ.prod μ, k z=conj (k z.swap)) ∧ ambientKD μ ν F k}

def HasInfiniteExtreme (F : LCAReality.FourierRealization μ ν) : Prop :=
  ∃ T ∈ (ambientStates μ ν F).extremePoints ℝ, ¬FiniteDimensional ℂ (LinearMap.range T.toLinearMap)

variable [μ.IsAddHaarMeasure] [ν.IsHaarMeasure]
variable (N : CO G)
local instance : DiscreteTopology (Qm N) := QuotientGroup.discreteTopology (openMul N).isOpen
variable [DecidableEq (Qm N)] [Countable (Qm N)]
local instance : DecidableEq (Q N) := (inferInstance : DecidableEq (Qm N))
local instance : Countable (Q N) := (inferInstance : Countable (Qm N))

private def unshifted (A : Discrete.L2 (Qm N) →L[ℂ] Discrete.L2 (Qm N)) (x : G) : Lp ℂ 2 μ :=
  shift μ (-x) (displacement N μ A x)

omit [MeasurableNeg G] [SecondCountableTopology G] [SFinite μ] in
private theorem unshifted_ae (A : Discrete.L2 (Qm N) →L[ℂ] Discrete.L2 (Qm N)) (x : G) :
    (unshifted μ N A x : G→ℂ)=ᵐ[μ] fun y => kernel μ N A x y := by
  have h := ((measurePreserving_add_left μ (-x)).quasiMeasurePreserving.ae_eq_comp (displacement_ae N μ A x))
  have s := Lp.coeFn_compMeasurePreserving (displacement N μ A x) (measurePreserving_add_left μ (-x))
  exact s.trans (h.mono fun y hy => by simpa [Function.comp_def] using hy)

omit [MeasurableNeg G] in
theorem rowAt_push (A : Discrete.L2 (Qm N) →L[ℂ] Discrete.L2 (Qm N))
    (k : Lp ℂ 2 (μ.prod μ)) (act : ActsBy μ (push μ N A) k) :
    ∀ᵐ x ∂μ, LCAReality.rowAt μ k x=displacement N μ A x := by
  have r := determine_rows μ (ordinaryRow μ k) (unshifted μ N A) (fun f => by
    filter_upwards [ordinaryRow_ae μ k,act f,push_apply_integral μ N A f] with x hx a b
    exact (integral_congr_ae (hx.mono fun y h => congrArg (· * f y) h)).trans
      (a.symm.trans (b.trans (integral_congr_ae ((unshifted_ae μ N A x).symm.mono fun y h => congrArg (· * f y) h)))))
  filter_upwards [r,ordinaryRow_ae μ k,LCAReality.rowAt_ae μ k] with x eq1 h1 h2
  rw [eq1] at h1
  have row : (fun y => k (x,y)) =ᵐ[μ] fun y => kernel μ N A x y := h1.symm.trans (unshifted_ae μ N A x)
  exact Lp.ext (h2.trans (((measurePreserving_add_left μ x).quasiMeasurePreserving.ae_eq_comp row).trans
    (displacement_ae N μ A x).symm))

private theorem measurable_by_position {X I Y : Type*} [MeasurableSpace X] [MeasurableSpace Y] [Countable I]
    (p : X → I) (mp : ∀ i, MeasurableSet {x | p x=i}) (g : I → Y → ℂ) (hg : ∀ i, Measurable (g i)) :
    Measurable (fun z : X × Y => g (p z.1) z.2) := by
  let _ : MeasurableSpace I := ⊤
  let _ : MeasurableSingletonClass I := ⟨fun _ => MeasurableSpace.measurableSet_top⟩
  have pm : Measurable p := measurable_to_countable' mp
  have gm : Measurable (fun z : I×Y => g z.1 z.2) := measurable_from_prod_countable_right hg
  exact gm.comp (pm.prodMap measurable_id)

omit [MeasurableNeg G] [MeasurableAdd G] [SFinite μ] [SFinite ν] [SecondCountableTopology G] in
theorem physicalRow_measurable (A : Discrete.L2 (Qm N) →L[ℂ] Discrete.L2 (Qm N)) :
    Measurable (fun z : G × Dual G => physicalRow N ν A z.1 z.2) := by
  let g (i : Qm N) := LCAQuotientDual.extension (openMul N) ν N.property (DiscreteKDRow.rowDensity (Qm N) A i)
  change Measurable (fun z : G × Dual G => (g (qmap N z.1) : Dual G → ℂ) z.2)
  exact measurable_by_position (qmap N) (fun i => fiber_meas N i) (fun i => (g i : Dual G → ℂ))
    (fun i => (Lp.stronglyMeasurable (g i)).measurable)

omit [MeasurableNeg G] in
theorem ambientKD_push_iff (F : LCAReality.FourierRealization μ ν)
    (A : Discrete.L2 (Qm N) →L[ℂ] Discrete.L2 (Qm N)) (k : Lp ℂ 2 (μ.prod μ)) (act : ActsBy μ (push μ N A) k) :
    ambientKD μ ν F k ↔ ∀ᵐ z : G × Dual G ∂μ.prod ν, 0 ≤ F.isometry (displacement N μ A z.1) z.2 := by
  simp_rw [transform_displacement]
  have rep : ∀ᵐ x ∂μ, physicalRow N ν A x = F.isometry (LCAReality.rowAt μ k x) := by
    filter_upwards [rowAt_push μ N A k act] with x e
    rw [e,transform_displacement]
  constructor
  · intro kd
    have hm := physicalRow_measurable ν N A
    have ms : MeasurableSet {z : G × Dual G | 0≤physicalRow N ν A z.1 z.2} := by
      simp only [Complex.nonneg_iff,Set.ofPred_and]
      exact (measurableSet_le measurable_const (Complex.continuous_re.measurable.comp hm)).inter
        (measurableSet_eq_fun measurable_const (Complex.continuous_im.measurable.comp hm))
    apply (Measure.ae_prod_iff_ae_ae ms).mpr
    filter_upwards [ambientKD_rows μ ν F k kd,rep] with x hx e
    rwa [e]
  · intro sign
    exact ⟨_,physicalRow_measurable ν N A,rep.mono (fun x e => e ▸ Filter.EventuallyEq.rfl),sign⟩

omit [MeasurableNeg G] in
theorem push_mem_iff (F : LCAReality.FourierRealization μ ν)
    (A : Discrete.L2 (Qm N) →L[ℂ] Discrete.L2 (Qm N)) :
    A ∈ DiscreteTransfer.states (Qm N) ↔ push μ N A ∈ ambientStates μ ν F := by
  rw [section_state_iff N μ ν F A]
  constructor
  · rintro ⟨p,t,q⟩
    obtain ⟨k,s,a⟩ := CompactFourier.exists_physical_kernel (push μ N A) p ⟨1,t.1⟩
    exact ⟨p,t,k,a,s,(ambientKD_push_iff μ ν N F A k a).mpr q⟩
  · rintro ⟨p,t,k,a,_,q⟩
    exact ⟨p,t,(ambientKD_push_iff μ ν N F A k a).mp q⟩

omit [MeasurableNeg G] in
theorem push_extreme (F : LCAReality.FourierRealization μ ν)
    {A : Discrete.L2 (Qm N) →L[ℂ] Discrete.L2 (Qm N)}
    (e : A ∈ (DiscreteTransfer.states (Qm N)).extremePoints ℝ) :
    push μ N A ∈ (ambientStates μ ν F).extremePoints ℝ :=
  IsometricSupport.extreme_lift (inclusion μ N).toContinuousLinearMap (inclusion μ N).isometry
    _ _ (fun _ h => h.1) (push_mem_iff μ ν N F) e

omit [MeasurableNeg G] in
theorem infinite_extreme_of_quotient (F : LCAReality.FourierRealization μ ν)
    (h : DiscreteTransfer.HasInfiniteExtreme (Qm N)) : HasInfiniteExtreme μ ν F := by
  obtain ⟨A,e,hi⟩ := h
  refine ⟨push μ N A,push_extreme μ ν N F e,?_⟩
  let iso := IsometricSupport.rangeEquiv (inclusion μ N).toContinuousLinearMap (inclusion μ N).isometry A
  intro finite
  let _ : FiniteDimensional ℂ (LinearMap.range (IsometricSupport.lift (inclusion μ N).toContinuousLinearMap A).toLinearMap) := finite
  exact hi (FiniteDimensional.of_injective iso.toLinearMap iso.injective)

end KDClosure.LCAQuotient
