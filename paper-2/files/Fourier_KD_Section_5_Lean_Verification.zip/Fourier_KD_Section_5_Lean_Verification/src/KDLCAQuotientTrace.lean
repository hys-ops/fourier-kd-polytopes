import KDOperatorTrace
import KDIsometricSupport
import Mathlib.Analysis.InnerProductSpace.StarOrder

/-! Trace-one correspondence for an isometric copy of a discrete Hilbert space,
including arbitrary ambient Hilbert spaces and infinite-dimensional supports. -/
noncomputable section
namespace KDClosure.LCAQuotientTrace
open Set Discrete ContinuousLinearMap
open scoped InnerProductSpace BigOperators ENNReal ComplexOrder
variable {D K : Type*} [DecidableEq D] [NormedAddCommGroup K] [InnerProductSpace ℂ K] [CompleteSpace K]

def frameMass (T : K →L[ℂ] K) : Set ℝ :=
  {r | ∃ n : ℕ, ∃ v : Fin n → K, Orthonormal ℂ v ∧
    (∑ j, (inner ℂ (v j) (T (v j))).re)=r}

omit [DecidableEq D] in
theorem source_tests (J : Discrete.L2 D →ₗᵢ[ℂ] K) (A : Discrete.L2 D →L[ℂ] Discrete.L2 D) :
    finiteFrameMass A ⊆ frameMass (IsometricSupport.lift J.toContinuousLinearMap A) := by
  rintro r ⟨n,v,hv,rfl⟩
  refine ⟨n,fun i => J (v i),hv.comp_linearIsometry J ,Finset.sum_congr rfl (fun i _ => ?_)⟩
  have left : J.toContinuousLinearMap.adjoint ∘L J.toContinuousLinearMap=1 :=
    (isometry_iff_adjoint_comp_self _).mp J.isometry
  change (inner ℂ (J (v i)) (J (A (J.toContinuousLinearMap.adjoint (J (v i)))))).re = _
  rw [J.inner_map_map]
  exact congrArg (fun z => (inner ℂ (v i) (A z)).re) (DFunLike.congr_fun left (v i))

private theorem positive_square {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℂ X]
    [CompleteSpace X] (A : X →L[ℂ] X) (p : A.IsPositive) :
    ∃ S : X →L[ℂ] X, S.adjoint=S ∧ ∀ x, A x = S.adjoint (S x) := by
  let S := CFC.sqrt A
  have sa : S.adjoint = S := (CFC.sqrt_nonneg A).star_eq
  refine ⟨S,sa,fun x => ?_⟩
  rw [sa]
  exact DFunLike.congr_fun (CFC.sqrt_mul_sqrt_self A ((nonneg_iff_isPositive A).mpr p)).symm x

theorem upper {A : Discrete.L2 D →L[ℂ] Discrete.L2 D} (J : Discrete.L2 D →ₗᵢ[ℂ] K)
    (hA : A.IsPositive) (hd : Summable fun i => (entries A (i,i)).re) :
    ∑' i, (entries A (i,i)).re ∈ upperBounds (frameMass (IsometricSupport.lift J.toContinuousLinearMap A)) := by
  rintro r ⟨n,v,hv,rfl⟩
  obtain ⟨S,sa,fact⟩ := positive_square A hA
  let e (i : D) : Discrete.L2 D := lp.single 2 i (1:ℂ)
  let T := J.toContinuousLinearMap
  have normSrc (x : Discrete.L2 D) : (inner ℂ x (A x)).re=‖S x‖^2 := by
    rw [fact,S.adjoint_inner_right]; exact (norm_sq_eq_re_inner (𝕜:=ℂ) _).symm
  have normDst (x : K) : (inner ℂ x (IsometricSupport.lift T A x)).re=‖S (T.adjoint x)‖^2 := by
    change (inner ℂ x (T (A (T.adjoint x)))).re=_
    rw [←T.adjoint_inner_left,normSrc]
  have coeff (i : D) (j : Fin n) : ‖S (T.adjoint (v j)) i‖ = ‖inner ℂ (v j) (J (S (e i)))‖ := by
    have hc : inner ℂ (e i) (S (T.adjoint (v j))) = S (T.adjoint (v j)) i := by
      simp [e,lp.inner_single_left,RCLike.inner_apply]
    rw [←hc, ←S.adjoint_inner_left,sa,norm_inner_symm]
    rw [T.adjoint_inner_left]
    rfl
  have sums (j : Fin n) : HasSum (fun i => ‖inner ℂ (v j) (J (S (e i)))‖^2) (‖S (T.adjoint (v j))‖^2) := by
    have h := lp.hasSum_norm (by norm_num : 0 < (2:ℝ≥0∞).toReal) (S (T.adjoint (v j)))
    simpa only [ENNReal.toReal_ofNat,Real.rpow_two,coeff] using h
  have hf := hasSum_sum (s:=Finset.univ) (fun (j : Fin n) _ => sums j)
  change (∑ i : Fin n, (inner ℂ (v i) (IsometricSupport.lift T A (v i))).re) ≤ _
  simp_rw [normDst]
  apply hasSum_le _ hf hd.hasSum
  intro i
  have le := hv.sum_inner_products_le (s:=Finset.univ) (J (S (e i)))
  rw [J.norm_map] at le
  exact le.trans_eq (normSrc (e i)).symm

theorem trace_iff (J : Discrete.L2 D →ₗᵢ[ℂ] K)
    (A : Discrete.L2 D →L[ℂ] Discrete.L2 D) (pos : A.IsPositive) (t : ℝ) :
    IsLUB (frameMass (IsometricSupport.lift J.toContinuousLinearMap A)) t ↔ IsLUB (finiteFrameMass A) t := by
  have sub := source_tests J A
  constructor
  · intro h
    have hd := (boundedFrames_iff_diagonal pos).mp ⟨t,fun _ hx => h.1 (sub hx)⟩
    have src := trace_isLUB pos hd
    have dst : IsLUB (frameMass (IsometricSupport.lift J.toContinuousLinearMap A)) (∑' i, (entries A (i,i)).re) :=
      ⟨upper J pos hd,fun _ hc => src.2 (fun _ hx => hc (sub hx))⟩
    exact h.unique dst ▸ src
  · intro h
    have hd := (boundedFrames_iff_diagonal pos).mp ⟨t,h.1⟩
    have eqn := (trace_isLUB pos hd).unique h
    exact ⟨eqn ▸ upper J pos hd,fun _ hc => h.2 (fun _ hx => hc (sub hx))⟩

end KDClosure.LCAQuotientTrace
