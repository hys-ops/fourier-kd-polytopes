import KDLCAQuotientLocalize

/-! Move a localized extreme to the subgroup itself by unitary translation
of positions, keeping the Fourier displacement convention fixed. -/
noncomputable section
namespace KDClosure.LCAQuotient
open MeasureTheory Filter Set CompactCore CompactCoset
open scoped KDClosure.SubgroupMeasure ComplexOrder ENNReal ComplexConjugate
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
  [T2Space G] [LocallyCompactSpace G] [MeasurableSpace G] [BorelSpace G] [SecondCountableTopology G]
variable (μ : Measure G) [μ.IsAddHaarMeasure] (ν : Measure (Dual G)) [SFinite ν]

omit [T2Space G] [LocallyCompactSpace G] [SecondCountableTopology G] in
theorem shift_inverse (t : G) (f : Lp ℂ 2 μ) : shift μ t (shift μ (-t) f)=f := by
  apply Lp.ext
  have a := Lp.coeFn_compMeasurePreserving f (measurePreserving_add_left μ (-t))
  have b := Lp.coeFn_compMeasurePreserving (shift μ (-t) f) (measurePreserving_add_left μ t)
  filter_upwards [b,(measurePreserving_add_left μ t).quasiMeasurePreserving.ae_eq_comp a] with x hx h
  change shift μ (-t) f (t+x)=f (-t+(t+x)) at h
  change shift μ t (shift μ (-t) f) x=shift μ (-t) f (t+x) at hx
  rw [neg_add_cancel_left] at h
  exact hx.trans h

def move (t : G) : Lp ℂ 2 μ ≃ₗᵢ[ℂ] Lp ℂ 2 μ :=
  LinearIsometryEquiv.ofSurjective (shift μ t) (fun f => ⟨shift μ (-t) f,shift_inverse μ t f⟩)

omit [T2Space G] [LocallyCompactSpace G] [SecondCountableTopology G] in
theorem move_ae (t : G) (f : Lp ℂ 2 μ) :
    (move μ t f : G→ℂ)=ᵐ[μ] fun x => f (t+x) :=
  Lp.coeFn_compMeasurePreserving f (measurePreserving_add_left μ t)

omit [T2Space G] [LocallyCompactSpace G] [SecondCountableTopology G] in
theorem move_symm (t : G) : (move μ t).symm=move μ (-t) := by
  ext f : 1
  apply (move μ t).injective
  rw [LinearIsometryEquiv.apply_symm_apply]
  exact (shift_inverse μ t f).symm

def moveOp (t : G) (T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ) := CompactFourier.unitaryPush (move μ t) T

def moveKernel (t : G) (k : Lp ℂ 2 (μ.prod μ)) : Lp ℂ 2 (μ.prod μ) :=
  Lp.compMeasurePreserving (Prod.map (t+·) (t+·)) ((measurePreserving_add_left μ t).prod (measurePreserving_add_left μ t)) k

omit [T2Space G] in
theorem moveKernel_ae (t : G) (k : Lp ℂ 2 (μ.prod μ)) :
    (moveKernel μ t k : G×G→ℂ) =ᵐ[μ.prod μ] fun z => k (t+z.1,t+z.2) :=
  Lp.coeFn_compMeasurePreserving k ((measurePreserving_add_left μ t).prod (measurePreserving_add_left μ t))

omit [T2Space G] in
theorem move_act (t : G) {T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ} {k : Lp ℂ 2 (μ.prod μ)}
    (act : ActsBy μ T k) : ActsBy μ (moveOp μ t T) (moveKernel μ t k) := by
  intro f
  let f' := (move μ t).symm f
  have drop : (f' : G→ℂ)=ᵐ[μ] fun y => f (-t+y) := by
    change ((move μ t).symm f : G→ℂ)=ᵐ[μ] _
    rw [move_symm]
    exact move_ae μ _ _
  have act' := (measurePreserving_add_left μ t).quasiMeasurePreserving.ae (act f')
  filter_upwards [move_ae μ t (T f'),act',Measure.ae_ae_of_ae_prod (moveKernel_ae μ t k)] with x he ce ke
  change move μ t (T f') x = _
  change T f' (t+x)=_ at ce
  rw [he,ce,←integral_add_left_eq_self (μ:=μ) (fun y => k (t+x,y)*f' y) t]
  apply integral_congr_ae
  filter_upwards [ke,(measurePreserving_add_left μ t).quasiMeasurePreserving.ae_eq_comp drop] with y hy dy
  change f' (t+y)=f (-t+(t+y)) at dy
  simp only [neg_add_cancel_left] at dy
  rw [dy,hy]

omit [T2Space G] in
theorem move_rows (t : G) (k : Lp ℂ 2 (μ.prod μ)) :
    ∀ᵐ x ∂μ, LCAReality.rowAt μ (moveKernel μ t k) x=LCAReality.rowAt μ k (t+x) := by
  have a := (measurePreserving_add_left μ t).quasiMeasurePreserving.ae (LCAReality.rowAt_ae μ k)
  have b := (measurePreserving_prod_add μ μ).quasiMeasurePreserving.ae (moveKernel_ae μ t k)
  filter_upwards [LCAReality.rowAt_ae μ (moveKernel μ t k),a,Measure.ae_ae_of_ae_prod b] with x h1 h2 h3
  apply Lp.ext
  filter_upwards [h1,h2,h3] with y e1 e2 e3
  change moveKernel μ t k (x,x+y)=k (t+x,t+(x+y)) at e3
  change LCAReality.rowAt μ k (t+x) y = k (t+x,(t+x)+y) at e2
  exact e1.trans (e3.trans (by simpa only [add_assoc] using e2.symm))

omit [T2Space G] in
theorem move_KD (t : G) (F : LCAReality.FourierRealization μ ν) {k : Lp ℂ 2 (μ.prod μ)}
    (kd : ambientKD μ ν F k) : ambientKD μ ν F (moveKernel μ t k) := by
  obtain ⟨q,mq,rows,sign⟩ := kd
  have mp := (measurePreserving_add_left μ t).prod (MeasurePreserving.id ν)
  refine ⟨fun z => q (t+z.1,z.2),mq.comp mp.measurable,?_,mp.quasiMeasurePreserving.ae sign⟩
  filter_upwards [move_rows μ t k,(measurePreserving_add_left μ t).quasiMeasurePreserving.ae rows] with x hx he
  rw [hx]
  exact he

omit [T2Space G] in
theorem move_mem (t : G) (F : LCAReality.FourierRealization μ ν) {T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ}
    (s : T ∈ ambientStates μ ν F) : moveOp μ t T ∈ ambientStates μ ν F := by
  obtain ⟨p,tr,k,a,_,kd⟩ := s
  have p' := (CompactFourier.positive_unitary_iff (move μ t) T).mpr p
  have tr' : IsLUB (mass (moveOp μ t T)) 1 := by
    change IsLUB (CompactFourier.frameMass (CompactFourier.unitaryPush (move μ t) T)) 1
    rwa [CompactFourier.frameMass_unitary]
  have ac := move_act μ t a
  exact ⟨p',tr',_,ac,hermitian_of_acts μ _ p' ⟨1,tr'.1⟩ ac,move_KD μ ν t F kd⟩

omit [T2Space G] [LocallyCompactSpace G] [SecondCountableTopology G] in
theorem move_inv_op (t : G) (T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ) : moveOp μ t (moveOp μ (-t) T)=T := by
  ext x : 1
  change move μ t (move μ (-t) (T ((move μ (-t)).symm ((move μ t).symm x))))=_
  rw [←move_symm μ t,LinearIsometryEquiv.symm_symm,LinearIsometryEquiv.apply_symm_apply,LinearIsometryEquiv.apply_symm_apply]

omit [T2Space G] in
theorem move_extreme (t : G) (F : LCAReality.FourierRealization μ ν) {T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ}
    (e : T∈(ambientStates μ ν F).extremePoints ℝ) : moveOp μ t T∈(ambientStates μ ν F).extremePoints ℝ := by
  refine ⟨move_mem μ ν t F e.1,?_⟩
  intro S hs U hu seg
  obtain ⟨a,b,ha,hb,sm,blend⟩ := seg
  have back : a • moveOp μ (-t) S + b • moveOp μ (-t) U=T := by
    calc
      _ = moveOp μ (-t) (a • S + b • U) := by ext f : 1; simp [moveOp,CompactFourier.unitaryPush]
      _ = T := by rw [blend]; simpa only [neg_neg] using move_inv_op μ (-t) T
  obtain eqn := e.2 (move_mem μ ν (-t) F hs) (move_mem μ ν (-t) F hu) ⟨a,b,ha,hb,sm,back⟩
  exact (move_inv_op μ t S).symm.trans (congrArg (moveOp μ t) eqn)

omit [T2Space G] [LocallyCompactSpace G] [SecondCountableTopology G] in
theorem translated_support (K : CO G) (t : G) (T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ)
    (s : (LCAReality.mask μ (fiber K (π K t)) (fiber_meas K _)).comp T=T) :
    (LCAReality.mask μ (K.val : Set G) K.val.isOpen.measurableSet).comp (moveOp μ t T)=moveOp μ t T := by
  ext f : 1
  apply Lp.ext
  let u := T ((move μ t).symm f)
  have eqn : LCAReality.mask μ (fiber K (π K t)) (fiber_meas K _) u=u := DFunLike.congr_fun s ((move μ t).symm f)
  have orig := LCAReality.mask_ae μ (fiber K (π K t)) (fiber_meas K _) u
  rw [eqn] at orig
  filter_upwards [LCAReality.mask_ae μ (K.val : Set G) K.val.isOpen.measurableSet (move μ t u),
    move_ae μ t u,(measurePreserving_add_left μ t).quasiMeasurePreserving.ae orig] with x hm hu ho
  change LCAReality.mask μ (K.val : Set G) K.val.isOpen.measurableSet (move μ t u) x=move μ t u x
  change u (t+x)=(fiber K (π K t)).indicator u (t+x) at ho
  rw [hm]
  by_cases xin : x∈K.val
  · rw [Set.indicator_of_mem xin]
  · rw [Set.indicator_of_notMem xin,hu]
    have no : t+x ∉ fiber K (π K t) := by
      intro mem
      have eq : π K (t+x)=π K t := mem
      have n := QuotientAddGroup.eq_iff_sub_mem.mp eq
      exact xin (by simpa using n)
    rw [Set.indicator_of_notMem no] at ho
    exact ho.symm

/-- The bounded-section necessity can inspect only genuine extremes whose
range is physically supported on the distinguished compact subgroup itself. -/
theorem infinite_extreme_in_maximal (K : CO G) (maxK : ∀ H : CO G, subgroup H ≤ subgroup K)
    (F : LCAReality.FourierRealization μ ν) (h : HasInfiniteExtreme μ ν F) :
    ∃ S ∈ (ambientStates μ ν F).extremePoints ℝ, ¬FiniteDimensional ℂ (LinearMap.range S.toLinearMap) ∧
      (LCAReality.mask μ (K.val : Set G) K.val.isOpen.measurableSet).comp S=S := by
  obtain ⟨T,e,hi⟩ := h
  obtain ⟨i,hc⟩ := extreme_one_coset μ ν K maxK F T e
  obtain ⟨t,ht⟩ := QuotientAddGroup.mk'_surjective (subgroup K) i
  change π K t=i at ht
  rw [←ht] at hc
  refine ⟨moveOp μ t T,move_extreme μ ν t F e,?_,translated_support μ K t T hc⟩
  intro finite
  have E : LinearMap.range T.toLinearMap ≃ₗ[ℂ] LinearMap.range (moveOp μ t T).toLinearMap := by
    change _ ≃ₗ[ℂ] LinearMap.range (CompactFourier.unitaryPush (move μ t) T).toLinearMap
    rw [←CompactFourier.lift_eq_push]
    exact IsometricSupport.rangeEquiv _ (move μ t).isometry T
  exact hi (FiniteDimensional.of_injective E.toLinearMap E.injective)

end KDClosure.LCAQuotient
