import KDCompactFourierRepresent

/-! Uniqueness of the joint L² integral kernel of a Hilbert space operator,
on an arbitrary countably generated σ-algebra with s-finite measure. -/
noncomputable section
namespace KDClosure.LCAQuotient
open Set MeasureTheory Filter
open scoped ENNReal ComplexConjugate
variable {X : Type*} [MeasurableSpace X] (μ : Measure X) [SFinite μ]

def ordinaryRow (k : Lp ℂ 2 (μ.prod μ)) (x : X) : Lp ℂ 2 μ :=
  open Classical in if m : MemLp (fun y : X => k (x,y)) 2 μ then m.toLp _ else 0

theorem ordinaryRow_ae (k : Lp ℂ 2 (μ.prod μ)) :
    ∀ᵐ x ∂μ, (ordinaryRow μ k x : X→ℂ) =ᵐ[μ] fun y => k (x,y) := by
  have sq := (memLp_two_iff_integrable_sq_norm (Lp.aestronglyMeasurable k)).mp (Lp.memLp k)
  filter_upwards [sq.prod_right_ae] with x hx
  have mf : Measurable (fun y => k (x,y)) := (Lp.stronglyMeasurable k).measurable.comp measurable_prodMk_left
  have h := (memLp_two_iff_integrable_sq_norm mf.aestronglyMeasurable).mpr hx
  simpa only [ordinaryRow,dif_pos h] using h.coeFn_toLp

def ActsBy (T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ) (k : Lp ℂ 2 (μ.prod μ)) : Prop :=
  ∀ f : Lp ℂ 2 μ, ∀ᵐ x ∂μ, T f x = ∫ y, k (x,y) * f y ∂μ

/-- Each test initially has its own exceptional set of positions. A countable
total set of tests gives equality of the complete L² rows simultaneously. -/
theorem determine_rows [MeasurableSpace.CountablyGenerated X] (u v : X → Lp ℂ 2 μ)
    (tests : ∀ f : Lp ℂ 2 μ, ∀ᵐ x ∂μ,
      (∫ y, u x y * f y ∂μ) = ∫ y, v x y * f y ∂μ) : ∀ᵐ x ∂μ, u x=v x := by
  let _ : Fact ((2:ℝ≥0∞) ≠ ∞) := ⟨by simp⟩
  obtain ⟨s,b,hb⟩ := exists_hilbertBasis ℂ (Lp ℂ 2 μ)
  have on := b.orthonormal
  rw [hb] at on
  let _ : Countable s := CompactFourier.countable_orthonormal s on
  let conjVec := Complex.conjCLE.toContinuousLinearMap.compLpL 2 μ
  have eqInner (w a : Lp ℂ 2 μ) : inner ℂ a w = ∫ y, w y * conjVec a y ∂μ := by
    rw [MeasureTheory.L2.inner_def]
    apply integral_congr_ae
    filter_upwards [Complex.conjCLE.toContinuousLinearMap.coeFn_compLpL (p:=2) (μ:=μ) a] with y hy
    rw [show conjVec a y=conj (a y) from hy,RCLike.inner_apply]
  filter_upwards [ae_all_iff.mpr fun i:s => tests (conjVec (b i))] with x hx
  apply b.repr.injective
  ext i
  simpa only [b.repr_apply_apply,eqInner] using hx i

theorem kernel_unique [MeasurableSpace.CountablyGenerated X]
    (T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ) {k l : Lp ℂ 2 (μ.prod μ)}
    (hk : ActsBy μ T k) (hl : ActsBy μ T l) : k=l := by
  have rows := determine_rows μ (ordinaryRow μ k) (ordinaryRow μ l) (fun f => by
    filter_upwards [hk f,hl f,ordinaryRow_ae μ k,ordinaryRow_ae μ l] with x h₁ h₂ r₁ r₂
    exact (integral_congr_ae (r₁.mono fun y h => congrArg (· * f y) h)).trans
      (h₁.symm.trans (h₂.trans (integral_congr_ae (r₂.symm.mono fun y h => congrArg (· * f y) h)))))
  apply Lp.ext
  apply (Measure.ae_prod_iff_ae_ae (measurableSet_eq_fun (Lp.stronglyMeasurable k).measurable
    (Lp.stronglyMeasurable l).measurable)).mpr
  filter_upwards [rows,ordinaryRow_ae μ k,ordinaryRow_ae μ l] with x hx rk rl
  rw [←hx] at rl
  exact rk.symm.trans rl

theorem hermitian_of_acts [MeasurableSpace.CountablyGenerated X]
    (T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ) (hp : T.IsPositive) (ht : BddAbove (CompactFourier.frameMass T))
    {k : Lp ℂ 2 (μ.prod μ)} (hk : ActsBy μ T k) :
    ∀ᵐ z ∂μ.prod μ, k z=conj (k z.swap) := by
  obtain ⟨l,hs,hl⟩ := CompactFourier.exists_physical_kernel T hp ht
  rwa [kernel_unique μ T hk hl]
end KDClosure.LCAQuotient
