import KDLCAQuotientDual
import Mathlib.MeasureTheory.Measure.Haar.Basic

/-! Compact-open annihilators and the zero-measure frequency test in the
original structural lemma, avoiding full Pontryagin biduality. -/
noncomputable section
namespace KDClosure.LCAAnnihilator
open Topology Set MeasureTheory CompactDualReduction LCAQuotientDual
open scoped Pointwise

abbrev CompOpen (G : Type*) [CommGroup G] [TopologicalSpace G] :=
  {K : OpenSubgroup G // IsCompact (K : Set G)}

variable {G : Type*} [CommGroup G] [TopologicalSpace G] [IsTopologicalGroup G]
variable [LocallyCompactSpace G]

omit [IsTopologicalGroup G] in
/-- Compactness of B gives a common identity-neighborhood where all its
characters lie in one small arc. Powers stay in B, so the entire common
neighborhood in fact pairs to 1. -/
theorem compact_family_common_kernel (B : Subgroup (PontryaginDual G))
    (hc : IsCompact (B : Set (PontryaginDual G))) :
    ∃ V : Set G, IsOpen V ∧ 1 ∈ V ∧ ∀ x ∈ V, ∀ φ ∈ B, φ x = 1 := by
  let W := Circle.centeredArc (Real.pi/2)
  have hW := Circle.isOpen_centeredArc (Real.pi/2)
  have one : (1 : Circle) ∈ W := by
    rw [Circle.mem_centeredArc (by linarith [Real.pi_pos])]
    simp [Real.pi_pos]
  let ev (z : PontryaginDual G × G) := z.1 z.2
  have c : Continuous ev := continuous_eval (F:=ContinuousMonoidHom G Circle)
  have sub : ((B:Set (PontryaginDual G)) ×ˢ ({1}:Set G)) ⊆ ev ⁻¹' W := by
    rintro ⟨φ,x⟩ ⟨_, hx : x = 1⟩
    subst x; simpa [ev] using one
  obtain ⟨A,V,_,ho,ba,oneV,prod⟩ := generalized_tube_lemma hc isCompact_singleton (hW.preimage c) sub
  refine ⟨V,ho,oneV rfl,?_⟩
  intro x hx φ hφ
  apply Circle.eq_one_of_forall_pow_mem_centeredArc_pi_div_two
  intro n _
  have z := prod (show (φ^n,x)∈A ×ˢ V from ⟨ba (B.pow_mem hφ n),hx⟩)
  change ((φ^n) x) ∈ W at z
  have eq : (φ^n) x = φ x ^ n := ContinuousMonoidHom.pow_apply (φ : G →ₜ* Circle) n x
  rw [eq] at z
  exact z

theorem kernel_open_of_compact_family {φ : PontryaginDual G}
    {B : Subgroup (PontryaginDual G)} (hc : IsCompact (B : Set (PontryaginDual G))) (hφ : φ ∈ B) :
    IsOpen (φ.toMonoidHom.ker : Set G) := by
  obtain ⟨V,ho,oneV,eq⟩ := compact_family_common_kernel B hc
  exact φ.toMonoidHom.ker.isOpen_of_mem_nhds (Filter.mem_of_superset (ho.mem_nhds oneV)
    (fun x hx => eq x hx φ hφ))

def intersectKernel (K : CompOpen G) (φ : PontryaginDual G)
    (hφ : IsOpen (φ.toMonoidHom.ker : Set G)) : CompOpen G :=
  ⟨K.val ⊓ (⟨φ.toMonoidHom.ker,hφ⟩ : OpenSubgroup G),
    K.property.inter_right (φ.toMonoidHom.ker.isClosed_of_isOpen hφ)⟩

def dualCompactOpen (K : CompOpen G) : CompOpen (PontryaginDual G) :=
  ⟨⟨ann K.val,ann_open K.val K.property⟩,ann_compact K.val⟩

theorem dual_region_iff_open_kernel (K : CompOpen G) (φ : PontryaginDual G) :
    (∃ B : CompOpen (PontryaginDual G), φ ∈ B.val) ↔ IsOpen (φ.toMonoidHom.ker : Set G) := by
  constructor
  · rintro ⟨B,hφ⟩
    exact kernel_open_of_compact_family (B:=B.val.toSubgroup) B.property hφ
  · intro ho
    let H := intersectKernel K φ ho
    exact ⟨dualCompactOpen H,fun _ hx => hx.2⟩

/-- The exact annihilator equality, in both directions; no duality
equivalence between the original group and its bidual is required. -/
theorem core_iff_dual_region (K : CompOpen G) (x : G) :
    (∀ H : CompOpen G, x ∈ H.val) ↔
      ∀ B : CompOpen (PontryaginDual G), ∀ φ ∈ B.val, φ x = 1 := by
  constructor
  · intro inCore B φ hφ
    have ho := (dual_region_iff_open_kernel K φ).mp ⟨B,hφ⟩
    exact (inCore (intersectKernel K φ ho)).2
  · intro annih H
    by_contra h
    obtain ⟨φ,hφ,ne⟩ := distinguishes_subgroup H.val h
    exact ne (annih (dualCompactOpen H) φ hφ)

variable [MeasurableSpace G] [BorelSpace G] (μ : Measure G) [μ.IsHaarMeasure] [μ.InnerRegular]

/-- Outside the union of compact open subgroups of the dual, evaluation
can equal 1 only on a Haar-null set in position space. -/
theorem null_kernel_off_dual_region (K : CompOpen G) (φ : PontryaginDual G)
    (outside : ¬∃ B : CompOpen (PontryaginDual G), φ∈B.val) :
    μ {x : G | φ x=1}=0 := by
  let H := φ.toMonoidHom.ker
  change μ (H:Set G)=0
  by_contra ne
  have hc : MeasurableSet (H : Set G) := (isClosed_singleton.preimage φ.continuous).measurableSet
  have nh := Measure.div_mem_nhds_one_of_haar_pos μ (H : Set G) hc (pos_iff_ne_zero.mpr ne)
  rw [coe_div_coe] at nh
  exact outside ((dual_region_iff_open_kernel K φ).mpr (H.isOpen_of_mem_nhds nh))

end KDClosure.LCAAnnihilator
