import KDLCARealitySingleSector
import KDManyAmbientWindows
import Mathlib.MeasureTheory.Integral.DominatedConvergence

noncomputable section
namespace KDClosure.LCAReality
open MeasureTheory Filter Set CompactCore Topology
open scoped ENNReal ComplexConjugate Pointwise ComplexOrder
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
    [MeasurableSpace G] [BorelSpace G] [SecondCountableTopology G] [T2Space G] [LocallyCompactSpace G]
variable (μ : Measure G) [μ.IsAddHaarMeasure]

omit [SecondCountableTopology G] [T2Space G] [LocallyCompactSpace G] in
theorem shift_add (a b : G) (v : Lp ℂ 2 μ) : shift μ a (shift μ b v)=shift μ (a+b) v := by
  apply Lp.ext
  have t := (measurePreserving_add_left μ a).quasiMeasurePreserving.ae_eq_comp (shift_ae μ b v)
  filter_upwards [shift_ae μ a (shift μ b v),t,shift_ae μ (a+b) v] with x hx ht h
  change shift μ b v (a+x)=v (b+(a+x)) at ht
  rw [hx,ht,h,add_left_comm,add_assoc]

def subgroupAverage (N : CO G) (v : Lp ℂ 2 μ) : Lp ℂ 2 μ :=
  (μ.real (N.val : Set G))⁻¹ • ∫ x in (N.val : Set G), shift μ x v ∂μ

omit [IsTopologicalAddGroup G] [BorelSpace G] [SecondCountableTopology G] [T2Space G] [LocallyCompactSpace G] in
private theorem mass_ne (N : CO G) : μ.real (N.val : Set G)≠0 :=
  (ENNReal.toReal_pos (N.val.isOpen.measure_pos μ ⟨0,N.val.zero_mem⟩).ne' N.property.measure_ne_top).ne'

theorem subgroupAverage_invariant (N : CO G) (v : Lp ℂ 2 μ) (h : G) (hh : h∈subgroup N) :
    shift μ h (subgroupAverage μ N v)=subgroupAverage μ N v := by
  let S := (N.val : Set G)
  have ms : MeasurableSet S := N.val.isOpen.measurableSet
  have vi : IntegrableOn (fun x => shift μ x v) S μ := (continuous_shift μ v).continuousOn.integrableOn_compact N.property
  have eq : ∀ x : G, S.indicator (fun y => shift μ (h+y) v) x = S.indicator (fun y => shift μ y v) (h+x) := by
    intro x
    have iff : h+x∈S ↔ x∈S := (subgroup N).add_mem_cancel_left hh
    by_cases hx : x∈S
    · rw [Set.indicator_of_mem hx,Set.indicator_of_mem (iff.mpr hx)]
    · rw [Set.indicator_of_notMem hx,Set.indicator_of_notMem (iff.not.mpr hx)]
  unfold subgroupAverage
  rw [(shift μ h).map_smul_of_tower,←(shift μ h).integral_comp_comm vi]
  congr 1
  calc
    _ = ∫ x in S, shift μ (h+x) v ∂μ := integral_congr_ae (.of_forall fun x => shift_add μ h x v)
    _ = ∫ x, S.indicator (fun y => shift μ (h+y) v) x ∂μ := (integral_indicator ms).symm
    _ = ∫ x, S.indicator (fun y => shift μ y v) (h+x) ∂μ := integral_congr_ae (.of_forall eq)
    _ = _ := (integral_add_left_eq_self (μ:=μ) (S.indicator (fun y => shift μ y v)) h).trans (integral_indicator ms)

/-- Averaging a vector moved at most ε by every translation in a compact
open subgroup changes it by at most ε in the genuine Hilbert norm. -/
theorem average_error (N : CO G) (v : Lp ℂ 2 μ) (ε : ℝ)
    (small : ∀ x∈subgroup N, ‖shift μ x v-v‖≤ε) :
    ‖subgroupAverage μ N v-v‖≤ε := by
  let S := (N.val : Set G)
  let m := μ.real S
  have nz : m≠0 := mass_ne μ N
  have mp : 0≤m := ENNReal.toReal_nonneg
  have vi : IntegrableOn (fun x => shift μ x v) S μ := (continuous_shift μ v).continuousOn.integrableOn_compact N.property
  have ci : IntegrableOn (fun _ : G => v) S μ := integrableOn_const N.property.measure_ne_top
  have eq : subgroupAverage μ N v-v=m⁻¹ • (∫ x in S, shift μ x v-v ∂μ) := by
    rw [integral_sub vi ci,setIntegral_const,smul_sub,smul_smul,inv_mul_cancel₀ nz,one_smul]
    rfl
  have hi := norm_setIntegral_le_of_norm_le_const (μ:=μ) (f:=fun x => shift μ x v-v)
    N.property.measure_ne_top.lt_top small
  rw [eq,norm_smul,Real.norm_eq_abs,abs_of_nonneg (inv_nonneg.mpr mp)]
  calc
    _ ≤ m⁻¹*(ε*m) := mul_le_mul_of_nonneg_left hi (inv_nonneg.mpr mp)
    _ = ε := by field_simp

omit [MeasurableSpace G] [BorelSpace G] [SecondCountableTopology G] [T2Space G] [LocallyCompactSpace G] in
/-- Descending compact opens eventually fit inside every open neighborhood
of their intersection. Only the compactness of the first one is used. -/
theorem eventually_sub_open (w : ManyOpen.Windows G) (O : Set G) (ho : IsOpen O)
    (contains : ∀ x : G, (∀ n, x∈subgroup (w.L n)) → x∈O) :
    ∀ᶠ n : ℕ in atTop, ((w.L n).val : Set G)⊆O := by
  let A := ((w.L 0).val : Set G) ∩ Oᶜ
  have ca : IsCompact A := (w.L 0).property.inter_right ho.isClosed_compl
  have cover : A⊆⋃ n, ((w.L n).val : Set G)ᶜ := by
    intro x hx
    by_contra no
    have every : ∀ n, x∈subgroup (w.L n) := fun n => by by_contra hn; exact no (mem_iUnion.mpr ⟨n,hn⟩)
    exact hx.2 (contains x every)
  obtain ⟨m,hm⟩ := ca.elim_directed_cover _ (fun n => (w.L n).val.isClosed.isOpen_compl) cover
    (fun i j => ⟨max i j,compl_subset_compl.mpr (fun _ h => w.down (le_max_left i j) h),
      compl_subset_compl.mpr (fun _ h => w.down (le_max_right i j) h)⟩)
  filter_upwards [eventually_ge_atTop m] with n hn
  intro x hx
  by_contra no
  exact hm ⟨w.down (Nat.zero_le n) hx,no⟩ (w.down hn hx)

theorem averages_tendsto (w : ManyOpen.Windows G) (v : Lp ℂ 2 μ)
    (inv : ∀ h : G, (∀ n, h∈subgroup (w.L n)) → shift μ h v=v) :
    Tendsto (fun n => subgroupAverage μ (w.L n) v) atTop (𝓝 v) := by
  apply Metric.tendsto_nhds.mpr
  intro ε he
  let O := {h : G | ‖shift μ h v-v‖<ε/2}
  have ho : IsOpen O := isOpen_lt ((continuous_shift μ v).sub continuous_const).norm continuous_const
  have cover : ∀ x : G, (∀ n, x∈subgroup (w.L n)) → x∈O := by
    intro x hx
    change ‖shift μ x v-v‖<ε/2
    rw [inv x hx,sub_self,norm_zero]
    linarith
  filter_upwards [eventually_sub_open w O ho cover] with n hn
  rw [dist_eq_norm]
  exact (average_error μ (w.L n) v (ε/2) (fun x hx => (hn hx).le)).trans_lt (by linarith)

end KDClosure.LCAReality
