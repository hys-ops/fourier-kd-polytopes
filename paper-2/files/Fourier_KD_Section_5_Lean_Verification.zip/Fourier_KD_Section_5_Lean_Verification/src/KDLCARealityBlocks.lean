import KDLCARealityIncidence

noncomputable section
namespace KDClosure.LCAReality
open MeasureTheory Filter Set CompactCore Topology
open scoped ENNReal ComplexConjugate Pointwise ComplexOrder
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
variable [MeasurableSpace G] [BorelSpace G] [LocallyCompactSpace G]
variable (μ : Measure G) [μ.IsAddHaarMeasure] [μ.InnerRegular] [SFinite μ]
variable [MeasurableSpace (Dual G)] [BorelSpace (Dual G)] (ν : Measure (Dual G)) [SFinite ν]

omit [LocallyCompactSpace G] [μ.InnerRegular] [SFinite μ] [SFinite ν] in
/-- A slice invariant under its own displacement h is also invariant
under a prescribed l whenever their annihilators have the stated
containment up to a dual null set. -/
theorem slice_period_of_annihilator (F : FourierRealization μ ν)
    (h l : G) (f : Lp ℂ 2 μ) (period : ∀ᵐ x ∂μ, f (h+x)=f x)
    (inc : ∀ᵐ χ ∂ν, phase χ h=1 → phase χ l=1) :
    ∀ᵐ x ∂μ, f (l+x)=f x := by
  have eq : shift μ l f = f := by
    apply F.isometry.injective
    rw [fourier_shift]
    apply Lp.ext
    filter_upwards [modulate_ae ν (-l) (F.isometry f),weyl_slice_support μ ν F h f period,inc] with χ hm hw hi
    rw [hm]
    by_cases hp : phase χ h=1
    · have p := phase_neg_mul χ l
      rw [hi hp,mul_one] at p
      rw [p,one_mul]
    · rw [hw hp,mul_zero]
  have rev := shift_ae μ l f
  rw [eq] at rev
  exact rev.symm

variable [SecondCountableTopology G]

/-- Frequency-block conclusion of Lemma 1, as an actual simultaneous
translation identity on the physical Hilbert--Schmidt kernel. -/
theorem kernel_core_invariance (K : CO G) (F : FourierRealization μ ν)
    (k : Lp ℂ 2 (μ.prod μ)) (l : G) (core : ∀ H : CO G, l∈subgroup H)
    (hermitian : ∀ᵐ z : G × G ∂μ.prod μ, k z = conj (k (z.2,z.1)))
    (row : ∀ᵐ z : G × G ∂μ.prod μ, k (z.1,z.1+z.2) = conj (k (z.1,z.1-z.2))) :
    ∀ᵐ z : G × G ∂μ.prod μ, k (l+z.1,l+z.2)=k z := by
  let s (z : G×G) := (z.2,z.2+z.1)
  have mp : MeasurePreserving s (μ.prod μ) (μ.prod μ) := measurePreserving_prod_add_swap μ μ
  have m := (Lp.memLp k).comp_measurePreserving mp
  have square := (memLp_two_iff_integrable_sq_norm m.1).mp m
  have periodic := Measure.ae_ae_of_ae_prod (displacement_periodic μ k hermitian row)
  have nested : ∀ᵐ h ∂μ, ∀ᵐ x ∂μ, k (l+x,l+(x+h))=k (x,x+h) := by
    filter_upwards [square.prod_right_ae,periodic,ae_annihilator_core μ ν K l core] with h hi inv inc
    let f (x : G) := k (x,x+h)
    have mf : Measurable f := (Lp.stronglyMeasurable k).measurable.comp
      (measurable_id.prodMk (measurable_id.add measurable_const))
    have lp : MemLp f 2 μ := (memLp_two_iff_integrable_sq_norm mf.aestronglyMeasurable).mpr hi
    have tr := (measurePreserving_add_left μ h).quasiMeasurePreserving.ae_eq_comp lp.coeFn_toLp
    have periodic' : ∀ᵐ x ∂μ, lp.toLp f (h+x)=lp.toLp f x := by
      filter_upwards [lp.coeFn_toLp,tr,inv] with x hx ht hp
      exact ht.trans (hp.trans hx.symm)
    have l_period := slice_period_of_annihilator μ ν F h l _ periodic' inc
    have tl := (measurePreserving_add_left μ l).quasiMeasurePreserving.ae_eq_comp lp.coeFn_toLp
    filter_upwards [lp.coeFn_toLp,tl,l_period] with x hx ht hp
    simpa [f,add_assoc] using (ht.symm.trans (hp.trans hx) : f (l+x)=f x)
  let d (z : G×G) := (l+z.2,l+(z.2+z.1))
  have md : Measurable d := (measurable_const.add measurable_snd).prodMk
    (measurable_const.add (measurable_snd.add measurable_fst))
  have ms : MeasurableSet {z | k (d z)=k (s z)} :=
    measurableSet_eq_fun ((Lp.stronglyMeasurable k).measurable.comp md)
      ((Lp.stronglyMeasurable k).measurable.comp mp.measurable)
  have joint : ∀ᵐ z ∂μ.prod μ, k (d z)=k (s z) := (Measure.ae_prod_iff_ae_ae ms).mpr nested
  have invS : MeasurePreserving (fun z : G×G => (-z.1+z.2,z.1)) (μ.prod μ) (μ.prod μ) :=
    Measure.measurePreserving_swap.comp (measurePreserving_prod_neg_add μ μ)
  filter_upwards [invS.quasiMeasurePreserving.ae joint] with z hz
  change k (l+z.1,l+(z.1+(-z.1+z.2))) = k (z.1,z.1+(-z.1+z.2)) at hz
  simpa only [add_neg_cancel_left,Prod.mk.eta] using hz

/-- Both structure equations from the original joint numerical KD sign
on a second countable LCA group with a compact open subgroup. -/
theorem kernel_blocks_of_KD [MeasurableNeg G] [MeasurableAdd G] [μ.IsNegInvariant]
    (K : CO G) (F : FourierRealization μ ν) (k : Lp ℂ 2 (μ.prod μ))
    (hermitian : ∀ᵐ z : G × G ∂μ.prod μ, k z=conj (k (z.2,z.1)))
    (kd : ∀ᵐ z : G × Dual G ∂μ.prod ν, 0 ≤ F.isometry (rowAt μ k z.1) z.2) :
    (∀ᵐ z : G × G ∂μ.prod μ, (¬∃ H : CO G, z.2-z.1 ∈ subgroup H) → k z=0) ∧
    (∀ l : G, (∀ H : CO G, l∈subgroup H) →
      ∀ᵐ z : G × G ∂μ.prod μ, k (l+z.1,l+z.2)=k z) :=
  ⟨position_support_of_KD μ ν K F k hermitian kd,fun l hl => kernel_core_invariance μ ν K F k l hl
    hermitian (kernel_row_involution_of_KD μ ν F k kd)⟩

/-- Both structure equations from the original joint numerical KD sign
on a second countable LCA group with a compact open subgroup. -/
theorem kernel_blocks_of_rows [MeasurableNeg G] [MeasurableAdd G] [μ.IsNegInvariant]
    (K : CO G) (F : FourierRealization μ ν) (k : Lp ℂ 2 (μ.prod μ))
    (hermitian : ∀ᵐ z : G × G ∂μ.prod μ, k z=conj (k (z.2,z.1)))
    (kd : ∀ᵐ x ∂μ, ∀ᵐ χ ∂ν, 0 ≤ F.isometry (rowAt μ k x) χ) :
    (∀ᵐ z : G × G ∂μ.prod μ, (¬∃ H : CO G, z.2-z.1 ∈ subgroup H) → k z=0) ∧
    (∀ l : G, (∀ H : CO G, l∈subgroup H) →
      ∀ᵐ z : G × G ∂μ.prod μ, k (l+z.1,l+z.2)=k z) :=
  ⟨position_support_of_rows μ ν K F k hermitian kd,fun l hl => kernel_core_invariance μ ν K F k l hl
    hermitian (kernel_row_involution_of_rows μ ν F k kd)⟩

end KDClosure.LCAReality
