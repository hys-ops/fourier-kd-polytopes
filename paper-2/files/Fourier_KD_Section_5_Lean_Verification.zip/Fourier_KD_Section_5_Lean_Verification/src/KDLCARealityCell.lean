import KDLCARealityOperator

noncomputable section
namespace KDClosure.LCAReality
open MeasureTheory Filter Set CompactCore Topology CompactCoset
open scoped ENNReal ComplexConjugate Pointwise ComplexOrder
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
  [MeasurableSpace G] [BorelSpace G] [SecondCountableTopology G]
variable (μ : Measure G) [SFinite μ] [μ.IsAddHaarMeasure]

/-- If every translation from an open subgroup fixes a measurable scalar
function almost everywhere, the function is a.e. constant on every
specific coset. The order of the two a.e. quantifiers is justified by
Fubini before any point in a coset is chosen. -/
theorem constant_on_coset (H : CO G) (g : G→ℂ) (mg : Measurable g)
    (inv : ∀ h ∈ subgroup H, ∀ᵐ x ∂μ, g (h+x)=g x) (a : G) :
    ∃ c : ℂ, ∀ᵐ y ∂μ, y∈coset H a → g y=c := by
  have m1 : MeasurableSet {z : G×G | z.1∈subgroup H} := H.val.isOpen.measurableSet.preimage measurable_fst
  have m2 : MeasurableSet {z : G×G | g (z.1+z.2)=g z.2} :=
    measurableSet_eq_fun (mg.comp (measurable_fst.add measurable_snd)) (mg.comp measurable_snd)
  have m : MeasurableSet {z : G×G | z.1∈subgroup H → g (z.1+z.2)=g z.2} := by
    convert m1.compl.union m2 using 1
    ext z; simp [imp_iff_not_or]
  have joint : ∀ᵐ z : G×G ∂μ.prod μ, z.1∈subgroup H → g (z.1+z.2)=g z.2 :=
    (Measure.ae_prod_iff_ae_ae m).mpr (Filter.Eventually.of_forall fun h => by
      by_cases hh : h∈subgroup H
      · exact (inv h hh).mono fun _ i _ => i
      · exact .of_forall fun _ i => (hh i).elim)
  have flip := Measure.ae_ae_of_ae_prod ((Measure.measurePreserving_swap (μ:=μ) (ν:=μ)).quasiMeasurePreserving.ae joint)
  have mass : μ (coset H a) ≠ 0 :=
    ((H.val.isOpen.preimage (continuous_id.sub continuous_const)).measure_pos μ ⟨a,by simp⟩).ne'
  obtain ⟨x,hx,good⟩ := Measure.exists_mem_of_measure_ne_zero_of_ae mass (ae_restrict_of_ae flip)
  refine ⟨g x,?_⟩
  filter_upwards [(measurePreserving_add_left μ (-x)).quasiMeasurePreserving.ae good] with y hy
  change (-x+y)∈subgroup H → g (-x+y+x)=g x at hy
  intro mem
  have h : -x+y∈subgroup H := by
    have t := (subgroup H).sub_mem (show y-a∈subgroup H from mem) (show x-a∈subgroup H from hx)
    convert t using 1; abel
  simpa only [neg_add_cancel_comm] using hy h

/-- A physical character eigenfunction is exactly a scalar multiple of the
same ambient character on every H-coset. -/
theorem mode_on_coset (H : CO G) (γ : Dual G) (v : Lp ℂ 2 μ)
    (inv : ∀ h : subgroup H, LCAReality.shift μ (h:G) v=phase γ (h:G) • v) (a : G) :
    ∃ c : ℂ, ∀ᵐ y ∂μ, y∈coset H a → v y=c*phase γ y := by
  let g (x:G) := phase γ (-x)*v x
  have cm : Continuous (fun x : G => phase γ x) := continuous_subtype_val.comp γ.continuous
  have mg : Measurable g := (cm.measurable.comp measurable_neg).mul (Lp.stronglyMeasurable v).measurable
  have fixed (h : G) (hh : h∈subgroup H) : ∀ᵐ x ∂μ, g (h+x)=g x := by
    have eq := shift_ae μ h v
    rw [inv ⟨h,hh⟩] at eq
    filter_upwards [eq,Lp.coeFn_smul (phase γ h) v] with x a b
    change (phase γ h • v) x=phase γ h*v x at b
    change phase γ (-(h+x))*v (h+x)=phase γ (-x)*v x
    rw [←a,b,neg_add,phase_add]
    calc
      _ = (phase γ (-h)*phase γ h)*(phase γ (-x)*v x) := by ring
      _ = _ := by rw [phase_neg_mul,one_mul]
  obtain ⟨c,hc⟩ := constant_on_coset μ H g mg fixed a
  refine ⟨c,hc.mono fun y hy h => ?_⟩
  have t := hy h
  change phase γ (-y)*v y=c at t
  rw [←t]
  calc
    _ = (phase γ (-y)*phase γ y)*v y := by rw [phase_neg_mul,one_mul]
    _ = _ := by ring
end KDClosure.LCAReality
