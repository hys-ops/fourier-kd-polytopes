import KDLCARealityOperator
import KDLCAQuotientState

noncomputable section
namespace KDClosure.LCAReality
open MeasureTheory Filter Set CompactCore Topology
open scoped ENNReal ComplexConjugate Pointwise ComplexOrder
variable {X : Type*} [MeasurableSpace X] (ρ : Measure X)

theorem mask_isStarProjection (S : Set X) (hs : MeasurableSet S) :
    IsStarProjection (mask ρ S hs) := by
  constructor
  · ext f : 1
    apply Lp.ext
    filter_upwards [mask_ae ρ S hs (mask ρ S hs f), mask_ae ρ S hs f] with x hx hf
    change mask ρ S hs (mask ρ S hs f) x=mask ρ S hs f x
    by_cases h : x∈S
    · simpa only [Set.indicator_of_mem h] using hx
    · rw [hx,hf,Set.indicator_of_notMem h,Set.indicator_of_notMem h]
  · apply ContinuousLinearMap.isSelfAdjoint_iff_isSymmetric.mpr
    intro f g
    change inner ℂ (mask ρ S hs f) g = inner ℂ f (mask ρ S hs g)
    simp only [MeasureTheory.L2.inner_def]
    apply integral_congr_ae
    filter_upwards [mask_ae ρ S hs f,mask_ae ρ S hs g] with x hx hy
    change inner ℂ (mask ρ S hs f x) (g x) = inner ℂ (f x) (mask ρ S hs g x)
    rw [hx,hy]
    by_cases h : x∈S <;> simp [h]

theorem mask_add_compl (S : Set X) (hs : MeasurableSet S) :
    (mask ρ S hs) + (mask ρ Sᶜ hs.compl) = 1 := by
  ext f : 1
  apply Lp.ext
  filter_upwards [mask_ae ρ S hs f,mask_ae ρ Sᶜ hs.compl f,Lp.coeFn_add (mask ρ S hs f) (mask ρ Sᶜ hs.compl f)] with x hx hy ha
  change (mask ρ S hs f+mask ρ Sᶜ hs.compl f) x=f x
  change (mask ρ S hs f+mask ρ Sᶜ hs.compl f) x=mask ρ S hs f x+mask ρ Sᶜ hs.compl f x at ha
  rw [ha,hx,hy]
  by_cases h : x∈S <;> simp [h]

theorem positive_mask_comp (S : Set X) (hs : MeasurableSet S) (T : Lp ℂ 2 ρ →L[ℂ] Lp ℂ 2 ρ)
    (hp : T.IsPositive) (comm : (mask ρ S hs).comp T = T.comp (mask ρ S hs)) :
    ((mask ρ S hs).comp T).IsPositive := by
  let P := mask ρ S hs
  have p := mask_isStarProjection ρ S hs
  have sa : P.adjoint=P := p.isSelfAdjoint.star_eq
  have pp : P.comp P=P := p.isIdempotentElem
  have pos := hp.conj_adjoint P
  rw [sa] at pos
  have eq : (P.comp T).comp P = P.comp T := by
    change P.comp (T.comp P) = _
    rw [← comm]
    change (P.comp P).comp T=P.comp T
    rw [pp]
  exact eq ▸ pos

variable (S : Set X) (hs : MeasurableSet S) (k : Lp ℂ 2 (ρ.prod ρ))

def cutKernel : Lp ℂ 2 (ρ.prod ρ) :=
  mask (ρ.prod ρ) (Prod.fst ⁻¹' S) (hs.preimage measurable_fst) k

theorem cutKernel_ae : (cutKernel ρ S hs k : X×X → ℂ)=ᵐ[ρ.prod ρ] (Prod.fst ⁻¹' S).indicator k :=
  mask_ae _ _ _ _

variable [SFinite ρ]

theorem cut_kernel_acts {T : Lp ℂ 2 ρ →L[ℂ] Lp ℂ 2 ρ} (act : LCAQuotient.ActsBy ρ T k) :
    LCAQuotient.ActsBy ρ ((mask ρ S hs).comp T) (cutKernel ρ S hs k) := by
  intro f
  filter_upwards [mask_ae ρ S hs (T f),act f,Measure.ae_ae_of_ae_prod (cutKernel_ae ρ S hs k)] with x hx ha hk
  change mask ρ S hs (T f) x=_
  rw [hx]
  by_cases h : x∈S
  · rw [Set.indicator_of_mem h,ha]
    apply integral_congr_ae
    exact hk.mono fun y hy => by change k (x,y)*f y=cutKernel ρ S hs k (x,y)*f y; rw [hy,Set.indicator_of_mem (s:=Prod.fst ⁻¹' S) h]
  · rw [Set.indicator_of_notMem h]
    symm
    apply integral_eq_zero_of_ae
    exact hk.mono fun y hy => by change cutKernel ρ S hs k (x,y)*f y=0; rw [hy,Set.indicator_of_notMem (s:=Prod.fst ⁻¹' S) h,zero_mul]

variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
    [MeasurableSpace G] [BorelSpace G] [SecondCountableTopology G]
variable (μ : Measure G) [SFinite μ] [μ.IsAddLeftInvariant]
variable (A : Set G) (ha : MeasurableSet A) (w : Lp ℂ 2 (μ.prod μ))

theorem cut_rows : ∀ᵐ x ∂μ, rowAt μ (cutKernel μ A ha w) x=A.indicator (rowAt μ w) x := by
  have pair := (measurePreserving_prod_add μ μ).quasiMeasurePreserving.ae (cutKernel_ae μ A ha w)
  filter_upwards [rowAt_ae μ w,rowAt_ae μ (cutKernel μ A ha w),Measure.ae_ae_of_ae_prod pair] with x h k m
  by_cases hx : x∈A
  · rw [Set.indicator_of_mem hx]
    apply Lp.ext
    filter_upwards [h,k,m] with y e₁ e₂ e₃
    change cutKernel μ A ha w (x,x+y)=(Prod.fst ⁻¹' A).indicator w (x,x+y) at e₃
    exact e₂.trans ((e₃.trans (Set.indicator_of_mem (s:=Prod.fst ⁻¹' A) hx _)).trans e₁.symm)
  · rw [Set.indicator_of_notMem hx]
    apply Lp.ext
    filter_upwards [k,m,Lp.coeFn_zero ℂ 2 μ] with y e₂ e₃ e₀
    change cutKernel μ A ha w (x,x+y)=(Prod.fst ⁻¹' A).indicator w (x,x+y) at e₃
    exact e₂.trans ((e₃.trans (Set.indicator_of_notMem (s:=Prod.fst ⁻¹' A) hx _)).trans e₀.symm)

open scoped KDClosure.SubgroupMeasure
variable (ν : Measure (Dual G)) [SFinite ν]

omit [SFinite ν] in
theorem cut_kernel_KD (F : FourierRealization μ ν) (kd : LCAQuotient.ambientKD μ ν F w) :
    LCAQuotient.ambientKD μ ν F (cutKernel μ A ha w) := by
  obtain ⟨q,mq,rq,sq⟩ := kd
  refine ⟨(Prod.fst ⁻¹' A).indicator q,mq.indicator (ha.preimage measurable_fst),?_,?_⟩
  · filter_upwards [cut_rows μ A ha w,rq] with x hr hq
    by_cases hx : x∈A
    · rw [Set.indicator_of_mem hx] at hr
      rw [hr]
      filter_upwards [hq] with χ e
      simpa only [Set.indicator_of_mem (s:=Prod.fst ⁻¹' A) (a:=(x,χ)) hx] using e
    · rw [Set.indicator_of_notMem hx] at hr
      rw [hr,map_zero]
      filter_upwards [Lp.coeFn_zero ℂ 2 ν] with χ e
      simpa only [Set.indicator_of_notMem (s:=Prod.fst ⁻¹' A) (a:=(x,χ)) hx,Pi.zero_apply] using e.symm
  · filter_upwards [sq] with z hq
    by_cases hz : z.1∈A
    · rwa [Set.indicator_of_mem (s:=Prod.fst ⁻¹' A) hz]
    · rw [Set.indicator_of_notMem (s:=Prod.fst ⁻¹' A) hz]

omit [IsTopologicalAddGroup G] [BorelSpace G] [SecondCountableTopology G] [μ.IsAddLeftInvariant] in
theorem cut_kernel_hermitian (herm : ∀ᵐ z ∂μ.prod μ, w z=conj (w z.swap))
    (supp : ∀ᵐ z : G×G ∂μ.prod μ, (¬∃ H : CO G, z.2-z.1∈subgroup H) → w z=0)
    (stable : ∀ x y, (∃ H : CO G, y-x∈subgroup H) → (x∈A ↔ y∈A)) :
    ∀ᵐ z ∂μ.prod μ, cutKernel μ A ha w z=conj (cutKernel μ A ha w z.swap) := by
  have s := (Measure.measurePreserving_swap (μ:=μ) (ν:=μ)).quasiMeasurePreserving.ae (cutKernel_ae μ A ha w)
  filter_upwards [cutKernel_ae μ A ha w,s,herm,supp] with z a b h p
  change cutKernel μ A ha w z.swap = (Prod.fst ⁻¹' A).indicator w z.swap at b
  rw [a,b]
  by_cases i : z.1∈A <;> by_cases j : z.2∈A
  · simpa [Set.indicator_of_mem (s:=Prod.fst ⁻¹' A) (a:=z) i,Set.indicator_of_mem (s:=Prod.fst ⁻¹' A) (a:=z.swap) j] using h
  · rw [Set.indicator_of_mem (s:=Prod.fst ⁻¹' A) i,Set.indicator_of_notMem (s:=Prod.fst ⁻¹' A) j,map_zero]
    exact p (fun e => j ((stable _ _ e).mp i))
  · rw [Set.indicator_of_notMem (s:=Prod.fst ⁻¹' A) i,Set.indicator_of_mem (s:=Prod.fst ⁻¹' A) j,←h]
    exact (p (fun e => i ((stable _ _ e).mpr j))).symm
  · rw [Set.indicator_of_notMem (s:=Prod.fst ⁻¹' A) i,Set.indicator_of_notMem (s:=Prod.fst ⁻¹' A) j,map_zero]

/-- Splitting an ambient KD state by a union of U-position cosets gives
two positive operators, each with an actual KD-positive Hermitian kernel,
and their sum equals the original operator. -/
theorem cut_pair [MeasurableNeg G] [MeasurableAdd G] [μ.IsNegInvariant]
    (K : CO G) (F : FourierRealization μ ν) (T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ)
    (pos : T.IsPositive) (act : LCAQuotient.ActsBy μ T w)
    (herm : ∀ᵐ z ∂μ.prod μ, w z=conj (w z.swap)) (kd : LCAQuotient.ambientKD μ ν F w)
    (stable : ∀ x y, (∃ H : CO G, y-x∈subgroup H) → (x∈A ↔ y∈A)) :
    (mask μ A ha).comp T + (mask μ Aᶜ ha.compl).comp T = T ∧
    (∀ (S : Set G) (hs : MeasurableSet S), (S=A ∨ S=Aᶜ) →
      ((mask μ S hs).comp T).IsPositive ∧
      LCAQuotient.ActsBy μ ((mask μ S hs).comp T) (cutKernel μ S hs w) ∧
      (∀ᵐ z ∂μ.prod μ, cutKernel μ S hs w z=conj (cutKernel μ S hs w z.swap)) ∧
      LCAQuotient.ambientKD μ ν F (cutKernel μ S hs w)) := by
  have supp := position_support_of_rows μ ν K F w herm (LCAQuotient.ambientKD_rows μ ν F w kd)
  constructor
  · rw [← ContinuousLinearMap.add_comp,mask_add_compl]; rfl
  · intro S hs cases
    have st : ∀ x y, (∃ H : CO G, y-x∈subgroup H) → (x∈S ↔ y∈S) := by
      rcases cases with rfl|rfl
      · exact stable
      · exact fun x y he => (stable x y he).not
    exact ⟨positive_mask_comp μ S hs T pos (operator_mask_commutes μ w act supp S hs st),
      cut_kernel_acts μ S hs w act,cut_kernel_hermitian μ S hs w herm supp st,cut_kernel_KD μ S hs w ν F kd⟩
end KDClosure.LCAReality
