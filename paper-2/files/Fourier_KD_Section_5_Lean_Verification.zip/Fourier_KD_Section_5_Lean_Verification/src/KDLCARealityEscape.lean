import KDLCARealityKernel
import Mathlib.MeasureTheory.Measure.Real

noncomputable section
namespace KDClosure.LCAReality
open MeasureTheory Set Filter Pointwise Topology
open scoped ENNReal ComplexConjugate
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G]

/-- An element whose entire cyclic orbit is contained in a compact set. -/
def CompactCyclic (h : G) : Prop := ∃ C : Set G, IsCompact C ∧ ∀ n : ℤ, n • h ∈ C

variable [IsTopologicalAddGroup G] [T2Space G] [SigmaCompactSpace G]
  [MeasurableSpace G] [BorelSpace G]

/-- A finite nonzero measure invariant under translation forces compact
containment of the whole cyclic orbit. The same compact difference set
works uniformly over all iterates. -/
theorem compactCyclic_of_invariant_mass (h : G) (ν : Measure G) [IsFiniteMeasure ν]
    (ne : ν ≠ 0) (inv : MeasurePreserving (h+·) ν ν) : CompactCyclic h := by
  have half := ENNReal.half_lt_self (Measure.measure_univ_eq_zero.not.mpr ne)
    (measure_ne_top ν univ)
  have sup : (⨆ n : ℕ, ν (compactCovering G n)) = ν univ := by
    rw [← (show Monotone (compactCovering G) from fun _ _ h => compactCovering_subset G h).measure_iUnion, iUnion_compactCovering]
  obtain ⟨j,hj⟩ := lt_iSup_iff.mp (sup ▸ half : ν univ / 2 < ⨆ n : ℕ, ν (compactCovering G n))
  let C := compactCovering G j
  have hc : IsCompact C := isCompact_compactCovering G j
  have mc := hc.isClosed.measurableSet
  have hreal : ν.real univ / 2 < ν.real C := by
    have H := (ENNReal.toReal_lt_toReal (by finiteness) (measure_ne_top ν C)).mpr hj
    simpa [Measure.real, ENNReal.toReal_div] using H
  have pos (n : ℕ) : ∃ x ∈ C, n • h+x ∈ C := by
    have iter (x : G) : (h+·)^[n] x=n • h+x := by
      induction n with
      | zero => simp
      | succ n ih => rw [Function.iterate_succ_apply', ih, succ_nsmul]; abel
    by_contra! no
    have sub : ((h+·)^[n]) ⁻¹' C ⊆ Cᶜ := fun x hx hx' =>
      no x hx' (iter x ▸ hx)
    have le := measureReal_mono (μ:=ν) sub
    have eq := congrArg ENNReal.toReal ((inv.iterate n).measure_preimage mc.nullMeasurableSet)
    change ν.real (((h+·)^[n]) ⁻¹' C) = ν.real C at eq
    rw [eq,measureReal_compl mc] at le
    linarith
  have cc : IsCompact (C-C) := by
    rw [← Set.sub_image_prod]
    exact (hc.prod hc).image continuous_sub
  refine ⟨C-C,cc,?_⟩
  intro i
  cases i with
  | ofNat n =>
    obtain ⟨x,hx,hx'⟩ := pos n
    exact ⟨_,hx',_,hx,by simp⟩
  | negSucc n =>
    obtain ⟨x,hx,hx'⟩ := pos (n+1)
    exact ⟨_,hx,_,hx',by simp [negSucc_zsmul,add_comm]⟩

/-- Nonzero translation-periodic square-integrable functions have a compact-cyclic period. -/
theorem periodic_slice_zero_of_not_compactCyclic (h : G) (outside : ¬CompactCyclic h)
    (μ : Measure G) [μ.IsAddLeftInvariant] (f : Lp ℂ 2 μ)
    (inv : ∀ᵐ x ∂μ, f (h+x)=f x) : f=0 := by
  let d (x : G) := ENNReal.ofReal (‖f x‖^2)
  have md : Measurable d := ((Lp.stronglyMeasurable f).measurable.norm.pow_const 2).ennreal_ofReal
  have integr := (memLp_two_iff_integrable_sq_norm (Lp.memLp f).1).mp (Lp.memLp f)
  have hd : ∫⁻ x, d x ∂μ ≠ ∞ := integr.lintegral_lt_top.ne
  let _ : IsFiniteMeasure (μ.withDensity d) := isFiniteMeasure_withDensity hd
  have hv : MeasurePreserving (h+·) (μ.withDensity d) (μ.withDensity d) :=
    withDensity_periodic (measurePreserving_add_left μ h) md (inv.mono fun x hx => by simp [d,hx])
  have zero : μ.withDensity d = 0 := by
    by_contra ne
    exact outside (compactCyclic_of_invariant_mass h _ ne hv)
  have ae := (withDensity_eq_zero_iff md.aemeasurable).mp zero
  apply Lp.ext
  filter_upwards [ae,Lp.coeFn_zero ℂ 2 μ] with x hx hz
  change ENNReal.ofReal (‖f x‖^2)=0 at hx
  rw [ENNReal.ofReal_eq_zero] at hx
  rw [hz]
  exact norm_eq_zero.mp (by nlinarith [norm_nonneg (f x)])

variable [SecondCountableTopology G] (μ : Measure G) [SFinite μ] [μ.IsAddLeftInvariant]

/-- Without any compact-open assumption, almost every displacement slice
is concentrated on compact-cyclic displacements. The conclusion is
deliberately nested so that it does not require measurability of CompactCyclic. -/
theorem compactCyclic_slice_support (k : Lp ℂ 2 (μ.prod μ))
    (hermitian : ∀ᵐ z : G × G ∂μ.prod μ, k z = conj (k (z.2,z.1)))
    (row : ∀ᵐ z : G × G ∂μ.prod μ, k (z.1,z.1+z.2) = conj (k (z.1,z.1-z.2))) :
    ∀ᵐ h ∂μ, ∀ᵐ x ∂μ, (¬CompactCyclic h) → k (x,x+h)=0 := by
  let s (z : G×G) := (z.2,z.2+z.1)
  have mp : MeasurePreserving s (μ.prod μ) (μ.prod μ) := measurePreserving_prod_add_swap μ μ
  have m := (Lp.memLp k).comp_measurePreserving mp
  have square := (memLp_two_iff_integrable_sq_norm m.1).mp m
  have periodic := Measure.ae_ae_of_ae_prod (displacement_periodic μ k hermitian row)
  have nested : ∀ᵐ h ∂μ, ∀ᵐ x ∂μ, (¬CompactCyclic h) → k (x,x+h)=0 := by
    filter_upwards [square.prod_right_ae,periodic] with h hi inv
    by_cases outside : ¬CompactCyclic h
    · let f (x : G) := k (x,x+h)
      have mf : Measurable f := (Lp.stronglyMeasurable k).measurable.comp
        (measurable_id.prodMk (measurable_id.add measurable_const))
      have lp : MemLp f 2 μ := (memLp_two_iff_integrable_sq_norm mf.aestronglyMeasurable).mpr hi
      have tr := (measurePreserving_add_left μ h).quasiMeasurePreserving.ae_eq_comp lp.coeFn_toLp
      have periodic' : ∀ᵐ x ∂μ, lp.toLp f (h+x)=lp.toLp f x := by
        filter_upwards [lp.coeFn_toLp,tr,inv] with x hx ht hp
        exact ht.trans (hp.trans hx.symm)
      have zero := periodic_slice_zero_of_not_compactCyclic h outside μ (lp.toLp f) periodic'
      have ae := lp.coeFn_toLp
      rw [zero] at ae
      filter_upwards [ae,Lp.coeFn_zero ℂ 2 μ] with x hx hx0
      exact fun _ => hx.symm.trans hx0
    · exact .of_forall fun _ f => False.elim (outside f)
  exact nested

/-- If almost every displacement escapes every compact set along its
integer orbit, a Hermitian kernel with row involution is zero. -/
theorem kernel_zero_of_ae_escape (k : Lp ℂ 2 (μ.prod μ))
    (hermitian : ∀ᵐ z : G × G ∂μ.prod μ, k z = conj (k (z.2,z.1)))
    (row : ∀ᵐ z : G × G ∂μ.prod μ, k (z.1,z.1+z.2) = conj (k (z.1,z.1-z.2)))
    (escape : ∀ᵐ h ∂μ, ¬ CompactCyclic h) : k=0 := by
  let s (z : G×G) := (z.2,z.2+z.1)
  have mp : MeasurePreserving s (μ.prod μ) (μ.prod μ) := measurePreserving_prod_add_swap μ μ
  have ms : MeasurableSet {z | k (s z)=0} :=
    measurableSet_eq_fun ((Lp.stronglyMeasurable k).measurable.comp mp.measurable) measurable_const
  have joint : ∀ᵐ z ∂μ.prod μ, k (s z)=0 := (Measure.ae_prod_iff_ae_ae ms).mpr (by
    filter_upwards [compactCyclic_slice_support μ k hermitian row,escape] with h hi he
    exact hi.mono fun x hx => hx he)
  have invS : MeasurePreserving (fun z : G×G => (-z.1+z.2,z.1)) (μ.prod μ) (μ.prod μ) :=
    Measure.measurePreserving_swap.comp (measurePreserving_prod_neg_add μ μ)
  apply Lp.ext
  filter_upwards [invS.quasiMeasurePreserving.ae joint,Lp.coeFn_zero ℂ 2 (μ.prod μ)] with z hz h0
  change k (z.1,z.1+(-z.1+z.2))=0 at hz
  exact (by simpa only [add_neg_cancel_left, Prod.mk.eta] using hz : k z=0).trans h0.symm

end KDClosure.LCAReality
