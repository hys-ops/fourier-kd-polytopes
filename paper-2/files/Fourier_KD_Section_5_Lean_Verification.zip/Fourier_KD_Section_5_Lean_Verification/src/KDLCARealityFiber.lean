import KDLCARealityFrequencyCut

noncomputable section
namespace KDClosure.LCAReality
open MeasureTheory Filter Set CompactCore Topology
open scoped ENNReal ComplexConjugate Pointwise ComplexOrder KDClosure.SubgroupMeasure
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
    [MeasurableSpace G] [BorelSpace G] [SecondCountableTopology G]
variable (μ : Measure G) [SFinite μ] [μ.IsAddLeftInvariant]
variable (ν : Measure (Dual G))
variable {I : Type*} [Countable I]

/-- The joint frequency fiber of any countable family of translations. -/
def frequencyFiber (h : I → G) (a : I → ℂ) : Set (Dual G) := {χ | ∀ i, phase χ (-h i)=a i}

omit [IsTopologicalAddGroup G] [MeasurableSpace G] [BorelSpace G] [SecondCountableTopology G] in
theorem measurable_frequencyFiber (h : I → G) (a : I → ℂ) : MeasurableSet (frequencyFiber h a) := by
  have eq : frequencyFiber h a = ⋂ i, {χ : Dual G | phase χ (-h i)=a i} := by ext χ; simp [frequencyFiber]
  rw [eq]
  exact MeasurableSet.iInter fun i => measurableSet_eq_fun (phase_measurable_at _) measurable_const

omit [SecondCountableTopology G] [SFinite μ] in
/-- A square-integrable vector lies in the physical spectral row projection
exactly when every translation acts by its prescribed eigenvalue. -/
theorem rowMask_fixed_iff (F : FourierRealization μ ν)
    (h : I → G) (a : I → ℂ) (valid : MaskExact μ ν F (frequencyFiber h a) (measurable_frequencyFiber h a)) (f : Lp ℂ 2 μ) :
    frequencyRowMask μ ν F (frequencyFiber h a) (measurable_frequencyFiber h a) f=f ↔
      ∀ i, shift μ (h i) f = a i • f := by
  let S := frequencyFiber h a
  let hs := measurable_frequencyFiber h a
  let B := frequencyRowMask μ ν F S hs
  have sp : B f=f ↔ ∀ᵐ χ ∂ν, χ∉S → F.isometry f χ=0 := by
    have m := mask_ae ν S hs (F.isometry f)
    constructor
    · intro eq
      have t : F.isometry f = (mask ν S hs) (F.isometry f) :=
        (congrArg F.isometry eq).symm.trans (valid f)
      rw [←t] at m
      exact m.mono fun χ he hn => he.trans (Set.indicator_of_notMem hn _)
    · intro hv
      apply F.isometry.injective
      rw [valid]
      apply Lp.ext
      filter_upwards [m,hv] with χ he hn
      by_cases hc : χ∈S
      · exact he.trans (Set.indicator_of_mem hc _)
      · exact he.trans ((Set.indicator_of_notMem hc _).trans (hn hc).symm)
  change B f=f ↔ _
  rw [sp]
  constructor
  · intro supp i
    apply F.isometry.injective
    rw [fourier_shift,map_smul]
    apply Lp.ext
    filter_upwards [supp,modulate_ae ν (-(h i)) (F.isometry f),Lp.coeFn_smul (a i) (F.isometry f)] with χ hh hm hs
    rw [hm,hs]
    by_cases hc : χ∈S
    · change phase χ (-(h i))*F.isometry f χ=a i*F.isometry f χ
      rw [(hc : ∀ j, phase χ (-h j)=a j) i]
    · change phase χ (-(h i))*F.isometry f χ=a i*F.isometry f χ
      rw [hh hc,mul_zero,mul_zero]
  · intro fixed
    have each (i : I) : ∀ᵐ χ ∂ν, phase χ (-h i)*F.isometry f χ=a i*F.isometry f χ := by
      have e := congrArg F.isometry (fixed i)
      rw [fourier_shift,map_smul] at e
      have hm := modulate_ae ν (-h i) (F.isometry f)
      rw [e] at hm
      filter_upwards [hm,Lp.coeFn_smul (a i) (F.isometry f)] with χ hy hz
      exact hy.symm.trans hz
    filter_upwards [ae_all_iff.mpr each] with χ hall
    intro outside
    by_contra ne
    exact outside (fun i => mul_right_cancel₀ ne (hall i))

end KDClosure.LCAReality
