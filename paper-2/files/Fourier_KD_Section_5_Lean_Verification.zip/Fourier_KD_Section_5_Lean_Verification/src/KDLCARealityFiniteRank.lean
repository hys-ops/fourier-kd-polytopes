import KDLCARealityCell
import KDLCARealitySingleSector
import KDLCAQuotientLocalize

noncomputable section
namespace KDClosure.LCAReality
open MeasureTheory Filter Set CompactCore CompactCoset Topology LCAQuotient
open scoped ENNReal ComplexConjugate Pointwise ComplexOrder KDClosure.SubgroupMeasure BigOperators
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
    [MeasurableSpace G] [BorelSpace G] [SecondCountableTopology G]
variable (μ : Measure G) [SFinite μ] [μ.IsAddHaarMeasure]

omit [SecondCountableTopology G] [SFinite μ] in
theorem cell_mem (H : CO G) (γ : Dual G) (a : G) :
    MemLp ((coset H a).indicator (phase γ)) 2 μ := by
  let C := coset H a
  have m := coset_meas H a
  have g := memLp_indicator_const (μ:=μ) (2:ℝ≥0∞) m (1:ℝ) (Or.inr (coset_compact H a).measure_ne_top)
  have cont : Continuous (fun x : G => phase γ x) := continuous_subtype_val.comp γ.continuous
  apply g.mono' (cont.measurable.indicator m).aestronglyMeasurable
  exact .of_forall fun y => by
    by_cases h : y∈coset H a
    · simp only [Set.indicator_of_mem h]
      exact (Circle.norm_coe _).le
    · simp [h]

def cell (H : CO G) (γ : Dual G) (a : G) : Lp ℂ 2 μ := (cell_mem μ H γ a).toLp _

omit [SecondCountableTopology G] [SFinite μ] in
theorem cell_ae (H : CO G) (γ : Dual G) (a : G) :
    (cell μ H γ a : G→ℂ)=ᵐ[μ] (coset H a).indicator (phase γ) := (cell_mem μ H γ a).coeFn_toLp

variable (H K : CO G)
local instance : Fintype (CoreQuot H K) := @Fintype.ofFinite _ (finite_core H K)

omit [SecondCountableTopology G] [IsTopologicalAddGroup G] [MeasurableSpace G] [BorelSpace G] in
/-- Partition of a physical position coset of K into exactly [K:H]
cosets of H, with an explicit unique finite quotient index. -/
theorem partition_index (le : H≤K) (u x : G) :
    (x∈coset K u ↔ ∃! j : CoreQuot H K, x∈coset H (u+(CompactCoset.representative H K j:G))) := by
  let r := CompactCoset.representative H K
  have criterion {j : CoreQuot H K} (hk : x-u ∈ K.val) :
      x∈coset H (u+(r j:G)) ↔ quotientIndex H K (x-u) hk=j := by
    change x-(u+(r j:G))∈H.val ↔ quotientIndex H K (x-u) hk=j
    have key := QuotientAddGroup.eq_iff_sub_mem (N:=((subgroup H).addSubgroupOf (subgroup K)))
      (x:=(⟨x-u,hk⟩:subgroup K)) (y:=r j)
    change quotientIndex H K (x-u) hk=QuotientAddGroup.mk' _ (r j) ↔ (x-u)-(r j:G)∈H.val at key
    rw [show QuotientAddGroup.mk' _ (r j)=j from CompactCoset.representative_spec H K j,sub_sub] at key
    exact key.symm
  constructor
  · intro hx
    exact ⟨quotientIndex H K (x-u) hx,(criterion hx).mpr rfl,fun j h => ((criterion hx).mp h).symm⟩
  · rintro ⟨j,h,_⟩
    have v := K.val.add_mem (le (show x-(u+(r j:G))∈H.val from h)) (r j).property
    change x-u∈K.val
    rw [show x-(u+(r j:G))+(r j:G)=x-u from by abel] at v
    exact v

/-- Every vector with one position coset and one H-character is a finite
linear combination of the [K:H] explicit wave packets on the small cosets. -/
theorem mode_span (le : H≤K) (u : G) (γ : Dual G) (v : Lp ℂ 2 μ)
    (support : ∀ᵐ x ∂μ, x∉coset K u → v x=0)
    (fixed : ∀ l : subgroup H, LCAReality.shift μ (l:G) v=phase γ (l:G) • v) :
    v ∈ Submodule.span ℂ (Set.range (fun j : CoreQuot H K => cell μ H γ (u+(CompactCoset.representative H K j:G)))) := by
  classical
  let r (j : CoreQuot H K) := u+(CompactCoset.representative H K j:G)
  let W := Submodule.span ℂ (Set.range (fun j : CoreQuot H K => cell μ H γ (r j)))
  choose c spec using fun j : CoreQuot H K => mode_on_coset μ H γ v fixed (r j)
  let w (j : CoreQuot H K) := c j • cell μ H γ (r j)
  have eval (j : CoreQuot H K) : ∀ᵐ x ∂μ, w j x=c j*((coset H (r j)).indicator (phase γ) x) := by
    filter_upwards [Lp.coeFn_smul (c j) (cell μ H γ (r j)),cell_ae μ H γ (r j)] with x t s
    change w j x=c j*(cell μ H γ (r j) x) at t
    rw [t,s]
  have eq : v=∑ j, w j := by
    apply Lp.ext
    filter_upwards [support,ae_all_iff.mpr spec,ae_all_iff.mpr eval,Lp.coeFn_fun_finsetSum Finset.univ w] with x sup hc hw sum
    rw [sum]
    by_cases inK : x∈coset K u
    · obtain ⟨j,hj,unique⟩ := (partition_index H K le u x).mp inK
      rw [Finset.sum_eq_single j]
      · rw [hw,Set.indicator_of_mem hj,hc j hj]
      · intro i _ ij
        have no : x∉coset H (r i) := fun hi => ij (unique i hi)
        rw [hw,Set.indicator_of_notMem no,mul_zero]
      · simp
    · rw [sup inK]
      symm
      apply Finset.sum_eq_zero
      intro i _
      have no : x∉coset H (r i) := by
        intro hi
        have h' := K.val.add_mem (le (show x-(u+(CompactCoset.representative H K i:G))∈H.val from hi)) (CompactCoset.representative H K i).property
        apply inK
        change x-u∈K.val
        rw [show x-(u+(CompactCoset.representative H K i:G))+(CompactCoset.representative H K i:G)=x-u from by abel] at h'
        exact h'
      rw [hw,Set.indicator_of_notMem no,mul_zero]
  rw [eq]
  exact W.sum_mem (fun j _ => W.smul_mem (c j) (Submodule.subset_span (Set.mem_range_self j)))

theorem finite_rank_in_mode (le : H≤K) (u : G) (γ : Dual G) (T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ)
    (supp : ∀ f, ∀ᵐ x ∂μ, x∉coset K u → T f x=0)
    (mode : ∀ l : subgroup H, ∀ f, LCAReality.shift μ (l:G) (T f)=phase γ (l:G) • T f) :
    FiniteDimensional ℂ (LinearMap.range T.toLinearMap) ∧
       Module.finrank ℂ (LinearMap.range T.toLinearMap) ≤ idx H K := by
  classical
  let v (j : CoreQuot H K) := cell μ H γ (u+(CompactCoset.representative H K j:G))
  let V := Submodule.span ℂ (Set.range v)
  let _ : FiniteDimensional ℂ V := FiniteDimensional.span_of_finite ℂ (Set.finite_range v)
  have subset : LinearMap.range T.toLinearMap ≤ V := by
    rintro _ ⟨f,rfl⟩
    exact mode_span μ H K le u γ (T f) (supp f) (fun l => mode l f)
  refine ⟨FiniteDimensional.of_injective (Submodule.inclusion subset) (Submodule.inclusion_injective _),?_⟩
  have small := Submodule.finrank_mono subset
  have size : Module.finrank ℂ V ≤ Fintype.card (CoreQuot H K) :=
    (finrank_span_le_card (R:=ℂ) (Set.range v)).trans
      (by convert! Fintype.card_range_le v; rw [Set.toFinset_card])
  exact small.trans (size.trans_eq (Nat.card_eq_fintype_card (α:=CoreQuot H K)).symm)

end KDClosure.LCAReality
