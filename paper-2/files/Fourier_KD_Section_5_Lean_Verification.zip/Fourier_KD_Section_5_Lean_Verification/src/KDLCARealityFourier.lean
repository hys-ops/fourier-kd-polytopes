import KDLCARealityKernel
import KDCompactCosetAE
import Mathlib.MeasureTheory.Function.SimpleFuncDenseLp

/-! The L² reality implication requires only an isometric Fourier transform
with its defining integral on the dense integrable functions. Proving this
interface is inhabited on a group is a separate harmonic analysis task. -/
noncomputable section
namespace KDClosure.LCAReality
open MeasureTheory Filter Set CompactCore
open scoped ENNReal ComplexConjugate
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G]
  [MeasurableSpace G] [MeasurableNeg G]
abbrev Dual (G : Type*) [AddCommGroup G] [TopologicalSpace G] := PontryaginDual (Multiplicative G)
variable (μ : Measure G) [μ.IsNegInvariant]
variable [MeasurableSpace (Dual G)] (ν : Measure (Dual G))

def phase (χ : Dual G) (x : G) : ℂ := χ (Multiplicative.ofAdd x)

def conjugateLp {X : Type*} [MeasurableSpace X] (ρ : Measure X) :
    Lp ℂ 2 ρ →L[ℝ] Lp ℂ 2 ρ := Complex.conjCLE.toContinuousLinearMap.compLpL 2 ρ

theorem conjugate_ae {X : Type*} [MeasurableSpace X] (ρ : Measure X) (f : Lp ℂ 2 ρ) :
    (conjugateLp ρ f : X → ℂ) =ᵐ[ρ] fun x => conj (f x) :=
  Complex.conjCLE.toContinuousLinearMap.coeFn_compLpL f

def reflect : Lp ℂ 2 μ →L[ℝ] Lp ℂ 2 μ :=
  (conjugateLp μ).comp ((Lp.compMeasurePreservingₗᵢ ℝ Neg.neg (Measure.measurePreserving_neg μ)).toContinuousLinearMap)

omit [TopologicalSpace G] [MeasurableSpace (Dual G)] in
theorem reflect_ae (f : Lp ℂ 2 μ) : (reflect μ f : G → ℂ) =ᵐ[μ] fun x => conj (f (-x)) := by
  let i := Lp.compMeasurePreserving Neg.neg (Measure.measurePreserving_neg μ) f
  filter_upwards [conjugate_ae μ i,Lp.coeFn_compMeasurePreserving f (Measure.measurePreserving_neg μ)] with x hc hi
  exact hc.trans (congrArg conj hi)

omit [MeasurableNeg G] in
/-- This interface asserts precisely Plancherel isometry and agreement with
the ordinary positive-phase character integral on integrable L² functions.
No involution, reality, kernel support or quantum classification is a field. -/
structure FourierRealization where
  isometry : Lp ℂ 2 μ →ₗᵢ[ℂ] Lp ℂ 2 ν
  integral_ae : ∀ f : Lp ℂ 2 μ, Integrable (f : G→ℂ) μ →
    (isometry f : Dual G → ℂ) =ᵐ[ν] fun χ => ∫ x, f x * phase χ x ∂μ

theorem fourier_reflection (F : FourierRealization μ ν) (f : Lp ℂ 2 μ) :
    F.isometry (reflect μ f)=conjugateLp ν (F.isometry f) := by
  have intCase (g : Lp ℂ 2 μ) (hi : Integrable (g : G → ℂ) μ) :
      F.isometry (reflect μ g)=conjugateLp ν (F.isometry g) := by
    have j := (Measure.measurePreserving_neg μ).integrable_comp_of_integrable hi
    have j' := Complex.conjCLE.toContinuousLinearMap.integrable_comp j
    have hj : Integrable (reflect μ g : G → ℂ) μ := j'.congr (reflect_ae μ g).symm
    apply Lp.ext
    filter_upwards [F.integral_ae (reflect μ g) hj,F.integral_ae g hi,conjugate_ae ν (F.isometry g)] with χ hg hq hc
    rw [hg,hc,hq,←integral_conj]
    calc
      _ = ∫ x, conj (g (-x)) * phase χ x ∂μ :=
        integral_congr_ae ((reflect_ae μ g).mono fun x hx => by rw [hx])
      _ = ∫ x, conj (g x * phase χ x) ∂μ := by
        rw [← integral_neg_eq_self (μ:=μ) (fun x => conj (g x * phase χ x))]
        apply integral_congr_ae
        apply Filter.Eventually.of_forall
        intro x
        have ph : phase χ (-x) = conj (phase χ x) := by
          change ((χ ((Multiplicative.ofAdd x)⁻¹)):ℂ)=_
          rw [map_inv,Circle.coe_inv_eq_conj]; rfl
        change conj (g (-x)) * phase χ x = conj (g (-x) * phase χ (-x))
        rw [map_mul,ph,starRingEnd_self_apply]
  apply Lp.induction (by norm_num : (2:ℝ≥0∞)≠∞)
    (fun g => F.isometry (reflect μ g)=conjugateLp ν (F.isometry g)) _ _ _ f
  · intro c s hs hm
    exact intCase _ (integrable_indicatorConstLp hs hm.ne c)
  · intro a b ha hb _ e₁ e₂
    simp only [map_add,e₁,e₂]
  · exact isClosed_eq (F.isometry.continuous.comp (reflect μ).continuous)
      ((conjugateLp ν).continuous.comp F.isometry.continuous)

/-- A real L² Fourier row implies the physical conjugate-reflection identity
in Haar measure; injectivity is applied only after intertwining is proved. -/
theorem row_reflection_of_real (F : FourierRealization μ ν) (f : Lp ℂ 2 μ)
    (real : ∀ᵐ χ ∂ν, conj (F.isometry f χ) = F.isometry f χ) :
    ∀ᵐ x ∂μ, f x=conj (f (-x)) := by
  have eq : reflect μ f=f := F.isometry.injective ((fourier_reflection μ ν F f).trans (Lp.ext <|
    (conjugate_ae ν (F.isometry f)).trans real))
  have h := reflect_ae μ f
  rw [eq] at h
  exact h

end KDClosure.LCAReality
