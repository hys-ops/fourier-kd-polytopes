import KDLCARealityTranspose
import KDLCARealityCut

noncomputable section
namespace KDClosure.LCAReality
open MeasureTheory Filter Set CompactCore Topology
open scoped ENNReal ComplexConjugate Pointwise ComplexOrder KDClosure.SubgroupMeasure

variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
    [MeasurableSpace G] [BorelSpace G] [SecondCountableTopology G]
variable (μ : Measure G) [SFinite μ] [μ.IsAddLeftInvariant]
variable (ν : Measure (Dual G))

/-- Pull a target spectral mask back to the source by the Hilbert adjoint. -/
def frequencyRowMask (F : FourierRealization μ ν)
    (S : Set (Dual G)) (hs : MeasurableSet S) : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ :=
  let J := F.isometry.toContinuousLinearMap
  J.adjoint.comp ((mask ν S hs).comp J)

/-- A mask carries the closed isometry range to itself. The exactness of
all joint character sectors and their complements is proved in Range. -/
def MaskExact (F : FourierRealization μ ν) (S : Set (Dual G)) (hs : MeasurableSet S) : Prop :=
  ∀ f, F.isometry (frequencyRowMask μ ν F S hs f)=mask ν S hs (F.isometry f)

omit [SecondCountableTopology G] [SFinite μ] in
theorem frequencyRowMask_shift (F : FourierRealization μ ν)
    (S : Set (Dual G)) (hs : MeasurableSet S) (valid : MaskExact μ ν F S hs) (x : G) (f : Lp ℂ 2 μ) :
    shift μ x (frequencyRowMask μ ν F S hs f)=frequencyRowMask μ ν F S hs (shift μ x f) := by
  apply F.isometry.injective
  rw [fourier_shift,valid,valid,fourier_shift]
  apply Lp.ext
  filter_upwards [modulate_ae ν (-x) (mask ν S hs (F.isometry f)),mask_ae ν S hs (F.isometry f),
    mask_ae ν S hs (modulate ν (-x) (F.isometry f)),modulate_ae ν (-x) (F.isometry f)]
    with χ a b c d
  rw [a,b,c]
  by_cases h : χ∈S <;> simp [h,d]

omit [IsTopologicalAddGroup G] [BorelSpace G] [SecondCountableTopology G] [SFinite μ] [μ.IsAddLeftInvariant] in
theorem frequencyRowMask_projection (F : FourierRealization μ ν)
    (S : Set (Dual G)) (hs : MeasurableSet S) (valid : MaskExact μ ν F S hs) : IsStarProjection (frequencyRowMask μ ν F S hs) := by
  have p := mask_isStarProjection ν S hs
  let B := frequencyRowMask μ ν F S hs
  have eq (f : Lp ℂ 2 μ) := valid f
  constructor
  · ext f : 1
    apply F.isometry.injective
    change F.isometry (B (B f)) = F.isometry (B f)
    rw [eq,eq]
    exact DFunLike.congr_fun p.isIdempotentElem.eq (F.isometry f)
  · apply ContinuousLinearMap.isSelfAdjoint_iff_isSymmetric.mpr
    intro f g
    change inner ℂ (B f) g = inner ℂ f (B g)
    rw [←F.isometry.inner_map_map (B f) g,←F.isometry.inner_map_map f (B g),eq,eq]
    exact (ContinuousLinearMap.isSelfAdjoint_iff_isSymmetric.mp p.isSelfAdjoint) _ _

end KDClosure.LCAReality
