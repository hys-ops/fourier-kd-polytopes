import KDLCARealityRange
import KDLCARealityFrequencySign
import KDLCAQuotientSplit

noncomputable section
namespace KDClosure.LCAReality
open MeasureTheory Filter Set CompactCore Topology LCAQuotient
open scoped ENNReal ComplexConjugate Pointwise ComplexOrder KDClosure.SubgroupMeasure
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
  [MeasurableSpace G] [BorelSpace G] [SecondCountableTopology G]
variable (μ : Measure G) [SFinite μ] [μ.IsAddLeftInvariant] (ν : Measure (Dual G))
variable {I : Type*} [Countable I]
section Abstract
variable {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℂ H] [CompleteSpace H]
theorem positive_input_cut (T P : H →L[ℂ] H) (t : T.IsPositive) (p : IsStarProjection P)
    (comm : P.comp T=T.comp P) : (T.comp P).IsPositive := by
  have pos := t.conj_adjoint P
  have sa : P.adjoint=P := p.isSelfAdjoint.star_eq
  rw [sa] at pos
  have e : (P.comp T).comp P = T.comp P := by
    rw [comm]
    change T.comp (P.comp P)=_
    rw [show P.comp P=P from p.isIdempotentElem]
  exact e ▸ pos
end Abstract

omit [IsTopologicalAddGroup G] [BorelSpace G] [SecondCountableTopology G] [SFinite μ] [μ.IsAddLeftInvariant] in
theorem input_mask_compl (F : FourierRealization μ ν)
    (S : Set (Dual G)) (hs : MeasurableSet S) (okS : MaskExact μ ν F S hs) (okC : MaskExact μ ν F Sᶜ hs.compl) :
    kernelTranspose μ (frequencyRowMask μ ν F S hs)+kernelTranspose μ (frequencyRowMask μ ν F Sᶜ hs.compl)=1 := by
  let B := frequencyRowMask μ ν F S hs
  let D := frequencyRowMask μ ν F Sᶜ hs.compl
  have e : B+D=1 := by
    ext v : 1
    apply F.isometry.injective
    change F.isometry (B v+D v)=F.isometry v
    rw [map_add,okS,okC]
    exact DFunLike.congr_fun (mask_add_compl ν S hs) (F.isometry v)
  have bsa : B.adjoint=B := (frequencyRowMask_projection μ ν F S hs okS).isSelfAdjoint.star_eq
  have dsa : D.adjoint=D := (frequencyRowMask_projection μ ν F Sᶜ hs.compl okC).isSelfAdjoint.star_eq
  ext v : 1
  change complexConj μ (B.adjoint (complexConj μ v))+complexConj μ (D.adjoint (complexConj μ v))=v
  rw [bsa,dsa,←map_add]
  have sum : B (complexConj μ v)+D (complexConj μ v)=complexConj μ v := DFunLike.congr_fun e _
  rw [sum,complexConj_invol]

/-- An extreme physical state is supported entirely in, or is orthogonal
to, any joint input character sector of countably many translations with
which it commutes. Each side of the split is verified numerically KD-positive
through its actual measurable phase-space representative. -/
theorem frequency_dichotomy (F : FourierRealization μ ν)
    (h : I→G) (a : I→ℂ) (T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ)
    (e : T∈(ambientStates μ ν F).extremePoints ℝ)
    (comm : ∀ i, (LCAReality.shift μ (h i)).comp T=T.comp (LCAReality.shift μ (h i))) :
    T.comp (jointProjection μ ν F h a)=0 ∨ T.comp (jointProjection μ ν F h a)=T := by
  obtain ⟨pt,tr,k,act,_,kd⟩ := e.1
  let S := frequencyFiber h a
  let hs := measurable_frequencyFiber h a
  have pair := fiberMask_preimages μ ν F h a
  have okS : MaskExact μ ν F S hs := pair.1
  have okC : MaskExact μ ν F Sᶜ hs.compl := pair.2
  let P := jointProjection μ ν F h a
  let R := kernelTranspose μ (frequencyRowMask μ ν F Sᶜ hs.compl)
  have p : IsStarProjection P := transpose_projection μ _ (frequencyRowMask_projection μ ν F S hs okS)
  have r : IsStarProjection R := transpose_projection μ _ (frequencyRowMask_projection μ ν F Sᶜ hs.compl okC)
  have pc : P.comp T=T.comp P := jointProjection_commutes μ ν F h a okS T pt.isSelfAdjoint.star_eq comm
  have pr : P+R=1 := input_mask_compl μ ν F S hs okS okC
  have rc : R.comp T=T.comp R := by
    have er : R=1-P := by rw [←pr]; abel
    rw [er,ContinuousLinearMap.sub_comp,ContinuousLinearMap.comp_sub,pc]; rfl
  have pu := positive_input_cut T P pt p pc
  have pv := positive_input_cut T R pt r rc
  have uv : T.comp P + T.comp R=T := by rw [←ContinuousLinearMap.comp_add,pr]; rfl
  obtain ⟨ta,tb,_,_,_,qa,qb⟩ := LCAQuotient.trace_split pu pv (uv.symm ▸ tr)
  obtain ⟨ka,_,ak⟩ := CompactFourier.exists_physical_kernel (T.comp P) pu ⟨ta,qa.1⟩
  obtain ⟨kb,_,bk⟩ := CompactFourier.exists_physical_kernel (T.comp R) pv ⟨tb,qb.1⟩
  have cu : kdCone μ ν F (T.comp P) :=
    ⟨pu,ka,ak,frequency_cut_KD μ ν F S hs okS T k ka act ak kd⟩
  have cv : kdCone μ ν F (T.comp R) :=
    ⟨pv,kb,bk,frequency_cut_KD μ ν F Sᶜ hs.compl okC T k kb act bk kd⟩
  obtain ⟨c,eqn⟩ := split_proportional μ ν F cu cv (uv.symm ▸ e)
  rw [uv] at eqn
  have cp : c • (T.comp P) = T.comp P := by
    calc
      _ = (c • T).comp P := rfl
      _ = (T.comp P).comp P := congrArg (fun A : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ => A.comp P) eqn.symm
      _ = _ := by change T.comp (P.comp P)=_; rw [show P.comp P=P from p.isIdempotentElem]
  by_cases one : c=1
  · exact Or.inr (by simpa only [one,one_smul] using eqn)
  · apply Or.inl
    have null : (c-1) • (T.comp P)=0 := by rw [sub_smul,cp,one_smul,sub_self]
    exact (smul_eq_zero.mp null).resolve_left (sub_ne_zero.mpr one)
end KDClosure.LCAReality
