import KDLCARealityFrequencyCut

noncomputable section
namespace KDClosure.LCAReality
open MeasureTheory Filter Set CompactCore Topology
open scoped ENNReal ComplexConjugate Pointwise ComplexOrder KDClosure.SubgroupMeasure

variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
    [MeasurableSpace G] [BorelSpace G] [SecondCountableTopology G]
variable (μ : Measure G) [SFinite μ] [μ.IsAddLeftInvariant]
variable (ν : Measure (Dual G))

/-- Exact improvement over an almost-everywhere support statement.
Whenever the physical cut has an integral kernel, the original KD symbol
restricts as a function on the entire dual mask. -/
theorem frequency_cut_KD (F : FourierRealization μ ν)
    (S : Set (Dual G)) (hs : MeasurableSet S) (valid : MaskExact μ ν F S hs)
    (T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ) (k k' : Lp ℂ 2 (μ.prod μ)) (rep : LCAQuotient.ActsBy μ T k)
    (rep' : LCAQuotient.ActsBy μ (T.comp (kernelTranspose μ (frequencyRowMask μ ν F S hs))) k')
    (kd : LCAQuotient.ambientKD μ ν F k) : LCAQuotient.ambientKD μ ν F k' := by
  obtain ⟨q,mq,rq,pq⟩ := kd
  let B := frequencyRowMask μ ν F S hs
  have rows := row_of_transpose_cut μ T B k k' rep rep' (frequencyRowMask_shift μ ν F S hs valid)
  refine ⟨(Prod.snd ⁻¹' S).indicator q,mq.indicator (hs.preimage measurable_snd),?_,?_⟩
  · filter_upwards [rows,rq] with x h hr
    rw [h,valid]
    filter_upwards [hr,mask_ae ν S hs (F.isometry (rowAt μ k x))] with χ a b
    rw [b]
    by_cases hc : χ∈S
    · simpa only [Set.indicator_of_mem (s:=Prod.snd ⁻¹' S) (a:=(x,χ)) hc,Set.indicator_of_mem hc] using a
    · simp only [Set.indicator_of_notMem (s:=Prod.snd ⁻¹' S) (a:=(x,χ)) hc,Set.indicator_of_notMem hc]
  · filter_upwards [pq] with z hz
    by_cases hc : z.2∈S
    · simpa only [Set.indicator_of_mem (s:=Prod.snd ⁻¹' S) (a:=z) hc] using hz
    · simp only [Set.indicator_of_notMem (s:=Prod.snd ⁻¹' S) (a:=z) hc,le_refl]

end KDClosure.LCAReality
