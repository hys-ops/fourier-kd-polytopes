import KDLCARealityWeyl

noncomputable section
namespace KDClosure.LCAReality
open MeasureTheory Filter Set CompactCore Topology
open scoped ENNReal ComplexConjugate Pointwise
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
variable [MeasurableSpace G] [BorelSpace G] [LocallyCompactSpace G]
variable (μ : Measure G) [μ.IsAddHaarMeasure] [μ.InnerRegular] [SFinite μ]
variable [MeasurableSpace (Dual G)] [BorelSpace (Dual G)] (ν : Measure (Dual G)) [SFinite ν]

omit [SFinite μ] [MeasurableSpace (Dual G)] [BorelSpace (Dual G)] in
/-- A character nontrivial on the core has a Haar-null annihilator. -/
theorem null_of_nontrivial_on_core (K : CO G) (l : G) (core : ∀ H : CO G, l∈subgroup H)
    (χ : Dual G) (ne : phase χ l≠1) : μ {x : G | phase χ x=1}=0 := by
  let H : AddSubgroup G := {
    carrier := {x : G | phase χ x=1}
    zero_mem' := by change ((χ 1):ℂ)=1; rw [map_one]; rfl
    add_mem' := by intro x y hx hy; exact (phase_add χ x y).trans (by dsimp at hx hy; rw [hx,hy,one_mul])
    neg_mem' := by intro x hx; have e := phase_neg_mul χ x; dsimp at hx; rwa [hx,mul_one] at e }
  have c : Continuous (fun x : G => phase χ x) := continuous_subtype_val.comp χ.continuous
  have mc : MeasurableSet (H : Set G) := measurableSet_eq_fun c.measurable measurable_const
  change μ (H : Set G)=0
  by_contra nonzero
  have nh := Measure.sub_mem_nhds_zero_of_addHaar_pos μ (H : Set G) mc (pos_iff_ne_zero.mpr nonzero)
  rw [coe_sub_coe] at nh
  have ho := H.isOpen_of_mem_nhds nh
  let J : CO G := ⟨K.val ⊓ (⟨H,ho⟩ : OpenAddSubgroup G),K.property.inter_right (H.isClosed_of_isOpen ho)⟩
  exact ne (core J).2

variable [SecondCountableTopology G]

/-- Fubini is applied to a Borel incidence relation, independently of any
choice of representatives of a partial Fourier transform. For almost
every h all L² functions may reuse the same exceptional set in χ. -/
theorem ae_annihilator_core (K : CO G) (l : G) (core : ∀ H : CO G, l∈subgroup H) :
    ∀ᵐ h ∂μ, ∀ᵐ χ ∂ν, phase χ h=1 → phase χ l=1 := by
  have c : Continuous (fun z : Dual G × G => phase z.1 z.2) :=
    continuous_subtype_val.comp (continuous_eval (F:=ContinuousMonoidHom (Multiplicative G) Circle))
  have m1 : MeasurableSet {z : Dual G×G | phase z.1 z.2=1} := measurableSet_eq_fun c.measurable measurable_const
  have m2 : MeasurableSet {z : Dual G×G | phase z.1 l=1} :=
    measurableSet_eq_fun ((phase_measurable_at l).comp measurable_fst) measurable_const
  have eq : {z : Dual G × G | phase z.1 z.2=1 → phase z.1 l=1} =
      {z | phase z.1 z.2=1}ᶜ ∪ {z | phase z.1 l=1} := by
    classical
    ext z
    simp [imp_iff_not_or]
  have m : MeasurableSet {z : Dual G × G | phase z.1 z.2=1 → phase z.1 l=1} := eq ▸ (m1.compl.union m2)
  have joint : ∀ᵐ z : Dual G × G ∂ν.prod μ, phase z.1 z.2=1 → phase z.1 l=1 :=
    (Measure.ae_prod_iff_ae_ae m).mpr (by
      apply Filter.Eventually.of_forall
      intro χ
      by_cases yes : phase χ l=1
      · exact .of_forall fun _ _ => yes
      · have hnull := null_of_nontrivial_on_core μ K l core χ yes
        have hne : ∀ᵐ h ∂μ, phase χ h≠1 := ae_iff.mpr (by simpa using hnull)
        exact hne.mono fun _ hh e => False.elim (hh e))
  exact Measure.ae_ae_of_ae_prod ((Measure.measurePreserving_swap (μ:=μ) (ν:=ν)).quasiMeasurePreserving.ae joint)

end KDClosure.LCAReality
