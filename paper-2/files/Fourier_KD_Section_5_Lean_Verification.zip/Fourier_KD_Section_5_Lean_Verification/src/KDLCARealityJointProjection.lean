import KDLCARealityFiber
import KDLCARealityProjection

noncomputable section
namespace KDClosure.LCAReality
open MeasureTheory Filter Set CompactCore Topology
open scoped ENNReal ComplexConjugate Pointwise ComplexOrder KDClosure.SubgroupMeasure
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
  [MeasurableSpace G] [BorelSpace G]
variable (μ : Measure G) [μ.IsAddLeftInvariant] (ν : Measure (Dual G))
variable {I : Type*} [Countable I]

theorem shift_conj (x : G) (f : Lp ℂ 2 μ) :
    shift μ x (complexConj μ f) = complexConj μ (shift μ x f) := by
  apply Lp.ext
  have r := (measurePreserving_add_left μ x).quasiMeasurePreserving.ae_eq_comp (complexConj_ae μ f)
  filter_upwards [shift_ae μ x (complexConj μ f),r,complexConj_ae μ (shift μ x f),shift_ae μ x f] with y t a b c
  exact t.trans (a.trans ((congrArg conj c.symm).trans b.symm))

/-- The physical input projection, which acts on test functions by the
transpose of the output mask on the kernel's rows. -/
def jointProjection (F : FourierRealization μ ν)
    (h : I→G) (a : I→ℂ) : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ :=
  kernelTranspose μ (frequencyRowMask μ ν F (frequencyFiber h a) (measurable_frequencyFiber h a))

theorem jointProjection_spec (F : FourierRealization μ ν)
    (h : I→G) (a : I→ℂ) (valid : MaskExact μ ν F (frequencyFiber h a) (measurable_frequencyFiber h a)) (f : Lp ℂ 2 μ) :
    jointProjection μ ν F h a f=f ↔ ∀ i, shift μ (h i) f = conj (a i) • f := by
  let B := frequencyRowMask μ ν F (frequencyFiber h a) (measurable_frequencyFiber h a)
  have proj := frequencyRowMask_projection μ ν F (frequencyFiber h a) (measurable_frequencyFiber h a) valid
  change kernelTranspose μ B f=f ↔ _
  rw [transpose_fixed_iff μ B proj.isSelfAdjoint.star_eq,rowMask_fixed_iff μ ν F h a valid]
  constructor
  · intro fixed i
    have e := congrArg (complexConj μ) (fixed i)
    rw [shift_conj,complexConj_invol,map_smulₛₗ,complexConj_invol] at e
    exact e
  · intro fixed i
    rw [shift_conj,fixed i,map_smulₛₗ]
    simp

/-- For arbitrary countable translation directions, a self-adjoint operator
commuting with them commutes with every joint frequency-fiber projection. -/
theorem jointProjection_commutes (F : FourierRealization μ ν)
    (h : I→G) (a : I→ℂ) (valid : MaskExact μ ν F (frequencyFiber h a) (measurable_frequencyFiber h a)) (T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ) (sa : T.adjoint=T)
    (comm : ∀ i, (shift μ (h i)).comp T=T.comp (shift μ (h i))) :
    (jointProjection μ ν F h a).comp T=T.comp (jointProjection μ ν F h a) := by
  have p := transpose_projection μ _ (frequencyRowMask_projection μ ν F (frequencyFiber h a) (measurable_frequencyFiber h a) valid)
  apply commutes_of_fixed _ T p sa
  intro f hf
  apply (jointProjection_spec μ ν F h a valid _).mpr
  intro i
  have eq := (jointProjection_spec μ ν F h a valid _).mp hf i
  exact (DFunLike.congr_fun (comm i) f).trans ((congrArg T eq).trans (T.map_smul _ _))

end KDClosure.LCAReality
