import KDLCARealityPosition
import Mathlib.MeasureTheory.Group.Prod
import Mathlib.MeasureTheory.Integral.Prod

/-! The first position block of the LCA structural reduction directly from
the Hilbert--Schmidt kernel and the physical row involution. -/
noncomputable section
namespace KDClosure.LCAReality
open CompactCore MeasureTheory Filter Set
open scoped ENNReal ComplexConjugate
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
  [MeasurableSpace G] [BorelSpace G] [MeasurableAdd G] [MeasurableNeg G]
  [SecondCountableTopology G]
variable (μ : Measure G) [SFinite μ] [μ.IsAddLeftInvariant]

omit [IsTopologicalAddGroup G] [MeasurableSpace G] [BorelSpace G] [MeasurableAdd G] [MeasurableNeg G] [SecondCountableTopology G] in
/-- U is an actual open set, independently of the number of compact opens. -/
theorem open_supportRegion : IsOpen {h : G | ∃ H : CO G, h ∈ subgroup H} := by
  have eq : {h : G | ∃ H : CO G, h ∈ subgroup H} = ⋃ H : CO G, (H.val : Set G) := by ext; simp
  rw [eq]
  exact isOpen_iUnion fun H => H.val.isOpen

omit [MeasurableNeg G] [MeasurableAdd G] in
/-- Coordinate-level self-adjointness and row reality are joint a.e.
identities. All substitutions below are measure-preserving shears. -/
theorem displacement_periodic (k : Lp ℂ 2 (μ.prod μ))
    (hermitian : ∀ᵐ z : G × G ∂μ.prod μ, k z = conj (k (z.2,z.1)))
    (row : ∀ᵐ z : G × G ∂μ.prod μ, k (z.1,z.1+z.2) = conj (k (z.1,z.1-z.2))) :
    ∀ᵐ z : G × G ∂μ.prod μ, k (z.1+z.2,z.1+z.2+z.1) = k (z.2,z.2+z.1) := by
  have h1 := (measurePreserving_prod_add_swap μ μ).quasiMeasurePreserving.ae hermitian
  have mp : MeasurePreserving (fun z : G×G => (z.1+z.2,z.1)) (μ.prod μ) (μ.prod μ) :=
    Measure.measurePreserving_swap.comp (measurePreserving_prod_add μ μ)
  have h2 := mp.quasiMeasurePreserving.ae row
  filter_upwards [h1,h2] with z hz hz'
  change k (z.2,z.2+z.1) = conj (k (z.2+z.1,z.2)) at hz
  change k (z.1+z.2,z.1+z.2+z.1) = conj (k (z.1+z.2,z.1+z.2-z.1)) at hz'
  rw [hz',hz,add_sub_cancel_left,add_comm z.1 z.2]

/-- Physical joint-a.e. position block support on U, with the square-integrable
kernel, no elementwise choice of values on product null sets. -/
theorem kernel_position_support (K : CO G) (k : Lp ℂ 2 (μ.prod μ))
    (hermitian : ∀ᵐ z : G × G ∂μ.prod μ, k z = conj (k (z.2,z.1)))
    (row : ∀ᵐ z : G × G ∂μ.prod μ, k (z.1,z.1+z.2) = conj (k (z.1,z.1-z.2))) :
    ∀ᵐ z : G × G ∂μ.prod μ, (¬∃ H : CO G, z.2-z.1 ∈ subgroup H) → k z = 0 := by
  let s (z : G×G) := (z.2,z.2+z.1)
  have mp : MeasurePreserving s (μ.prod μ) (μ.prod μ) := measurePreserving_prod_add_swap μ μ
  have m := (Lp.memLp k).comp_measurePreserving mp
  have square := (memLp_two_iff_integrable_sq_norm m.1).mp m
  have periodic := Measure.ae_ae_of_ae_prod (displacement_periodic μ k hermitian row)
  have nested : ∀ᵐ h ∂μ, ∀ᵐ x ∂μ, (¬∃ H : CO G, h ∈ subgroup H) → k (x,x+h)=0 := by
    filter_upwards [square.prod_right_ae,periodic] with h hi inv
    by_cases outside : ¬∃ H : CO G,h ∈ subgroup H
    · let f (x : G) := k (x,x+h)
      have mf : Measurable f := (Lp.stronglyMeasurable k).measurable.comp
        (measurable_id.prodMk (measurable_id.add measurable_const))
      have lp : MemLp f 2 μ := (memLp_two_iff_integrable_sq_norm mf.aestronglyMeasurable).mpr hi
      have tr := (measurePreserving_add_left μ h).quasiMeasurePreserving.ae_eq_comp lp.coeFn_toLp
      have periodic' : ∀ᵐ x ∂μ, lp.toLp f (h+x)=lp.toLp f x := by
        filter_upwards [lp.coeFn_toLp,tr,inv] with x hx ht hp
        exact ht.trans (hp.trans hx.symm)
      have zero := periodic_slice_zero K h outside μ (lp.toLp f) periodic'
      have ae := lp.coeFn_toLp
      rw [zero] at ae
      filter_upwards [ae,Lp.coeFn_zero ℂ 2 μ] with x hx hx0
      exact fun _ => hx.symm.trans hx0
    · exact .of_forall fun _ f => False.elim (outside f)
  let pred (z : G×G) : Prop := (¬∃ H : CO G, z.1 ∈ subgroup H) → k (s z)=0
  have ms : MeasurableSet {z | pred z} := by
    have eqn : {z | pred z} = Prod.fst ⁻¹' {h : G | ∃ H : CO G, h ∈ subgroup H} ∪
        {z | k (s z)=0} := by
      classical
      ext z
      simp only [Set.mem_ofPred_eq,Set.mem_union,Set.mem_preimage,pred]
      tauto
    rw [eqn]
    exact (open_supportRegion.measurableSet.preimage measurable_fst).union
      (measurableSet_eq_fun ((Lp.stronglyMeasurable k).measurable.comp mp.measurable) measurable_const)
  have joint : ∀ᵐ z ∂μ.prod μ, pred z := (Measure.ae_prod_iff_ae_ae ms).mpr nested
  have invS : MeasurePreserving (fun z : G×G => (-z.1+z.2,z.1)) (μ.prod μ) (μ.prod μ) :=
    Measure.measurePreserving_swap.comp (measurePreserving_prod_neg_add μ μ)
  filter_upwards [invS.quasiMeasurePreserving.ae joint] with z hz
  change (¬∃ H : CO G,-z.1+z.2 ∈ subgroup H) → k (z.1,z.1+(-z.1+z.2))=0 at hz
  simpa only [neg_add_cancel_left, add_neg_cancel_left,sub_eq_neg_add] using hz

end KDClosure.LCAReality
