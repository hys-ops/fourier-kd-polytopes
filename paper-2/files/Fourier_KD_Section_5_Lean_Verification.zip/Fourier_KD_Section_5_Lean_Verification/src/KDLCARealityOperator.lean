import KDLCARealityBlocks
import KDLCAQuotientUniqueness

noncomputable section
namespace KDClosure.LCAReality
open MeasureTheory Filter Set CompactCore Topology
open scoped ENNReal ComplexConjugate Pointwise ComplexOrder
variable {X : Type*} [MeasurableSpace X] (ρ : Measure X)

theorem maskMem (S : Set X) (hs : MeasurableSet S) :
    MemLp (S.indicator (fun _ => (1 : ℂ))) ∞ ρ := by
  apply memLp_top_of_bound ((measurable_const.indicator hs).aestronglyMeasurable) 1
  exact .of_forall fun x => by by_cases h : x∈S <;> simp [h]

/-- Orthogonal position mask, applied to any measurable union of cosets. -/
def mask (S : Set X) (hs : MeasurableSet S) : Lp ℂ 2 ρ →L[ℂ] Lp ℂ 2 ρ :=
  ((ContinuousLinearMap.mul ℂ ℂ).holderL ρ ∞ 2 2) ((maskMem ρ S hs).toLp _)

theorem mask_ae (S : Set X) (hs : MeasurableSet S) (f : Lp ℂ 2 ρ) :
    (mask ρ S hs f : X → ℂ)=ᵐ[ρ] S.indicator f := by
  have a := (ContinuousLinearMap.mul ℂ ℂ).coeFn_holder (r:=2) ((maskMem ρ S hs).toLp _) f
  filter_upwards [a,(maskMem ρ S hs).coeFn_toLp] with x hx hc
  change mask ρ S hs f x = _ at hx ⊢
  calc
    _ = _ := hx
    _ = _ := by
      change (maskMem ρ S hs).toLp _ x * f x = _
      rw [hc]
      by_cases h : x∈S <;> simp [h]

variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
variable [MeasurableSpace G] [BorelSpace G] [SecondCountableTopology G]
variable (μ : Measure G) [SFinite μ] [μ.IsAddLeftInvariant]
variable {T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ} (k : Lp ℂ 2 (μ.prod μ))

omit [IsTopologicalAddGroup G] [BorelSpace G] [SecondCountableTopology G] [μ.IsAddLeftInvariant] in
/-- The first block-support equation gives actual commutation with every
measurable position mask that is constant on the compact-open cosets. -/
theorem operator_mask_commutes (act : LCAQuotient.ActsBy μ T k)
    (supp : ∀ᵐ z : G×G ∂μ.prod μ, (¬∃ H : CO G, z.2-z.1∈subgroup H) → k z=0)
    (S : Set G) (hs : MeasurableSet S) (stable : ∀ x y, (∃ H : CO G, y-x∈subgroup H) → (x∈S ↔ y∈S)) :
    (mask μ S hs).comp T = T.comp (mask μ S hs) := by
  ext f : 1
  apply Lp.ext
  filter_upwards [mask_ae μ S hs (T f),act f,act (mask μ S hs f),Measure.ae_ae_of_ae_prod supp] with x hx ht hc hsupp
  change mask μ S hs (T f) x=T (mask μ S hs f) x
  rw [hx,hc]
  by_cases xin : x∈S
  · rw [Set.indicator_of_mem xin,ht]
    apply integral_congr_ae
    filter_upwards [mask_ae μ S hs f,hsupp] with y hy hxy
    rw [hy]
    by_cases yin : y∈S
    · rw [Set.indicator_of_mem yin]
    · have hz := hxy (fun p => yin ((stable x y p).mp xin))
      change k (x,y)=0 at hz
      rw [hz,zero_mul,zero_mul]
  · rw [Set.indicator_of_notMem xin]
    symm
    apply integral_eq_zero_of_ae
    filter_upwards [mask_ae μ S hs f,hsupp] with y hy hxy
    rw [hy]
    by_cases yin : y∈S
    · have hz := hxy (fun p => xin ((stable x y p).mpr yin))
      change k (x,y)=0 at hz
      simp [hz]
    · simp [Set.indicator_of_notMem yin]

omit [SecondCountableTopology G] in
/-- The simultaneous-translation kernel identity is actual commutation of
the original integral operator with the unitary on position wavefunctions. -/
theorem operator_translation_commutes (act : LCAQuotient.ActsBy μ T k) (l : G)
    (invar : ∀ᵐ z : G×G ∂μ.prod μ, k (l+z.1,l+z.2)=k z) :
    (shift μ l).comp T = T.comp (shift μ l) := by
  ext f : 1
  apply Lp.ext
  have tr := (measurePreserving_add_left μ l).quasiMeasurePreserving.ae (act f)
  filter_upwards [shift_ae μ l (T f),tr,act (shift μ l f),Measure.ae_ae_of_ae_prod invar] with x hx ht hc inv
  change shift μ l (T f) x=T (shift μ l f) x
  change T f (l+x)=∫y, k (l+x,y)*f y ∂μ at ht
  rw [hx,ht,hc,←integral_add_left_eq_self (μ:=μ) (fun y => k (l+x,y)*f y) l]
  apply integral_congr_ae
  filter_upwards [shift_ae μ l f,inv] with y hy hxy
  exact congrArg₂ (· * ·) hxy hy.symm

end KDClosure.LCAReality
