import KDDiscreteReduction
import Mathlib.Dynamics.Ergodic.MeasurePreserving
import Mathlib.MeasureTheory.Group.Integral
import Mathlib.MeasureTheory.Measure.WithDensity
import Mathlib.MeasureTheory.Function.L2Space

noncomputable section
namespace KDClosure.LCAReality
open MeasureTheory Topology Set Filter
open CompactCore DiscreteReduction
open scoped ENNReal

variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]

theorem compact_open_orbit_iff (K : CO G) (h : G) :
    (∃ H : CO G, h ∈ subgroup H) ↔ IsOfFinAddOrder (π K h) := by
  constructor
  · rintro ⟨H,hh⟩
    let _ : Finite (image K H) := Set.finite_coe_iff.mpr (image_finite K H)
    let z : image K H := ⟨π K h,⟨h,hh,rfl⟩⟩
    obtain ⟨n,hn,eq⟩ := isOfFinAddOrder_iff_nsmul_eq_zero.mp (isOfFinAddOrder_of_finite z)
    exact isOfFinAddOrder_iff_nsmul_eq_zero.mpr ⟨n,hn,congrArg Subtype.val eq⟩
  · intro fin
    classical
    let S := AddSubgroup.zmultiples (π K h)
    let H := S.comap (π K)
    have le : subgroup K ≤ H := by
      intro u hu
      show π K u ∈ S
      have eq : π K u=0 := (QuotientAddGroup.eq_zero_iff (N:=subgroup K) u).mpr hu
      rw [eq]; exact S.zero_mem
    have ho := AddSubgroup.isOpen_mono le K.val.isOpen
    have fiber (z : D K) : IsCompact ((π K) ⁻¹' {z}) := by
      obtain ⟨w,rfl⟩ := QuotientAddGroup.mk'_surjective (subgroup K) z
      have eqn : (π K) ⁻¹' ({π K w} : Set (D K)) = (fun x : G => x+w) '' (subgroup K : Set G) := by
        ext u
        change (π K u = π K w) ↔ _
        constructor
        · intro eq
          exact ⟨u-w,QuotientAddGroup.eq_iff_sub_mem.mp eq,sub_add_cancel ..⟩
        · rintro ⟨x,hx,rfl⟩
          exact QuotientAddGroup.eq_iff_sub_mem.mpr (by simpa using hx)
      rw [eqn]
      exact K.property.image (continuous_id.add continuous_const)
    have union_eq : (H : Set G) = ⋃ z ∈ (S : Set (D K)), (π K) ⁻¹' {z} := by
      ext x
      simp [H]
    have hc : IsCompact (H : Set G) := union_eq ▸ fin.finite_zmultiples.isCompact_biUnion (fun z _ => fiber z)
    exact ⟨⟨⟨H,ho⟩,hc⟩,AddSubgroup.mem_zmultiples _⟩

variable [MeasurableSpace G] [BorelSpace G] [MeasurableAdd G]

omit [MeasurableAdd G] in
/-- A finite invariant mass cannot see an infinite orbit in the discrete
quotient by an open subgroup. This uses finite-measure recurrence on
each coset; no dual group or Plancherel assumption enters. -/
theorem finite_periodic_mass_zero [SecondCountableTopology G]
    (K : CO G) (h : G) (outside : ¬ ∃ H : CO G, h ∈ subgroup H)
    (ν : Measure G) [IsFiniteMeasure ν] (invariant : MeasurePreserving (h+·) ν ν) :
    ν = 0 := by
  let _ : Countable (D K) := DiscreteReduction.countable K
  let _ : DiscreteTopology (D K) := discrete K
  let F (y : D K) := (π K) ⁻¹' {y}
  have fin (y : D K) : ν (F y) = 0 := by
    by_contra ne
    have openF : IsOpen (F y) := (isOpen_discrete _).preimage (QuotientAddGroup.continuous_mk (N:=subgroup K))
    obtain ⟨x,hx,n,hn,ret⟩ := invariant.exists_mem_iterate_mem openF.measurableSet.nullMeasurableSet ne
    have iter (n : ℕ) : (h+·)^[n] x = n • h+x := by
      induction n with
      | zero => simp
      | succ n ih => rw [Function.iterate_succ_apply',ih,succ_nsmul]; abel
    change π K x=y at hx
    change π K ((h+·)^[n] x) = y at ret
    rw [iter, map_add, map_nsmul,hx] at ret
    exact outside ((compact_open_orbit_iff K h).mpr (isOfFinAddOrder_iff_nsmul_eq_zero.mpr
      ⟨n,Nat.pos_of_ne_zero hn,add_eq_right.mp ret⟩))
  have full : (⋃ y, F y) = univ := eq_univ_of_forall fun x => mem_iUnion.mpr ⟨π K x,rfl⟩
  exact Measure.measure_univ_eq_zero.mp (full ▸ measure_iUnion_null fin)

theorem withDensity_periodic {X : Type*} [MeasurableSpace X]
    {μ : Measure X} {τ : X → X} (mp : MeasurePreserving τ μ μ) {d : X → ℝ≥0∞}
    (md : Measurable d) (inv : ∀ᵐ x ∂μ, d (τ x)=d x) :
    MeasurePreserving τ (μ.withDensity d) (μ.withDensity d) := by
  refine ⟨mp.measurable,?_⟩
  ext s hs
  rw [Measure.map_apply mp.measurable hs,withDensity_apply d (mp.measurable hs),withDensity_apply d hs]
  calc
    _ = ∫⁻ x in τ ⁻¹' s, d (τ x) ∂μ := lintegral_congr_ae (ae_restrict_of_ae (inv.mono fun _ e => e.symm))
    _ = _ := (mp.restrict_preimage hs).lintegral_comp md

/-- Every L² displacement slice invariant a.e. by that displacement vanishes
off the union of compact open subgroups. The finite invariant mass is the
square norm of the slice times the actual ambient Haar measure. -/
theorem periodic_slice_zero [SecondCountableTopology G]
    (K : CO G) (h : G) (outside : ¬ ∃ H : CO G, h ∈ subgroup H)
    (μ : Measure G) [μ.IsAddLeftInvariant] (f : Lp ℂ 2 μ)
    (inv : ∀ᵐ x ∂μ, f (h+x)=f x) : f=0 := by
  let d (x : G) := ENNReal.ofReal (‖f x‖^2)
  have md : Measurable d := ((Lp.stronglyMeasurable f).measurable.norm.pow_const 2).ennreal_ofReal
  have integr := (memLp_two_iff_integrable_sq_norm (Lp.memLp f).1).mp (Lp.memLp f)
  have hd : ∫⁻ x, d x ∂μ ≠ ∞ := integr.lintegral_lt_top.ne
  let _ : IsFiniteMeasure (μ.withDensity d) := isFiniteMeasure_withDensity hd
  have hv : MeasurePreserving (h+·) (μ.withDensity d) (μ.withDensity d) :=
    withDensity_periodic (measurePreserving_add_left μ h) md (inv.mono fun x hx => by simp [d,hx])
  have zero := finite_periodic_mass_zero K h outside _ hv
  have ae := (withDensity_eq_zero_iff md.aemeasurable).mp zero
  apply Lp.ext
  filter_upwards [ae,Lp.coeFn_zero ℂ 2 μ] with x hx hz
  change ENNReal.ofReal (‖f x‖^2)=0 at hx
  rw [ENNReal.ofReal_eq_zero] at hx
  rw [hz]
  exact norm_eq_zero.mp (by nlinarith [norm_nonneg (f x)])

end KDClosure.LCAReality
