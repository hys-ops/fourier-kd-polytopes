import KDLCARealityTranspose

noncomputable section
namespace KDClosure.LCAReality
open MeasureTheory Filter Set CompactCore Topology
open scoped ENNReal ComplexConjugate Pointwise ComplexOrder
variable {X : Type*} [MeasurableSpace X] (ρ : Measure X)

theorem complexConj_inner (f g : Lp ℂ 2 ρ) :
    inner ℂ (complexConj ρ f) (complexConj ρ g) = inner ℂ g f := by
  simp only [MeasureTheory.L2.inner_def]
  apply integral_congr_ae
  filter_upwards [complexConj_ae ρ f,complexConj_ae ρ g] with x hx hy
  simp [RCLike.inner_apply,hx,hy,mul_comm]

theorem transpose_projection (B : Lp ℂ 2 ρ →L[ℂ] Lp ℂ 2 ρ) (proj : IsStarProjection B) :
    IsStarProjection (kernelTranspose ρ B) := by
  have sa : B.adjoint=B := proj.isSelfAdjoint.star_eq
  have ap (v : Lp ℂ 2 ρ) : kernelTranspose ρ B v=complexConj ρ (B (complexConj ρ v)) := by
    change complexConj ρ (B.adjoint (complexConj ρ v))=_
    rw [sa]
  constructor
  · ext f : 1
    change kernelTranspose ρ B (kernelTranspose ρ B f)=kernelTranspose ρ B f
    simp only [ap,complexConj_invol]
    exact congrArg (complexConj ρ) (DFunLike.congr_fun proj.isIdempotentElem.eq (complexConj ρ f))
  · apply ContinuousLinearMap.isSelfAdjoint_iff_isSymmetric.mpr
    intro f g
    change inner ℂ (kernelTranspose ρ B f) g = inner ℂ f (kernelTranspose ρ B g)
    calc
      _ = inner ℂ (complexConj ρ (B (complexConj ρ f))) (complexConj ρ (complexConj ρ g)) := by rw [ap,complexConj_invol]
      _ = inner ℂ (complexConj ρ g) (B (complexConj ρ f)) := complexConj_inner ρ _ _
      _ = inner ℂ (B (complexConj ρ g)) (complexConj ρ f) := (ContinuousLinearMap.isSelfAdjoint_iff_isSymmetric.mp proj.isSelfAdjoint _ _).symm
      _ = inner ℂ (complexConj ρ (complexConj ρ f)) (complexConj ρ (B (complexConj ρ g))) := (complexConj_inner ρ _ _).symm
      _ = _ := by rw [complexConj_invol,ap]

theorem transpose_fixed_iff (B : Lp ℂ 2 ρ →L[ℂ] Lp ℂ 2 ρ) (sa : B.adjoint=B) (f : Lp ℂ 2 ρ) :
    kernelTranspose ρ B f=f ↔ B (complexConj ρ f)=complexConj ρ f := by
  change complexConj ρ (B.adjoint (complexConj ρ f))=f ↔ _
  rw [sa]
  constructor
  · intro e
    simpa only [complexConj_invol] using congrArg (complexConj ρ) e
  · intro e
    rw [e,complexConj_invol]

variable {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℂ H] [CompleteSpace H]
/-- A self-adjoint operator preserving the fixed vectors of an orthogonal
projection commutes with it, using adjoints to obtain the reverse corner. -/
theorem commutes_of_fixed (P T : H →L[ℂ] H) (p : IsStarProjection P) (sa : T.adjoint=T)
    (stable : ∀ f, P f=f → P (T f)=T f) : P.comp T=T.comp P := by
  have pp : P.comp P=P := p.isIdempotentElem
  have ps : P.adjoint=P := p.isSelfAdjoint.star_eq
  have eq : P.comp (T.comp P)=T.comp P := by
    ext f
    exact stable (P f) (DFunLike.congr_fun pp f)
  have dual := congrArg ContinuousLinearMap.adjoint eq
  simp only [ContinuousLinearMap.adjoint_comp,sa,ps] at dual
  exact dual.symm.trans eq

end KDClosure.LCAReality
