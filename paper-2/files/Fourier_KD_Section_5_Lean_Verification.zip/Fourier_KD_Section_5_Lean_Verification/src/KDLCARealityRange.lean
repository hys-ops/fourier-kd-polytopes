import KDLCARealityJointProjection

/-! Joint spectral masks reduce the Fourier image without an assumption
that the Fourier isometry is surjective. -/
noncomputable section
namespace KDClosure.LCAReality
open MeasureTheory Filter Set CompactCore Topology
open scoped ENNReal ComplexConjugate Pointwise ComplexOrder KDClosure.SubgroupMeasure
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
  [MeasurableSpace G] [BorelSpace G]
variable (μ : Measure G) [μ.IsAddLeftInvariant] (ν : Measure (Dual G))
variable {I : Type*} [Countable I]

theorem shift_adjoint (x : G) : (shift μ x).adjoint=shift μ (-x) := by
  have iso : Isometry (shift μ x) := (Lp.compMeasurePreservingₗᵢ ℂ (x+·) (measurePreserving_add_left μ x)).isometry
  have id := ((shift μ x).isometry_iff_adjoint_comp_self).mp iso
  have right (f : Lp ℂ 2 μ) : shift μ x (shift μ (-x) f)=f := by
    apply Lp.ext
    have t := (measurePreserving_add_left μ x).quasiMeasurePreserving.ae_eq_comp (shift_ae μ (-x) f)
    filter_upwards [shift_ae μ x (shift μ (-x) f),t] with y hy hz
    exact hy.trans (by simpa [Function.comp_def] using hz)
  ext f : 1
  calc
    _ = (shift μ x).adjoint (shift μ x (shift μ (-x) f)) := congrArg _ (right f).symm
    _ = _ := DFunLike.congr_fun id _

omit [IsTopologicalAddGroup G] [MeasurableSpace G] [BorelSpace G] in
theorem modulate_adjoint (x : G) : (modulate ν x).adjoint=modulate ν (-x) := by
  ext g : 1
  apply ext_inner_left ℂ
  intro f
  rw [ContinuousLinearMap.adjoint_inner_right]
  simp only [MeasureTheory.L2.inner_def]
  apply integral_congr_ae
  filter_upwards [modulate_ae ν x f,modulate_ae ν (-x) g] with χ h1 h2
  have ph : phase χ (-x)=conj (phase χ x) := by
    change ((χ ((Multiplicative.ofAdd x)⁻¹)):ℂ)=_
    rw [map_inv,Circle.coe_inv_eq_conj]; rfl
  simp only [h1,h2,RCLike.inner_apply,ph,map_mul]
  ring

/-- The closed-range projection commutes with each character multiplier.
Only the Fourier isometry and the dense integral agreement are needed. -/
theorem rangeProjection_modulates (F : FourierRealization μ ν) (h : G) :
    let J := F.isometry.toContinuousLinearMap
    (J.comp J.adjoint).comp (modulate ν (-h))=(modulate ν (-h)).comp (J.comp J.adjoint) := by
  let J := F.isometry.toContinuousLinearMap
  have he (a : G) : J.comp (shift μ a)=(modulate ν (-a)).comp J := by
    ext f : 1
    exact fourier_shift μ ν F a f
  have a := congrArg ContinuousLinearMap.adjoint (he (-h))
  simp only [ContinuousLinearMap.adjoint_comp,shift_adjoint,modulate_adjoint,neg_neg] at a
  ext f : 1
  exact (congrArg J (DFunLike.congr_fun a.symm f)).trans (DFunLike.congr_fun (he h) _)

omit [IsTopologicalAddGroup G] [MeasurableSpace G] [BorelSpace G] in
/-- The exact joint frequency mask, stated solely in the target Hilbert space. -/
theorem target_mask_fixed (h : I→G) (a : I→ℂ) (g : Lp ℂ 2 ν) :
    mask ν (frequencyFiber h a) (measurable_frequencyFiber h a) g=g ↔
      ∀ i, modulate ν (-h i) g=a i • g := by
  let S := frequencyFiber h a
  let hs := measurable_frequencyFiber h a
  let M := mask ν S hs
  have spec := mask_ae ν S hs g
  constructor
  · intro fixed i
    have f : M g=g := fixed
    rw [show mask ν S hs g=g from f] at spec
    apply Lp.ext
    filter_upwards [spec,modulate_ae ν (-(h i)) g,Lp.coeFn_smul (a i) g] with χ hx hy hz
    rw [hy,hz]
    change phase χ (-(h i))*g χ=a i*g χ
    by_cases mem : χ∈S
    · rw [(mem : ∀ i, phase χ (-h i)=a i) i]
    · rw [Set.indicator_of_notMem mem] at hx
      rw [hx,mul_zero,mul_zero]
  · intro fixed
    have eq (i : I) : ∀ᵐ χ ∂ν, phase χ (-h i)*g χ=a i*g χ := by
      have m := modulate_ae ν (-h i) g
      rw [fixed i] at m
      filter_upwards [m,Lp.coeFn_smul (a i) g] with χ hx hy
      exact hx.symm.trans hy
    apply Lp.ext
    filter_upwards [spec,ae_all_iff.mpr eq] with χ hm e
    change mask ν S hs g χ=g χ
    rw [hm]
    by_cases mem : χ∈S
    · rw [Set.indicator_of_mem mem]
    · rw [Set.indicator_of_notMem mem]
      symm
      by_contra ne
      exact mem (fun i => mul_right_cancel₀ ne (e i))

theorem rangeProjection_fiber (F : FourierRealization μ ν) (h : I→G) (a : I→ℂ) :
    let J := F.isometry.toContinuousLinearMap
    let M := mask ν (frequencyFiber h a) (measurable_frequencyFiber h a)
    M.comp (J.comp J.adjoint)=(J.comp J.adjoint).comp M := by
  let J := F.isometry.toContinuousLinearMap
  let R := J.comp J.adjoint
  have r : R.adjoint=R := by simp [R]
  apply commutes_of_fixed _ R (mask_isStarProjection _ _ _) r
  intro f fixed
  apply (target_mask_fixed ν h a _).mpr
  intro i
  have e := (target_mask_fixed ν h a f).mp fixed i
  exact (DFunLike.congr_fun (rangeProjection_modulates μ ν F (h i)).symm f).trans ((congrArg R e).trans (R.map_smul _ _))

/-- The concrete, unconditional preimage of the joint spectral projection.
The same result holds on its complementary frequency set. -/
theorem fiberMask_preimages (F : FourierRealization μ ν) (h : I→G) (a : I→ℂ) :
    let J := F.isometry.toContinuousLinearMap
    let M := mask ν (frequencyFiber h a) (measurable_frequencyFiber h a)
    let N := mask ν (frequencyFiber h a)ᶜ (measurable_frequencyFiber h a).compl
    (∀ f, J (J.adjoint (M (J f)))=M (J f)) ∧ (∀ f, J (J.adjoint (N (J f)))=N (J f)) := by
  let J := F.isometry.toContinuousLinearMap
  let R := J.comp J.adjoint
  let M := mask ν (frequencyFiber h a) (measurable_frequencyFiber h a)
  let N := mask ν (frequencyFiber h a)ᶜ (measurable_frequencyFiber h a).compl
  have j : J.adjoint.comp J=1 := J.isometry_iff_adjoint_comp_self.mp F.isometry.isometry
  have rf (f : Lp ℂ 2 μ) : R (J f)=J f := congrArg J (DFunLike.congr_fun j f)
  have mr : M.comp R=R.comp M := rangeProjection_fiber μ ν F h a
  have nr : N.comp R=R.comp N := by
    have comp : M+N=1 := mask_add_compl _ _ _
    have eq : N=1-M := by rw [←comp]; abel
    rw [eq,ContinuousLinearMap.sub_comp,ContinuousLinearMap.comp_sub,mr]; rfl
  exact ⟨fun f => (DFunLike.congr_fun mr.symm (J f)).trans (congrArg M (rf f)),
    fun f => (DFunLike.congr_fun nr.symm (J f)).trans (congrArg N (rf f))⟩
end KDClosure.LCAReality
