import KDLCARealityFrequencyExtreme
import KDCompactDualReduction
import Mathlib.MeasureTheory.Function.LpSpace.ContinuousCompMeasurePreserving

noncomputable section
namespace KDClosure.LCAReality
open MeasureTheory Filter Set CompactCore Topology TopologicalSpace LCAQuotient
open scoped ENNReal ComplexConjugate Pointwise ComplexOrder KDClosure.SubgroupMeasure
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
  [MeasurableSpace G] [BorelSpace G] [SecondCountableTopology G]
section Cover
variable (μ : Measure G) [SFinite μ] [μ.IsAddLeftInvariant] (ν : Measure (Dual G))
variable {I J : Type*} [Countable I] [Countable J]

/-- If a countable list of joint frequency sectors covers the actual dual,
every extreme belongs wholly to one member; the assumption is explicit
because arbitrary unrelated lists of eigenvalue patterns need not cover it. -/
theorem extreme_one_frequency (F : FourierRealization μ ν) (h : I→G) (a : J→I→ℂ)
    (cover : ∀ χ : Dual G, ∃ j, χ∈frequencyFiber h (a j))
    (T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ) (e : T∈(ambientStates μ ν F).extremePoints ℝ)
    (comm : ∀ i, (LCAReality.shift μ (h i)).comp T=T.comp (LCAReality.shift μ (h i))) :
    ∃ j, (jointProjection μ ν F h (a j)).comp T=T := by
  by_contra! contra
  have zero (j : J) : (jointProjection μ ν F h (a j)).comp T=0 := by
    have c := jointProjection_commutes μ ν F h (a j) (fiberMask_preimages μ ν F h (a j)).1 T e.1.1.isSelfAdjoint.star_eq comm
    have no := contra j
    rw [c] at no ⊢
    exact (frequency_dichotomy μ ν F h (a j) T e comm).resolve_right no
  have op : T=0 := by
    ext f : 1
    let g := complexConj μ (T f)
    have each (j : J) : ∀ᵐ χ ∂ν, χ∈frequencyFiber h (a j) → F.isometry g χ=0 := by
      let S := frequencyFiber h (a j)
      let hs := measurable_frequencyFiber h (a j)
      let B := frequencyRowMask μ ν F S hs
      have good := fiberMask_preimages μ ν F h (a j)
      have sa : B.adjoint=B := (frequencyRowMask_projection μ ν F S hs good.1).isSelfAdjoint.star_eq
      have q := DFunLike.congr_fun (zero j) f
      change complexConj μ (B.adjoint g)=0 at q
      rw [sa] at q
      have bg : B g=0 := by simpa only [complexConj_invol,map_zero] using congrArg (complexConj μ) q
      have eq : mask ν S hs (F.isometry g)=0 := (good.1 g).symm.trans ((congrArg F.isometry bg).trans (map_zero _))
      have ma := mask_ae ν S hs (F.isometry g)
      rw [eq] at ma
      filter_upwards [ma,Lp.coeFn_zero ℂ 2 ν] with χ hx hc
      intro hi
      rw [Set.indicator_of_mem hi] at hx
      exact hx.symm.trans hc
    have fg : F.isometry g=0 := by
      apply Lp.ext
      filter_upwards [ae_all_iff.mpr each,Lp.coeFn_zero ℂ 2 ν] with χ hh hz
      obtain ⟨j,hj⟩ := cover χ
      exact (hh j hj).trans hz.symm
    have gz := F.isometry.injective (fg.trans (map_zero F.isometry).symm)
    change T f=0
    simpa only [g,complexConj_invol,map_zero] using congrArg (complexConj μ) gz
  have t0 : IsLUB (mass T) 0 := by
    rw [op]
    constructor
    · rintro _ ⟨_,_,_,rfl⟩; simp
    · intro v hv; apply hv; exact ⟨0,Fin.elim0,(orthonormal_subsingleton_iff.mpr (fun i : Fin 0 => i.elim0)),by simp⟩
  exact zero_ne_one (t0.unique e.1.2.1)

end Cover
variable [LocallyCompactSpace G] [T2Space G] (μ : Measure G) [μ.IsAddHaarMeasure] [SFinite μ] (ν : Measure (Dual G))

omit [SFinite μ] in
/-- Haar translation is strongly continuous, including on arbitrary L²
wavefunctions rather than just on compactly supported test vectors. -/
theorem continuous_shift (v : Lp ℂ 2 μ) : Continuous (fun x : G => LCAReality.shift μ x v) := by
  let m : C(G×G,G) := ⟨fun p => p.1+p.2,continuous_add⟩
  exact continuous_const.compMeasurePreservingLp m.curry.continuous (fun x => measurePreserving_add_left μ x) (by simp)

def restrictPhase (L : AddSubgroup G) (χ : Dual G) : Dual L :=
  χ.comp ⟨L.subtype.toMultiplicative,continuous_subtype_val⟩

/-- A state extreme in the full ambient KD-positive space, invariant in
operator commutators under a compact subgroup, occupies exactly one
character type of that subgroup. -/
theorem compact_translation_sector (F : FourierRealization μ ν) (L : AddSubgroup G)
    (compact : IsCompact (L : Set G))
    (T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ) (e : T∈(ambientStates μ ν F).extremePoints ℝ)
    (comm : ∀ l : L, (LCAReality.shift μ (l:G)).comp T=T.comp (LCAReality.shift μ (l:G))) :
    ∃ ψ : Dual G, ∀ l : L, ∀ f, LCAReality.shift μ (l:G) (T f) = phase ψ (l:G) • T f := by
  let _ : CompactSpace L := isCompact_iff_compactSpace.mp compact
  let _ : CompactSpace (Multiplicative L) := (inferInstance : CompactSpace L)
  let _ : T2Space (Multiplicative L) := (inferInstance : T2Space L)
  let _ : SecondCountableTopology L := Topology.IsInducing.subtypeVal.secondCountableTopology
  let _ : SecondCountableTopology (Multiplicative L) := (inferInstance : SecondCountableTopology L)
  let _ : Countable (Dual L) := CompactDualReduction.dual_countable
  let d := denseSeq L
  let h (i : ℕ) := (d i : G)
  let a (ψ : Set.range (restrictPhase (G:=G) L)) (i : ℕ) := phase ψ.val (-d i)
  have cv (χ : Dual G) : ∃ ψ : Set.range (restrictPhase (G:=G) L), χ∈frequencyFiber h (a ψ) := ⟨⟨restrictPhase L χ,χ,rfl⟩,fun _ => rfl⟩
  obtain ⟨ψ,occupied⟩ := extreme_one_frequency μ ν F h a cv T e (fun i => comm (d i))
  obtain ⟨γ,hγ⟩ := ψ.property
  refine ⟨γ,fun l f => ?_⟩
  have ev := (jointProjection_spec μ ν F h (a ψ) (fiberMask_preimages μ ν F h (a ψ)).1 (T f)).mp
    (DFunLike.congr_fun occupied f)
  have cn : Continuous (fun y : L => phase ψ.val y • T f) :=
    (show Continuous (fun y:L => phase ψ.val y) from continuous_subtype_val.comp ψ.val.continuous).smul continuous_const
  have cm : Continuous (fun y : L => LCAReality.shift μ (y:G) (T f)) := (continuous_shift μ _).comp continuous_subtype_val
  have eq : (fun y : L => LCAReality.shift μ (y:G) (T f)) = (fun y : L => phase ψ.val y • T f) := by
    apply (denseRange_denseSeq L).equalizer cm cn
    funext i
    change LCAReality.shift μ (h i) (T f)=phase ψ.val (d i) • T f
    rw [ev i]
    have ph : phase ψ.val (-d i)=conj (phase ψ.val (d i)) := by
      change ((ψ.val ((Multiplicative.ofAdd (d i))⁻¹)):ℂ)=_
      rw [map_inv,Circle.coe_inv_eq_conj]; rfl
    rw [show a ψ i=phase ψ.val (-d i) from rfl,ph,Complex.conj_conj]
  have val : phase ψ.val l=phase γ (l:G) := by rw [←hγ]; rfl
  exact (congrFun eq l).trans (by rw [val])
end KDClosure.LCAReality
