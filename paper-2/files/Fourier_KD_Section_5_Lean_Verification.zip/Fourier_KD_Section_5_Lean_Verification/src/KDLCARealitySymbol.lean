import KDLCARealityFourier

noncomputable section
namespace KDClosure.LCAReality
open MeasureTheory Filter Set CompactCore
open scoped ENNReal ComplexConjugate ComplexOrder
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G]
  [IsTopologicalAddGroup G] [MeasurableSpace G] [BorelSpace G]
  [MeasurableNeg G] [MeasurableAdd G] [SecondCountableTopology G]
variable (μ : Measure G) [SFinite μ] [μ.IsNegInvariant] [μ.IsAddLeftInvariant]
variable [MeasurableSpace (Dual G)] (ν : Measure (Dual G)) [SFinite ν]

/-- Use the actual L² displacement row whenever it exists. The square-
integrability of the joint kernel makes the exceptional positions null. -/
def rowAt (k : Lp ℂ 2 (μ.prod μ)) (x : G) : Lp ℂ 2 μ :=
  open Classical in if m : MemLp (fun h : G => k (x,x+h)) 2 μ then m.toLp _ else 0

omit [MeasurableNeg G] [MeasurableAdd G] [μ.IsNegInvariant] [MeasurableSpace (Dual G)] in
theorem rowAt_ae (k : Lp ℂ 2 (μ.prod μ)) :
    ∀ᵐ x ∂μ, (rowAt μ k x : G→ℂ) =ᵐ[μ] fun h => k (x,x+h) := by
  have m := (Lp.memLp k).comp_measurePreserving (measurePreserving_prod_add μ μ)
  have sq := (memLp_two_iff_integrable_sq_norm m.1).mp m
  filter_upwards [sq.prod_right_ae] with x hx
  have mf : Measurable (fun h : G => k (x,x+h)) := (Lp.stronglyMeasurable k).measurable.comp
    (measurable_const.prodMk (measurable_const.add measurable_id))
  have h := (memLp_two_iff_integrable_sq_norm mf.aestronglyMeasurable).mpr hx
  simpa only [rowAt,dif_pos h] using h.coeFn_toLp

omit [MeasurableAdd G] [SFinite ν] in
/-- Sign of the Fourier-KD symbol implies the joint physical row involution. -/
theorem kernel_row_involution_of_rows (F : FourierRealization μ ν) (k : Lp ℂ 2 (μ.prod μ))
    (kd : ∀ᵐ x ∂μ, ∀ᵐ χ ∂ν, 0 ≤ F.isometry (rowAt μ k x) χ) :
    ∀ᵐ z : G × G ∂μ.prod μ, k (z.1,z.1+z.2)=conj (k (z.1,z.1-z.2)) := by
  have mm := (Lp.stronglyMeasurable k).measurable
  have ms : MeasurableSet {z : G×G | k (z.1,z.1+z.2)=conj (k (z.1,z.1-z.2))} :=
    measurableSet_eq_fun (mm.comp (measurable_fst.prodMk (measurable_fst.add measurable_snd)))
      (Complex.continuous_conj.measurable.comp (mm.comp (measurable_fst.prodMk (measurable_fst.sub measurable_snd))))
  apply (Measure.ae_prod_iff_ae_ae ms).mpr
  filter_upwards [rowAt_ae μ k,kd] with x hx hq
  have real : ∀ᵐ χ ∂ν, conj (F.isometry (rowAt μ k x) χ) = F.isometry (rowAt μ k x) χ := by
    filter_upwards [hq] with χ hχ
    exact Complex.conj_eq_iff_im.mpr (Complex.nonneg_iff.mp hχ).2.symm
  have h2 := row_reflection_of_real μ ν F (rowAt μ k x) real
  have hn := (Measure.measurePreserving_neg μ).quasiMeasurePreserving.ae_eq_comp hx
  filter_upwards [hx,hn,h2] with h h1 hneg htwo
  change rowAt μ k x (-h) = k (x,x+ -h) at hneg
  rw [←h1,htwo,hneg,sub_eq_add_neg]


omit [MeasurableAdd G] in
/-- Sign of the Fourier-KD symbol implies the joint physical row involution. -/
theorem kernel_row_involution_of_KD (F : FourierRealization μ ν) (k : Lp ℂ 2 (μ.prod μ))
    (kd : ∀ᵐ z : G × Dual G ∂μ.prod ν, 0 ≤ F.isometry (rowAt μ k z.1) z.2) :
    ∀ᵐ z : G × G ∂μ.prod μ, k (z.1,z.1+z.2)=conj (k (z.1,z.1-z.2)) :=
  kernel_row_involution_of_rows μ ν F k (Measure.ae_ae_of_ae_prod kd)

/-- Position block conclusion from the original joint a.e. Fourier-KD sign,
the Hermitian kernel identity, and Plancherel's defining L¹ agreement. -/
theorem position_support_of_KD (K : CO G) (F : FourierRealization μ ν)
    (k : Lp ℂ 2 (μ.prod μ))
    (hermitian : ∀ᵐ z : G × G ∂μ.prod μ, k z=conj (k (z.2,z.1)))
    (kd : ∀ᵐ z : G × Dual G ∂μ.prod ν, 0 ≤ F.isometry (rowAt μ k z.1) z.2) :
    ∀ᵐ z : G × G ∂μ.prod μ, (¬∃ H : CO G, z.2-z.1 ∈ subgroup H) → k z=0 := by
  apply kernel_position_support μ K k hermitian
  exact kernel_row_involution_of_KD μ ν F k kd

omit [SFinite ν] in
/-- Position support from the nested numerical KD sign that is independent
of choices of representatives in the exceptional vertical sections. -/
theorem position_support_of_rows (K : CO G) (F : FourierRealization μ ν)
    (k : Lp ℂ 2 (μ.prod μ))
    (hermitian : ∀ᵐ z : G × G ∂μ.prod μ, k z=conj (k (z.2,z.1)))
    (kd : ∀ᵐ x ∂μ, ∀ᵐ χ ∂ν, 0 ≤ F.isometry (rowAt μ k x) χ) :
    ∀ᵐ z : G × G ∂μ.prod μ, (¬∃ H : CO G, z.2-z.1 ∈ subgroup H) → k z=0 :=
  kernel_position_support μ K k hermitian (kernel_row_involution_of_rows μ ν F k kd)

end KDClosure.LCAReality
