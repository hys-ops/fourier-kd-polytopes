import KDLCARealityOperator

noncomputable section
namespace KDClosure.LCAReality
open MeasureTheory Filter Set CompactCore Topology
open scoped ENNReal ComplexConjugate Pointwise ComplexOrder
variable {X : Type*} [MeasurableSpace X] (ρ : Measure X)

def complexConj : Lp ℂ 2 ρ →L⋆[ℂ] Lp ℂ 2 ρ :=
  (starL ℂ : ℂ ≃L⋆[ℂ] ℂ).toContinuousLinearMap.compLpL 2 ρ

theorem complexConj_ae (f : Lp ℂ 2 ρ) : (complexConj ρ f : X → ℂ)=ᵐ[ρ] fun x => conj (f x) :=
  (starL ℂ : ℂ ≃L⋆[ℂ] ℂ).toContinuousLinearMap.coeFn_compLpL f

theorem complexConj_invol (f : Lp ℂ 2 ρ) : complexConj ρ (complexConj ρ f)=f := by
  apply Lp.ext
  filter_upwards [complexConj_ae ρ (complexConj ρ f),complexConj_ae ρ f] with x h t
  rw [h,t,Complex.conj_conj]

def kernelTranspose (B : Lp ℂ 2 ρ →L[ℂ] Lp ℂ 2 ρ) : Lp ℂ 2 ρ →L[ℂ] Lp ℂ 2 ρ :=
  (complexConj ρ).comp (B.adjoint.comp (complexConj ρ))

/-- Physical row operators act by transpose with respect to the complex
bilinear integral pairing, as the kernel integral uses no conjugate. -/
theorem transpose_pair (B : Lp ℂ 2 ρ →L[ℂ] Lp ℂ 2 ρ) (a f : Lp ℂ 2 ρ) :
    (∫ x, B a x * f x ∂ρ) = ∫ x, a x * kernelTranspose ρ B f x ∂ρ := by
  have bil (u v : Lp ℂ 2 ρ) : (∫ x, u x*v x ∂ρ)=inner ℂ (complexConj ρ v) u := by
    rw [MeasureTheory.L2.inner_def]
    apply integral_congr_ae
    filter_upwards [complexConj_ae ρ v] with x hx
    simp [RCLike.inner_apply,hx]
  rw [bil,bil]
  change _=inner ℂ (complexConj ρ (complexConj ρ (B.adjoint (complexConj ρ f)))) a
  rw [complexConj_invol,B.adjoint_inner_left]

variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
  [MeasurableSpace G] [BorelSpace G] [SecondCountableTopology G]
variable (μ : Measure G) [SFinite μ] [μ.IsAddLeftInvariant]

/-- The ordinary and displacement rows of the original Hilbert--Schmidt
kernel agree under the same Haar translation for almost every x. -/
theorem shift_ordinary_row (k : Lp ℂ 2 (μ.prod μ)) :
    ∀ᵐ x ∂μ, shift μ x (LCAQuotient.ordinaryRow μ k x)=rowAt μ k x := by
  filter_upwards [rowAt_ae μ k,LCAQuotient.ordinaryRow_ae μ k] with x hd ho
  apply Lp.ext
  exact ((shift_ae μ x _).trans ((measurePreserving_add_left μ x).quasiMeasurePreserving.ae_eq_comp ho)).trans hd.symm

/-- A translation-equivariant operator on physical kernel rows transforms
the rows of the full integral operator multiplied by its transpose. -/
theorem row_of_transpose_cut (T B : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ)
    (k k' : Lp ℂ 2 (μ.prod μ)) (rep : LCAQuotient.ActsBy μ T k)
    (rep' : LCAQuotient.ActsBy μ (T.comp (kernelTranspose μ B)) k')
    (comm : ∀ x f, shift μ x (B f) = B (shift μ x f)) :
    ∀ᵐ x ∂μ, rowAt μ k' x=B (rowAt μ k x) := by
  have rows := LCAQuotient.determine_rows μ (LCAQuotient.ordinaryRow μ k') (fun x => B (LCAQuotient.ordinaryRow μ k x)) (by
    intro f
    filter_upwards [LCAQuotient.ordinaryRow_ae μ k',LCAQuotient.ordinaryRow_ae μ k,
      rep' f,rep (kernelTranspose μ B f)] with x hk' hk ha hb
    calc
      _ = ∫ y, k' (x,y)*f y ∂μ := integral_congr_ae (hk'.mono fun y hy => congrArg (· * f y) hy)
      _ = ∫ y, k (x,y)*kernelTranspose μ B f y ∂μ := ha.symm.trans hb
      _ = ∫ y, LCAQuotient.ordinaryRow μ k x y * kernelTranspose μ B f y ∂μ :=
        integral_congr_ae (hk.symm.mono fun y hy => congrArg (· * kernelTranspose μ B f y) hy)
      _ = _ := (transpose_pair μ B _ f).symm)
  filter_upwards [rows,shift_ordinary_row μ k,shift_ordinary_row μ k'] with x h a b
  rw [←a,←b,h,comm]

end KDClosure.LCAReality
