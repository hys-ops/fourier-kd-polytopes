import KDLCARealitySymbol
import KDLCARealityAnnihilator
import Mathlib.MeasureTheory.Function.Holder

noncomputable section
namespace KDClosure.LCAReality
open MeasureTheory Filter Set CompactCore Topology
open scoped ENNReal ComplexConjugate Pointwise
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
  [MeasurableSpace G] [BorelSpace G]
variable (μ : Measure G) [μ.IsAddLeftInvariant]
variable [MeasurableSpace (Dual G)] [BorelSpace (Dual G)] (ν : Measure (Dual G))

omit [IsTopologicalAddGroup G] [MeasurableSpace G] [BorelSpace G] in
theorem phase_measurable_at (h : G) : Measurable (fun χ : Dual G => phase χ h) := by
  have e := continuous_eval_const (F:=ContinuousMonoidHom (Multiplicative G) Circle) (Multiplicative.ofAdd h)
  have a : Continuous (fun χ : Dual G => phase χ h) := continuous_subtype_val.comp e
  exact a.measurable

omit [IsTopologicalAddGroup G] [MeasurableSpace G] [BorelSpace G] in
theorem phaseMem (h : G) : MemLp (fun χ : Dual G => phase χ h) ∞ ν :=
  memLp_top_of_bound (phase_measurable_at h).aestronglyMeasurable 1 (.of_forall fun χ => by
    change ‖(χ (Multiplicative.ofAdd h):ℂ)‖ ≤ 1
    exact (Circle.norm_coe _).le)

def modulate (h : G) : Lp ℂ 2 ν →L[ℂ] Lp ℂ 2 ν :=
  ((ContinuousLinearMap.mul ℂ ℂ).holderL ν ∞ 2 2) ((phaseMem ν h).toLp _)

omit [IsTopologicalAddGroup G] [MeasurableSpace G] [BorelSpace G] in
theorem modulate_ae (h : G) (f : Lp ℂ 2 ν) :
    (modulate ν h f : Dual G → ℂ) =ᵐ[ν] fun χ => phase χ h * f χ := by
  have a := (ContinuousLinearMap.mul ℂ ℂ).coeFn_holder (r:=2) ((phaseMem ν h).toLp _) f
  filter_upwards [a,(phaseMem ν h).coeFn_toLp] with χ hx hc
  exact hx.trans (by rw [hc]; rfl)

def shift (h : G) : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ :=
  (Lp.compMeasurePreservingₗᵢ ℂ (h+·) (measurePreserving_add_left μ h)).toContinuousLinearMap

omit [MeasurableSpace (Dual G)] [BorelSpace (Dual G)] in
theorem shift_ae (h : G) (f : Lp ℂ 2 μ) :
    (shift μ h f : G → ℂ) =ᵐ[μ] fun x => f (h+x) :=
  Lp.coeFn_compMeasurePreserving f (measurePreserving_add_left μ h)

omit [IsTopologicalAddGroup G] [MeasurableSpace G] [BorelSpace G] [MeasurableSpace (Dual G)] [BorelSpace (Dual G)] in
theorem phase_add (χ : Dual G) (a b : G) : phase χ (a+b) = phase χ a * phase χ b := by
  change ((χ ((Multiplicative.ofAdd a)*(Multiplicative.ofAdd b))):ℂ) = _
  rw [map_mul]; rfl

omit [IsTopologicalAddGroup G] [MeasurableSpace G] [BorelSpace G] [MeasurableSpace (Dual G)] [BorelSpace (Dual G)] in
theorem phase_neg_mul (χ : Dual G) (a : G) : phase χ (-a) * phase χ a = 1 := by
  rw [← phase_add,neg_add_cancel]
  change ((χ 1):ℂ)=1
  rw [map_one]; rfl

/-- Positive-phase Fourier transform intertwines h-translation with the
negative h-character multiplier. The Haar integral is used only on the
dense L¹∩L² subspace. -/
theorem fourier_shift (F : FourierRealization μ ν) (h : G) (f : Lp ℂ 2 μ) :
    F.isometry (shift μ h f) = modulate ν (-h) (F.isometry f) := by
  have intCase (g : Lp ℂ 2 μ) (hi : Integrable (g : G → ℂ) μ) :
      F.isometry (shift μ h g) = modulate ν (-h) (F.isometry g) := by
    have j := (measurePreserving_add_left μ h).integrable_comp_of_integrable hi
    have hj : Integrable (shift μ h g : G → ℂ) μ := j.congr (shift_ae μ h g).symm
    apply Lp.ext
    filter_upwards [F.integral_ae (shift μ h g) hj,F.integral_ae g hi,modulate_ae ν (-h) (F.isometry g)] with χ hg hq hc
    rw [hg,hc,hq, ← integral_const_mul]
    calc
      _ = ∫ x, g (h+x) * phase χ x ∂μ := integral_congr_ae ((shift_ae μ h g).mono fun x hx => by rw [hx])
      _ = ∫ x, phase χ (-h) * (g (h+x) * phase χ (h+x)) ∂μ := by
        apply integral_congr_ae
        exact .of_forall fun x => by
          dsimp only
          rw [phase_add]
          calc
            _ = (phase χ (-h)*phase χ h)*(g (h+x)*phase χ x) := by rw [phase_neg_mul,one_mul]
            _ = _ := by ring
      _ = _ := integral_add_left_eq_self (μ:=μ) (fun x => phase χ (-h) * (g x * phase χ x)) h
  apply Lp.induction (by norm_num : (2:ℝ≥0∞)≠∞)
    (fun g => F.isometry (shift μ h g)=modulate ν (-h) (F.isometry g)) _ _ _ f
  · intro c s hs hm
    exact intCase _ (integrable_indicatorConstLp hs hm.ne c)
  · intro a b ha hb _ e₁ e₂
    simp only [map_add,e₁,e₂]
  · exact isClosed_eq (F.isometry.continuous.comp (shift μ h).continuous)
      ((modulate ν (-h)).continuous.comp F.isometry.continuous)

/-- An h-periodic row is supported on the physical annihilator of h. -/
theorem weyl_slice_support (F : FourierRealization μ ν) (h : G) (f : Lp ℂ 2 μ)
    (period : ∀ᵐ x ∂μ, f (h+x)=f x) :
    ∀ᵐ χ ∂ν, phase χ h ≠ 1 → F.isometry f χ=0 := by
  have eq : shift μ h f=f := Lp.ext ((shift_ae μ h f).trans period)
  have m := fourier_shift μ ν F h f
  rw [eq] at m
  have a := modulate_ae ν (-h) (F.isometry f)
  rw [←m] at a
  filter_upwards [a] with χ hx
  intro ne
  by_contra nonzero
  have he := (mul_right_cancel₀ nonzero (by simpa using hx.symm : phase χ (-h)*F.isometry f χ=1*F.isometry f χ))
  have one := phase_neg_mul χ h
  rw [he,one_mul] at one
  exact ne one

end KDClosure.LCAReality
