import KDLCARealityAverage
import KDLCARealityFiniteRank

noncomputable section
namespace KDClosure.LCAReality
open MeasureTheory Filter Set CompactCore Topology
open scoped ENNReal ComplexConjugate Pointwise ComplexOrder
section Masks
variable {X : Type*} [MeasurableSpace X] (ρ : Measure X)

/-- Strong convergence for an increasing sequence of measurable masks on
vectors supported in their union. The reference measure can be infinite. -/
theorem masks_tendsto (S : ℕ→Set X) (ms : ∀ n, MeasurableSet (S n)) (inc : Monotone S)
    (v : Lp ℂ 2 ρ) (supp : ∀ᵐ x ∂ρ, (¬∃ n, x∈S n) → v x=0) :
    Tendsto (fun n => mask ρ (S n) (ms n) v) atTop (𝓝 v) := by
  have int := (memLp_two_iff_integrable_sq_norm (Lp.aestronglyMeasurable v)).mp (Lp.memLp v)
  let e (n : ℕ) (x : X) : ℝ := (S n)ᶜ.indicator (fun y => ‖v y‖^2) x
  have rep (n : ℕ) :
      ‖mask ρ (S n) (ms n) v-v‖^2 = ∫ x, e n x ∂ρ := by
    rw [←CompactFourier.sq_integral]
    apply integral_congr_ae
    filter_upwards [Lp.coeFn_sub (mask ρ (S n) (ms n) v) v,mask_ae ρ (S n) (ms n) v] with x hx hm
    change (mask ρ (S n) (ms n) v-v) x=mask ρ (S n) (ms n) v x-v x at hx
    change ‖(mask ρ (S n) (ms n) v-v) x‖^2=e n x
    rw [hx,hm]
    by_cases mem : x∈S n <;> simp [e,mem]
  have res : Tendsto (fun n => ∫ x, e n x ∂ρ) atTop (𝓝 (∫ _ : X, (0:ℝ) ∂ρ)) := by
    apply tendsto_integral_of_dominated_convergence (fun x => ‖v x‖^2)
    · intro n
      exact int.1.indicator (ms n).compl
    · exact int
    · intro n
      exact .of_forall fun x => by by_cases hx : x∈S n <;> simp [e,hx]
    · filter_upwards [supp] with x hx
      apply tendsto_const_nhds.congr'
      by_cases ex : ∃ n,x∈S n
      · obtain ⟨n,hn⟩ := ex
        filter_upwards [eventually_ge_atTop n] with j hj
        simp [e,inc hj hn]
      · exact .of_forall fun n => by
          have hn : x∉S n := fun t => ex ⟨n,t⟩
          simp [e,hn,hx ex]
  apply tendsto_iff_norm_sub_tendsto_zero.mpr
  have t : Tendsto (fun n => ‖mask ρ (S n) (ms n) v-v‖^2) atTop (𝓝 0) := by simpa only [rep,integral_zero] using res
  simpa only [Function.comp_def,Real.sqrt_sq (norm_nonneg _),Real.sqrt_zero] using (Real.continuous_sqrt.tendsto 0).comp t

theorem mask_dist_le (S : Set X) (hs : MeasurableSet S) (u v : Lp ℂ 2 ρ) :
    dist (mask ρ S hs u) (mask ρ S hs v) ≤ dist u v := by
  let P := mask ρ S hs
  have normle : ‖P‖≤1 := IsStarProjection.norm_le P (mask_isStarProjection ρ S hs)
  rw [dist_eq_norm,dist_eq_norm,←map_sub]
  exact (P.le_opNorm _).trans (by nlinarith [norm_nonneg (u-v)])
end Masks

variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
  [MeasurableSpace G] [BorelSpace G] [SecondCountableTopology G] [T2Space G] [LocallyCompactSpace G]
variable (μ : Measure G) [μ.IsAddHaarMeasure] [SFinite μ]

omit [SecondCountableTopology G] [T2Space G] [LocallyCompactSpace G] [SFinite μ] in
theorem mask_shift_of_mem (K : CO G) (h : G) (mem : h∈subgroup K) (v : Lp ℂ 2 μ) :
    shift μ h (mask μ (K.val : Set G) K.val.isOpen.measurableSet v) =
      mask μ (K.val : Set G) K.val.isOpen.measurableSet (shift μ h v) := by
  let S := (K.val : Set G)
  let ms := K.val.isOpen.measurableSet
  have t := (measurePreserving_add_left μ h).quasiMeasurePreserving.ae_eq_comp (mask_ae μ S ms v)
  apply Lp.ext
  filter_upwards [shift_ae μ h (mask μ S ms v),t,mask_ae μ S ms (shift μ h v),shift_ae μ h v] with x a b c d
  change mask μ S ms v (h+x)=S.indicator v (h+x) at b
  change shift μ h (mask μ S ms v) x = mask μ S ms (shift μ h v) x
  rw [a,b,c]
  have equiv : h+x∈S ↔ x∈S := (subgroup K).add_mem_cancel_left mem
  by_cases hx : x∈S
  · exact (Set.indicator_of_mem (equiv.mpr hx) _).trans ((Set.indicator_of_mem hx _).trans d).symm
  · exact (Set.indicator_of_notMem (equiv.not.mpr hx) _).trans (Set.indicator_of_notMem hx _).symm

def windowSpan (H K : CO G) : Submodule ℂ (Lp ℂ 2 μ) :=
  Submodule.span ℂ (Set.range (fun j : CoreQuot H K => cell μ H 1 (CompactCoset.representative H K j:G)))

/-- An explicit sequence in the physical finite windows. -/
theorem central_approximants (w : ManyOpen.Windows G) (v : Lp ℂ 2 μ)
    (support : ∀ᵐ x ∂μ, (¬ ∃ n, x∈subgroup (w.K n)) → v x=0)
    (inv : ∀ h : G, (∀ n, h∈subgroup (w.L n)) → shift μ h v=v) :
    ∃ b : ℕ→Lp ℂ 2 μ, (∀ n, b n∈windowSpan μ (w.L n) (w.K n)) ∧ Tendsto b atTop (𝓝 v) := by
  let avg (n:ℕ) := subgroupAverage μ (w.L n) v
  let S (n:ℕ) := ((w.K n).val : Set G)
  let ms (n:ℕ) : MeasurableSet (S n) := (w.K n).val.isOpen.measurableSet
  let b (n:ℕ) := mask μ (S n) (ms n) (avg n)
  refine ⟨b,?_,?_⟩
  · intro n
    have outside : ∀ᵐ x ∂μ, x∉CompactCoset.coset (w.K n) 0 → b n x=0 := by
      filter_upwards [mask_ae μ (S n) (ms n) (avg n)] with x hx
      intro no
      have hn : x∉S n := by
        intro p
        apply no
        change x-0∈(w.K n).val
        rw [sub_zero]
        exact p
      exact hx.trans (Set.indicator_of_notMem hn _)
    have fixed (l : subgroup (w.L n)) : shift μ (l:G) (b n)=phase (1:Dual G) (l:G) • b n := by
      have a := subgroupAverage_invariant μ (w.L n) v (l:G) l.property
      change shift μ _ (mask μ (S n) (ms n) (avg n))=_
      rw [mask_shift_of_mem μ (w.K n) _ (w.within n l.property),show shift μ (l:G) (avg n)=avg n from a]
      have one : phase (1 : Dual G) (l:G)=1 := rfl
      rw [one,one_smul]
    simpa only [windowSpan,zero_add] using mode_span μ (w.L n) (w.K n) (w.within n) 0 1 (b n) outside fixed
  · have ac := averages_tendsto μ w v inv
    have mc := masks_tendsto μ S ms (fun _ _ h _ hi => w.up h hi) v support
    apply Metric.tendsto_nhds.mpr
    intro ε he
    have half : 0<ε/2 := half_pos he
    filter_upwards [Metric.tendsto_nhds.mp ac (ε/2) half,Metric.tendsto_nhds.mp mc (ε/2) half] with n ha hb
    have first : dist (b n) (mask μ (S n) (ms n) v) ≤ dist (avg n) v :=
      mask_dist_le μ (S n) (ms n) (avg n) v
    have s : dist (avg n) v + dist (mask μ (S n) (ms n) v) v < ε := by
      change dist (avg n) v<ε/2 at ha
      linarith
    calc
      dist (b n) v ≤ dist (b n) (mask μ (S n) (ms n) v) + dist (mask μ (S n) (ms n) v) v :=
        dist_triangle _ _ _
      _ ≤ dist (avg n) v + dist (mask μ (S n) (ms n) v) v := add_le_add first (le_refl (dist (mask μ (S n) (ms n) v) v))
      _ < ε := s

/-- Strong convergence of any finite-window star projections that fix the
specified central cells. No spectral, trace or probability normalization
assumption is imposed on the tested vector. -/
theorem central_window_strong (w : ManyOpen.Windows G) (P : ℕ→Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ)
    (proj : ∀ n, IsStarProjection (P n))
    (cells : ∀ n j, P n (cell μ (w.L n) 1 (CompactCoset.representative (w.L n) (w.K n) j:G)) =
      cell μ (w.L n) 1 (CompactCoset.representative (w.L n) (w.K n) j:G))
    (v : Lp ℂ 2 μ) (support : ∀ᵐ x ∂μ, (¬∃ n, x∈subgroup (w.K n)) → v x=0)
    (inv : ∀ h : G, (∀ n, h∈subgroup (w.L n)) → shift μ h v=v) :
    Tendsto (fun n => P n v) atTop (𝓝 v) := by
  obtain ⟨b,belongs,lim⟩ := central_approximants μ w v support inv
  have fix (n:ℕ) : P n (b n)=b n := by
    let V := (P n).toLinearMap.eqLocus LinearMap.id
    have sub : windowSpan μ (w.L n) (w.K n) ≤ V :=
      Submodule.span_le.mpr (by rintro _ ⟨j,rfl⟩; exact cells n j)
    exact sub (belongs n)
  apply Metric.tendsto_nhds.mpr
  intro ε he
  filter_upwards [Metric.tendsto_nhds.mp lim (ε/2) (half_pos he)] with n hn
  have nn := IsStarProjection.norm_le (P n) (proj n)
  have d : dist (P n v) (P n (b n)) ≤ dist v (b n) := by
    rw [dist_eq_norm,dist_eq_norm,←map_sub]
    exact ((P n).le_opNorm _).trans (by nlinarith [norm_nonneg (v-b n)])
  rw [fix n,dist_comm v (b n)] at d
  exact (dist_triangle _ (b n) _).trans_lt (by linarith)
end KDClosure.LCAReality
