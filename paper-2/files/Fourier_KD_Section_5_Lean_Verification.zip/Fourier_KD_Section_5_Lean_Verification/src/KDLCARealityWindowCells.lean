import KDLCARealityWindow
import KDReducedPartialCells

noncomputable section
namespace KDClosure.LCAReality
open MeasureTheory Set Filter Topology CompactCore CompactCoset ReducedWindows
open scoped ENNReal ComplexConjugate Pointwise
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
  [MeasurableSpace G] [BorelSpace G] [SecondCountableTopology G] [T2Space G] [LocallyCompactSpace G]
variable (μ : Measure G) [μ.IsAddHaarMeasure] [SFinite μ]

omit [SFinite μ] [T2Space G] [LocallyCompactSpace G] in
theorem physical_cell_mem_window (H K : CO G) (le : H≤K) (i : CoreQuot H K) :
    LCAReality.cell μ H 1 (CompactCoset.representative H K i:G) ∈ ReducedWindows.cellSpace μ H K := by
  let r : subgroup K := CompactCoset.representative H K i
  let C := coset H (r:G)
  apply mem_cellSpace_of_step μ H K le (C.indicator (phase (1:Dual G))) (cell_ae μ H 1 r)
  · intro x hx
    apply Set.indicator_of_notMem
    intro hc
    exact hx (show x∈K.val from by
      have h := K.val.add_mem (le (show x-r∈H.val from hc)) r.property
      rw [sub_add_cancel] at h
      exact h)
  · intro x y h
    have equ : x∈C ↔ y∈C := by
      change x-r∈H.val ↔ y-r∈H.val
      constructor
      · intro hx
        have hy := H.val.sub_mem hx h
        rwa [show (x-r)-(x-y)=y-r from by abel] at hy
      · intro hy
        have hx := H.val.add_mem h hy
        rwa [show (x-y)+(y-r)=x-r from by abel] at hx
    by_cases hx : x∈C
    · rw [Set.indicator_of_mem hx,Set.indicator_of_mem (equ.mp hx)]; rfl
    · rw [Set.indicator_of_notMem hx,Set.indicator_of_notMem (equ.not.mp hx)]

/-- Actual, normalized isometric finite-section ranges, on an arbitrary
ambient group. Only the vector is restricted to the central sector. -/
theorem physical_window_strong (w : ManyOpen.Windows G) (v : Lp ℂ 2 μ)
    (support : ∀ᵐ x ∂μ, (¬∃ n, x∈subgroup (w.K n)) → v x=0)
    (invariant : ∀ h : G, (∀ n, h∈subgroup (w.L n)) → LCAReality.shift μ h v=v) :
    Tendsto (fun n => (ReducedWindows.cellSpace μ (w.L n) (w.K n)).starProjection v) atTop (𝓝 v) :=
  central_window_strong μ w _ (fun _ => isStarProjection_starProjection)
    (fun n i => (ReducedWindows.cellSpace μ _ _).starProjection_eq_self_iff.mpr
      (physical_cell_mem_window μ _ _ (w.within n) i)) v support invariant

end KDClosure.LCAReality
