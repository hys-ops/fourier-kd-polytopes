import KDCompactFourierTransfer
import Mathlib.LinearAlgebra.Dimension.Basic

/-! Exact range correspondence under real or complex unitary changes of
coordinates. Cardinal rank (including infinite rank) is preserved. -/
noncomputable section
namespace KDClosure.UnitaryRank
universe u v w
variable {𝕜 : Type u} [RCLike 𝕜]
    {H : Type v} {K : Type w} [NormedAddCommGroup H] [InnerProductSpace 𝕜 H]
    [NormedAddCommGroup K] [InnerProductSpace 𝕜 K]

def transport (e : H ≃ₗᵢ[𝕜] K) (T : H→L[𝕜]H) : K→L[𝕜]K :=
  (e : H→L[𝕜]K) ∘L T ∘L (e.symm : K→L[𝕜]H)

def rangeEquiv (e : H ≃ₗᵢ[𝕜] K) (T : H→L[𝕜]H) :
    LinearMap.range T.toLinearMap ≃ₗ[𝕜] LinearMap.range (transport e T).toLinearMap :=
  LinearEquiv.ofBijective
    { toFun := fun x => ⟨e x.val,by
        obtain ⟨y,hy⟩ := x.property
        exact ⟨e y,by change e (T (e.symm (e y)))=e x.val; rw [e.symm_apply_apply]; exact congrArg e hy⟩⟩
      map_add' := fun x y => Subtype.ext (map_add e x.val y.val)
      map_smul' := fun c x => Subtype.ext (map_smul e c x.val) }
    ⟨fun _ _ h => Subtype.ext (e.injective (congrArg Subtype.val h)),fun x => by
      obtain ⟨y,hy⟩ := x.property
      exact ⟨⟨T (e.symm y),e.symm y,rfl⟩,Subtype.ext hy⟩⟩

theorem finite_iff (e : H ≃ₗᵢ[𝕜] K) (T : H→L[𝕜]H) :
    FiniteDimensional 𝕜 (LinearMap.range (transport e T).toLinearMap) ↔
      FiniteDimensional 𝕜 (LinearMap.range T.toLinearMap) := by
  constructor <;> intro _
  · exact Module.Finite.equiv (rangeEquiv e T).symm
  · exact Module.Finite.equiv (rangeEquiv e T)

theorem rank_le_one_iff (e : H ≃ₗᵢ[𝕜] K) (T : H→L[𝕜]H) :
    Module.rank 𝕜 (LinearMap.range (transport e T).toLinearMap)≤1 ↔ Module.rank 𝕜 (LinearMap.range T.toLinearMap)≤1 := by
  have eqn := (rangeEquiv e T).lift_rank_eq
  have cmp : Cardinal.lift.{v} (Module.rank 𝕜 (LinearMap.range (transport e T).toLinearMap))≤1 ↔
      Cardinal.lift.{w} (Module.rank 𝕜 (LinearMap.range T.toLinearMap))≤1 := by rw [eqn]
  simpa using cmp

section SameUniverse
variable {K' : Type v} [NormedAddCommGroup K'] [InnerProductSpace 𝕜 K']
theorem rank_unitary (e : H ≃ₗᵢ[𝕜] K') (T : H→L[𝕜]H) :
    Module.rank 𝕜 (LinearMap.range (transport e T).toLinearMap)=Module.rank 𝕜 (LinearMap.range T.toLinearMap) :=
  (rangeEquiv e T).rank_eq.symm
end SameUniverse
end KDClosure.UnitaryRank
