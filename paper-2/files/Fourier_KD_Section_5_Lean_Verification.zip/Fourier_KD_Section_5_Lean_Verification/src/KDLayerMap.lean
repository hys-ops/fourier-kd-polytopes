import KDWeights
import Mathlib.Logic.Equiv.Fin.Basic

namespace KDClosure
variable {p L : ℕ} [NeZero p] [NeZero L]

noncomputable def zvalEquiv (n : ℕ) [NeZero n] : ZMod n ≃ Fin n where
  toFun x := ⟨x.val,x.val_lt⟩
  invFun j := (j.val : ZMod n)
  left_inv := ZMod.natCast_zmod_val
  right_inv j := Fin.ext (ZMod.val_natCast_of_lt j.isLt)

/-- This is a set bijection, not a false direct-product group isomorphism. -/
noncomputable def pack (a b : ℕ) [NeZero a] [NeZero b] :
    ZMod a × ZMod b ≃ ZMod (a*b) :=
  ((zvalEquiv a).prodCongr (zvalEquiv b)).trans (finProdFinEquiv.trans (zvalEquiv (a*b)).symm)

theorem pack_val {a b : ℕ} [NeZero a] [NeZero b] (x : ZMod a) (y : ZMod b) :
    (pack a b (x,y)).val = y.val + b*x.val :=
  ZMod.val_natCast_of_lt (finProdFinEquiv ((zvalEquiv a) x,(zvalEquiv b) y)).isLt

def levelSize (p L : ℕ) : ℕ → ℕ
  | 0 => p
  | n+1 => (levelSize p L n * L)*p

instance sizeNZ : ∀ n, NeZero (levelSize p L n)
  | 0 => inferInstanceAs (NeZero p)
  | n+1 =>
    let _ : NeZero (levelSize p L n) := sizeNZ n
    inferInstanceAs (NeZero ((levelSize p L n*L)*p))

noncomputable def shuffle (A B C : Type*) : A × (B × C) ≃ (C × B) × A where
  toFun x := ((x.2.2,x.2.1),x.1)
  invFun y := (y.2,(y.1.2,y.1.1))
  left_inv _ := rfl
  right_inv _ := rfl

noncomputable def encodeLevel (p L : ℕ) [NeZero p] [NeZero L] :
    (j : ℕ) → Level p L j ≃ ZMod (levelSize p L j)
  | 0 => Equiv.refl _
  | n+1 => (shuffle (ZMod p) (ZMod L) (Level p L n)).trans
    (((((encodeLevel p L n).prodCongr (Equiv.refl _)).trans (pack _ L)).prodCongr
      (Equiv.refl _)).trans (pack _ p))

theorem encode_succ (n : ℕ) (b : ZMod p) (g : ZMod L) (x : Level p L n) :
    (encodeLevel p L (n+1) (b,g,x)).val =
       b.val + p*(g.val + L*(encodeLevel p L n x).val) := by
  change (pack _ p (pack _ L (encodeLevel p L n x,g),b)).val = _
  rw [pack_val, pack_val]

theorem old_head_image (n : ℕ) (x : Level p L n) :
    (encodeLevel p L (n+1) (0,0,x)).val = (p*L)*(encodeLevel p L n x).val := by
  simp [encode_succ,Nat.mul_assoc]

theorem size_prime_power (p m n : ℕ) :
    levelSize p (p^m) n = p^(1+n*(m+1)) := by
  induction n with
  | zero => simp [levelSize]
  | succ n ih =>
    rw [levelSize,ih,←pow_add, ←pow_succ]
    congr 1
    ring

theorem base_digit_bounds (n : ℕ) (x : Level p L n) :
    (baseLabel p L n x).val*(p*L)^n ≤ (encodeLevel p L n x).val ∧
    (encodeLevel p L n x).val < ((baseLabel p L n x).val+1)*(p*L)^n := by
  induction n with
  | zero => change x.val*1 ≤ x.val ∧ x.val < (x.val+1)*1; omega
  | succ n ih =>
    obtain ⟨b,g,x⟩ := x
    obtain ⟨lo,hi⟩ := ih x
    have hp : 0<p := Nat.pos_of_ne_zero (NeZero.ne p)
    have hL : 0<L := Nat.pos_of_ne_zero (NeZero.ne L)
    have residue : b.val+p*g.val < p*L := by
      calc b.val+p*g.val < p+p*g.val := Nat.add_lt_add_right b.val_lt _
           _ = p*(g.val+1) := by ring
           _ ≤ p*L := Nat.mul_le_mul_left _ g.val_lt
    rw [encode_succ]; change (baseLabel p L n x).val * _ ≤ _ ∧ _ < ((baseLabel p L n x).val+1)*_
    rw [pow_succ]
    constructor
    · nlinarith [Nat.mul_le_mul_right (p*L) lo]
    · nlinarith [Nat.mul_le_mul_right (p*L) (show (encodeLevel p L n x).val+1 ≤ _ from hi)]

theorem physical_color (n l : ℕ) (x : Level p L n) :
    (encodeLevel p L n x).val < l*(p*L)^n ↔ (baseLabel p L n x).val < l := by
  obtain ⟨lo,hi⟩ := base_digit_bounds n x
  constructor
  · intro h; by_contra! h'
    exact (not_lt_of_ge ((Nat.mul_le_mul_right _ h').trans lo)) h
  · intro h
    exact hi.trans_le (Nat.mul_le_mul_right _ h)
end KDClosure
