import KDScheduledFace

namespace KDClosure
open Set Matrix
open scoped ComplexOrder
variable {D : Type*} {p q : ℕ} [Fact p.Prime] [Fact q.Prime]

/-- A finite witness carries no entries outside its chart. -/
noncomputable def extendMatrix {I : Type*} (r : I → D) (C : Matrix I I ℂ)
    (z : D×D) : ℂ := by
  classical
  exact if hx : z.1 ∈ range r then
    if hy : z.2 ∈ range r then C (Classical.choose hx) (Classical.choose hy) else 0
  else 0

theorem extendMatrix_on {I : Type*} (r : I → D) (inj : Function.Injective r)
    (C : Matrix I I ℂ) (x y : I) : extendMatrix r C (r x,r y) = C x y := by
  classical
  have select (u : I) (hu : r u ∈ range r) : Classical.choose hu = u := inj hu.choose_spec
  simp [extendMatrix,select]

private theorem extendMatrix_bounded {I : Type*} (r : I → D) (C : Matrix I I ℂ)
    (b : ∀ i j, ‖C i j‖ ≤ 1) (z : D×D) : ‖extendMatrix r C z‖ ≤ 1 := by
  classical
  by_cases hx : z.1 ∈ range r <;> by_cases hy : z.2 ∈ range r <;> simp [extendMatrix,hx,hy,b]

private theorem extendMatrix_hermitian {I : Type*} (r : I → D) (C : Matrix I I ℂ)
    (h : C.IsHermitian) (x y : D) : star (extendMatrix r C (x,y)) = extendMatrix r C (y,x) := by
  classical
  by_cases hx : x ∈ range r <;> by_cases hy : y ∈ range r <;> simp [extendMatrix,hx,hy]
  exact h.apply _ _

variable (e : ∀ n : ℕ, Head p q n → D)

/-- Exactly one finite chart's PSD, trace budget, and Fourier reality/positivity tests. -/
def HeadTests (n : ℕ) (A : D×D → ℂ) : Prop :=
  (∀ u, 0 ≤ (cornerQ e n u A).re) ∧
  cornerTrace e n A ≤ 1 ∧
  (∀ x t k v, 0 ≤ (table (rowsOf (e n) A) x t k v).re) ∧
  (∀ x t k v, (table (rowsOf (e n) A) x t k v).im = 0)

private theorem isClosed_tests_all {I X : Type*} [TopologicalSpace X] {P : I→X→Prop}
    (cl : ∀ i, IsClosed {x | P i x}) : IsClosed {x | ∀ i, P i x} := by
  rw [Set.ofPred_forall]
  exact isClosed_iInter cl

private theorem headTests_closed (n : ℕ) : IsClosed {A | HeadTests e n A} := by
  unfold HeadTests
  repeat' apply IsClosed.inter
  · apply isClosed_tests_all; intro u; apply isClosed_le continuous_const
    unfold cornerQ; fun_prop
  · change IsClosed {A | cornerTrace e n A ≤ (1:ℝ)}
    exact isClosed_le (by unfold cornerTrace; fun_prop : Continuous (cornerTrace e n)) continuous_const
  · repeat' (apply isClosed_tests_all; intro)
    exact isClosed_le continuous_const (Complex.continuous_re.comp (continuous_table ..))
  · repeat' (apply isClosed_tests_all; intro)
    exact isClosed_eq (Complex.continuous_im.comp (continuous_table ..)) continuous_const

/-- A diagonal compactness argument which starts from finite matrices. Each
matrix needs the ambient state tests and additional closed requirements only
through the given finite cutoff, with no consistency between witness matrices.
No trace-class operator, ambient positive kernel, or infinite feasible witness
is part of the input. -/
theorem compact_limit_finite_matrices (V : ℕ → Set (D×D → ℂ)) (cv : ∀ n, IsClosed (V n))
    (finiteWitnesses : ∀ K : ℕ, ∃ (N : ℕ) (C : Matrix (Head p q N) (Head p q N) ℂ),
      (∀ i j, ‖C i j‖ ≤ 1) ∧ C.IsHermitian ∧
      ∀ n ≤ K, HeadTests e n (extendMatrix (e N) C) ∧ extendMatrix (e N) C ∈ V n) :
    ∃ A ∈ cornerSlice e, ∀ n, A ∈ V n := by
  let S (K : ℕ) := {A : D×D → ℂ | (∀ z, ‖A z‖ ≤ 1) ∧ (∀ x y, star (A (x,y)) = A (y,x)) ∧
    ∀ n≤K, HeadTests e n A ∧ A ∈ V n}
  have cl (K) : IsClosed (S K) := by
    dsimp only [S]
    repeat' apply IsClosed.inter
    · apply isClosed_tests_all; intro z; exact isClosed_le (continuous_apply z).norm continuous_const
    · apply isClosed_tests_all; intro x; apply isClosed_tests_all; intro y
      exact isClosed_eq (continuous_apply _).star (continuous_apply _)
    · change IsClosed {A | ∀ n, ∀ _ : n≤K, HeadTests e n A ∧ A ∈ V n}
      simp only [Set.ofPred_forall]
      exact isClosed_iInter fun n => isClosed_iInter fun _ => (headTests_closed e n).inter (cv n)
  have cm : IsCompact (S 0) := (isCompact_univ_pi fun _ : D×D => isCompact_closedBall (0:ℂ) 1).of_isClosed_subset
    (cl 0) (fun _ h i _ => by simpa [Metric.mem_closedBall] using h.1 i)
  obtain ⟨A,hA⟩ := IsCompact.nonempty_iInter_of_sequence_nonempty_isCompact_isClosed S
    (fun _ _ h => ⟨h.1,h.2.1,fun j hj => h.2.2 j (Nat.le_succ_of_le hj)⟩)
    (fun K => by
      obtain ⟨N,C,b,herm,cut⟩ := finiteWitnesses K
      exact ⟨extendMatrix (e N) C,extendMatrix_bounded _ _ b,extendMatrix_hermitian _ _ herm,cut⟩) cm cl
  have whole (n) := Set.mem_iInter.mp hA n
  have tests (n) := ((whole n).2.2 n le_rfl).1
  exact ⟨A,⟨(whole 0).1,(whole 0).2.1,fun n => (tests n).1,fun n => (tests n).2.1,
      fun n => (tests n).2.2.1,fun n => (tests n).2.2.2⟩,fun n => ((whole n).2.2 n le_rfl).2⟩

/-- Every finite layer of required face zeros is closed in the coordinate topology. -/
theorem layerZeros_closed (l : ℕ) (s : ℕ → ℕ) (χ : ℕ → AddChar (ZMod p) ℂ)
    (a : ℕ → ℂ) (d₁ d₂ : Additive (pRoots p) → ℂ) (c : ℂ) (K : ℕ) :
    IsClosed {A | LayerZeros (q:=q) l s χ a d₁ d₂ c K A} := by
  unfold LayerZeros
  apply IsClosed.inter
  · change IsClosed {A | ∀ j, ∀ _ : j ≤ K, testValue _ (.quad (s j) (birthVector s χ a d₁ d₂ c j)) A = 0}
    simp only [Set.ofPred_forall]
    exact isClosed_iInter fun j => isClosed_iInter fun _ => isClosed_eq (testValue _ _).continuous continuous_const
  · change IsClosed {A | ∀ n, ∀ _ : n≤K, ∀ x t k v, ∀ _ : Protected (color (p:=p) n l) x t v,
                          testValue _ (.kd n x t k v) A = 0}
    simp only [Set.ofPred_forall]
    repeat' (apply isClosed_iInter; intro)
    exact isClosed_eq (testValue _ _).continuous continuous_const

/-- The only witness assumption here quantifies over *finite matrices* and
finite layers of explicitly defined tests. The output is a single extreme
kernel on the full discrete Prüfer-by-prime group with infinite support. -/
theorem finite_matrix_extreme_infinite_support (pq : p≠q) (l : ℕ) (hl : 0<l) (hlt : l<p)
    (s : ℕ → ℕ) (hs : StrictMono s) (χ : ℕ → AddChar (ZMod p) ℂ)
    (a : ℕ → ℂ) (ha : ∀ j, a j ≠ 0) (d₁ d₂ : Additive (pRoots p) → ℂ)
    (h₁ : ∀ x, d₁ x ≠ 0) (h₂ : ∀ x, d₂ x ≠ 0) (c : ℂ) (hc : c ≠ 0)
    (o : Additive (pRoots p) × ZMod q) (δ : ℝ) (hδ : 0<δ)
    (per : ∀ A ∈ cornerSlice (fun i => cyclicMixedHead p q i),
      ∀ n, Periodic (rowsOf (cyclicMixedHead p q n) A))
    (finiteWitnesses : ∀ K, ∃ N, ∃ C : Matrix (Head p q N) (Head p q N) ℂ,
      (∀ i j, ‖C i j‖ ≤ 1) ∧ C.IsHermitian ∧
      let A := extendMatrix (cyclicMixedHead p q N) C
      δ ≤ (A (o,o)).re ∧ ∀ n≤K,
        HeadTests (fun i => cyclicMixedHead p q i) n A ∧ LayerZeros l s χ a d₁ d₂ c n A) :
    ∃ B ∈ (cornerSlice (fun i => cyclicMixedHead p q i)).extremePoints ℝ,
      0 < (B (o,o)).re ∧ (columnSupport B).Infinite ∧ ∀ K, LayerZeros l s χ a d₁ d₂ c K B := by
  let V (n : ℕ) := {A | δ ≤ (A (o,o)).re ∧ LayerZeros l s χ a d₁ d₂ c n A}
  have closed (n) : IsClosed (V n) := (isClosed_le continuous_const
    (Complex.continuous_re.comp (continuous_apply _))).inter (layerZeros_closed l s χ a d₁ d₂ c n)
  obtain ⟨A,hA,all⟩ := compact_limit_finite_matrices (fun i => cyclicMixedHead p q i) V closed (fun K => by
    obtain ⟨N,C,b,herm,pos,tests⟩ := finiteWitnesses K
    exact ⟨N,C,b,herm,fun n hn => ⟨(tests n hn).1,pos,(tests n hn).2⟩⟩)
  exact scheduled_extreme_infinite_support pq l hl hlt s hs χ a ha d₁ d₂ h₁ h₂ c hc o δ hδ per
    (fun K => ⟨A,hA,(all K).1,(all K).2⟩)

end KDClosure
