import KDReducedCofinal

noncomputable section
namespace KDClosure.ManyOpen
open CompactCore Set
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]

/-- Nested finite windows before any quotient or restriction of the original
ambient group. Cofinality controls every compact open in both directions. -/
structure Windows (G : Type*) [AddCommGroup G] [TopologicalSpace G] where
  L : ℕ → CO G
  K : ℕ → CO G
  down : Antitone L
  up : Monotone K
  within : ∀ n, L n ≤ K n
  cofinal : ∀ C : CO G, ∃ n, L n ≤ C ∧ C ≤ K n

private def intervals (a : ℕ→CO G) : ℕ → CO G × CO G
  | 0 => (a 0,a 0)
  | n+1 => (meet (intervals a n).1 (a (n+1)),join (intervals a n).2 (a (n+1)))

theorem windows [SecondCountableTopology G] [Nonempty (CO G)] : Nonempty (Windows G) := by
  let _ : Countable (CO G) := ReducedWindows.countable_opens
  obtain ⟨a,onto⟩ := exists_surjective_nat (CO G)
  let l (n:ℕ) := (intervals a n).1
  let k (n:ℕ) := (intervals a n).2
  have contains (n:ℕ) : l n≤a n ∧ a n≤k n := by
    cases n with
    | zero => exact ⟨le_rfl,le_rfl⟩
    | succ n => exact ⟨(inf_le_right : (_ ⊓ _ : OpenAddSubgroup G)≤_),
      (le_sup_right : (_ : OpenAddSubgroup G) ≤ _ ⊔ _)⟩
  refine ⟨⟨l,k,antitone_nat_of_succ_le (fun _ => (inf_le_left : (_ ⊓ _ : OpenAddSubgroup G)≤_)),
    monotone_nat_of_le_succ (fun _ => (le_sup_left : (_ : OpenAddSubgroup G) ≤ _ ⊔ _)),
    fun n => (contains n).1.trans (contains n).2,?_⟩⟩
  intro C
  obtain ⟨n,rfl⟩ := onto C
  exact ⟨n,contains n⟩

namespace Windows
variable (w : Windows G)
omit [IsTopologicalAddGroup G] in
theorem upper_iff (x:G) : (∃ n, x∈subgroup (w.K n)) ↔ ∃ A : CO G, x∈subgroup A := by
  refine ⟨fun ⟨n,h⟩ => ⟨w.K n,h⟩,?_⟩
  rintro ⟨A,h⟩
  obtain ⟨n,_,k⟩ := w.cofinal A
  exact ⟨n,k h⟩
omit [IsTopologicalAddGroup G] in
theorem lower_iff (x:G) : (∀ n, x∈subgroup (w.L n)) ↔ ∀ A : CO G, x∈subgroup A := by
  refine ⟨?_,fun h n => h (w.L n)⟩
  intro h A
  obtain ⟨n,l,_⟩ := w.cofinal A
  exact l (h n)
theorem upper_union [Nonempty (CO G)] :
    (⋃ n,((w.K n).val:Set G)) = (ActualCore.U G:Set G) := by
  ext x
  exact Set.mem_iUnion.trans (w.upper_iff x)
omit [IsTopologicalAddGroup G] in
theorem lower_inter :
    (⋂ n,((w.L n).val:Set G)) = ⋂ A : CO G,(A.val:Set G) := by
  ext x
  simp only [Set.mem_iInter]
  exact w.lower_iff x
end Windows
end KDClosure.ManyOpen
