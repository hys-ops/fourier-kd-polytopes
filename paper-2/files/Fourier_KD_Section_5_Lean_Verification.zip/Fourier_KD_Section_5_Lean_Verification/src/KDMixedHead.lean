import KDFiniteSummand
import KDPrimeColor
import Mathlib.Analysis.SpecialFunctions.Pow.Real

namespace KDClosure
open Matrix
open scoped ComplexOrder BigOperators
variable {p q : ℕ} [Fact p.Prime] [Fact q.Prime]

/-- A single declaration on the actual cyclic position and transverse groups. The
unscaled channels are e_0 ± 1/sqrt(q).  Periodicity, KD zeros and the two null
equations are the exact inherited conditions. No variable crossing/mixing
hypothesis on the colouring is supplied by the caller. -/
theorem mixed_head_vanish (pq : p ≠ q) (n l : ℕ) (hl : 0 < l) (hlt : l < p)
    (F : Blocks (p^(n+1)) q) (per : Periodic F)
    (hz : ∀ x t k s, Protected (color (p:=p) n l) x t s → table F x t k s = 0)
    (ps : (physical F).PosSemidef) (d₁ d₂ : ZMod (p^(n+1)) → ℂ)
    (dn₁ : ∀ x, d₁ x ≠ 0) (dn₂ : ∀ x, d₂ x ≠ 0) (c : ℂ) (hc : c ≠ 0)
    (kp : physical F *ᵥ (headVec d₁ ((Real.sqrt (q:ℝ) : ℂ)⁻¹) +
      c • headVec d₂ (-((Real.sqrt (q:ℝ) : ℂ)⁻¹))) = 0)
    (km : physical F *ᵥ (headVec d₁ ((Real.sqrt (q:ℝ) : ℂ)⁻¹) -
      c • headVec d₂ (-((Real.sqrt (q:ℝ) : ℂ)⁻¹))) = 0) :
    physical F = 0 := by
  have hq : 0 < (q:ℝ) := Nat.cast_pos.mpr (Fact.out : Nat.Prime q).pos
  have hsq : (Real.sqrt (q:ℝ) : ℂ)^2 = (q:ℂ) := by
    exact_mod_cast (Real.sq_sqrt hq.le)
  have cop : p.Coprime q := (Nat.coprime_primes Fact.out Fact.out).mpr pq
  apply finiteHeadVanish (cop.pow_left _) per (prime_color_both n l hl hlt) hz ps dn₁ dn₂
      (z:=((Real.sqrt (q:ℝ) : ℂ)⁻¹)) (by simp) _ hc kp km
  rw [inv_pow,hsq,mul_inv_cancel₀ (Nat.cast_ne_zero.mpr (Fact.out : Nat.Prime q).ne_zero)]

end KDClosure
