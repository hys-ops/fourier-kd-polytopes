import KDScheduledFace
import KDGlobalPeriod
import KDDiscreteOperator

namespace KDClosure
open Set Discrete

abbrev MixedD (p q : ℕ) := Additive (pRoots p) × ZMod q

noncomputable def physicalTests (p q : ℕ) [Fact p.Prime] [Fact q.Prime] :
    Set (L2 (MixedD p q) →L[ℂ] L2 (MixedD p q)) := by
  classical
  exact entries ⁻¹' cornerSlice (fun i => cyclicMixedHead p q i)

/-- Full operator conclusion in the explicitly defined finite Fourier corner model.
The remaining witness requirement is uniform visibility plus physical tests for
every finite prefix. Its quantifiers are essential to this theorem. -/
theorem scheduled_operator (p q : ℕ) [Fact p.Prime] [Fact q.Prime] (pq : p≠q)
    (l : ℕ) (hl : 0<l) (hlt : l<p)
    (s : ℕ → ℕ) (hs : StrictMono s) (χ : ℕ → AddChar (ZMod p) ℂ)
    (a : ℕ → ℂ) (ha : ∀ j, a j ≠ 0) (d₁ d₂ : Additive (pRoots p) → ℂ)
    (h₁ : ∀ x, d₁ x ≠ 0) (h₂ : ∀ x, d₂ x ≠ 0) (c : ℂ) (hc : c ≠ 0)
    (o : MixedD p q) (δ : ℝ) (hδ : 0<δ)
    (per : ∀ A ∈ cornerSlice (fun i => cyclicMixedHead p q i),
      ∀ n, Periodic (rowsOf (cyclicMixedHead p q n) A))
    (feasible : ∀ K, ∃ A ∈ cornerSlice (fun i => cyclicMixedHead p q i),
      δ ≤ (A (o,o)).re ∧ LayerZeros l s χ a d₁ d₂ c K A) :
    ∃ T ∈ (physicalTests p q).extremePoints ℝ, T.IsPositive ∧
      (∑' x : MixedD p q, (inner ℂ (lp.single 2 x (1:ℂ)) (T (lp.single 2 x (1:ℂ)))).re)=1 ∧
      ¬ FiniteDimensional ℂ (LinearMap.range T.toLinearMap) := by
  classical
  let e := fun i => (cyclicMixedHead p q i : Head p q i → MixedD p q)
  have cover (F : Finset (MixedD p q)) : ∃ n, (F : Set _) ⊆ range (e n) :=
    finite_in_head e all_cyclic_heads_increasing all_cyclic_heads_exhaust F.finite_toSet
  obtain ⟨A,hA,visible,inf,_⟩ :=
    scheduled_extreme_infinite_support pq l hl hlt s hs χ a ha d₁ d₂ h₁ h₂ c hc o δ hδ per feasible
  obtain ⟨T,hT,repr,extT⟩ := realizeExtreme e hA (cyclicMixedHead_injective p q) cover
  refine ⟨T,extT,hT,?_,?_⟩
  · have mass := extreme_mass_one e hA.1 (cyclicMixedHead_injective p q) cover hA o visible
    calc
      _ = ∑' x : MixedD p q, (A (x,x)).re := tsum_congr fun x =>
        congrArg Complex.re (congrFun repr (x,x))
      _ = 1 := mass
  · apply infinite_rank_of_realized_columnSupport T hT (fun x => lp.single 2 x (1:ℂ))
      (A:=A) (fun x y => (congrFun repr (x,y)).symm)
      (diagonalBudget e hA.1 (cyclicMixedHead_injective p q) cover).1 _ (mixed_two_finite p q) inf
    exact chart_periodic_global (fun n => cyclicMixedHead p q n)
      all_cyclic_heads_increasing all_cyclic_heads_exhaust (per A hA.1)

end KDClosure
