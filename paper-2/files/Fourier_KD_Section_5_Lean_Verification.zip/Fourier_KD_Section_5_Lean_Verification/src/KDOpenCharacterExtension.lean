import Mathlib.Algebra.Category.Grp.Injective
import Mathlib.Topology.Algebra.OpenSubgroup
import Mathlib.Topology.Algebra.PontryaginDual

/-! Restriction of circle characters to an open subgroup is onto. This is
the character-extension step needed for open subgroups, in particular for
arbitrary subgroups of a discrete group. -/

noncomputable section
namespace KDClosure.OpenCharacter
open Topology
variable {G : Type*} [CommGroup G] [TopologicalSpace G] [IsTopologicalGroup G]

private def argumentGroup : AddCircle (1:ℝ) ≃+ Additive Circle where
  toEquiv := (AddCircle.homeomorphCircle (one_ne_zero : (1:ℝ) ≠ 0)).toEquiv.trans Additive.ofMul
  map_add' x y := by
    change AddCircle.homeomorphCircle _ (x+y) = AddCircle.homeomorphCircle _ x * AddCircle.homeomorphCircle _ y
    simp only [AddCircle.homeomorphCircle_apply, AddCircle.toCircle_add]

/-- Every unitary character of an open subgroup extends continuously over
the entire abelian group. Continuity of the extension is proved at the
identity, using that the subgroup is open. -/
theorem extends_of_open (H : OpenSubgroup G) (χ : PontryaginDual H) :
    ∃ ψ : PontryaginDual G, ∀ h : H, ψ (h:G) = χ h := by
  let i : Additive H →+ Additive G := H.toSubgroup.subtype.toAdditive
  let g : Additive H →+ AddCircle (1:ℝ) :=
    argumentGroup.symm.toAddMonoidHom.comp χ.toMonoidHom.toAdditive
  obtain ⟨e,he⟩ := (Module.Baer.of_divisible (AddCircle (1:ℝ))).extension_property_addMonoidHom
    i (show Function.Injective i from Subtype.val_injective) g
  let f : G →* Circle := (argumentGroup.toAddMonoidHom.comp e).toMultiplicative
  have agrees (x : H) : f (x:G) = χ x := by
    have hx := DFunLike.congr_fun he (Additive.ofMul x)
    change e (Additive.ofMul (x:G)) = argumentGroup.symm (Additive.ofMul (χ x)) at hx
    change (argumentGroup (e (Additive.ofMul (x:G)))).toMul = χ x
    rw [hx, argumentGroup.apply_symm_apply]
    rfl
  have cc : Continuous (fun x : H => f (x:G)) := by
    simpa only [agrees] using (show Continuous (fun x : H => χ x) from χ.continuous)
  have cf : Continuous f := by
    apply continuous_of_continuousAt_one
    have oh : IsOpenEmbedding (fun x : H => (x:G)) :=
      H.isOpen.isOpenEmbedding_subtypeVal
    exact oh.continuousAt_iff.mp (cc.continuousAt (x:=(1:H)))
  exact ⟨⟨f,cf⟩,agrees⟩

end KDClosure.OpenCharacter
