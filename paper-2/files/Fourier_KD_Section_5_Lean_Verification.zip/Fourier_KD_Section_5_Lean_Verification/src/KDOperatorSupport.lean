import KDGramSupport
import Mathlib.Analysis.InnerProductSpace.StarOrder
import Mathlib.Analysis.SpecialFunctions.ContinuousFunctionalCalculus.Rpow.Basic

namespace KDClosure
open scoped InnerProductSpace ComplexOrder
open ContinuousLinearMap
variable {D H : Type*} [AddCommGroup D] [NormedAddCommGroup H]
  [InnerProductSpace ℂ H] [CompleteSpace H]

/-- Finite rank is a genuine finite-dimensional operator range, not a supplied
Gram factorization. On the position basis the summability hypothesis is the trace bound. -/
theorem finite_operator_support (T : H →L[ℂ] H)
    [FiniteDimensional ℂ (LinearMap.range T.toLinearMap)] (pos : T.IsPositive)
    (e : D → H) (traceFinite : Summable (fun x => (inner ℂ (e x) (T (e x))).re))
    (period : ∀ x y, inner ℂ (e x) (T (e y)) = inner ℂ (e y) (T (e (y+y-x))))
    (two : {y : D | y+y=0}.Finite) :
    {y | T (e y) ≠ 0}.Finite := by
  obtain ⟨S,hs⟩ := CStarAlgebra.nonneg_iff_eq_star_mul_self.mp
    ((ContinuousLinearMap.nonneg_iff_isPositive T).mpr pos)
  have fact (x : H) : T x = S.adjoint (S x) := by rw [hs]; rfl
  have ker : T.toLinearMap.ker = S.toLinearMap.ker := by
    rw [hs]; exact S.ker_adjoint_comp_self
  let equiv := T.toLinearMap.quotKerEquivRange.symm.trans
    ((Submodule.quotEquivOfEq _ _ ker).trans S.toLinearMap.quotKerEquivRange)
  let _ : FiniteDimensional ℂ (LinearMap.range S.toLinearMap) := equiv.finiteDimensional
  let v (x : D) : LinearMap.range S.toLinearMap := ⟨S (e x), e x, rfl⟩
  have gram (x y : D) : inner ℂ (v x) (v y) = inner ℂ (e x) (T (e y)) := by
    change inner ℂ (S (e x)) (S (e y)) = _
    rw [fact, S.adjoint_inner_right]
  have summ : Summable (fun x => ‖v x‖^2) := by
    have heq (x : D) : ‖v x‖^2 = (inner ℂ (e x) (T (e x))).re := by
      rw [←gram]; exact norm_sq_eq_re_inner (𝕜:=ℂ) (v x)
    simpa only [heq] using traceFinite
  apply (finite_gram_support v summ (fun x y => by rw [gram,gram,period]) two).subset
  intro y hy zero
  apply hy
  have hz : S (e y) = 0 := congrArg Subtype.val zero
  rw [fact,hz,map_zero]

end KDClosure
