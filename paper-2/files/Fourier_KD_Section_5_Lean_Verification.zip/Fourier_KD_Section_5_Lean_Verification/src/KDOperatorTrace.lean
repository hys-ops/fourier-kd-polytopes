import KDDiscreteOperator
import Mathlib.Analysis.InnerProductSpace.StarOrder
import Mathlib.Analysis.SpecialFunctions.ContinuousFunctionalCalculus.Rpow.Basic

noncomputable section

namespace KDClosure.Discrete
open scoped InnerProductSpace ComplexOrder ENNReal BigOperators
open ContinuousLinearMap

variable {D : Type*} [DecidableEq D]

private theorem squareFactor {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℂ H]
    [CompleteSpace H] (T : H →L[ℂ] H) (hT : T.IsPositive) :
    ∃ S : H →L[ℂ] H, S.adjoint = S ∧ ∀ x, T x = S.adjoint (S x) := by
  let S := CFC.sqrt T
  have sa : S.adjoint = S := (CFC.sqrt_nonneg T).star_eq
  refine ⟨S,sa,fun x => ?_⟩
  rw [sa]
  exact DFunLike.congr_fun (CFC.sqrt_mul_sqrt_self T ((nonneg_iff_isPositive T).mpr hT)).symm x

/-- An intrinsic trace test for positive operators. The index of the test frame
need not be finite; the inequality holds on every finite subfamily. -/
theorem frameTrace_le {T : L2 D →L[ℂ] L2 D} (hT : T.IsPositive)
    (hd : Summable fun i => (entries T (i,i)).re)
    {J : Type*} {v : J → L2 D} (hv : Orthonormal ℂ v) (s : Finset J) :
    ∑ j ∈ s, (inner ℂ (v j) (T (v j))).re ≤ ∑' i, (entries T (i,i)).re := by
  obtain ⟨S,sa,fact⟩ := squareFactor T hT
  have normSq (x : L2 D) : (inner ℂ x (T x)).re = ‖S x‖^2 := by
    rw [fact, S.adjoint_inner_right]
    exact (norm_sq_eq_re_inner (𝕜 := ℂ) _).symm
  let e (i : D) : L2 D := lp.single 2 i (1:ℂ)
  have coeff (i : D) (j : J) : ‖(S (v j)) i‖ = ‖inner ℂ (v j) (S (e i))‖ := by
    have he : inner ℂ (e i) (S (v j)) = (S (v j)) i := by
      simp [e,lp.inner_single_left,RCLike.inner_apply]
    rw [← he, norm_inner_symm (𝕜 := ℂ) (v j) (S (e i))]
    conv_rhs => rw [← sa, S.adjoint_inner_left]
  have hsum (j : J) : HasSum (fun i => ‖inner ℂ (v j) (S (e i))‖^2) (‖S (v j)‖^2) := by
    have hp : 0 < (2:ℝ≥0∞).toReal := by norm_num
    have hn := lp.hasSum_norm hp (S (v j))
    simpa only [ENNReal.toReal_ofNat,Real.rpow_two,coeff] using hn
  have he (i : D) : ‖S (e i)‖^2 = (entries T (i,i)).re := (normSq (e i)).symm
  have hf := hasSum_sum (s := s) (fun j _ => hsum j)
  simp_rw [normSq]
  apply hasSum_le _ hf hd.hasSum
  intro i
  exact (hv.sum_inner_products_le (s := s) (S (e i))).trans_eq (he i)

/-- Possible unnormalized trace tests on all finite orthonormal systems.
The supremum is the intrinsic trace of a positive operator. -/
def finiteFrameMass (T : L2 D →L[ℂ] L2 D) : Set ℝ :=
  {r | ∃ n : ℕ, ∃ v : Fin n → L2 D, Orthonormal ℂ v ∧
    (∑ j, (inner ℂ (v j) (T (v j))).re) = r}

private theorem partialFrame (T : L2 D →L[ℂ] L2 D) (s : Finset D) :
    (∑ i ∈ s, (entries T (i,i)).re) ∈ finiteFrameMass T := by
  classical
  let k (i : Fin s.card) : D := (s.equivFin.symm i : s).val
  have inj : Function.Injective k := Subtype.val_injective.comp s.equivFin.symm.injective
  let v (i : Fin s.card) : L2 D := lp.single 2 (k i) (1:ℂ)
  have on : Orthonormal ℂ v := by
    rw [orthonormal_iff_ite]
    intro i j
    by_cases hij : i=j
    · subst j
      simp [v]
    · have hkj : k i ≠ k j := fun h => hij (inj h)
      simp [v,lp.inner_single_left,RCLike.inner_apply,Pi.single_eq_of_ne hkj,hij]
  refine ⟨s.card,v,on,?_⟩
  change (∑ i, (entries T (k i,k i)).re) = ∑ i ∈ s, (entries T (i,i)).re
  exact (s.equivFin.symm.sum_comp (fun i : s => (entries T (i.val,i.val)).re)).trans
    (s.sum_coe_sort (fun i => (entries T (i,i)).re))

/-- The intrinsic supremum of all finite orthonormal tests is exactly the
summable physical diagonal. Thus the positive trace-class criterion is
basis-independent, including its exact numerical trace. -/
theorem trace_isLUB {T : L2 D →L[ℂ] L2 D} (hT : T.IsPositive)
    (hd : Summable fun i => (entries T (i,i)).re) :
    IsLUB (finiteFrameMass T) (∑' i, (entries T (i,i)).re) := by
  classical
  constructor
  · rintro r ⟨n,v,hv,rfl⟩
    exact frameTrace_le hT hd hv Finset.univ
  · intro r hr
    apply hd.tsum_le_of_sum_le
    intro s
    exact hr (partialFrame T s)

/-- Uniform bounds on *all* finite orthonormal tests are equivalent to
summability of the coordinate diagonal for a positive operator. -/
theorem boundedFrames_iff_diagonal {T : L2 D →L[ℂ] L2 D} (hT : T.IsPositive) :
    BddAbove (finiteFrameMass T) ↔ Summable (fun i => (entries T (i,i)).re) := by
  constructor
  · rintro ⟨c,hc⟩
    apply summable_of_sum_le (c := c)
    · intro i
      exact hT.re_inner_nonneg_right (lp.single 2 i (1:ℂ))
    · exact fun s => hc (partialFrame T s)
  · exact fun hd => ⟨_,(trace_isLUB hT hd).1⟩

/-- In the nonzero exposed construction the representative has intrinsic trace one. -/
theorem realized_trace_one {T : L2 D →L[ℂ] L2 D} (hT : T.IsPositive)
    (hd : Summable fun i => (entries T (i,i)).re)
    (unit : ∑' i, (entries T (i,i)).re = 1) : IsLUB (finiteFrameMass T) 1 :=
  unit ▸ trace_isLUB hT hd

end KDClosure.Discrete
