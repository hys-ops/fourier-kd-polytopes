import KDCompactCosetRow
import KDOpenCharacterExtension

/-! §5: actual Haar integrals of every ambient character packet at every quotient cell.
The phase convention is the same positive character convention as the finite Fourier row. -/
noncomputable section
set_option linter.unusedSectionVars false
namespace KDClosure.Hull
open MeasureTheory Set CompactCore CompactCoset Classical
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
  [T2Space G] [MeasurableSpace G] [BorelSpace G] [MeasurableAdd G]

omit [IsTopologicalAddGroup G] [T2Space G] [MeasurableSpace G] [BorelSpace G] [MeasurableAdd G] in
private theorem coset_rec {H : CO G} {a x y : G} (hx : x ∈ coset H a) :
    y ∈ coset H a ↔ y - x ∈ H.val := by
  change x - a ∈ H.val at hx
  change y-a ∈ H.val ↔ _
  constructor
  · intro hy
    simpa using H.val.sub_mem hy hx
  · intro hy
    simpa using H.val.add_mem hy hx

omit [T2Space G] [MeasurableSpace G] [BorelSpace G] [MeasurableAdd G] in
/-- Two intersecting cosets meet in precisely one translate of the meet. -/
theorem coset_inter_eq {L H : CO G} {r a x : G}
    (hx : x ∈ coset L r ∩ coset H a) :
    coset L r ∩ coset H a = coset (meet L H) x := by
  ext y
  exact and_congr (coset_rec hx.1) (coset_rec hx.2)

variable (μ : Measure G) [μ.IsAddHaarMeasure]

/-- Actual cell integral; wavefunction and cell normalizations are fixed scalars. -/
def coeff (L K H : CO G) (a : G) (η : AddChar G ℂ) (i : CoreQuot L K) : ℂ :=
  ∫ x in coset L (representative L K i : G) ∩ coset H a, η x ∂μ

theorem coeff_eq {L K H : CO G} {a x : G} (η : AddChar G ℂ) (i : CoreQuot L K)
    (hx : x ∈ coset L (representative L K i : G) ∩ coset H a) :
    coeff μ L K H a η i =
      if annihilates (meet L H) η then (μ.real ((meet L H).1 : Set G) : ℂ) * η x else 0 := by
  rw [coeff, coset_inter_eq hx, coset_character_integral]

omit [IsTopologicalAddGroup G] [T2Space G] [BorelSpace G] [MeasurableAdd G] [μ.IsAddHaarMeasure] in
theorem coeff_empty {L K H : CO G} {a : G} (η : AddChar G ℂ) (i : CoreQuot L K)
    (hx : ¬ (coset L (representative L K i : G) ∩ coset H a).Nonempty) :
    coeff μ L K H a η i = 0 := by
  simp [coeff, Set.not_nonempty_iff_eq_empty.mp hx]

theorem all_zero_of_not_annihilates (L K H : CO G) (a : G) (η : AddChar G ℂ)
    (hn : ¬ annihilates (meet L H) η) : coeff μ L K H a η = 0 := by
  funext i
  by_cases he : (coset L (representative L K i : G) ∩ coset H a).Nonempty
  · obtain ⟨x,hx⟩ := he
    simpa [hn] using coeff_eq μ η i hx
  · exact coeff_empty μ η i he

abbrev proj (L K : CO G) := QuotientAddGroup.mk' ((subgroup L).addSubgroupOf (subgroup K))

/-- The subgroup ((K ∩ H)+L)/L, written as the quotient image of K ∩ H. -/
def active (L K H : CO G) : AddSubgroup (CoreQuot L K) :=
  ((subgroup H).addSubgroupOf (subgroup K)).map (proj L K)

omit [IsTopologicalAddGroup G] [T2Space G] [MeasurableSpace G] [BorelSpace G] [MeasurableAdd G] in
private theorem proj_eq_iff {L K : CO G} (u v : subgroup K) :
    proj L K u = proj L K v ↔ (u : G) - v ∈ L.val :=
  QuotientAddGroup.eq_iff_sub_mem

omit [IsTopologicalAddGroup G] [T2Space G] [MeasurableSpace G] [BorelSpace G] [MeasurableAdd G] in
private theorem mem_rep_cell {L K : CO G} (u : subgroup K) (i : CoreQuot L K) :
    (u : G) ∈ coset L (representative L K i : G) ↔ proj L K u = i := by
  change ((u:G) - representative L K i ∈ L.val) ↔ _
  rw [← proj_eq_iff, show proj L K (representative L K i) = i from representative_spec L K i]

theorem active_iff_cell_nonempty {L K H : CO G} (hLK : L ≤ K) {a : G}
    (x₀ : subgroup K) (hx₀ : (x₀ : G) ∈ coset H a) (i : CoreQuot L K) :
    i - proj L K x₀ ∈ active L K H ↔
      (coset L (representative L K i : G) ∩ coset H a).Nonempty := by
  constructor
  · rintro ⟨h,hh,eqn⟩
    refine ⟨((h+x₀ : subgroup K) : G), (mem_rep_cell _ _).2 ?_, ?_⟩
    · rw [map_add,eqn,sub_add_cancel]
    · change (h:G) ∈ H.val at hh
      exact (coset_rec hx₀).2 (by simpa using hh)
  · rintro ⟨x, hxr, hxa⟩
    have hxK : x ∈ K.val := by
      have e : x-(representative L K i:G) ∈ K.val := hLK hxr
      simpa using K.val.add_mem e (representative L K i).property
    let u : subgroup K := ⟨x,hxK⟩
    have piu : proj L K u = i := (mem_rep_cell u i).1 hxr
    exact ⟨u-x₀, (coset_rec hx₀).1 hxa, by rw [map_sub,piu]⟩

omit [μ.IsAddHaarMeasure] in
/-- The actual finite vector has no support outside the indicated quotient coset. -/
theorem off_coset {L K H : CO G} (hLK : L ≤ K) {a : G} (η : AddChar G ℂ)
    (x₀ : subgroup K) (hx₀ : (x₀ : G) ∈ coset H a) (i : CoreQuot L K)
    (out : i - proj L K x₀ ∉ active L K H) : coeff μ L K H a η i = 0 :=
  coeff_empty μ η i (fun hx => out ((active_iff_cell_nonempty hLK x₀ hx₀ i).2 hx))

theorem on_coset {L K H : CO G} {a : G} {η : AddChar G ℂ}
    (ha : annihilates (meet L H) η) (x₀ : subgroup K) (hx₀ : (x₀ : G) ∈ coset H a)
    (h : subgroup K) (hh : (h : G) ∈ H.val) :
    coeff μ L K H a η (proj L K x₀ + proj L K h) =
      (μ.real ((meet L H).1 : Set G) : ℂ) * η (x₀ : G) * η (h : G) := by
  have hx : ((x₀+h : subgroup K):G) ∈ coset L (representative L K (proj L K x₀ + proj L K h) : G) ∩ coset H a :=
    ⟨(mem_rep_cell _ _).2 (map_add _ _ _), (coset_rec hx₀).2 (by simpa using hh)⟩
  rw [coeff_eq μ η _ hx, if_pos ha]
  change _ * η ((x₀:G) + (h:G)) = _
  rw [AddChar.map_add_eq_mul, mul_assoc]


omit [T2Space G] [MeasurableSpace G] [BorelSpace G] [MeasurableAdd G] in
/-- Character on the active finite subgroup, extended to a character of all of K/L.
This is a conclusion, not an extra hypothesis on the ambient packet. -/
theorem compatible_character (L K H : CO G) (η : AddChar G ℂ) (hη : ∀ t, ‖η t‖ = 1)
    (ha : annihilates (meet L H) η) :
    ∃ γ : AddChar (CoreQuot L K) ℂ, ∀ h : subgroup K, (h:G) ∈ H.val →
      γ (proj L K h) = η (h:G) := by
  classical
  let D := CoreQuot L K
  let W := active L K H
  have liftSpec (w : W) : ∃ h : subgroup K, (h:G) ∈ H.val ∧ proj L K h = w.val :=
    w.property
  let l (w : W) := (liftSpec w).choose
  have lH (w : W) : (l w : G) ∈ H.val := (liftSpec w).choose_spec.1
  have lq (w : W) : proj L K (l w) = w.val := (liftSpec w).choose_spec.2
  have same (u v : subgroup K) (hu : (u:G) ∈ H.val) (hv : (v:G) ∈ H.val)
      (hq : proj L K u = proj L K v) : η (u:G) = η (v:G) := by
    have hmem : (u:G) - v ∈ (meet L H).val :=
      ⟨(proj_eq_iff _ _).1 hq, H.val.sub_mem hu hv⟩
    calc
      η (u:G) = η (((u:G)-v)+v) := by rw [sub_add_cancel]
      _ = η (v:G) := by rw [AddChar.map_add_eq_mul, ha _ hmem, one_mul]
  let valχ (w : W) : Circle := ⟨η (l w:G), by change dist _ 0 = 1; simpa using hη (l w:G)⟩
  let S : OpenSubgroup (Multiplicative D) := ⟨W.toSubgroup, by
    have : DiscreteTopology D := QuotientAddGroup.discreteTopology_iff.mpr
      (L.val.isOpen.preimage continuous_subtype_val)
    exact isOpen_discrete _⟩
  let cv (s : S) : W := ⟨s.val.toAdd,s.property⟩
  let χ : PontryaginDual S :=
    { toFun := fun s => valχ (cv s)
      map_one' := by
        apply Subtype.ext
        change η (l (cv 1):G) = 1
        calc
          _ = η ((0:subgroup K):G) := same _ _ (lH _) H.val.zero_mem (by rw [lq,map_zero]; rfl)
          _ = 1 := η.map_zero_eq_one
      map_mul' := fun s t => by
        apply Subtype.ext
        change η (l (cv (s*t)):G) = η (l (cv s):G) * η (l (cv t):G)
        calc
          _ = η ((l (cv s) + l (cv t) : subgroup K):G) :=
            same _ _ (lH _) (H.val.add_mem (lH _) (lH _)) (by rw [lq,map_add,lq,lq]; rfl)
          _ = _ := η.map_add_eq_mul _ _
      continuous_toFun := by
        have : DiscreteTopology D := QuotientAddGroup.discreteTopology_iff.mpr
          (L.val.isOpen.preimage continuous_subtype_val)
        exact continuous_of_discreteTopology }
  obtain ⟨ψ,hψ⟩ := OpenCharacter.extends_of_open S χ
  let γ : AddChar D ℂ :=
    { toFun := fun d => (ψ (Multiplicative.ofAdd d):ℂ)
      map_zero_eq_one' := by change (ψ 1:ℂ) = 1; simp
      map_add_eq_mul' := fun d e => by change (ψ (Multiplicative.ofAdd d * Multiplicative.ofAdd e):ℂ) = _; simp }
  refine ⟨γ,fun h hh => ?_⟩
  let u : W := ⟨proj L K h,⟨h,hh,rfl⟩⟩
  let s : S := ⟨Multiplicative.ofAdd u.val,u.property⟩
  have agree : γ (proj L K h) = η (l u:G) :=
    congrArg (fun z : Circle => (z:ℂ)) (hψ s)
  exact agree.trans (same _ _ (lH _) hh (lq _))

/-- Every (unnormalized) compressed packet is zero or an explicit scalar times a
finite subgroup-coset character packet, on the actual D=K/L.
The input is an arbitrary ambient packet: its center need not lie in K, and
the character need not be trivial on L. -/
theorem compressed_packet (L K H : CO G) (hLK : L ≤ K) (a : G)
    (η : AddChar G ℂ) (hη : ∀ t, ‖η t‖ = 1) :
    coeff μ L K H a η = 0 ∨
    ∃ (b : CoreQuot L K) (γ : AddChar (CoreQuot L K) ℂ) (c : ℂ),
      ∀ i, coeff μ L K H a η i = if i-b ∈ active L K H then c * γ (i-b) else 0 := by
  classical
  by_cases ha : annihilates (meet L H) η
  · by_cases hc : ∃ x₀ : subgroup K, (x₀:G) ∈ coset H a
    · obtain ⟨x₀,hx₀⟩ := hc
      obtain ⟨γ,hγ⟩ := compatible_character L K H η hη ha
      right
      refine ⟨proj L K x₀, γ, (μ.real ((meet L H).1 : Set G):ℂ) * η (x₀:G), fun i => ?_⟩
      by_cases hi : i - proj L K x₀ ∈ active L K H
      · rw [if_pos hi]
        obtain ⟨h,hh,eqn⟩ := hi
        change (h:G) ∈ H.val at hh
        have he : proj L K x₀ + proj L K h = i := by rw [eqn, add_sub_cancel]
        rw [← eqn,hγ h hh]
        exact he ▸ on_coset μ ha x₀ hx₀ h hh
      · rw [if_neg hi]
        exact off_coset μ hLK η x₀ hx₀ i hi
    · left; funext i
      apply coeff_empty
      rintro ⟨x,hxr,hxa⟩
      apply hc
      have h : x - (representative L K i : G) ∈ K.val := hLK hxr
      exact ⟨⟨x, by simpa using K.val.add_mem h (representative L K i).property⟩,hxa⟩
  · exact Or.inl (all_zero_of_not_annihilates μ L K H a η ha)

end KDClosure.Hull
