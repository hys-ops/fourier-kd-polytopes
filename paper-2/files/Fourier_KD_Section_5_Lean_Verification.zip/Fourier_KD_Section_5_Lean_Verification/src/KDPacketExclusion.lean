import KDPacketRays
import KDTraceCompression
import Mathlib.Analysis.Normed.Module.FiniteDimension

noncomputable section
set_option linter.unusedSectionVars false
namespace KDClosure.Hull
open Classical Set MeasureTheory CompactCore LCAQuotient
open scoped Matrix.Norms.Elementwise ComplexOrder ComplexConjugate InnerProductSpace ENNReal

variable {D : Type*} [Fintype D]
variable {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℂ X] [CompleteSpace X]

def matrixTests (e : D → X) : (X →L[ℂ] X) →ₗ[ℝ] (Matrix D D ℂ) where
  toFun A := Matrix.of fun i j => inner ℂ (e i) (A (e j))
  map_add' A B := by ext i j; simp [inner_add_right]
  map_smul' r A := by ext i j; change inner ℂ _ (r • A _) = r • inner ℂ _ _; rw [←algebraMap_smul ℂ r,inner_smul_right,←algebraMap_smul ℂ r]; rfl

def realTrace : Matrix D D ℂ →L[ℝ] ℝ :=
  Complex.reCLM.comp (Matrix.traceLinearMap D ℝ ℂ).toContinuousLinearMap

def traceClosure (s : Set (X →L[ℂ] X)) : Set (X →L[ℂ] X) :=
  {T | ∀ ε : ℝ, 0 < ε → ∃ A ∈ s, traceVariational (A-T) < ENNReal.ofReal ε}

/-- Any trace-norm approximation also approximates *all* finite frame entries
simultaneously. Thus we can use the known topology of the finite matrix space. -/
theorem tests_map_traceClosure (e : D → X) (norm : ∀ i, ‖e i‖ = 1)
    {s : Set (X →L[ℂ] X)} {T : X →L[ℂ] X} (ht : T ∈ traceClosure s) :
    matrixTests e T ∈ closure (matrixTests e '' s) := by
  apply Metric.mem_closure_iff.mpr
  intro ε hε
  obtain ⟨A,ha,small⟩ := ht ε hε
  refine ⟨_,⟨A,ha,rfl⟩,?_⟩
  rw [dist_comm,dist_eq_norm,←map_sub,Matrix.norm_lt_iff hε]
  intro i j
  apply (ENNReal.ofReal_lt_ofReal_iff hε).mp
  rw [ofReal_norm]
  exact (unit_entry_le (A-T) (e j) (e i) (norm j) (norm i)).trans_lt small

variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
  [T2Space G] [MeasurableSpace G] [BorelSpace G] [MeasurableAdd G]
  (μ : Measure G) [μ.IsAddHaarMeasure]
local instance (L K : CO G) : Fintype (CoreQuot L K) := @Fintype.ofFinite _ (finite_core L K)
def frameVectors (L K : CO G) (i : CoreQuot L K) : Lp ℂ 2 μ :=
  sectionJ μ L K (lp.single 2 i 1)

/-- We deliberately allow *all* scalar multiples in the wavefunction: the
excluded closed hull is bigger than the normalized-packet hull. -/
def packetOperators : Set (Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ) :=
  {T | ∃ (H : CO G) (a : G) (η : AddChar G ℂ) (hc : Continuous η)
    (hu : ∀ t, ‖η t‖=1) (s : ℂ), T = InnerProductSpace.rankOne ℂ (ket μ H a η hc hu s) (ket μ H a η hc hu s)}

theorem matrixTests_packet (L K : CO G) (ψ : Lp ℂ 2 μ) :
    matrixTests (frameVectors μ L K) (InnerProductSpace.rankOne ℂ ψ ψ) =
    ketMatrix (fun i => (sectionJ μ L K).toContinuousLinearMap.adjoint ψ i) := by
  classical
  let J := (sectionJ μ L K).toContinuousLinearMap
  have coeff (i : CoreQuot L K) :
      inner ℂ (frameVectors μ L K i) ψ = J.adjoint ψ i := by
    change inner ℂ (J (lp.single 2 i 1)) ψ = _
    rw [← J.adjoint_inner_right]
    simp [lp.inner_single_left,RCLike.inner_apply]
  ext i j
  change inner ℂ (frameVectors μ L K i) (inner ℂ ψ (frameVectors μ L K j) • ψ) = _
  rw [inner_smul_right,← inner_conj_symm,coeff,coeff]
  change conj (J.adjoint ψ j) * (J.adjoint ψ i) = (J.adjoint ψ i) * conj (J.adjoint ψ j)
  exact mul_comm _ _

/-- Concrete manuscript separation. Any operator whose *actual* unit Haar
cell entries form a trace-one matrix outside the full finite pure hull cannot
be a trace-norm limit of mixtures of ambient coset-character projectors. No
cone, classification of finite pure states, or continuity result is assumed. -/
theorem finite_witness_excludes_packets (L K : CO G) (le : L ≤ K) (T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ)
    (trace_one : (matrixTests (frameVectors μ L K) T).trace=1)
    (outside : matrixTests (frameVectors μ L K) T ∉ convexHull ℝ (finitePure (CoreQuot L K))) :
    T ∉ traceClosure (convexHull ℝ (packetOperators μ)) := by
  classical
  let D := CoreQuot L K
  let e := frameVectors μ L K
  let B := convexHull ℝ (finitePackets D)
  have flip (x : Matrix D D ℂ) (hx : x∈finitePackets D) : realTrace x = 1 := by
    obtain ⟨⟨W,b,γ⟩,rfl⟩ := hx
    change (packetMatrix W b γ).trace.re = 1
    rw [packet_trace]; rfl
  have one : ∀ x ∈ B, realTrace x=1 := trace_on_convexHull _ flip
  have hc := rays_closed (realTrace (D:=D)) (finitePackets_finite.isCompact_convexHull ℝ) one
  have conv : Convex ℝ (rays B) := rays_convex (convex_convexHull _ _)
  have gens : matrixTests e '' packetOperators μ ⊆ rays B := by
    rintro _ ⟨_,⟨H,a,η,hcη,hu,s,rfl⟩,rfl⟩
    change matrixTests (frameVectors μ L K) _ ∈ _
    rw [matrixTests_packet]
    exact ambient_packet_to_finite_ray μ L K H le a η hcη hu s
  have sub : matrixTests e '' convexHull ℝ (packetOperators μ) ⊆ rays B := by
    have gen' : packetOperators μ ⊆ (matrixTests e) ⁻¹' rays B :=
      fun x hx => gens ⟨x,hx,rfl⟩
    have hs := convexHull_min gen' (conv.is_linear_preimage (matrixTests e).isLinear)
    rintro _ ⟨x,hx,rfl⟩
    exact hs hx
  intro near
  have n (i : D) : ‖e i‖ = 1 := by simp [e,frameVectors,lp.norm_single]
  have inCone := closure_minimal sub hc (tests_map_traceClosure e n near)
  have tr : realTrace (matrixTests e T) = 1 := congrArg Complex.re trace_one
  have inB := (trace_one_slice _ one tr).mp inCone
  exact outside ((convexHull_mono finitePackets_subset) inB)

/-- The operator whose finite coordinates are C in the orthonormal family e.
For Haar-cell vectors this is the exact operator JCJ*, not a model cone. -/
def finiteLift (e : D → X) (C : Matrix D D ℂ) : X →L[ℂ] X :=
  ∑ i, ∑ j, C i j • InnerProductSpace.rankOne ℂ (e i) (e j)

theorem tests_finiteLift (e : D → X) (he : Orthonormal ℂ e) (C : Matrix D D ℂ) :
    matrixTests e (finiteLift e C) = C := by
  classical
  ext i j
  change inner ℂ (e i) ((∑ a, ∑ b, C a b • InnerProductSpace.rankOne ℂ (e a) (e b)) (e j)) = C i j
  simp [inner_sum,inner_smul_right,orthonormal_iff_ite.mp he,
    InnerProductSpace.rankOne_apply]

theorem finite_witness_lift_excludes_packets (L K : CO G) (le : L ≤ K)
    (C : Matrix (CoreQuot L K) (CoreQuot L K) ℂ) (trace_one : C.trace=1)
    (outside : C ∉ convexHull ℝ (finitePure (CoreQuot L K))) :
    finiteLift (frameVectors μ L K) C ∉ traceClosure (convexHull ℝ (packetOperators μ)) := by
  have on : Orthonormal ℂ (frameVectors μ L K) := by
    change Orthonormal ℂ (fun i => sectionJ μ L K (lp.single 2 i (1:ℂ)))
    have onv := (atom_orthonormal μ L).comp (indexMap L K) (indexMap_inj L K)
    have eq : (fun i => sectionJ μ L K (lp.single 2 i (1:ℂ))) = atom μ L ∘ indexMap L K :=
      funext (sectionJ_single μ L K)
    rw [eq]; exact onv
  apply finite_witness_excludes_packets μ L K le
  · rwa [tests_finiteLift _ on]
  · rwa [tests_finiteLift _ on]
end KDClosure.Hull
