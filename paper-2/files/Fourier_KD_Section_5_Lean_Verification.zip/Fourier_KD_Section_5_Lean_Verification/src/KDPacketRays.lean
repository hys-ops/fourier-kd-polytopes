import KDPhysicalCompression
import KDFinitePacketSign
import KDClosedHullSeparation
import Mathlib.Analysis.Matrix.Normed
import Mathlib.Analysis.Matrix.Spectrum
import Mathlib.LinearAlgebra.Matrix.PosDef

noncomputable section
set_option linter.unusedSectionVars false
namespace KDClosure.Hull
open Classical Matrix Set
open scoped Matrix.Norms.Elementwise ComplexOrder ComplexConjugate BigOperators InnerProductSpace
variable {D : Type*} [AddCommGroup D] [Fintype D]

def ketMatrix (v : D → ℂ) : Matrix D D ℂ := Matrix.vecMulVec v (star v)
def packetVec (W : AddSubgroup D) (b : D) (γ : AddChar D ℂ) (x : D) : ℂ :=
  if x-b ∈ W then ((Real.sqrt (Fintype.card W):ℂ)⁻¹)*γ (x-b) else 0
def packetMatrix (W : AddSubgroup D) (b : D) (γ : AddChar D ℂ) :=
  ketMatrix (packetVec W b γ)
def finitePackets (D : Type*) [AddCommGroup D] [Fintype D] : Set (Matrix D D ℂ) :=
  Set.range (fun t : (AddSubgroup D) × D × (AddChar D ℂ) => packetMatrix t.1 t.2.1 t.2.2)

/-- Actual finite states in the ket convention, with literal matrix rank and
the unscaled physical KD sign (a fixed positive factor times the lower KD coefficient). -/
def finitePure (D : Type*) [AddCommGroup D] [Fintype D] [DecidableEq D] :
    Set (Matrix D D ℂ) := {A | A.PosSemidef ∧ A.trace=1 ∧ A.rank=1 ∧
      ∀ x (k : AddChar D ℂ), 0 ≤ ∑ y, A x y*k (y-x)}

theorem finitePackets_finite : (finitePackets D).Finite := Set.finite_range _

theorem packet_trace (W : AddSubgroup D) (b : D) (γ : AddChar D ℂ) :
    (packetMatrix W b γ).trace = 1 := by
  classical
  let d := Real.sqrt (Fintype.card W)
  have sq : (d:ℂ)^2=(Fintype.card W:ℂ) := by exact_mod_cast Real.sq_sqrt (Nat.cast_nonneg _)
  have eqn (i : D) : (packetMatrix W b γ) i i = if i-b∈W then ((d:ℂ)^2)⁻¹ else 0 := by
    change packetVec W b γ i * conj (packetVec W b γ i) = _
    rw [Complex.mul_conj]
    by_cases h : i-b ∈ W
    · rw [packetVec,if_pos h,if_pos h,Complex.normSq_mul,Complex.normSq_eq_norm_sq (γ _), AddChar.norm_apply]
      simp [d,Complex.normSq_eq_norm_sq, abs_of_nonneg (Real.sqrt_nonneg _)]
      exact sq.symm
    · simp [packetVec,h]
  change (∑ i, (packetMatrix W b γ) i i)=1
  simp_rw [eqn]
  have eis : (∑ h : W, ((d:ℂ)^2)⁻¹) = ∑ i : D, if i-b∈W then ((d:ℂ)^2)⁻¹ else 0 := by
    apply Fintype.sum_of_injective (fun h : W => b+h.val)
      (fun {s t} eq => Subtype.ext (add_left_cancel eq))
    · intro i hi
      have no : i-b ∉ W := fun h => hi ⟨⟨i-b,h⟩,by change b+(i-b)=i; abel⟩
      simp [no]
    · intro h; simp
  rw [←eis,sq]
  simp [Fintype.card_ne_zero]

theorem finitePackets_subset [DecidableEq D] : finitePackets D ⊆ finitePure D := by
  classical
  rintro A ⟨⟨W,b,γ⟩,rfl⟩
  let v := packetVec W b γ
  let A := packetMatrix W b γ
  have ps : A.PosSemidef := Matrix.posSemidef_vecMulVec_self_star v
  have tr : A.trace=1 := packet_trace _ _ _
  have le : A.rank≤1 := Matrix.rank_vecMulVec_le _ _
  have pos : 0 < A.rank := by
    have ne : ∃ j, ps.isHermitian.eigenvalues j ≠ 0 := by
      by_contra! hz
      rw [ps.isHermitian.trace_eq_sum_eigenvalues] at tr
      simp [hz] at tr
    obtain ⟨j,hj⟩ := ne
    have : Nonempty {i // ps.isHermitian.eigenvalues i ≠ 0} := ⟨⟨j,hj⟩⟩
    exact ps.isHermitian.rank_eq_card_non_zero_eigs ▸ Fintype.card_pos
  refine ⟨ps,tr,le_antisymm le (Nat.one_le_iff_ne_zero.mpr (ne_of_gt pos)),?_⟩
  intro x k
  let w : D → ℂ := fun i => conj (v i)
  have shape (i : D) : w i = if i-b∈W then ((Real.sqrt (Fintype.card W):ℂ)⁻¹)*(-γ) (i-b) else 0 := by
    by_cases h : i-b∈W
    · simp [w,v,packetVec,h]
      simpa only [neg_sub] using (AddChar.map_neg_eq_conj γ (i-b)).symm
    · simp [w,v,packetVec,h]
  simpa [rowOfVector,w,A,packetMatrix,ketMatrix,v,Matrix.vecMulVec] using 
    finite_packet_positive W b (-γ) _ w shape x k

theorem shaped_matrix_ray {v : D → ℂ} (W : AddSubgroup D) (b : D) (γ : AddChar D ℂ) (c : ℂ)
    (vs : ∀ i, v i = if i-b ∈ W then c*γ (i-b) else 0) :
    ketMatrix v ∈ rays (convexHull ℝ (finitePackets D)) := by
  classical
  let d := Real.sqrt (Fintype.card W)
  have hd : (d:ℂ) ≠ 0 := by exact_mod_cast (show d≠0 by dsimp [d]; positivity)
  let t := c*(d:ℂ)
  have fac (i : D) : v i = t * packetVec W b γ i := by
    rw [vs,packetVec]
    by_cases h : i-b∈W
    · rw [if_pos h,if_pos h]; dsimp [t]; change c * γ (i-b) = c*(d:ℂ)*((d:ℂ)⁻¹*γ (i-b)); field_simp
    · simp [h]
  refine ⟨Complex.normSq t, Complex.normSq_nonneg _, packetMatrix W b γ,
    subset_convexHull ℝ _ ⟨⟨W,b,γ⟩,rfl⟩,?_⟩
  ext i j
  change v i * conj (v j) = (Complex.normSq t) • (packetVec W b γ i * conj (packetVec W b γ j))
  rw [fac i,fac j,map_mul,Complex.real_smul,← Complex.mul_conj]
  ring

open MeasureTheory CompactCore LCAQuotient
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
  [T2Space G] [MeasurableSpace G] [BorelSpace G] [MeasurableAdd G]
  (μ : Measure G) [μ.IsAddHaarMeasure]
local instance (L K : CO G) : Fintype (CoreQuot L K) := @Fintype.ofFinite _ (finite_core L K)
theorem ambient_packet_to_finite_ray (L K H : CO G) (le : L ≤ K) (a : G)
    (η : AddChar G ℂ) (hc : Continuous η) (hu : ∀ t, ‖η t‖=1) (s : ℂ) :
    let v := (sectionJ μ L K).toContinuousLinearMap.adjoint (ket μ H a η hc hu s)
    ketMatrix (fun i => v i) ∈ rays (convexHull ℝ (finitePackets (CoreQuot L K))) := by
  classical
  dsimp only
  rcases adjoint_packet_shape μ L K H le a η hc hu s with hz|⟨b,γ,c,he⟩
  · rw [hz]
    exact shaped_matrix_ray ⊥ 0 0 0 (fun i => by simp)
  · exact shaped_matrix_ray (active L K H) b γ c he

end KDClosure.Hull
