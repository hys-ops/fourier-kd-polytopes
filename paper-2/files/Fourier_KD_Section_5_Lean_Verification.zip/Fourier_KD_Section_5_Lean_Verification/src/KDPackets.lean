import Mathlib.Analysis.InnerProductSpace.Orthonormal
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Positivity

namespace KDClosure
open scoped BigOperators
/-- The same reciprocal average produces both exact cross-channel kernel identities.
The ratio c is written without a nested square root. -/
theorem packetConstants {a r μ : ℝ} (ha : 0 < a) (ha1 : a < 1)
    (hr : r^2 < 1) (hμ : 0 < μ) :
    let b := Real.sqrt (1-a^2)
    let t := Real.sqrt (1-(a*r)^2)
    let κ := b/t
    let y := κ/μ
    let c := (1-a*r)/t
    let hp := μ*(1-a*r)/b^2
    let hm := μ*(1+a*r)/b^2
    0 < κ ∧ κ < 1 ∧ 0 < c ∧ b*y*hp = c ∧ b*y*hm*c = 1 ∧ b^2*y^2*hp*hm=1 := by
  dsimp only
  have aa : 0 < 1-a^2 := by nlinarith [mul_pos (sub_pos.mpr ha1) (show 0<1+a by linarith)]
  have gap : (a*r)^2 < a^2 := by nlinarith [mul_pos (sq_pos_of_pos ha) (sub_pos.mpr hr)]
  have tt : 0 < 1-(a*r)^2 := by linarith
  have bn := Real.sqrt_pos.mpr aa
  have tn := Real.sqrt_pos.mpr tt
  have small : Real.sqrt (1-a^2) < Real.sqrt (1-(a*r)^2) := Real.sqrt_lt_sqrt aa.le (by linarith)
  have low : 0<1-a*r := by nlinarith [sq_nonneg (a*r-1)]
  refine ⟨div_pos bn tn,(div_lt_one tn).mpr small, div_pos low tn, ?_, ?_, ?_⟩
  · field_simp
  · field_simp
    rw [← mul_pow, Real.sq_sqrt tt.le, div_eq_one_iff_eq (ne_of_gt tt)]; ring
  · field_simp
    rw [← mul_pow, Real.sq_sqrt tt.le, div_eq_one_iff_eq (ne_of_gt tt)]; ring

/-- A weighted old-child/fresh-child recurrence from the actual construction.
v j stores the mean reciprocal weight and f j is the fresh reciprocal weight. -/
noncomputable def reciprocalMean (θ : ℝ) (f : ℕ → ℝ) : ℕ → ℝ
  | 0 => f 0
  | j+1 => θ * reciprocalMean θ f j + (1-θ)*f (j+1)

theorem reciprocal_bounds (θ : ℝ) (f : ℕ → ℝ) (hθ : 0 ≤ θ) (hθ' : θ ≤ 1)
    (hf : ∀ j, 0 < f j) (mono : Monotone f) (j : ℕ) :
    0 < reciprocalMean θ f j ∧ reciprocalMean θ f j ≤ f j ∧
    (1-θ)*f j ≤ reciprocalMean θ f j := by
  induction j with
  | zero =>
    simp only [reciprocalMean]
    exact ⟨hf 0, le_rfl, by nlinarith [mul_nonneg hθ (hf 0).le]⟩
  | succ j ih =>
    simp only [reciprocalMean]
    have hu := ih.2.1.trans (mono (Nat.le_succ j))
    have low := mul_nonneg hθ ih.1.le
    refine ⟨?_,by nlinarith [mul_le_mul_of_nonneg_left hu hθ],by linarith⟩
    by_cases ht : θ=0
    · simp [ht,hf]
    · exact add_pos_of_pos_of_nonneg (mul_pos (lt_of_le_of_ne hθ (Ne.symm ht)) ih.1)
        (mul_nonneg (sub_nonneg.mpr hθ') (hf _).le)

/-- Positive margin for all layers, for the whole sequence rather than a test prefix. -/
theorem packet_margin (θ κ : ℝ) (f : ℕ → ℝ) (hθ : 0≤θ) (hθ' : θ≤1) (hk : κ < 1-θ)
    (hf : ∀ j, 0 < f j) (mono : Monotone f) (j : ℕ) :
    κ / reciprocalMean θ f j < 1 / f j := by
  obtain ⟨hp,_,hl⟩ := reciprocal_bounds θ f hθ hθ' hf mono j
  exact (div_lt_div_iff₀ hp (hf j)).mpr (by nlinarith [mul_lt_mul_of_pos_right hk (hf j)])

variable {ι E F : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E]
    [NormedAddCommGroup F] [InnerProductSpace ℂ F]
/-- Infinite, not just finite-dimensional: two orthonormal systems give a
nonnegative two-channel quadratic form for any coefficients of modulus at most one. -/
theorem packet_form_nonneg (e : ι → E) (f : ι → F) (he : Orthonormal ℂ e)
    (hf : Orthonormal ℂ f) (s : ι → ℂ) (hs : ∀ j, ‖s j‖ ≤ 1) (v : E) (w : F) :
    let term := fun j => s j * star (inner ℂ (e j) v) * inner ℂ (f j) w
    Summable term ∧ 0 ≤ ‖v‖^2 + ‖w‖^2 + 2*(∑' j, term j).re := by
  let X := fun j => ‖inner ℂ (e j) v‖^2
  let Y := fun j => ‖inner ℂ (f j) w‖^2
  let T := fun j => s j * star (inner ℂ (e j) v) * inner ℂ (f j) w
  have sx : Summable X := he.inner_products_summable v
  have sy : Summable Y := hf.inner_products_summable w
  have bound (j : ι) : ‖T j‖ ≤ (X j+Y j)/2 := by
    simp only [T,norm_mul,norm_star]
    have h := mul_le_mul_of_nonneg_right (hs j) (norm_nonneg (inner ℂ (e j) v))
    have h' := mul_le_mul_of_nonneg_right h (norm_nonneg (inner ℂ (f j) w))
    dsimp [X,Y]
    nlinarith [sq_nonneg (‖inner ℂ (e j) v‖ - ‖inner ℂ (f j) w‖)]
  have hb : Summable (fun j => (X j+Y j)/2) := (sx.add sy).div_const 2
  have hsn : Summable (fun j => ‖T j‖) := Summable.of_nonneg_of_le (fun j => norm_nonneg _) bound hb
  refine ⟨hsn.of_norm, ?_⟩
  have hsum := hsn.tsum_le_tsum bound hb
  rw [tsum_div_const, (sx.tsum_add sy)] at hsum
  have hx : ∑' j, X j ≤ ‖v‖^2 := he.tsum_inner_products_le v
  have hy : ∑' j, Y j ≤ ‖w‖^2 := hf.tsum_inner_products_le w
  have hab := norm_tsum_le_tsum_norm hsn
  have hre := Complex.abs_re_le_norm (∑' j, T j)
  change 0 ≤ ‖v‖^2 + ‖w‖^2 + 2*(∑' j, T j).re
  linarith [neg_abs_le (∑' j, T j).re]
end KDClosure
