import KDSymbolBridge
import KDCoordinateSlice

/-! Minimal source port of Finite_Fourier_KD_Lean_Audit (Lean 4.34.1 → 4.33.1).
The indicated declarations, including the proof of hermitian_period, are copied
from the cited source lines. Their original namespaces are kept for imports.
Only the framework declarations needed for this path are compiled here. -/
noncomputable section
set_option autoImplicit false
open Matrix Classical
open scoped BigOperators ComplexOrder
namespace KDOperator
-- KDAudit.lean:470
abbrev Op (P : Type*) := Matrix P P ℂ
end KDOperator
namespace KDFourier
open KDOperator
variable {G : Type*} [AddCommGroup G] [Fintype G]
-- KDAudit.lean:555
def symbol (A : Op G) (x : G) (χ : AddChar G ℂ) : ℂ := ∑ y, A x y * χ (y-x)
end KDFourier
namespace KDPure
open KDOperator KDFourier
variable {G : Type*} [AddCommGroup G] [Fintype G] [DecidableEq G] {I : Type*} [Fintype I]
-- KDPure.lean:16–18, 58, 67–73
structure Frame (G I : Type*) [AddCommGroup G] [Fintype G] [DecidableEq G] [Fintype I] where
  char : I → AddChar G ℂ
  orth : ∀ x, ∑ i, char i x = if x=0 then (Fintype.card G : ℂ) else 0
def amp (u : G → ℂ) (k : AddChar G ℂ) := ∑ y, u y * k y
theorem reconstruct (F : Frame G I) (u : G → ℂ) (x : G) :
    (∑ i, amp u (F.char i) * F.char i (-x)) = (Fintype.card G:ℂ) * u x := by
  classical
  simp only [amp,Finset.sum_mul]
  rw [Finset.sum_comm]
  simp_rw [mul_assoc, ← AddChar.map_add_eq_mul, ← Finset.mul_sum, F.orth]
  simp [← sub_eq_add_neg,sub_eq_zero,mul_ite,mul_comm]
end KDPure
namespace KDAtoms
-- Original KDAtoms.lean:6; preserve its section-variable signature.
set_option linter.unusedSectionVars false
open KDOperator KDFourier KDPure
variable {G I : Type*} [AddCommGroup G] [Fintype G] [DecidableEq G] [Fintype I]
-- KDAtoms.lean:14–23, 30–50
def row (A : Op G) (x d : G) := A x (x+d)
theorem row_amp (A : Op G) (x : G) (k : AddChar G ℂ) : amp (row A x) k=symbol A x k := by
  change (∑ d, A x (x+d)*k d)=_
  simpa [symbol] using Equiv.sum_comp (Equiv.addLeft x) (fun y => A x y*k (y-x))

theorem row_unique (F : Frame G I) {u v : G→ℂ}
    (h : ∀ i, amp u (F.char i)=amp v (F.char i)) : u=v := by
  funext x
  apply mul_left_cancel₀ (a:=(Fintype.card G : ℂ)) (Nat.cast_ne_zero.mpr Fintype.card_ne_zero)
  rw [← reconstruct F,← reconstruct F]; simp only [h]

theorem char_conj (k : AddChar G ℂ) (x : G) : star (k x)= k (-x) := by
  rw [AddChar.map_neg_eq_inv]; exact (Complex.inv_eq_conj (k.norm_apply x)).symm

theorem hermitian_period (F : Frame G I) {A : Op G} (her : A.IsHermitian)
    (kd : ∀ x k, 0 ≤ symbol A x k) (d : G) :
    ∀ x, row A (x+d) d=row A x d := by
  have hsym (x : G) : (fun d => star (row A x (-d)))=row A x := by
    apply row_unique F; intro j
    let k := F.char j
    have hstar : star (amp (row A x) k)=amp (row A x) k := by
      rw [row_amp]; exact IsSelfAdjoint.of_nonneg (kd _ _)
    rw [← hstar]; unfold amp
    calc
      _ = ∑ y, star (row A x y)*k (-y) := by
        simpa [k] using Equiv.sum_comp (Equiv.neg G) (fun y => star (row A x y)*k (-y))
      _ = _ := by simp [star_sum,star_mul,char_conj,mul_comm]
  intro x
  have h := congrFun (hsym (x+d)) d
  change star (A (x+d) ((x+d)+ -d))=A (x+d) ((x+d)+d) at h
  simp [row, ← h,her.apply]
end KDAtoms

namespace KDClosure
variable {m q : ℕ} [NeZero m] [Fact q.Prime]

private theorem negative_frequency_sum {n : ℕ} [NeZero n] (x : ZMod n) :
    ∑ i : ZMod n, ZMod.stdAddChar (-(x*i)) = if x=0 then (Fintype.card (ZMod n):ℂ) else 0 := by
  simpa [neg_mul, mul_comm] using AddChar.sum_mulShift (-x) (ZMod.isPrimitive_stdAddChar n)

/-- The exact negative-sign pair of DFT characters is an orthogonal frame
in the original source convention. -/
noncomputable def productDFTFrame :
    KDPure.Frame (ZMod m × ZMod q) (ZMod m × ZMod q) where
  char := frequency
  orth x := by
    obtain ⟨a,b⟩ := x
    simp only [Fintype.sum_prod_type]
    change (∑ i : ZMod m, ∑ j : ZMod q, ZMod.stdAddChar (-(a*i)) * ZMod.stdAddChar (-(b*j))) = _
    simp_rw [← Finset.mul_sum, ← Finset.sum_mul,negative_frequency_sum]
    by_cases ha : a=0 <;> by_cases hb : b=0 <;> simp [ha,hb,Prod.ext_iff,Fintype.card_prod]

/-- New product-table adapter for the original hermitian_period declaration. -/
theorem periodic_of_hermitian_nonnegative (F : Blocks m q) (her : (physical F).IsHermitian)
    (nonneg : ∀ x t k s, 0 ≤ table F x t k s) : Periodic F := by
  apply (period_matches_old_rows F).mpr
  exact KDAtoms.hermitian_period productDFTFrame her ((symbol_nonneg_iff F).mpr nonneg)

/-- The chart-period input follows for every member of cornerSlice directly. -/
theorem cornerSlice_periodic {D : Type*} {p : ℕ} [Fact p.Prime]
    (e : ∀ n : ℕ, Head p q n → D) {A : D×D → ℂ} (hA : A ∈ cornerSlice e) (n : ℕ) :
    Periodic (rowsOf (e n) A) := by
  apply periodic_of_hermitian_nonnegative
  · ext i j
    change star (A (e n (j.1,j.2),e n (j.1+(i.1-j.1),i.2))) =
      A (e n (i.1,i.2),e n (i.1+(j.1-i.1),j.2))
    simpa using hA.2.1 (e n j) (e n i)
  · intro x t k s
    exact Complex.nonneg_iff.mpr ⟨hA.2.2.2.2.1 n x t k s,(hA.2.2.2.2.2 n x t k s).symm⟩

end KDClosure
