import KDSparseBudget
import KDPhysicalLift

namespace KDClosure.PhysicalLift
open Matrix Frequency
open scoped BigOperators
variable {q : ℕ} [Fact q.Prime] {X : Type*} [Fintype X] [DecidableEq X]

omit [Fintype X] in
/-- The total diagonal on one transverse fibre is unaffected by every wavelet. -/
theorem actual_fiber (d : X → ℝ) (flag : X → Bool) (Y : Matrix X X ℂ) (x : X) :
    (∑ t, (actualMatrix (q:=q) d flag Y (x,t) (x,t)).re) =
      d x*(if flag x then 2 else 2*(q:ℝ)-2) := by
  obtain ⟨hU,hV,hI⟩ := transverse_traces (q:=q)
  have H : (∑ t, actualMatrix (q:=q) d flag Y (x,t) (x,t)) =
      (d x:ℂ)*(if flag x then 2 else 2*(q:ℂ)-2) := by
    simp only [actualMatrix,ite_true,Matrix.sub_apply,Finset.sum_add_distrib,
      ←Finset.mul_sum,Finset.sum_sub_distrib,hU,hV,sub_self,mul_zero,add_zero]
    congr 1
    by_cases hx : flag x = true <;> simp [baseBlock,hx,Matrix.add_apply,Matrix.sub_apply,
      Finset.sum_add_distrib,Finset.sum_sub_distrib,hU,hV,hI] <;> ring
  have h := congrArg Complex.re H
  cases hx : flag x <;> simpa [Complex.re_sum,Complex.re_ofReal_mul,hx] using h

theorem actual_trace_bound (d : X → ℝ) (hd : ∀ x, 0≤d x) (flag : X → Bool) (Y : Matrix X X ℂ) :
    (∑ i, (actualMatrix (q:=q) d flag Y i i).re) ≤ (2*q:ℝ)*(∑ x,d x) := by
  have hq : 1 ≤ (q:ℝ) := by exact_mod_cast (Fact.out : Nat.Prime q).one_lt.le
  rw [Fintype.sum_prod_type,Finset.mul_sum]
  refine Finset.sum_le_sum fun x _ => ?_
  rw [actual_fiber,mul_comm (2*(q:ℝ))]
  apply mul_le_mul_of_nonneg_left _ (hd x)
  split_ifs <;> linarith

theorem actual_unnormalized_budget {p L : ℕ} [Fact p.Prime] [NeZero L] (hL : 1<L)
    (n : ℕ) (l : ℕ) (hl : 0<l)
    (Y : Matrix (ZMod (levelSize p L n)) (ZMod (levelSize p L n)) ℂ) :
    let A := actualMatrix (q:=q) (originalWeight (p:=p) (L:=L) (fresh p L) n) (signFlag l n) Y
    (∑ i, (A i i).re) ≤ (2*q:ℝ)*((p:ℝ)+∑' j,shellMass p L j) ∧
    (∑ t, (A (0,t) (0,t)).re) = 2 := by
  dsimp only
  have hf := fresh_props (p:=p) (L:=L)
  have lim := uniform_levelMass (p:=p) hL n
  have ts : (∑ x, originalWeight (p:=p) (L:=L) (fresh p L) n x) = levelMass p L n := by
    rw [← Equiv.sum_comp (encodeLevel p L n)]
    simp [originalWeight,levelMass]
  have orig0 : ∀ n, originalWeight (p:=p) (L:=L) (fresh p L) n 0=1 ∧
      signFlag (p:=p) (L:=L) l n 0=true := by
    intro k
    have ev (i) : encodeLevel p L (i+1) (0,0,(encodeLevel p L i).symm 0)=0 := by
      apply (ZMod.val_injective _)
      simp only [old_head_image,Equiv.apply_symm_apply,ZMod.val_zero,mul_zero]
    induction k with
    | zero =>
      simp [originalWeight,signFlag,encodeLevel,weight,baseLabel,fresh]
      exact decide_eq_true (by change (0:ZMod p).val<l; simpa using hl)
    | succ i ih =>
      have e := (encodeLevel p L (i+1)).symm_apply_eq.mpr (ev i).symm
      simpa [originalWeight,signFlag,e,weight,extendWeight,baseLabel] using ih
  constructor
  · refine (actual_trace_bound _ (fun x => (inv_nonneg.mpr (weights_positive _ hf.1 hf.2 _ _).le)) _ _).trans ?_
    change (2*q:ℝ)*(∑ x, originalWeight (p:=p) (L:=L) (fresh p L) n x) ≤ _
    rw [ts]
    exact mul_le_mul_of_nonneg_left lim (by positivity)
  · simp only [actual_fiber,(orig0 n).1,(orig0 n).2,ite_true,one_mul]

end KDClosure.PhysicalLift
