import KDPacketCompression
import KDLCAQuotient

/-! The integral from KDPacketCompression is the coordinate of the Hilbert
adjoint of the normalized Haar-cell isometry on the actual L² spaces. -/
noncomputable section
set_option linter.unusedSectionVars false
namespace KDClosure.Hull
open MeasureTheory Set CompactCore CompactCoset LCAQuotient Classical
open scoped InnerProductSpace ENNReal
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
  [T2Space G] [MeasurableSpace G] [BorelSpace G] [MeasurableAdd G]

def indexMap (L K : CO G) (i : CoreQuot L K) : Q L := π L (representative L K i : G)

theorem indexMap_inj (L K : CO G) : Function.Injective (indexMap L K) := by
  intro i j h
  have hd : (representative L K i:G)-(representative L K j:G) ∈ L.val :=
    QuotientAddGroup.eq_iff_sub_mem.mp h
  have he : proj L K (representative L K i) = proj L K (representative L K j) :=
    QuotientAddGroup.eq_iff_sub_mem.mpr hd
  exact (representative_spec L K i).symm.trans (he.trans (representative_spec L K j))

variable (μ : Measure G) [μ.IsAddHaarMeasure]

/-- The manuscript's J, specified by the same normalized indicator vectors. -/
def sectionJ (L K : CO G) :
    lp (fun _ : CoreQuot L K => ℂ) 2 →ₗᵢ[ℂ] Lp ℂ 2 μ :=
  ((atom_orthonormal μ L).comp (indexMap L K) (indexMap_inj L K)).orthogonalFamily.linearIsometry

theorem sectionJ_single (L K : CO G) (i : CoreQuot L K) :
    sectionJ μ L K (lp.single 2 i 1) = atom μ L (indexMap L K i) := by
  calc
    _ = (1:ℂ) • atom μ L (indexMap L K i) :=
      ((atom_orthonormal μ L).comp (indexMap L K) (indexMap_inj L K)).orthogonalFamily.linearIsometry_apply_single (i:=i) (1:ℂ)
    _ = _ := one_smul _ _

private theorem packet_mem (H : CO G) (a : G) (η : AddChar G ℂ)
    (hc : Continuous η) (hu : ∀ t, ‖η t‖ = 1) :
    MemLp ((coset H a).indicator η) 2 μ := by
  let m := coset_meas H a
  have g := memLp_indicator_const (μ:=μ) (2:ℝ≥0∞) m (1:ℝ) (Or.inr (coset_compact H a).measure_ne_top)
  apply g.mono' (hc.measurable.indicator m).aestronglyMeasurable
  exact .of_forall fun x => by by_cases h : x ∈ coset H a <;> simp [h,hu]

def ket (H : CO G) (a : G) (η : AddChar G ℂ)
    (hc : Continuous η) (hu : ∀ t, ‖η t‖ = 1) (s : ℂ) : Lp ℂ 2 μ :=
  s • (packet_mem μ H a η hc hu).toLp _

/-- Includes *both* the ambient packet coefficient and the Haar normalization
of J. No operator topology is substituted for the trace norm here. -/
theorem sectionJ_adjoint_coeff (L K H : CO G) (a : G) (η : AddChar G ℂ)
    (hc : Continuous η) (hu : ∀ t, ‖η t‖ = 1) (s : ℂ) (i : CoreQuot L K) :
    (sectionJ μ L K).toContinuousLinearMap.adjoint (ket μ H a η hc hu s) i =
      (scale μ L : ℂ) * s * coeff μ L K H a η i := by
  let J := (sectionJ μ L K).toContinuousLinearMap
  let p := (packet_mem μ H a η hc hu).toLp _
  let d := lp.single (E:=fun _ : CoreQuot L K => ℂ) 2 i (1:ℂ)
  let r := (representative L K i : G)
  let q := indexMap L K i
  have fibe : fiber L q = coset L r := fiber_coset L _
  have evalu : ∫ x in fiber L q, p x ∂μ = coeff μ L K H a η i := by
    rw [fibe]
    calc
      _ = ∫ x in coset L r, (coset H a).indicator η x ∂μ :=
        integral_congr_ae (ae_restrict_of_ae (packet_mem μ H a η hc hu).coeFn_toLp)
      _ = _ := setIntegral_indicator (coset_meas H a)
  have he : J d = atom μ L q := sectionJ_single μ L K i
  change (J.adjoint (s • p)) i = _
  calc
    _ = inner ℂ d (J.adjoint (s • p)) := by simp [d,lp.inner_single_left,RCLike.inner_apply]
    _ = inner ℂ (J d) (s • p) := J.adjoint_inner_right d _
    _ = s * inner ℂ (atom μ L q) p := by rw [he,inner_smul_right]
    _ = _ := by
      rw [atom, L2.inner_indicatorConstLp_eq_inner_setIntegral,evalu]
      simp only [RCLike.inner_apply,Complex.conj_ofReal]
      ring

/-- Exact shape of J*ψ for any actual ambient subgroup-coset wavefunction. -/
theorem adjoint_packet_shape (L K H : CO G) (le : L ≤ K)
    (a : G) (η : AddChar G ℂ) (hc : Continuous η) (hu : ∀ t, ‖η t‖ = 1) (s : ℂ) :
    let v := (sectionJ μ L K).toContinuousLinearMap.adjoint (ket μ H a η hc hu s)
    v = 0 ∨ ∃ (b : CoreQuot L K) (γ : AddChar (CoreQuot L K) ℂ) (c : ℂ),
      ∀ i, v i = if i-b ∈ active L K H then c * γ (i-b) else 0 := by
  dsimp only
  rcases compressed_packet μ L K H le a η hu with hz | ⟨b,γ,c,hs⟩
  · left; ext i; simp [sectionJ_adjoint_coeff,hz]
  · right; refine ⟨b,γ,(scale μ L : ℂ)*s*c,fun i => ?_⟩
    rw [sectionJ_adjoint_coeff, hs]
    split_ifs <;> ring

theorem compression_rankOne {X Y : Type*} [NormedAddCommGroup X] [InnerProductSpace ℂ X]
    [NormedAddCommGroup Y] [InnerProductSpace ℂ Y] [CompleteSpace X] [CompleteSpace Y]
    (J : X →L[ℂ] Y) (ψ : Y) :
    J.adjoint ∘L (InnerProductSpace.rankOne ℂ ψ ψ) ∘L J =
      InnerProductSpace.rankOne ℂ (J.adjoint ψ) (J.adjoint ψ) := by
  ext x
  simp only [ContinuousLinearMap.comp_apply, InnerProductSpace.rankOne_apply,map_smul]
  rw [J.adjoint_inner_left]

end KDClosure.Hull
