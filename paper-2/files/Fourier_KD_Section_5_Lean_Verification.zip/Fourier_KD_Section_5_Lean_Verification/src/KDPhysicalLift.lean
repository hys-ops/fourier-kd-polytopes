import KDTransverse
import KDPhysicalPackets

namespace KDClosure
namespace PhysicalLift

open Matrix Frequency
open scoped BigOperators ComplexOrder Kronecker
variable {q : ℕ} [Fact q.Prime]

noncomputable def a (q : ℕ) := invroot (q:ℝ)
noncomputable def b (q : ℕ) := Real.sqrt (1-(a q)^2)
noncomputable def c (z : ℝ) := invroot (2*(1+z))
noncomputable def e (q : ℕ) [NeZero q] (z : ℝ) (t : ZMod q) : ℂ :=
  (c z:ℂ)*channel q (z:ℂ) t

theorem a_properties : 0 < a q ∧ a q < 1 ∧ (q:ℝ)*(a q)^2=1 := by
  have hq : 1<(q:ℝ) := by exact_mod_cast (Fact.out : q.Prime).one_lt
  refine ⟨inv_pos.mpr (Real.sqrt_pos.mpr (by linarith)), ?_, ?_⟩
  · exact inv_lt_one_of_one_lt₀ (by simpa using Real.sqrt_lt_sqrt zero_le_one hq)
  · rw [a,invroot_sq (by linarith),mul_inv_cancel₀ (by linarith)]

theorem constants :
    (1+a q)*(c (a q))^2=1/2 ∧ (1-a q)*(c (-a q))^2=1/2 ∧
    b q*c (a q)*c (-a q)=1/2 := by
  obtain ⟨ha,ha1,_⟩ := a_properties (q:=q)
  have p : 0 < 1+a q := by linarith
  have m : 0 < 1-a q := by linarith
  have cp : c (a q)^2=(2*(1+a q))⁻¹ := invroot_sq (by positivity)
  have cm : c (-a q)^2=(2*(1-a q))⁻¹ := by
    simpa only [c, ← sub_eq_add_neg] using (invroot_sq (t:=2*(1+-a q)) (by linarith))
  have cb : 0≤1-(a q)^2 := by nlinarith [mul_pos p m]
  refine ⟨?_, ?_, ?_⟩
  · rw [cp]; field_simp
  · rw [cm]; field_simp
  · apply (sq_eq_sq₀ ?_ (by norm_num)).mp
    · rw [mul_pow,mul_pow,cp,cm, b,Real.sq_sqrt cb]
      field_simp; ring
    · exact mul_nonneg (mul_nonneg (Real.sqrt_nonneg _) (inv_nonneg.mpr (Real.sqrt_nonneg _)))
        (inv_nonneg.mpr (Real.sqrt_nonneg _))

noncomputable def outer (v w : ZMod q → ℂ) : Matrix (ZMod q) (ZMod q) ℂ := vecMulVec v (star w)

theorem e_star (z : ℝ) (t : ZMod q) : star (e q z t) = e q z t := by
  by_cases ht : t=0 <;> simp [e, channel,ht]

private theorem dprod (s z : ℝ) : star (e q s) ⬝ᵥ e q z =
    (c s*c z*(1+s+z+(q:ℝ)*s*z):ℝ) := by
  have h (t : ZMod q) : star (e q s t) * e q z t =
      (if t=0 then ((c s*c z*(1+s+z):ℝ):ℂ) else 0)+((c s*c z*s*z:ℝ):ℂ) := by
    rw [e_star]
    by_cases ht : t=0 <;> simp [e,channel,ht] <;> ring
  change ∑ t, star (e q s t)*e q z t = _
  simp_rw [h,Finset.sum_add_distrib]
  simp [nsmul_eq_mul]; ring

theorem frame_gram :
    star (e q (a q)) ⬝ᵥ e q (a q)=1 ∧ star (e q (-a q)) ⬝ᵥ e q (-a q)=1 ∧
    star (e q (a q)) ⬝ᵥ e q (-a q)=0 ∧ star (e q (-a q)) ⬝ᵥ e q (a q)=0 := by
  obtain ⟨_,_,hq⟩ := a_properties (q:=q)
  obtain ⟨hp,hm,_⟩ := constants (q:=q)
  simp only [dprod]
  norm_cast
  constructor
  · linear_combination 2*hp + (c (a q))^2*hq
  constructor
  · linear_combination 2*hm + (c (-a q))^2*hq
  constructor <;> linear_combination -(c (a q)*c (-a q))*hq

/-- The transverse factors, in the original q coordinates. -/
theorem transverse_expansion :
    U q + V q = (1+(a q:ℂ)) • outer (e q (a q)) (e q (a q)) +
       (1-(a q:ℂ)) • outer (e q (-a q)) (e q (-a q)) ∧
    U q - V q = (b q:ℂ) • (outer (e q (a q)) (e q (-a q)) +
                                  outer (e q (-a q)) (e q (a q))) := by
  obtain ⟨_,_,hq⟩ := a_properties (q:=q)
  obtain ⟨hp,hm,ho⟩ := constants (q:=q)
  have hi : (q:ℂ)⁻¹ = (a q:ℂ)^2 := by
    have h : (q:ℂ)*(a q:ℂ)^2=1 := by exact_mod_cast hq
    exact inv_eq_of_mul_eq_one_right h
  have hp' : (1+(a q:ℂ))*(c (a q):ℂ)^2=1/2 := by simpa using congrArg Complex.ofReal hp
  have hm' : (1-(a q:ℂ))*(c (-a q):ℂ)^2=1/2 := by simpa using congrArg Complex.ofReal hm
  have ho' : (b q:ℂ)*(c (a q):ℂ)*(c (-a q):ℂ)=1/2 := by simpa using congrArg Complex.ofReal ho
  let δ (t : ZMod q) : ℂ := if t=0 then 1 else 0
  have uform (t u : ZMod q) : U q t u = δ t*δ u := by
    by_cases ht : t=0 <;> by_cases hu : u=0 <;> simp [δ,U,ht,hu]
  have outerform (s z : ℝ) (t u : ZMod q) :
      outer (e q s) (e q z) t u = ((c s:ℂ)*(δ t+s))*((c z:ℂ)*(δ u+z)) := by
    change e q s t * star (e q z u) = _
    rw [e_star]; rfl
  constructor <;> ext t u
  · simp only [Matrix.add_apply,Matrix.smul_apply,smul_eq_mul,outerform,uform,V,hi,Complex.ofReal_neg]
    linear_combination -(δ t+(a q:ℂ))*(δ u+(a q:ℂ))*hp' - (δ t-(a q:ℂ))*(δ u-(a q:ℂ))*hm'
  · simp only [Matrix.sub_apply,Matrix.add_apply,Matrix.smul_apply,smul_eq_mul,outerform,uform,V,hi,Complex.ofReal_neg]
    linear_combination -((δ t+(a q:ℂ))*(δ u-(a q:ℂ))+(δ t-(a q:ℂ))*(δ u+(a q:ℂ)))*ho'

noncomputable def frame (q : ℕ) [NeZero q] : Matrix (ZMod q) Bool ℂ :=
  fun t j => e q (if j then a q else -a q) t

theorem frame_isometry : (frame q)ᴴ * frame q = 1 := by
  obtain ⟨hp,hm,hpm,hmp⟩ := frame_gram (q:=q)
  ext i j
  cases i <;> cases j <;>
    first | exact hm | exact hmp | exact hpm | exact hp

noncomputable def complement (q : ℕ) [NeZero q] :=
  1-(frame q)*(frame q)ᴴ

theorem complement_psd : (complement q).PosSemidef := by
  let P := frame q*(frame q)ᴴ
  have hs : Pᴴ=P := by simp [P]
  have hi : P*P=P := by
    dsimp only [P]
    rw [Matrix.mul_assoc, ←Matrix.mul_assoc (frame q)ᴴ,frame_isometry,Matrix.one_mul]
  have G := (PosSemidef.one (n:=ZMod q) (R:=ℂ)).conjTranspose_mul_mul_same (1-P)
  simpa [complement,P,conjTranspose_sub,hs,Matrix.sub_mul,Matrix.mul_sub,hi] using G

theorem complement_zero : complement q * frame q = 0 := by
  rw [complement,Matrix.sub_mul,Matrix.one_mul,Matrix.mul_assoc,frame_isometry,Matrix.mul_one,sub_self]

theorem complement_entry (t u : ZMod q) :
    complement q t u = (if t=u then 1 else 0) -
      outer (e q (a q)) (e q (a q)) t u - outer (e q (-a q)) (e q (-a q)) t u := by
  simp only [complement,Matrix.sub_apply,Matrix.one_apply,Matrix.mul_apply,
    Fintype.sum_bool,Matrix.conjTranspose_apply,frame,Bool.false_eq_true,if_false,if_true,
    outer,vecMulVec_apply,Pi.star_apply]
  ring

section Fiber
variable {X : Type*} [Fintype X] [DecidableEq X]

noncomputable def mount (v : ZMod q → ℂ) : Matrix (X×ZMod q) X ℂ :=
  fun it j => if it.1=j then v it.2 else 0

omit [Fact q.Prime] in
private theorem mount_left {J : Type*} (v : ZMod q → ℂ) (A : Matrix X J ℂ)
    (x : X×ZMod q) (j : J) : (mount (X:=X) v*A) x j = v x.2*A x.1 j := by
  simp [Matrix.mul_apply,mount,ite_mul]

omit [Fact q.Prime] in
private theorem mount_adj_right {J : Type*} (v : ZMod q → ℂ) (A : Matrix J X ℂ)
    (x : X×ZMod q) (j : J) : (A*(mount (X:=X) v)ᴴ) j x = A j x.1*star (v x.2) := by
  simp [Matrix.mul_apply,Matrix.conjTranspose_apply,mount,apply_ite]

private theorem mount_inner (v w : ZMod q → ℂ) :
    (mount (X:=X) v)ᴴ * mount w = (star v ⬝ᵥ w) • (1 : Matrix X X ℂ) := by
  ext i j
  rw [Matrix.mul_apply,Fintype.sum_prod_type]
  by_cases h : i=j
  · subst j
    simp [mount,Matrix.conjTranspose_apply,ite_mul,apply_ite,dotProduct,Finset.sum_ite_irrel]
  · simp [mount,Matrix.conjTranspose_apply,ite_mul,apply_ite,Finset.sum_ite_irrel,h,Ne.symm h]

noncomputable def embedding (q : ℕ) [NeZero q] : Matrix (X×ZMod q) (X⊕X) ℂ :=
  fromCols (mount (e q (a q))) (mount (e q (-a q)))

theorem embedding_gram : (embedding (X:=X) q)ᴴ * embedding (X:=X) q = 1 := by
  obtain ⟨hp,hm,hpm,hmp⟩ := frame_gram (q:=q)
  rw [embedding,conjTranspose_fromCols_eq_fromRows_conjTranspose,fromRows_mul_fromCols]
  simp [mount_inner,hp,hm,hpm,hmp,fromBlocks_one]

private theorem lift_complement_mounted (d : X → ℂ) (j : Bool) :
    (diagonal d ⊗ₖ complement q) * mount (X:=X) (fun t => frame q t j) = 0 := by
  ext ⟨x,t⟩ k
  rw [Matrix.mul_apply,Fintype.sum_prod_type]
  apply Finset.sum_eq_zero
  intro y _
  change (∑ s, (diagonal d x y * complement q t s) *
     (if y=k then frame q s j else 0))=0
  by_cases he : y=k
  · simp only [if_pos he,mul_assoc,←Finset.mul_sum]
    change _ * (complement q * frame q) t j = 0
    rw [complement_zero,Matrix.zero_apply,mul_zero]
  · simp [he]

theorem complement_kills_embedding (d : X → ℂ) :
    (diagonal d ⊗ₖ complement q) * embedding (X:=X) q = 0 := by
  rw [embedding,mul_fromCols]
  have hp := lift_complement_mounted (q:=q) d true
  have hm := lift_complement_mounted (q:=q) d false
  simp only [frame,if_true,Bool.false_eq_true,if_false] at hp hm
  rw [hp,hm]; ext i (k|k) <;> rfl


noncomputable def channelMatrix (d : X → ℝ) (flag : X → Bool) (Y : Matrix X X ℂ) :
    Matrix (X⊕X) (X⊕X) ℂ :=
  fromBlocks (diagonal fun x => (d x:ℂ)*(if flag x then 1+(a q:ℂ) else 1-(a q:ℂ)))
    ((b q:ℂ) • Y) ((b q:ℂ) • Y)
    (diagonal fun x => (d x:ℂ)*(if flag x then 1-(a q:ℂ) else 1+(a q:ℂ)))

noncomputable def actualMatrix (d : X → ℝ) (flag : X → Bool) (Y : Matrix X X ℂ) :
    Matrix (X×ZMod q) (X×ZMod q) ℂ :=
  fun xt yu => (if xt.1=yu.1 then (d xt.1:ℂ)*baseBlock q (flag xt.1=true) xt.2 yu.2 else 0)
    + Y xt.1 yu.1*(U q-V q) xt.2 yu.2

noncomputable def rest (d : X → ℝ) (flag : X → Bool) (x : X) : ℂ :=
  if flag x then 0 else 2*(d x:ℂ)

private theorem entry_congruence (P Q R S : Matrix X X ℂ) (x y : X) (t u : ZMod q) :
    (embedding (X:=X) q * fromBlocks P Q R S * (embedding (X:=X) q)ᴴ) (x,t) (y,u) =
    P x y * outer (e q (a q)) (e q (a q)) t u +
    Q x y * outer (e q (a q)) (e q (-a q)) t u +
    R x y * outer (e q (-a q)) (e q (a q)) t u +
    S x y * outer (e q (-a q)) (e q (-a q)) t u := by
  simp only [embedding,fromCols_mul_fromBlocks,conjTranspose_fromCols_eq_fromRows_conjTranspose,
    fromCols_mul_fromRows,Matrix.add_apply,mount_adj_right,mount_left,outer,vecMulVec_apply,
    Pi.star_apply,Matrix.add_apply]
  ring

theorem exact_decomposition (d : X → ℝ) (flag : X → Bool) (Y : Matrix X X ℂ) :
    actualMatrix (q:=q) d flag Y =
      embedding (X:=X) q * channelMatrix (q:=q) d flag Y * (embedding (X:=X) q)ᴴ
      + (diagonal (rest d flag) ⊗ₖ complement q) := by
  obtain ⟨plus,minus⟩ := transverse_expansion (q:=q)
  have ep (t u : ZMod q) := congrFun (congrFun plus t) u
  have em (t u : ZMod q) := congrFun (congrFun minus t) u
  simp only [Matrix.add_apply,Matrix.smul_apply,smul_eq_mul] at ep em
  have en (t u : ZMod q) : (ident q + ident q - U q - V q) t u =
      2*(if t=u then 1 else 0) -
       ((1+(a q:ℂ))*outer (e q (a q)) (e q (a q)) t u +
        (1-(a q:ℂ))*outer (e q (-a q)) (e q (-a q)) t u) := by
    rw [←ep]
    by_cases h : t=u <;> simp [ident,h] <;> ring
  ext ⟨x,t⟩ ⟨y,u⟩
  simp only [Matrix.add_apply,actualMatrix,channelMatrix,entry_congruence,
    kronecker_apply,diagonal_apply,Matrix.smul_apply,smul_eq_mul,em,complement_entry,rest]
  by_cases he : x=y
  · subst y
    cases hs : flag x <;> simp only [if_true,Bool.false_eq_true,if_false,baseBlock,en,ep,
      Matrix.add_apply] <;> ring
  · simp [he]; ring

/-- The paper matrix on the original product coordinates inherits PSD and
all exact null columns. The two-channel assumption can be supplied by the
finite cyclic packet certificate. No hypothesis concerns the complement. -/
theorem physicalLift {J : Type*} (d : X → ℝ) (hd : ∀ x, 0≤d x)
    (flag : X → Bool) (Y : Matrix X X ℂ) (K : Matrix (X⊕X) J ℂ)
    (ps : (channelMatrix (q:=q) d flag Y).PosSemidef)
    (hz : channelMatrix (q:=q) d flag Y*K=0) :
    (actualMatrix (q:=q) d flag Y).PosSemidef ∧
    actualMatrix (q:=q) d flag Y * (embedding (X:=X) q * K)=0 := by
  have hp : (diagonal (rest d flag)).PosSemidef := by
    apply PosSemidef.diagonal
    intro x
    by_cases h : flag x=true
    · simp [rest,h]
    · simpa [rest,h] using mul_nonneg (show (0:ℂ)≤2 by norm_num) (show 0≤(d x:ℂ) by exact_mod_cast hd x)
  rw [exact_decomposition]
  constructor
  · exact (ps.mul_mul_conjTranspose_same _).add (hp.kronecker complement_psd)
  · rw [Matrix.add_mul,←Matrix.mul_assoc _ (embedding (X:=X) q) K,
      ←Matrix.mul_assoc _ (embedding (X:=X) q) K,complement_kills_embedding,
      Matrix.zero_mul,add_zero,Matrix.mul_assoc _ (embedding (X:=X) q)ᴴ,
      embedding_gram,Matrix.mul_one,Matrix.mul_assoc,hz,Matrix.mul_zero]

end Fiber

section Cyclic
variable {p L : ℕ} [NeZero p] [NeZero L]

noncomputable def signFlag (l n : ℕ) (x : ZMod (levelSize p L n)) : Bool :=
  decide ((baseLabel p L n ((encodeLevel p L n).symm x)).val<l)

noncomputable def originalWeight (f : ℕ → ℝ) (n : ℕ) (x : ZMod (levelSize p L n)) : ℝ :=
  (weight p L f n ((encodeLevel p L n).symm x))⁻¹

noncomputable def channelRoot (f : ℕ → ℝ) (z : ℝ) (l n : ℕ) (x : ZMod (levelSize p L n)) : ℝ :=
  invroot (cyclicRealDensity f (paperChannelStat z l) n x)

noncomputable def columnScale (f : ℕ → ℝ) (z : ℝ) (l : ℕ) (j : ℕ) : ℂ :=
  invroot (cyclicMass (p:=p) (L:=L) f (paperChannelStat z l) j)

noncomputable def signedScale (f : ℕ → ℝ) (z : ℝ) (l n : ℕ) (ε : Fin n → Bool) (j : Fin n) : ℂ :=
  if ε j then columnScale (p:=p) (L:=L) f z l j.val else -columnScale (p:=p) (L:=L) f z l j.val

noncomputable def wave (χ : ℕ → AddChar (ZMod p) ℂ) (n : ℕ) :
    Matrix (ZMod (levelSize p L n)) (Fin n) ℂ := fun x j => cyclicPacket χ j.val n x

noncomputable def perturbation (q : ℕ) (χ : ℕ → AddChar (ZMod p) ℂ) (f : ℕ → ℝ)
    (l n : ℕ) (ε : Fin n → Bool) : Matrix (ZMod (levelSize p L n)) (ZMod (levelSize p L n)) ℂ :=
  (b q:ℂ)⁻¹ • outerPacketSum (wave χ n) (fun j => columnScale (p:=p) (L:=L) f (a q) l j.val)
    (signedScale (p:=p) (L:=L) f (-a q) l n ε)

noncomputable def channelNull (q : ℕ) (χ : ℕ → AddChar (ZMod p) ℂ) (f : ℕ → ℝ)
    (l n : ℕ) (ε : Fin n → Bool) :
    Matrix (ZMod (levelSize p L n) ⊕ ZMod (levelSize p L n)) (Fin n) ℂ :=
  fromRows (physicalNull (channelRoot f (a q) l n) (wave χ n)
    (fun j => columnScale (p:=p) (L:=L) f (a q) l j.val))
    (-(physicalNull (channelRoot f (-a q) l n) (wave χ n) (signedScale (p:=p) (L:=L) f (-a q) l n ε)))

private theorem root_square (f : ℕ → ℝ) (hf : ∀ i, 0<f i) (hm : Monotone f)
    (z : ℝ) (h1 : -1<z) (h2 : z<1) (l n : ℕ) (x : ZMod (levelSize p L n)) :
    (channelRoot f z l n x)^2 =
      originalWeight f n x * (if signFlag l n x then 1+z else 1-z) := by
  have hp : 0 < cyclicRealDensity f (paperChannelStat z l) n x :=
    mul_pos (paperChannelStat_pos h1 h2 _ _) (weights_positive f hf hm _ _)
  rw [channelRoot, invroot_sq hp.le,cyclicRealDensity,_root_.mul_inv_rev,paperChannelStat,inv_inv]
  by_cases h : (baseLabel p L n ((encodeLevel p L n).symm x)).val<l <;>
    simp [signFlag,signLabel,originalWeight,h,sub_eq_add_neg]

private theorem selfadj_outer {X J : Type*} [Fintype J] (ψ : Matrix X J ℂ)
    (h k : J → ℂ) (hh : ∀ j, star (h j)=h j) (hk : ∀ j, star (k j)=k j) :
    (outerPacketSum ψ h k)ᴴ = outerPacketSum ψ h k := by
  ext x y
  change star (∑ j, _) = ∑ j, _
  simp only [star_sum,star_mul,star_star,hh,hk]
  apply Finset.sum_congr rfl
  intro j _
  ring

/-- The candidate on the full original product Hilbert space, for arbitrary
finite cutoff, positive monotone weight schedule and packet signs. All n
embedded packet columns are sent to zero; PSD, orthogonality and kernel
equations are conclusions. -/
theorem finiteOriginalPSD (χ : ℕ → AddChar (ZMod p) ℂ) (hn : ∀ j, χ j≠1)
    (f : ℕ → ℝ) (hf : ∀ i, 0<f i) (hm : Monotone f) (l n : ℕ) (ε : Fin n → Bool) :
    let A := actualMatrix (q:=q) (originalWeight (p:=p) (L:=L) f n) (signFlag l n)
                  (perturbation q χ f l n ε)
    A.PosSemidef ∧ A*(embedding (X:=ZMod (levelSize p L n)) q*channelNull (L:=L) q χ f l n ε)=0 := by
  dsimp only
  obtain ⟨ha,ha1,_⟩ := a_properties (q:=q)
  let d := originalWeight (p:=p) (L:=L) f n
  let fl := signFlag (p:=p) (L:=L) l n
  let Y := perturbation (L:=L) q χ f l n ε
  let K := channelNull (L:=L) q χ f l n ε
  let h : Fin n → ℂ := fun j => columnScale (p:=p) (L:=L) f (a q) l j.val
  let k := signedScale (p:=p) (L:=L) f (-a q) l n ε
  let P := outerPacketSum (wave (L:=L) χ n) h k
  have hs : Pᴴ=P := by
    apply selfadj_outer
    · intro j; exact Complex.conj_ofReal _
    · intro j; dsimp only [k,signedScale]; split_ifs <;> simp [columnScale]
  have hd (x) : 0≤d x := (inv_pos.mpr (weights_positive f hf hm n _)).le
  have hB : 0<b q := Real.sqrt_pos.mpr (by nlinarith [mul_pos (sub_pos.mpr ha1) (show 0<1+a q by linarith)])
  have hb : (b q:ℂ)≠0 := Complex.ofReal_ne_zero.mpr hB.ne'
  have normY : (b q:ℂ) • Y = P := by
    simp only [Y,perturbation,smul_smul,mul_inv_cancel₀ hb,one_smul]; rfl
  have diag (z : ℝ) (lo : -1<z) (hi : z<1) :
      diagonal (fun x => ((channelRoot (p:=p) (L:=L) f z l n x:ℝ):ℂ)^2) =
      diagonal (fun x => (d x:ℂ)*(if fl x then 1+(z:ℂ) else 1-(z:ℂ))) := by
    congr 1; funext x
    rw [←Complex.ofReal_pow,root_square f hf hm z lo hi]
    by_cases hh : fl x=true <;> simp [fl,d] at hh ⊢ <;> simp_all
  have eqB : channelMatrix (q:=q) d fl Y =
      fromBlocks (diagonal fun x => ((channelRoot (p:=p) (L:=L) f (a q) l n x:ℝ):ℂ)^2)
        P Pᴴ (diagonal fun x => ((channelRoot (p:=p) (L:=L) f (-a q) l n x:ℝ):ℂ)^2) := by
    rw [channelMatrix,normY,hs,diag (a q) (by linarith) ha1,diag (-a q) (by linarith) (by linarith)]
    simp only [Complex.ofReal_neg,←sub_eq_add_neg,sub_neg_eq_add]
  have H := finiteCyclicSaturated (L:=L) χ hn f hf hm (paperChannelStat (a q) l)
      (paperChannelStat (-a q) l) (paperChannelStat_pos (by linarith) ha1 l)
      (paperChannelStat_pos (by linarith) (by linarith) l) n ε
  apply physicalLift d hd fl Y K
  · rw [eqB]; exact H.1
  · rw [eqB]; exact H.2

end Cyclic

end PhysicalLift
end KDClosure
