import KDWaveMoments
import Mathlib.Analysis.Matrix.Order
import Mathlib.Data.Matrix.ColumnRowPartitioned

namespace KDClosure
open Matrix
open scoped BigOperators ComplexOrder Matrix

section MatrixPackets

variable {X J : Type*} [Fintype X] [DecidableEq X] [Fintype J] [DecidableEq J]

private theorem orthogonal_complement_psd (V : Matrix X J ℂ)
    (hv : Vᴴ * V = 1) : (1 - V * Vᴴ).PosSemidef := by
  let P := V * Vᴴ
  have symm : Pᴴ = P := by simp [P]
  have idemp : P*P=P := by
    change (V*Vᴴ)*(V*Vᴴ) = V*Vᴴ
    rw [Matrix.mul_assoc, ← Matrix.mul_assoc Vᴴ, hv, Matrix.one_mul]
  have gram := (PosSemidef.one (n:=X) (R:=ℂ)).conjTranspose_mul_mul_same (1-P)
  simpa [conjTranspose_sub,symm,Matrix.sub_mul,Matrix.mul_sub,idemp] using gram

/-- The unweighted two-channel matrix is positive, with one exact kernel
column for each pair of orthonormal columns. -/
theorem partialIsometrySchur (U V : Matrix X J ℂ)
    (hu : Uᴴ * U = 1) (hv : Vᴴ * V = 1) :
    let K := U*Vᴴ
    let A := fromBlocks (1 : Matrix X X ℂ) K Kᴴ (1 : Matrix X X ℂ)
    A.PosSemidef ∧ A*(fromRows U (-V)) = 0 := by
  dsimp only
  have prod : (U*Vᴴ)ᴴ*(U*Vᴴ)=V*Vᴴ := by
    rw [conjTranspose_mul,conjTranspose_conjTranspose,Matrix.mul_assoc,←Matrix.mul_assoc Uᴴ,hu,Matrix.one_mul]
  constructor
  · let _ := invertibleOne (α := Matrix X X ℂ)
    apply (PosDef.fromBlocks₁₁ _ _ PosDef.one).mpr
    rw [inv_one, Matrix.mul_one, prod]
    exact orthogonal_complement_psd V hv
  · rw [fromBlocks_mul_fromRows]
    simp [Matrix.mul_assoc,hv,hu]

noncomputable def normalizedColumns (r : X → ℝ) (ψ : Matrix X J ℂ) (h : J → ℂ) :
    Matrix X J ℂ := fun x j => ((r x : ℂ)⁻¹ * ψ x j) * h j

/-- The off-diagonal block as a literal sum of packet outer products. The signed
coefficient (including the transverse factor b) is h j * star (k j). -/
noncomputable def outerPacketSum (ψ : Matrix X J ℂ) (h k : J → ℂ) : Matrix X X ℂ :=
  fun x y => ∑ j, (h j * star (k j)) * ψ x j * star (ψ y j)

private noncomputable def rootDiag (r : X → ℝ) : Matrix X X ℂ :=
  diagonal (fun x => (r x : ℂ))

omit [Fintype X] in
private theorem sqrt_diag_selfadj (r : X → ℝ) : (rootDiag r)ᴴ = rootDiag r := by
  ext i j
  by_cases e : i=j <;> simp [rootDiag, Matrix.conjTranspose_apply, e, Ne.symm]

omit [Fintype J] [DecidableEq J] in
private theorem root_times_normalized (r : X → ℝ) (hr : ∀ x, r x ≠ 0)
    (ψ : Matrix X J ℂ) (h : J → ℂ) :
    rootDiag r * normalizedColumns r ψ h = fun x j => ψ x j * h j := by
  ext x j
  simp [rootDiag, Matrix.diagonal_mul, normalizedColumns, ←mul_assoc, hr]

omit [DecidableEq J] in
private theorem root_cross (r s : X → ℝ) (hr : ∀ x, r x ≠ 0) (hs : ∀ x, s x ≠ 0)
    (ψ : Matrix X J ℂ) (h k : J → ℂ) :
    rootDiag r * (normalizedColumns r ψ h * (normalizedColumns s ψ k)ᴴ) * rootDiag s =
      outerPacketSum ψ h k := by
  rw [← Matrix.mul_assoc, Matrix.mul_assoc _ (normalizedColumns s ψ k)ᴴ,
    ← sqrt_diag_selfadj s, ←conjTranspose_mul, root_times_normalized r hr, root_times_normalized s hs]
  ext x y
  apply Finset.sum_congr rfl; intro j _
  change (ψ x j*h j)*star (ψ y j*k j) = _
  rw [star_mul]; ring

/-- All null vectors are explicit in physical coordinates, up to a nonzero
normalization per column. -/
noncomputable def physicalNull (r : X → ℝ) (ψ : Matrix X J ℂ) (h : J → ℂ) :
    Matrix X J ℂ := fun x j => ((r x : ℂ)⁻¹)^2 * ψ x j * h j

omit [Fintype J] [DecidableEq J] in
private theorem root_null (r : X → ℝ) (hr : ∀ x, r x ≠ 0) (ψ : Matrix X J ℂ) (h : J → ℂ) :
    rootDiag r * physicalNull r ψ h = normalizedColumns r ψ h := by
  ext x j
  simp [rootDiag,physicalNull,normalizedColumns, Matrix.diagonal_mul,pow_two,←mul_assoc, hr]

/-- Finite physical two-channel certificate. The assumptions are weighted Gram
identities on the given packets. The output checks the quadratic positivity of
the full physical matrix with off-diagonal outer-product sum, and checks all
null-vector columns in that same matrix. -/
theorem physicalPacketCertificate (r s : X → ℝ) (hr : ∀ x, r x ≠ 0) (hs : ∀ x, s x ≠ 0)
    (ψ : Matrix X J ℂ) (h k : J → ℂ)
    (hu : (normalizedColumns r ψ h)ᴴ * normalizedColumns r ψ h = 1)
    (hv : (normalizedColumns s ψ k)ᴴ * normalizedColumns s ψ k = 1) :
    let Y := outerPacketSum ψ h k
    let D (a : X → ℝ) := diagonal (fun x => (a x : ℂ)^2)
    let A := fromBlocks (D r) Y Yᴴ (D s)
    A.PosSemidef ∧ A * fromRows (physicalNull r ψ h) (-(physicalNull s ψ k)) = 0 := by
  dsimp only
  let U := normalizedColumns r ψ h
  let V := normalizedColumns s ψ k
  let W := fromBlocks (rootDiag r) 0 0 (rootDiag s)
  let B := fromBlocks (1 : Matrix X X ℂ) (U*Vᴴ) (U*Vᴴ)ᴴ (1 : Matrix X X ℂ)
  have ps := partialIsometrySchur U V hu hv
  change B.PosSemidef ∧ B * fromRows U (-V)=0 at ps
  have hc := root_cross r s hr hs ψ h k
  change rootDiag r * (U*Vᴴ) * rootDiag s = _ at hc
  have hc' : rootDiag s * (U*Vᴴ)ᴴ * rootDiag r = (outerPacketSum ψ h k)ᴴ := by
    calc
      _ = (rootDiag r * (U*Vᴴ)*rootDiag s)ᴴ := by simp only [conjTranspose_mul,sqrt_diag_selfadj,Matrix.mul_assoc]
      _ = _ := congrArg Matrix.conjTranspose hc
  have diag (z : X → ℝ) : rootDiag z * rootDiag z = diagonal (fun x => (z x:ℂ)^2) := by
    simp [rootDiag, diagonal_mul_diagonal, pow_two]
  have form : Wᴴ * B * W = fromBlocks (diagonal fun x => (r x:ℂ)^2)
      (outerPacketSum ψ h k) (outerPacketSum ψ h k)ᴴ (diagonal fun x => (s x:ℂ)^2) := by
    dsimp only [W,B]
    simp only [fromBlocks_conjTranspose,sqrt_diag_selfadj,conjTranspose_zero,
      fromBlocks_multiply, Matrix.mul_zero, Matrix.zero_mul, add_zero,zero_add,
      Matrix.mul_one,diag,hc,hc']
  have applied : W * fromRows (physicalNull r ψ h) (-(physicalNull s ψ k)) = fromRows U (-V) := by
    rw [show W=fromBlocks (rootDiag r) 0 0 (rootDiag s) from rfl,fromBlocks_mul_fromRows]
    simp [root_null r hr, root_null s hs,U,V]
  constructor
  · exact form ▸ ps.1.conjTranspose_mul_mul_same W
  · rw [←form,Matrix.mul_assoc,Matrix.mul_assoc,applied,ps.2,Matrix.mul_zero]


omit [DecidableEq X] [Fintype J] in
/-- One diagonal weighted Gram calculation suffices to normalize a complete
packet system. The masses and weights are read from the original coordinates. -/
theorem normalizedColumns_gram (r : X → ℝ) (ψ : Matrix X J ℂ) (h mass : J → ℂ)
    (G : ∀ i j, (∑ x, star (ψ x i) * ψ x j * ((r x:ℂ)⁻¹)^2) =
      if i=j then mass j else 0)
    (H : ∀ j, star (h j)*h j*mass j=1) :
    (normalizedColumns r ψ h)ᴴ * normalizedColumns r ψ h = 1 := by
  ext i j
  rw [Matrix.mul_apply]
  have factor (x : X) : (normalizedColumns r ψ h)ᴴ i x * normalizedColumns r ψ h x j =
      (star (h i)*h j) * (star (ψ x i) * ψ x j * ((r x:ℂ)⁻¹)^2) := by
    simp only [Matrix.conjTranspose_apply, normalizedColumns, star_mul, star_inv₀,
      show star (r x:ℂ)=(r x:ℂ) from Complex.conj_ofReal _]
    ring
  simp_rw [factor, ←Finset.mul_sum, G]
  by_cases he : i=j
  · subst i; simpa only [if_true,Matrix.one_apply_eq] using H j
  · simp [he]


noncomputable def invroot (t : ℝ) : ℝ := (Real.sqrt t)⁻¹

theorem invroot_ne_zero {t : ℝ} (ht : 0<t) : invroot t ≠ 0 := inv_ne_zero (Real.sqrt_pos.mpr ht).ne'

theorem invroot_sq {t : ℝ} (ht : 0≤t) : (invroot t)^2=t⁻¹ := by
  rw [invroot, inv_pow, Real.sq_sqrt ht]

theorem invroot_inv_sq {t : ℝ} (ht : 0≤t) : (((invroot t:ℝ):ℂ)⁻¹)^2=(t:ℂ) := by
  norm_cast
  rw [invroot,inv_inv,Real.sq_sqrt ht]

theorem invroot_normalizes {t : ℝ} (ht : 0<t) :
    star ((invroot t:ℝ):ℂ)*((invroot t:ℝ):ℂ)*(t:ℂ)=1 := by
  rw [show star ((invroot t:ℝ):ℂ) = (invroot t:ℂ) from Complex.conj_ofReal _, ←sq]
  exact_mod_cast (by rw [invroot_sq ht.le,inv_mul_cancel₀ ht.ne'] : (invroot t)^2*t=1)

end MatrixPackets

section PhysicalCyclic
variable {p L : ℕ} [NeZero p] [NeZero L]

/-- Weighted mass of the normalized jth packet at birth. -/
noncomputable def cyclicMass (f : ℕ → ℝ) (u : ZMod p → ℝ) (j : ℕ) : ℝ :=
  (∑ t, u t)/(p:ℝ) * reciprocalMean (1/(L:ℝ)) f (j+1)

noncomputable def cyclicRealDensity (f : ℕ → ℝ) (u : ZMod p → ℝ)
    (n : ℕ) (x : ZMod (levelSize p L n)) : ℝ :=
  u (baseLabel p L n ((encodeLevel p L n).symm x)) * weight p L f n ((encodeLevel p L n).symm x)

theorem weights_positive (f : ℕ → ℝ) (hf : ∀ i, 0<f i) (hm : Monotone f) :
    ∀ n x, 0<weight p L f n x := by
  have hl : 1≤(L:ℝ) := by exact_mod_cast (Nat.pos_of_ne_zero (NeZero.ne L))
  have θ : 1/(L:ℝ)≤1 := (div_le_one (by positivity)).mpr hl
  intro n
  induction n with
  | zero => exact fun _ => hf 0
  | succ n ih =>
    intro x
    change 0 < extendWeight (weight p L f n) _ _ _ _ _
    unfold extendWeight
    split_ifs with hb hg
    · exact ih _
    · exact hf _
    · rw [mean_eq_mix]
      exact (reciprocal_bounds (1/(L:ℝ)) f (by positivity) θ hf hm (n+1)).1

/-- Both channel masses are positive for positive position statistics. -/
theorem cyclicMass_pos (f : ℕ → ℝ) (hf : ∀ i, 0<f i) (hm : Monotone f)
    (u : ZMod p → ℝ) (hu : ∀ t, 0<u t) (j : ℕ) : 0<cyclicMass (L:=L) f u j := by
  have hl : 1≤(L:ℝ) := by exact_mod_cast (Nat.pos_of_ne_zero (NeZero.ne L))
  have θ : 1/(L:ℝ)≤1 := (div_le_one (by positivity)).mpr hl
  have avg := Finset.sum_pos (s:=Finset.univ) (fun t _ => hu t) Finset.univ_nonempty
  exact mul_pos (div_pos avg (Nat.cast_pos.mpr (Nat.pos_of_ne_zero (NeZero.ne p)))) (reciprocal_bounds _ f (by positivity) θ hf hm _).1

/-- For the actual finite cyclic packets, inverse square-root densities and
the measured birth masses produce an isometry without Gram assumptions.
The sign of each column is arbitrary. -/
theorem cyclic_normalized_isometry (χ : ℕ → AddChar (ZMod p) ℂ) (hn : ∀ j, χ j ≠ 1)
    (f : ℕ → ℝ) (hf : ∀ i, 0<f i) (hm : Monotone f)
    (u : ZMod p → ℝ) (hu : ∀ t, 0<u t) (n : ℕ) (ε : Fin n → Bool) :
    let ψ : Matrix (ZMod (levelSize p L n)) (Fin n) ℂ := fun x j => cyclicPacket χ j.val n x
    let r := fun x => invroot (cyclicRealDensity f u n x)
    let h : Fin n → ℂ := fun j => if ε j then (invroot (cyclicMass (L:=L) f u j.val):ℂ)
                                   else -(invroot (cyclicMass (L:=L) f u j.val):ℂ)
    (normalizedColumns r ψ h)ᴴ * normalizedColumns r ψ h = 1 := by
  dsimp only
  apply normalizedColumns_gram _ _ _ (fun j => (cyclicMass (L:=L) f u j.val:ℂ))
  · intro i j
    have dpos (x : ZMod (levelSize p L n)) : 0<cyclicRealDensity f u n x :=
      mul_pos (hu _) (weights_positive f hf hm _ _)
    simp_rw [invroot_inv_sq (dpos _).le]
    by_cases eq : i=j <;> simpa only [cyclicDensity,packetDensity,cyclicRealDensity,cyclicMass,Fin.val_inj,eq,if_true,if_false,Complex.ofReal_zero] using
      cyclic_gram (L:=L) χ hn f u i.val j.val n i.isLt j.isLt
  · intro j
    have hx := invroot_normalizes (cyclicMass_pos (L:=L) f hf hm u hu j.val)
    split_ifs <;> simpa using hx

/-- Every two positive channel statistics yield an actual two-channel matrix
on the physical cyclic head, positive semidefinite and simultaneously
annihilating its explicit n packet columns, including arbitrary packet signs. -/
theorem finiteCyclicSaturated (χ : ℕ → AddChar (ZMod p) ℂ) (hn : ∀ j, χ j ≠ 1)
    (f : ℕ → ℝ) (hf : ∀ i, 0<f i) (hm : Monotone f)
    (u v : ZMod p → ℝ) (hu : ∀ t, 0<u t) (hv : ∀ t, 0<v t) (n : ℕ) (ε : Fin n → Bool) :
    let ψ : Matrix (ZMod (levelSize p L n)) (Fin n) ℂ := fun x j => cyclicPacket χ j.val n x
    let r := fun x => invroot (cyclicRealDensity f u n x)
    let s := fun x => invroot (cyclicRealDensity f v n x)
    let h : Fin n → ℂ := fun j => invroot (cyclicMass (L:=L) f u j.val)
    let k : Fin n → ℂ := fun j => if ε j then (invroot (cyclicMass (L:=L) f v j.val):ℂ)
                                   else -(invroot (cyclicMass (L:=L) f v j.val):ℂ)
    let Y := outerPacketSum ψ h k
    let A := fromBlocks (diagonal fun x => (r x:ℂ)^2) Y Yᴴ (diagonal fun x => (s x:ℂ)^2)
    A.PosSemidef ∧ A * fromRows (physicalNull r ψ h) (-(physicalNull s ψ k)) = 0 := by
  dsimp only
  apply physicalPacketCertificate
  · intro x; exact invroot_ne_zero (mul_pos (hu _) (weights_positive f hf hm _ _))
  · intro x; exact invroot_ne_zero (mul_pos (hv _) (weights_positive f hf hm _ _))
  · simpa only [ite_true] using cyclic_normalized_isometry (L:=L) χ hn f hf hm u hu n (fun _ => true)
  · exact cyclic_normalized_isometry (L:=L) χ hn f hf hm v hv n ε

/-- The two physical channels use u with parameter a and with parameter -a.
This identification is entrywise, including the original position signs. -/
noncomputable def paperChannelStat (a : ℝ) (l : ℕ) (t : ZMod p) : ℝ :=
  (1+a*signLabel l t)⁻¹

omit [NeZero p] in
theorem paperChannelStat_pos {a : ℝ} (lo : -1<a) (hi : a<1) (l : ℕ) (t : ZMod p) :
    0<paperChannelStat a l t := by
  unfold paperChannelStat signLabel
  split_ifs <;> simp <;> linarith

theorem paperChannelMass (χ : ℕ → AddChar (ZMod p) ℂ) (hn : ∀ j, χ j≠1)
    (f : ℕ → ℝ) (a : ℝ) (ha : a^2≠1) (l : ℕ) (hl : l<p) (j : ℕ) :
    cyclicMass (p:=p) (L:=L) f (paperChannelStat a l) j =
    reciprocalMean (1/(L:ℝ)) f (j+1) * (1-a*(2*l/(p:ℝ)-1))/(1-a^2) := by
  have first := cyclic_gram (L:=L) χ hn f (paperChannelStat a l) j j (j+1) (by omega) (by omega)
  have second := cyclic_channel_gram (L:=L) χ hn f a ha l hl j j (j+1) (by omega) (by omega)
  have ent (x : ZMod (levelSize p L (j+1))) :
      cyclicDensity f (paperChannelStat a l) (j+1) x =
        ((weight p L f (j+1) ((encodeLevel p L (j+1)).symm x) /
          (1+a*signLabel l (baseLabel p L (j+1) ((encodeLevel p L (j+1)).symm x)))) : ℝ) := by
    dsimp [cyclicDensity,packetDensity,paperChannelStat]
    rw [div_eq_mul_inv,mul_comm]
  simp_rw [ent] at first
  have he := first.symm.trans second
  simpa only [if_true,Complex.ofReal_inj,cyclicMass] using he

/-- Exact coefficient match to Section 2. The factors used by finiteCyclicSaturated
multiply to the unsigned paper coefficient b·κ/μ; multiplying the second
column by ε gives both the signed coefficient and the paper null ratio εc. -/
theorem paperSaturatedScales {a r μ : ℝ} (ha : 0<a) (ha1 : a<1)
    (hr : r^2<1) (hμ : 0<μ) :
    let b := Real.sqrt (1-a^2)
    let t := Real.sqrt (1-(a*r)^2)
    let κ := b/t
    let hp := μ*(1-a*r)/b^2
    let hm := μ*(1+a*r)/b^2
    invroot hp * invroot hm = b*(κ/μ) ∧
      invroot hm = ((1-a*r)/t)*invroot hp := by
  dsimp only
  let b := Real.sqrt (1-a^2)
  let t := Real.sqrt (1-(a*r)^2)
  let z := b*((b/t)/μ)
  let c := (1-a*r)/t
  let hp := μ*(1-a*r)/b^2
  let hm := μ*(1+a*r)/b^2
  change invroot hp*invroot hm = z ∧ invroot hm = c*invroot hp
  obtain ⟨hk,_,_,hc,_,he⟩ := packetConstants ha ha1 hr hμ
  have hb : 0<b := Real.sqrt_pos.mpr (by nlinarith [mul_pos (sub_pos.mpr ha1) (show 0<1+a by linarith)])
  have hgap : (a*r)^2<a^2 := by nlinarith [mul_pos (sq_pos_of_pos ha) (sub_pos.mpr hr)]
  have aa : a^2<1 := by nlinarith [mul_pos (sub_pos.mpr ha1) (show 0<1+a by linarith)]
  have hpos : 0<hp := div_pos (mul_pos hμ (by nlinarith [sq_nonneg (a*r-1)])) (sq_pos_of_pos hb)
  have mpos : 0<hm := div_pos (mul_pos hμ (by nlinarith [sq_nonneg (a*r+1)])) (sq_pos_of_pos hb)
  change z*hp=c at hc
  change b^2*((b/t)/μ)^2*hp*hm=1 at he
  have saturation : z^2*hp*hm=1 := by simpa only [z,mul_pow] using he
  have hz : 0<z := mul_pos hb (div_pos hk hμ)
  have hp' : 0 < invroot hp := inv_pos.mpr (Real.sqrt_pos.mpr hpos)
  have hm' : 0 < invroot hm := inv_pos.mpr (Real.sqrt_pos.mpr mpos)
  have cross : invroot hp * invroot hm = z := by
    apply (sq_eq_sq₀ (mul_pos hp' hm').le hz.le).mp
    rw [mul_pow,invroot_sq hpos.le,invroot_sq mpos.le]
    field_simp [hpos.ne',mpos.ne']
    linear_combination -saturation
  refine ⟨cross, ?_⟩
  calc
    invroot hm = ((invroot hp)^2*hp)*invroot hm := by rw [invroot_sq hpos.le,inv_mul_cancel₀ hpos.ne',one_mul]
    _ = (invroot hp*invroot hm)*hp*invroot hp := by ring
    _ = c*invroot hp := by rw [cross,hc]

end PhysicalCyclic
end KDClosure
