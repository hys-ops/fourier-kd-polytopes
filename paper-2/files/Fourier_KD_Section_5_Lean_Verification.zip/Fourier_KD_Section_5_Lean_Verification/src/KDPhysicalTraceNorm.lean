import KDTraceNormalization
import KDTraceTraditionalAbs
import KDStateClosed

/-! Independent singular-value characterization on every pair of the physical
states in Section 5, including non-chain groups. Not a finite-dimensional test. -/
noncomputable section
namespace KDClosure.Hull
open MeasureTheory Set CompactCore LCAReality LCAQuotient
open scoped InnerProductSpace ENNReal KDClosure.SubgroupMeasure
universe u
variable {G : Type u} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
  [T2Space G] [LocallyCompactSpace G] [SecondCountableTopology G] [MeasurableSpace G] [BorelSpace G]
variable (μ : Measure G) [μ.IsAddHaarMeasure] (ν : Measure (LCAReality.Dual G)) [SFinite ν]
variable (F : FourierRealization μ ν)

set_option linter.unusedSectionVars false in
theorem physical_trace_distance_is_singular_sum
    {A B : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ} (ha : A ∈ ambientStates μ ν F) (hb : B ∈ ambientStates μ ν F) :
    let D := A-B
    ∃ (I : Type u) (b : HilbertBasis I ℂ (Lp ℂ 2 μ)) (s : I→ℝ),
      (∀ i, 0≤s i) ∧
      (∀ i, (D.adjoint ∘L D) (b i)=((s i)^2 : ℂ) • b i) ∧
      traceVariational D = ∑' i, ENNReal.ofReal (s i) ∧
      (∑' i, ENNReal.ofReal (s i)) ≤ 2 := by
  obtain ⟨hc,hs⟩ := state_difference_compact_symmetric A B ha.1 hb.1 ha.2.1 hb.2.1
  obtain ⟨I,b,s,pos,eig,eqn⟩ := traceVariational_compact_symmetric_singular_sum (A-B) hc hs
  exact ⟨I,b,s,pos,eig,eqn,eqn ▸ distance_between_states_le_two A B ha.1 hb.1 ha.2.1.1 hb.2.1.1⟩

set_option linter.unusedSectionVars false in
/-- On every pair of actual states, with no extra compactness or finiteness
input, the gauge in the criterion is the usual Tr sqrt(D†D). -/
theorem physical_trace_distance_is_trace_abs
    {A B : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ} (ha : A ∈ ambientStates μ ν F) (hb : B ∈ ambientStates μ ν F) :
    ∃ t : ℝ, IsLUB (Tight.Mass (traceAbs (A-B))) t ∧ traceVariational (A-B) = ENNReal.ofReal t := by
  have cp := (state_difference_compact_symmetric A B ha.1 hb.1 ha.2.1 hb.2.1).1
  have bound := distance_between_states_le_two A B ha.1 hb.1 ha.2.1.1 hb.2.1.1
  exact traceVariational_eq_trace_abs_of_compact (A-B) cp (ne_top_of_le_ne_top (by norm_num) bound)
end KDClosure.Hull
#print axioms KDClosure.Hull.physical_trace_distance_is_trace_abs
#print axioms KDClosure.Hull.physical_trace_distance_is_singular_sum
