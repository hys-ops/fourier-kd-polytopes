import KDTraceTightWOT
import KDStateClosedTrace
import Mathlib.Analysis.Normed.Operator.Compact.FiniteDimension

/-! Every positive state of trace one in the actual finite-frame definition
is compact; this auxiliary spectral bridge supplies compactness explicitly. -/
noncomputable section
namespace KDClosure.Hull
open Filter Set ContinuousLinearMap InnerProductSpace Tight
open scoped Topology ENNReal InnerProductSpace ComplexOrder
variable {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℂ X] [CompleteSpace X]

theorem finite_cut_error {I : Type*} (b : HilbertBasis I ℂ X) (s : Finset I)
    (T : X →L[ℂ] X) (p : T.IsPositive) (ht : 1 ∈ upperBounds (Mass T)) :
    traceVariational (T - (cut b s) ∘L T ∘L (cut b s)) ≤ ENNReal.ofReal (tailCost b s T) := by
  have adj : (cut b s).adjoint=cut b s := by simp [cut]
  unfold traceVariational
  refine iSup_le fun n => iSup_le fun u => iSup_le fun hu => iSup_le fun v => iSup_le fun hv => ?_
  have eq (j : Fin n) : inner ℂ (v j) ((T - cut b s ∘L T ∘L cut b s) (u j)) =
      inner ℂ (v j) (T (u j))-inner ℂ (cut b s (v j)) (T (cut b s (u j))) := by
    rw [sub_apply,inner_sub_right]
    change _-inner ℂ (v j) (cut b s (T (cut b s (u j)))) = _
    rw [←(cut b s).adjoint_inner_left,adj]
  simp only [eq,←ofReal_norm,←ENNReal.ofReal_sum_of_nonneg (fun _ _ => norm_nonneg _)]
  exact ENNReal.ofReal_le_ofReal (frame_tail b s p ht hu hv)

theorem positive_trace_one_compact (T : X →L[ℂ] X) (p : T.IsPositive) (ht : IsLUB (Mass T) 1) :
    IsCompactOperator T := by
  classical
  let C := {A : X →L[ℂ] X | IsCompactOperator A}
  have cc : IsClosed C := isClosed_setOfPred_isCompactOperator
  apply cc.closure_subset
  apply Metric.mem_closure_iff.mpr
  intro ε hp
  obtain ⟨I,b,_⟩ := exists_hilbertBasis ℂ X
  have hsd := (diag_spec b p).1.mp ⟨1,ht.1⟩
  have has : HasSum (diag b T) 1 := ((diag_spec b p).2 hsd).unique ht ▸ hsd.hasSum
  have taper : Tendsto (fun s => tailCost b s T) atTop (𝓝 0) := by
    have h : Tendsto (fun s : Finset I => 1 - ∑ i ∈ s, diag b T i) atTop (𝓝 (1-1 : ℝ)) :=
      tendsto_const_nhds.sub has
    simpa [tailCost] using (tendsto_const_nhds (x:=(2:ℝ))).mul ((Real.continuous_sqrt.tendsto _).comp h)
  obtain ⟨s,hs⟩ := (taper.eventually_lt_const (half_pos hp)).exists
  let P := cut b s
  have cp : IsCompactOperator P := by
    change ∑ i ∈ s, rankOne ℂ (b i) (b i) ∈ compactOperator (RingHom.id ℂ) X X
    apply Submodule.sum_mem
    intro i _
    change IsCompactOperator (rankOne ℂ (b i) (b i))
    rw [rankOne_def']
    exact (isCompactOperator_of_locallyCompactSpace_dom (innerSL ℂ (b i))).clm_comp (toSpanSingleton ℂ (b i))
  refine ⟨P ∘L T ∘L P,cp.comp_clm (T ∘L P),?_⟩
  rw [dist_eq_norm]
  exact (norm_le_of_traceVariational_lt (half_pos hp) ((finite_cut_error b s T p ht.1).trans_lt
    ((ENNReal.ofReal_lt_ofReal_iff (half_pos hp)).mpr hs))).trans_lt (half_lt_self hp)

theorem state_difference_compact_symmetric (A B : X →L[ℂ] X)
    (pa : A.IsPositive) (pb : B.IsPositive) (ha : IsLUB (Mass A) 1) (hb : IsLUB (Mass B) 1) :
    IsCompactOperator (A-B) ∧ (A-B).IsSymmetric :=
  ⟨(positive_trace_one_compact A pa ha).sub (positive_trace_one_compact B pb hb),
   pa.isSymmetric.sub pb.isSymmetric⟩
end KDClosure.Hull
