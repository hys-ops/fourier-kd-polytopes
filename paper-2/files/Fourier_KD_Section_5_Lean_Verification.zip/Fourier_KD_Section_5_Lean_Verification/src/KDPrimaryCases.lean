import KDPrimaryReduction
import Mathlib.Data.Nat.Factorization.Induction

namespace KDClosure.Primary

variable {G : Type*} [AddCommGroup G] {p : ℕ} [Fact p.Prime]

/-- If the p-kernel contains no elementary square, each of its nonzero
vectors spans the full kernel. -/
theorem kernel_line
    (nosq : ¬ ∃ c : (ZMod p × ZMod p) →+ G, Function.Injective c)
    (a b : G) (ha : p • a = 0) (ha' : a ≠ 0) (hb : p • b = 0) :
    b ∈ AddSubgroup.zmultiples a := by
  classical
  let K : AddSubgroup G := (p • AddMonoidHom.id G).ker
  let _ : Module (ZMod p) K := AddCommGroup.zmodModule fun x => Subtype.ext x.property
  let u : K := ⟨a,ha⟩
  let v : K := ⟨b,hb⟩
  by_cases hr : ∃ s : ZMod p, s • u = v
  · obtain ⟨s,hs⟩ := hr
    have ht : s.val • u = v := by
      rw [← Nat.cast_smul_eq_nsmul (ZMod p), ZMod.natCast_zmod_val,hs]
    have e : s.val • a = b := congrArg Subtype.val ht
    rw [← e]
    exact (AddSubgroup.zmultiples a).nsmul_mem (AddSubgroup.mem_zmultiples _) _
  · exfalso
    apply nosq
    let g := (LinearMap.toSpanSingleton (ZMod p) K u).coprod (LinearMap.toSpanSingleton (ZMod p) K v)
    refine ⟨K.subtype.comp g.toAddMonoidHom, Subtype.val_injective.comp
      ((injective_iff_map_eq_zero g.toAddMonoidHom).mpr ?_)⟩
    rintro ⟨s,t⟩ h
    change s • u + t • v = 0 at h
    by_cases ht : t = 0
    · subst t
      have hsu : s • u = 0 := by simpa using h
      have hs : s = 0 := by
        by_contra hsn
        apply ha'
        exact congrArg Subtype.val (show u = 0 from calc
          u = s⁻¹ • (s • u) := (inv_smul_smul₀ hsn u).symm
          _ = 0 := by rw [hsu,smul_zero])
      exact Prod.ext hs rfl
    · exfalso
      apply hr
      refine ⟨-(t⁻¹*s),?_⟩
      rw [neg_smul,mul_smul,← smul_neg,← eq_neg_of_add_eq_zero_right h,inv_smul_smul₀ ht]

/-- The complete p^n-kernel is cyclic as soon as any element has exact
order p^n and there is no elementary square. -/
theorem kernel_on_generator
    (nosq : ¬ ∃ c : (ZMod p × ZMod p) →+ G, Function.Injective c)
    (n : ℕ) (x : G) (hx : addOrderOf x = p^n) (y : G) (hy : p^n • y = 0) :
    y ∈ AddSubgroup.zmultiples x := by
  induction n generalizing x y with
  | zero =>
    have : y=0 := by simpa using hy
    exact this ▸ (AddSubgroup.zmultiples _).zero_mem
  | succ n ih =>
    have ox : addOrderOf (p • x) = p^n := by
      simpa [descend] using (descend (p:=p) (show n ≤ n+1 by omega) (⟨x,hx⟩ : Level G p (n+1))).property
    have oy : p^n • (p • y) = 0 := by simpa [smul_smul,← pow_succ] using hy
    obtain ⟨i,hi⟩ := AddSubgroup.mem_zmultiples_iff.mp (ih _ ox _ oy)
    have hz : p • (p^n • x) = 0 := by
      rw [smul_smul,← pow_succ',← hx,addOrderOf_nsmul_eq_zero]
    have hn : p^n • x ≠ 0 := by
      intro h
      have dvd := addOrderOf_dvd_iff_nsmul_eq_zero.mpr h
      rw [hx] at dvd
      exact (not_le_of_gt (pow_lt_pow_right₀ (Fact.out : p.Prime).one_lt (Nat.lt_succ_self n)))
        (Nat.le_of_dvd (pow_pos (Fact.out : p.Prime).pos _) dvd)
    have hv : p • (y-i • x) = 0 := by
      rw [nsmul_sub,← natCast_zsmul (i • x),smul_comm (M:=ℤ) (N:=ℤ),natCast_zsmul,hi,sub_self]
    have sub : AddSubgroup.zmultiples (p^n • x) ≤ AddSubgroup.zmultiples x :=
      AddSubgroup.zmultiples_le.mpr ((AddSubgroup.zmultiples x).nsmul_mem (AddSubgroup.mem_zmultiples _) _)
    simpa using (AddSubgroup.zmultiples x).add_mem (sub (kernel_line nosq _ _ hz hn hv))
      ((AddSubgroup.zmultiples x).zsmul_mem (AddSubgroup.mem_zmultiples _) i)

/-- Every pair of subgroups inside a rank-one p-component is comparable.
This includes infinite and finite subgroups. -/
theorem primary_subgroups_chain (nosq : ¬ ∃ c : (ZMod p × ZMod p) →+ G, Function.Injective c)
    {A B : AddSubgroup G} (ha : A ≤ AddCommGroup.primaryComponent G p)
    (hb : B ≤ AddCommGroup.primaryComponent G p) : A ≤ B ∨ B ≤ A := by
  classical
  by_contra! h
  obtain ⟨x,hx,hxb⟩ := Set.not_subset.mp h.1
  obtain ⟨y,hy,hya⟩ := Set.not_subset.mp h.2
  obtain ⟨i,hi⟩ := AddCommGroup.mem_primaryComponent_iff_addOrderOf.mp (ha hx)
  obtain ⟨j,hj⟩ := AddCommGroup.mem_primaryComponent_iff_addOrderOf.mp (hb hy)
  rcases le_total i j with le|le
  · apply hxb
    apply AddSubgroup.zmultiples_le.mpr hy
    exact kernel_on_generator nosq _ y hj x (addOrderOf_dvd_iff_nsmul_eq_zero.mp (hi ▸ pow_dvd_pow _ le))
  · apply hya
    apply AddSubgroup.zmultiples_le.mpr hx
    exact kernel_on_generator nosq _ x hi y (addOrderOf_dvd_iff_nsmul_eq_zero.mp (hj ▸ pow_dvd_pow _ le))


/-- With no elementary square, any bounded p-primary component is finite. -/
theorem bounded_primary_finite
    (nosq : ¬ ∃ c : (ZMod p × ZMod p) →+ G, Function.Injective c)
    (M : ℕ) (bound : ∀ x ∈ AddCommGroup.primaryComponent G p, p^M • x = 0) :
    ((AddCommGroup.primaryComponent G p : AddSubgroup G) : Set G).Finite := by
  classical
  let S (j : ℕ) := {x : G | addOrderOf x = p^j}
  have f (j : ℕ) : (S j).Finite := by
    by_cases h : (S j).Nonempty
    · obtain ⟨x,hx⟩ := h
      change addOrderOf x = p^j at hx
      have hxpos : 0 < addOrderOf x := hx ▸ pow_pos (Fact.out : p.Prime).pos _
      apply (addOrderOf_pos_iff.mp hxpos).finite_zmultiples.subset
      intro y hy
      exact kernel_on_generator nosq j x hx y (hy ▸ addOrderOf_nsmul_eq_zero y)
    · rw [Set.not_nonempty_iff_eq_empty.mp h]
      exact Set.finite_empty
  apply ((Set.finite_Iic M).biUnion (fun j _ => f j)).subset
  intro x hx
  obtain ⟨j,hj⟩ := AddCommGroup.mem_primaryComponent_iff_addOrderOf.mp hx
  have hdvd := addOrderOf_dvd_iff_nsmul_eq_zero.mpr (bound x hx)
  rw [hj] at hdvd
  exact Set.mem_iUnion₂.mpr ⟨j,(Nat.pow_dvd_pow_iff_le_right (Fact.out : p.Prime).one_lt).mp hdvd,hj⟩

/-- The prime support consists of primes with a nonzero primary component. -/
def active (G : Type*) [AddCommGroup G] : Set ℕ :=
  {r | r.Prime ∧ ∃ x ∈ AddCommGroup.primaryComponent G r, x ≠ 0}

/-- Primary components generate every abelian torsion group. The proof
decomposes each individual annihilator using Bézout; no finite-generation
assumption on the group is needed. -/
theorem generated_by_primary (torsion : IsAddTorsion G) (H : AddSubgroup G)
    (inc : ∀ r ∈ active G, AddCommGroup.primaryComponent G r ≤ H) : H = ⊤ := by
  have h (n : ℕ) : n > 0 → ∀ x : G, n • x = 0 → x ∈ H := by
    induction n using Nat.recOnPosPrimePosCoprime with
    | zero => simp
    | one =>
      intro _ x hx
      rw [one_nsmul] at hx
      exact hx ▸ H.zero_mem
    | prime_pow r k hr _ =>
      intro _ x hx
      by_cases hz : x = 0
      · exact hz ▸ H.zero_mem
      · have mem : x ∈ AddCommGroup.primaryComponent G r :=
          AddCommGroup.mem_primaryComponent.mpr ⟨k,hx⟩
        exact inc r ⟨hr,x,mem,hz⟩ mem
    | coprime a b ha hb hc ia ib =>
      intro _ x hx
      have aH := ia (by omega) (b • x) (by simpa only [smul_smul] using hx)
      have bH := ib (by omega) (a • x) (by simpa only [smul_smul,mul_comm b a] using hx)
      have bez := Nat.gcd_eq_gcd_ab a b
      rw [hc.gcd_eq_one,Nat.cast_one] at bez
      have eqn : ((a : ℤ) * a.gcdA b + (b : ℤ) * a.gcdB b) • x = x := by rw [← bez,one_smul]
      rw [← eqn,add_smul,mul_comm (a : ℤ),mul_comm (b : ℤ),mul_smul,mul_smul,natCast_zsmul,natCast_zsmul]
      exact H.add_mem (H.zsmul_mem bH _) (H.zsmul_mem aH _)
  apply top_unique
  intro x _
  obtain ⟨n,hn,hx⟩ := isOfFinAddOrder_iff_nsmul_eq_zero.mp (torsion x)
  exact h n hn x hx

private theorem finite_sup (S : Finset ℕ) (D : ℕ → AddSubgroup G)
    (h : ∀ i ∈ S, ((D i : AddSubgroup G) : Set G).Finite) :
    ((S.sup D : AddSubgroup G) : Set G).Finite := by
  classical
  induction S using Finset.induction_on with
  | empty => simp
  | insert i s hi ih =>
    rw [Finset.sup_insert]
    have hi' := h i (Finset.mem_insert_self _ _)
    have hs := ih (fun j hj => h j (Finset.mem_insert_of_mem hj))
    apply (Set.Finite.image2 (·+·) hi' hs).subset
    intro x hx
    exact AddSubgroup.mem_sup.mp hx

/-- A torsion group of infinite cardinality with finitely many occurring
primes must have an infinite primary component. -/
theorem infinite_primary_of_finite_primes [Infinite G] (torsion : IsAddTorsion G)
    (fin : (active G).Finite) :
    ∃ p ∈ active G, ((AddCommGroup.primaryComponent G p : AddSubgroup G) : Set G).Infinite := by
  classical
  by_contra! h
  let S := fin.toFinset
  let D := AddCommGroup.primaryComponent G
  have ht : S.sup D = ⊤ := generated_by_primary torsion _ <|
    fun i hi => Finset.le_sup (f:=D) (fin.mem_toFinset.mpr hi)
  have hf := finite_sup S D fun i hi => h i (fin.mem_toFinset.mp hi)
  rw [ht] at hf
  exact Set.infinite_univ hf


/-- The alternatives are exhaustive; they need not be mutually exclusive.
The square in the second branch lies inside the infinite primary component.
Finiteness of the two incomparable subgroups and countability of the group
are unnecessary for this algebraic reduction. -/
theorem torsion_cases [Infinite G] (torsion : IsAddTorsion G)
    (incomparable : ∃ A B : AddSubgroup G, ¬ A ≤ B ∧ ¬ B ≤ A) :
    (active G).Infinite ∨
    (∃ p ∈ active G, ((AddCommGroup.primaryComponent G p : AddSubgroup G) : Set G).Infinite ∧
      ∃ f : (ZMod p × ZMod p) →+ AddCommGroup.primaryComponent G p, Function.Injective f) ∨
    (∃ p ∈ active G, ∃ q ∈ active G, p ≠ q ∧
      ∃ e : (Additive (pRoots p) × ZMod q) →+ G, Function.Injective e) := by
  classical
  by_cases fin : (active G).Finite
  · right
    obtain ⟨p,hp,hpi⟩ := infinite_primary_of_finite_primes torsion fin
    let _ : Fact p.Prime := ⟨hp.1⟩
    by_cases sq : ∃ c : (ZMod p × ZMod p) →+ G, Function.Injective c
    · left
      obtain ⟨c,hc⟩ := sq
      have mem (z : ZMod p × ZMod p) : c z ∈ AddCommGroup.primaryComponent G p := by
        apply AddCommGroup.mem_primaryComponent.mpr
        refine ⟨1,?_⟩
        rw [pow_one,← map_nsmul]
        have hz : p • z = 0 := Prod.ext (by simp [nsmul_eq_mul]) (by simp [nsmul_eq_mul])
        rw [hz,map_zero]
      exact ⟨p,hp,hpi,c.codRestrict _ mem,fun _ _ h => hc (congrArg Subtype.val h)⟩
    · right
      have hother : ∃ q ∈ active G, p ≠ q := by
        by_contra! h
        have eqtop := generated_by_primary torsion (AddCommGroup.primaryComponent G p)
          (fun r hr => (h r hr) ▸ le_rfl)
        obtain ⟨A,B,hab,hba⟩ := incomparable
        have chain := primary_subgroups_chain (A:=A) (B:=B) sq (eqtop ▸ le_top) (eqtop ▸ le_top)
        exact chain.elim hab hba
      obtain ⟨q,hq,hpq⟩ := hother
      let _ : Fact q.Prime := ⟨hq.1⟩
      refine ⟨p,hp,q,hq,hpq,rank_one_unbounded_mixed hpq sq ?_ hq.2⟩
      intro M
      by_contra! h
      exact hpi (bounded_primary_finite sq M h)
  · exact Or.inl fin

end KDClosure.Primary
