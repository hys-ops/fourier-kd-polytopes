import KDGroupTower
import Mathlib.Order.KonigLemma
import Mathlib.Algebra.Module.ZMod

namespace KDClosure
namespace Primary

variable {G : Type*} [AddCommGroup G] {p : ℕ} [Fact p.Prime]

/-- A level contains the elements of exactly the indicated primary order. -/
def Level (G : Type*) [AddCommGroup G] (p i : ℕ) := {x : G // addOrderOf x = p^i}

/-- The height-j generator maps down by p^(j-i). -/
def descend {i j : ℕ} (h : i ≤ j) (x : Level G p j) : Level G p i :=
  ⟨p^(j-i) • x.val, by
    have hp : 0 < p := (Fact.out : p.Prime).pos
    rw [addOrderOf_nsmul' _ (pow_ne_zero _ hp.ne'),x.property,Nat.gcd_eq_right
      (pow_dvd_pow _ (Nat.sub_le _ _))]
    apply Nat.div_eq_of_eq_mul_left (pow_pos hp _)
    rw [← pow_add, Nat.add_sub_of_le h]⟩

theorem descend_trans {i j k : ℕ} (a : i ≤ j) (b : j ≤ k) (x : Level G p k) :
    descend a (descend b x) = descend (a.trans b) x := by
  apply Subtype.ext
  change p^(j-i) • (p^(k-j) • x.val) = p^(k-i) • x.val
  rw [smul_smul,← pow_add]
  congr 2
  omega

/-- Finite p-torsion gives finite fibers for multiplication by p, by translating
a nonempty fiber into its kernel. Exact-order elements exist to arbitrary height.
No countability or canonical choice of roots is assumed. -/
theorem coherent_generators
    (hker : {x : G | p • x = 0}.Finite)
    (hunbounded : ∀ n : ℕ, ∃ j ≥ n, Nonempty (Level G p j)) :
    ∃ f : ℕ → G, (∀ i, addOrderOf (f i) = p^i) ∧
      ∀ ⦃i j : ℕ⦄, i ≤ j → p^(j-i) • f j = f i := by
  classical
  let _ : Subsingleton (Level G p 0) := ⟨fun x y => by
    have one (z : Level G p 0) : z.val = 0 := by
      have hz := addOrderOf_nsmul_eq_zero z.val
      simpa [z.property] using hz
    exact Subtype.ext ((one x).trans (one y).symm)⟩
  let _ (n : ℕ) : Nonempty (Level G p n) := by
    obtain ⟨j,hj,⟨x⟩⟩ := hunbounded n
    exact ⟨descend hj x⟩
  have fibers (i : ℕ) (a : Level G p i) :
      {b : Level G p (i+1) | descend (Nat.le_add_right i 1) b = a}.Finite := by
    let s : Set (Level G p (i+1)) := {b | descend (Nat.le_add_right i 1) b = a}
    change s.Finite
    by_cases h : s.Nonempty
    · obtain ⟨u,hu⟩ := h
      have eqn (v : Level G p (i+1)) (hv : v ∈ s) : p • v.val = a.val := by
        have hv' := congrArg Subtype.val hv
        change p^((i+1)-i) • v.val = a.val at hv'
        simpa using hv'
      let _ := hker.fintype
      apply Set.finite_coe_iff.mp
      apply Finite.of_injective (fun v : s => (⟨v.val.val-u.val,by
        change p • (v.val.val - u.val) = 0
        rw [nsmul_sub,eqn v.val v.property,eqn u hu,sub_self]⟩ : {x : G | p • x = 0}))
      intro v w eq
      exact Subtype.ext (Subtype.ext (sub_left_inj.mp (congrArg Subtype.val eq)))
    · rw [Set.not_nonempty_iff_eq_empty.mp h]
      exact Set.finite_empty
  obtain ⟨f,hf⟩ := exists_seq_forall_proj_of_forall_finite (α:=Level G p)
    (fun h x => descend h x) (fun {_} x => by apply Subtype.ext; simp [descend])
    (fun {_ _ _} a b x => descend_trans a b x) fibers
  exact ⟨fun i => (f i).val,fun i => (f i).property,fun _ _ h => congrArg Subtype.val (hf h)⟩


/-- The increasing cyclic graphs of two equal-order, coherent generator
chains identify the first group faithfully with a subgroup of the second. -/
theorem glue_generators {A B : Type*} [AddCommGroup A] [AddCommGroup B]
    (p : ℕ) (a : ℕ → A) (b : ℕ → B) (oa : ∀ n, addOrderOf (a n) = addOrderOf (b n))
    (ha : ∀ n, p • a (n+1) = a n) (hb : ∀ n, p • b (n+1) = b n)
    (covers : ∀ x : A, ∃ n : ℕ, x ∈ AddSubgroup.zmultiples (a n)) :
    ∃ e : A →+ B, Function.Injective e ∧ ∀ n, e (a n) = b n := by
  let K (n : ℕ) := AddSubgroup.zmultiples (a n,b n)
  have inc : Monotone K := by
    apply monotone_nat_of_le_succ
    intro n
    apply AddSubgroup.zmultiples_le.mpr
    have h : p • (a (n+1), b (n+1)) = (a n,b n) := Prod.ext (ha n) (hb n)
    exact h ▸ (K (n+1)).nsmul_mem (AddSubgroup.mem_zmultiples _) p
  let S := ⨆ n : ℕ, K n
  let l : S →+ A := (AddMonoidHom.fst A B).comp S.subtype
  let r : S →+ B := (AddMonoidHom.snd A B).comp S.subtype
  have zero_eq (z : S) : l z = 0 ↔ r z = 0 := by
    obtain ⟨n,hn⟩ := (AddSubgroup.mem_iSup_of_directed inc.directed_le).mp z.property
    obtain ⟨i,hi⟩ := AddSubgroup.mem_zmultiples_iff.mp hn
    change z.val.1 = 0 ↔ z.val.2 = 0
    rw [← hi]
    change i • a n = 0 ↔ i • b n = 0
    rw [← addOrderOf_dvd_iff_zsmul_eq_zero,← addOrderOf_dvd_iff_zsmul_eq_zero,oa n]
  have li : Function.Injective l := (injective_iff_map_eq_zero _).mpr fun z hz =>
    Subtype.ext (Prod.ext hz ((zero_eq z).mp hz))
  have ri : Function.Injective r := (injective_iff_map_eq_zero _).mpr fun z hz =>
    Subtype.ext (Prod.ext ((zero_eq z).mpr hz) hz)
  have ls : Function.Surjective l := by
    intro x
    obtain ⟨n,hn⟩ := covers x
    obtain ⟨i,rfl⟩ := AddSubgroup.mem_zmultiples_iff.mp hn
    exact ⟨⟨i • (a n,b n),le_iSup K n ((K n).zsmul_mem (AddSubgroup.mem_zmultiples _) _)⟩,rfl⟩
  let e := AddEquiv.ofBijective l ⟨li,ls⟩
  refine ⟨r.comp e.symm.toAddMonoidHom,ri.comp e.symm.injective,?_⟩
  intro n
  let z : S := ⟨(a n,b n),le_iSup K n (AddSubgroup.mem_zmultiples _)⟩
  change r (e.symm (e z)) = b n
  rw [e.symm_apply_apply]
  rfl

private theorem atLevel (p n : ℕ) : rootsOfUnity (p^(n+1)) ℂ ≤ pRoots p :=
  le_iSup (fun j : ℕ => rootsOfUnity (p^j) ℂ) _

noncomputable def rootGen (p : ℕ) [Fact p.Prime] (n : ℕ) : Additive (pRoots p) :=
  rootHead (atLevel p n) 1

theorem rootGen_order (p : ℕ) [Fact p.Prime] (n : ℕ) : addOrderOf (rootGen p n) = p^(n+1) :=
  (addOrderOf_injective _ (rootHead_injective (atLevel p n)) 1).trans (ZMod.addOrderOf_one _)

theorem rootGen_step (p : ℕ) [Fact p.Prime] (n : ℕ) :
    p • rootGen p (n+1) = rootGen p n := by
  unfold rootGen
  rw [← map_nsmul]
  apply compatible_rootHead _ _ (b:=p) (Fact.out : p.Prime).pos (pow_succ _ _)
  rw [nsmul_eq_mul,mul_one,ZMod.val_natCast_of_lt, ZMod.val_one'' (ne_of_gt
    (one_lt_pow₀ (Fact.out : p.Prime).one_lt (Nat.succ_ne_zero n))),mul_one]
  calc p = p^1 := (pow_one _).symm
       _ < _ := pow_lt_pow_right₀ (Fact.out : p.Prime).one_lt (by omega)

theorem rootGen_covers (p : ℕ) [Fact p.Prime] (x : Additive (pRoots p)) :
    ∃ n : ℕ, x ∈ AddSubgroup.zmultiples (rootGen p n) := by
  obtain ⟨n,hn⟩ := (mem_pRoots_iff _ _).mp x.toMul.property
  have hx := (range_rootHead (atLevel p n) x).mpr
    (rootsMonotone p (show n ≤ n+1 by omega) hn)
  obtain ⟨k,rfl⟩ := hx
  obtain ⟨i,rfl⟩ := ZMod.intCast_surjective k
  refine ⟨n,AddSubgroup.mem_zmultiples_iff.mpr ⟨i,?_⟩⟩
  change i • (rootHead (atLevel p n)) 1 = _
  rw [← map_zsmul,zsmul_eq_mul,mul_one]

/-- Unbounded p-orders and finite p-torsion imply an actual embedded
complex-root model of the Prüfer group. -/
theorem prufer_embedding (hker : {x : G | p • x = 0}.Finite)
    (hunbounded : ∀ n : ℕ, ∃ j ≥ n, Nonempty (Level G p j)) :
    ∃ e : Additive (pRoots p) →+ G, Function.Injective e := by
  obtain ⟨f,ho,hd⟩ := coherent_generators hker hunbounded
  obtain ⟨e,hinj,_⟩ := glue_generators p (rootGen p) (fun n => f (n+1))
    (fun n => (rootGen_order p n).trans (ho _).symm) (rootGen_step p)
    (fun n => by simpa using hd (show n+1 ≤ (n+1)+1 by omega)) (rootGen_covers p)
  exact ⟨e,hinj⟩


/-- An element of exact order q realizes the cyclic transverse group. -/
theorem cyclic_embedding {q : ℕ} {g : G} (hg : addOrderOf g = q) :
    ∃ c : ZMod q →+ G, Function.Injective c := by
  let f : {f : ℤ →+ G // f q = 0} := ⟨zmultiplesHom G g,by
    change (q : ℤ) • g = 0
    rw [← addOrderOf_dvd_iff_zsmul_eq_zero,hg]⟩
  refine ⟨ZMod.lift q f,(ZMod.lift_injective (n:=q) (f:=f)).mpr ?_⟩
  intro i hi
  change i • g = 0 at hi
  exact (ZMod.intCast_zmod_eq_zero_iff_dvd _ _).mpr (hg ▸ addOrderOf_dvd_iff_zsmul_eq_zero.mpr hi)

theorem rootGen_torsion (x : Additive (pRoots p)) : ∃ n : ℕ, p^n • x = 0 := by
  obtain ⟨n,hn⟩ := rootGen_covers p x
  obtain ⟨i,rfl⟩ := AddSubgroup.mem_zmultiples_iff.mp hn
  exact ⟨n+1,by
    rw [← natCast_zsmul,smul_comm (M:=ℤ) (N:=ℤ),natCast_zsmul,← rootGen_order p n, addOrderOf_nsmul_eq_zero, zsmul_zero]⟩

/-- A Prüfer factor and an occurring different prime factor embed as their
actual direct product inside the original group. -/
theorem mixed_embedding {q : ℕ} [Fact q.Prime] (hpq : p ≠ q)
    (hker : {x : G | p • x = 0}.Finite)
    (hunbounded : ∀ n : ℕ, ∃ j ≥ n, Nonempty (Level G p j))
    (hq : ∃ g : G, addOrderOf g = q) :
    ∃ e : (Additive (pRoots p) × ZMod q) →+ G, Function.Injective e := by
  obtain ⟨ep,hep⟩ := prufer_embedding hker hunbounded
  obtain ⟨g,hg⟩ := hq
  obtain ⟨eqt,heq⟩ := cyclic_embedding hg
  let e := (ep.comp (AddMonoidHom.fst _ _)) + (eqt.comp (AddMonoidHom.snd _ _))
  refine ⟨e,(injective_iff_map_eq_zero e).mpr ?_⟩
  rintro ⟨x,t⟩ hz
  change ep x + eqt t = 0 at hz
  obtain ⟨n,hn⟩ := rootGen_torsion x
  have hpz : p^n • ep x = 0 := by rw [← map_nsmul, hn,map_zero]
  have hneg : ep x = -(eqt t) := eq_neg_of_add_eq_zero_left hz
  have hqz : q • ep x = 0 := by
    rw [hneg,smul_neg,← map_nsmul]
    simp [nsmul_eq_mul]
  have ho := Nat.eq_one_of_dvd_coprimes
    (((Nat.coprime_primes (Fact.out : p.Prime) (Fact.out : q.Prime)).mpr hpq).pow_left n)
    (addOrderOf_dvd_iff_nsmul_eq_zero.mpr hpz) (addOrderOf_dvd_iff_nsmul_eq_zero.mpr hqz)
  have hx : ep x = 0 := by simpa [ho] using addOrderOf_nsmul_eq_zero (ep x)
  have ht : eqt t = 0 := by simpa [hx] using hz
  exact Prod.ext (hep (hx.trans (map_zero _).symm)) (heq (ht.trans (map_zero _).symm))


/-- Excluding the elementary abelian square forces finite p-torsion.
Over F_p, two vectors on different lines give an additive copy of C_p × C_p. -/
theorem finite_kernel_of_no_square
    (nosq : ¬ ∃ c : (ZMod p × ZMod p) →+ G, Function.Injective c) :
    {x : G | p • x = 0}.Finite := by
  classical
  let K : AddSubgroup G := (p • AddMonoidHom.id G).ker
  change (K : Set G).Finite
  by_contra hi
  let _ : Infinite K := Set.infinite_coe_iff.mpr hi
  let _ : Module (ZMod p) K := AddCommGroup.zmodModule fun x => Subtype.ext x.property
  obtain ⟨a,ha⟩ := exists_ne (0 : K)
  let f := LinearMap.toSpanSingleton (ZMod p) K a
  obtain ⟨b,hb⟩ := (Set.finite_range (fun t : ZMod p => t • a)).exists_notMem
  let g := f.coprod (LinearMap.toSpanSingleton (ZMod p) K b)
  apply nosq
  refine ⟨K.subtype.comp g.toAddMonoidHom, Subtype.val_injective.comp
    ((injective_iff_map_eq_zero g.toAddMonoidHom).mpr ?_)⟩
  rintro ⟨s,t⟩ h
  change s • a + t • b = 0 at h
  by_cases ht : t = 0
  · subst t
    have hsa : s • a = 0 := by simpa using h
    have hs : s = 0 := by
      by_contra hs
      apply ha
      calc a = s⁻¹ • (s • a) := (inv_smul_smul₀ hs a).symm
           _ = 0 := by rw [hsa,smul_zero]
    exact Prod.ext hs rfl
  · exfalso
    apply hb
    refine ⟨-(t⁻¹*s),?_⟩
    change -(t⁻¹*s) • a = b
    rw [neg_smul,mul_smul,← smul_neg,← eq_neg_of_add_eq_zero_right h,inv_smul_smul₀ ht]

/-- The reduction expressed with primary components in the original group.
No countability or topology is needed in this algebraic step. -/
theorem rank_one_unbounded_mixed {q : ℕ} [Fact q.Prime] (hpq : p ≠ q)
    (nosq : ¬ ∃ c : (ZMod p × ZMod p) →+ G, Function.Injective c)
    (unbounded : ∀ n : ℕ, ∃ x ∈ AddCommGroup.primaryComponent G p, p^n • x ≠ 0)
    (other : ∃ y ∈ AddCommGroup.primaryComponent G q, y ≠ 0) :
    ∃ e : (Additive (pRoots p) × ZMod q) →+ G, Function.Injective e := by
  apply mixed_embedding hpq (finite_kernel_of_no_square nosq)
  · intro n
    obtain ⟨x,hx,hnot⟩ := unbounded n
    obtain ⟨j,hj⟩ := AddCommGroup.mem_primaryComponent_iff_addOrderOf.mp hx
    refine ⟨j,?_,⟨⟨x,hj⟩⟩⟩
    by_contra h
    exact hnot <| addOrderOf_dvd_iff_nsmul_eq_zero.mp (hj ▸ pow_dvd_pow _ (show j ≤ n by omega))
  · obtain ⟨y,hy,hy0⟩ := other
    obtain ⟨j,hj⟩ := AddCommGroup.mem_primaryComponent_iff_addOrderOf.mp hy
    have hpos : 1 ≤ j := by
      by_contra! h
      have hj0 : j = 0 := by omega
      exact hy0 (by simpa [hj,hj0] using addOrderOf_nsmul_eq_zero y)
    let x := descend (p:=q) hpos (⟨y,hj⟩ : Level G q j)
    exact ⟨x.val,by simpa using x.property⟩

end Primary
end KDClosure
