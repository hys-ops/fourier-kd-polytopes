import KDFourierHead
import Mathlib.Data.Nat.Prime.Int
namespace KDClosure
variable {p : ℕ} [Fact p.Prime]
/-- Every nonzero cyclic displacement generates the common order-p subgroup. -/
theorem step_in_orbit (n : ℕ) (h : ZMod (p^(n+1))) (hh : h ≠ 0) :
    ∃ i : ZMod (p^(n+1)), i*h = ((p^n : ℕ) : ZMod (p^(n+1))) := by
  let m := p^(n+1)
  let g := Nat.gcd h.val m
  have hd : g ∣ p^(n+1) := Nat.gcd_dvd_right _ _
  obtain ⟨k,hk,hg⟩ := (Nat.dvd_prime_pow (Fact.out : p.Prime)).mp hd
  have hkm : k ≠ n+1 := by
    intro e
    have hf : m ∣ h.val := by
      have := Nat.gcd_dvd_left h.val m
      rwa [show Nat.gcd h.val m = m from hg.trans (by rw [e])] at this
    apply hh
    simpa using (ZMod.natCast_eq_zero_iff h.val m).mpr hf
  have hk' : k ≤ n := by omega
  obtain ⟨l,hl⟩ : g ∣ p^n := hg ▸ pow_dvd_pow p hk'
  refine ⟨(l : ZMod m)*h⁻¹, ?_⟩
  calc
    (l : ZMod m)*h⁻¹*h = (l : ZMod m) * (h*h⁻¹) := by ring
    _ = (l : ZMod m) * (g : ZMod m) := by rw [ZMod.mul_inv_eq_gcd]
    _ = _ := by rw [← Nat.cast_mul, mul_comm l g, ← hl]

/-- A concrete admissible colouring. Its threshold is l full strips of width p^n. -/
def color (n l : ℕ) (x : ZMod (p^(n+1))) := x.val < l*p^n

theorem prime_color_both (n l : ℕ) (hl : 0 < l) (hlt : l < p) :
    Both (color (p:=p) n l) := by
  intro x h hh
  obtain ⟨i,hi⟩ := step_in_orbit n h hh
  let w := p^n
  let b := x.val % w
  let k := x.val / w
  let m := p^(n+1)
  have hw : 0 < w := pow_pos (Fact.out : Nat.Prime p).pos _
  have hb : b < w := Nat.mod_lt _ hw
  have hx : (x.val : ZMod m) = x := ZMod.natCast_zmod_val _
  have hn : b + k*w = x.val := by simpa [b,k,Nat.mul_comm] using Nat.mod_add_div x.val w
  have eqx : x = (b:ZMod m) + (k:ZMod m)*(w:ZMod m) := by
    rw [←hx, ← Nat.cast_mul, ← Nat.cast_add,hn]
  have hbase : x + (-(k:ZMod m)*i)*h = (b:ZMod m) := by
    rw [eqx, mul_assoc,hi]; ring
  have hupper : x + (((l:ZMod m)-(k:ZMod m))*i)*h = ((b+l*w : ℕ):ZMod m) := by
    rw [eqx,mul_assoc,hi]; simp only [Nat.cast_add, Nat.cast_mul]; change (b:ZMod m)+k*w + ((l:ZMod m)-k)*w = b+l*w; ring
  have hm : m=w*p := pow_succ p n
  have bl : b < l*w := lt_of_lt_of_le hb (by simpa using Nat.mul_le_mul_right w hl)
  have top : b+l*w < m := by
    rw [hm, mul_comm w p]
    calc b+l*w < w+l*w := Nat.add_lt_add_right hb _
         _ = (l+1)*w := by ring
         _ ≤ p*w := Nat.mul_le_mul_right w hlt
  constructor
  · refine ⟨-(k:ZMod m)*i, ?_⟩
    rw [hbase]; unfold color
    rwa [ZMod.val_natCast_of_lt (by omega : b<m)]
  · refine ⟨((l:ZMod m)-(k:ZMod m))*i, ?_⟩
    rw [hupper]; unfold color
    rw [ZMod.val_natCast_of_lt top]
    change ¬ b+l*w < l*w
    omega
end KDClosure
