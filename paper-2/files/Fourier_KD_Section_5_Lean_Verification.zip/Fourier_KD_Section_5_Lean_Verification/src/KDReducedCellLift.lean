import KDReducedProjection
import KDChainLimitBlockHull
import KDChainLimitMixtures
noncomputable section
namespace KDClosure.ReducedWindows
open MeasureTheory CompactCore CompactCoset ChainLimit LCAQuotient Set
open scoped Classical BigOperators InnerProductSpace ComplexOrder ENNReal KDClosure.SubgroupMeasure
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
variable (H K : CO G)
def sectionEmb : CoreQuot H K →+ Q H :=
  QuotientAddGroup.lift _ ((π H).comp (subgroup K).subtype) fun _z hz =>
    (QuotientAddGroup.eq_zero_iff _).mpr hz

omit [IsTopologicalAddGroup G] in
theorem sectionEmb_rep (i : CoreQuot H K) : sectionEmb H K i=π H (representative H K i:G) := by
  conv_lhs => rw [←representative_spec H K i]
  rfl

omit [IsTopologicalAddGroup G] in
theorem sectionEmb_inj : Function.Injective (sectionEmb H K) := by
  rintro i j eqn
  rw [sectionEmb_rep,sectionEmb_rep] at eqn
  have sub : (representative H K i:G)-(representative H K j:G)∈H.val :=
    QuotientAddGroup.eq_iff_sub_mem.mp eqn
  rw [←representative_spec H K i,←representative_spec H K j]
  exact QuotientAddGroup.eq_iff_sub_mem.mpr sub

abbrev I (H K : CO G) := Multiplicative (CoreQuot H K)
def mEmb : I H K →* Qm H := (sectionEmb H K).toMultiplicative
def ixEmb : I H K ↪ Qm H := ⟨mEmb H K,sectionEmb_inj H K⟩

variable [MeasurableSpace G] [BorelSpace G] [MeasurableAdd G] [T2Space G] [SecondCountableTopology G]
  (μ : Measure G) [μ.IsAddHaarMeasure] [SFinite μ]

def embedCells : Discrete.L2 (I H K) →ₗᵢ[ℂ] Lp ℂ 2 μ :=
  (LCAQuotient.inclusion μ H).comp (DiscreteEmbedding.inclusion (ixEmb H K))

omit [T2Space G] [SecondCountableTopology G] [SFinite μ] in
theorem embed_single (i : CoreQuot H K) :
    embedCells H K μ (lp.single 2 (.ofAdd i) 1)=normalizedCell H K μ 0 1 i := by
  change LCAQuotient.inclusion μ H (DiscreteEmbedding.inclusion (ixEmb H K) (lp.single 2 (.ofAdd i) 1))=_
  rw [DiscreteEmbedding.inclusion_single]
  change LCAQuotient.inclusion μ H (lp.single 2 (sectionEmb H K i) 1)=_
  rw [LCAQuotient.inclusion_single,one_smul,sectionEmb_rep]
  apply Lp.ext
  filter_upwards [normalizedCell_ae H K μ 0 1 i] with x hx
  change _=(normalizedCell H K μ 0 1 i) x
  rw [hx]
  change _ = (((1:LCAReality.Dual G) (Multiplicative.ofAdd x)):ℂ)* atom μ H (π H (0+(representative H K i:G))) x
  simp

omit [T2Space G] [MeasurableAdd G] [SecondCountableTopology G] [SFinite μ] in
theorem normalized_vector (F : Filtration G) (n : ℕ) (i : Idx F n) :
    normalizedCell (F.L n) (F.K n) μ 0 1 i =
      (scale μ (F.L n):ℂ) • vector F μ n i := by
  unfold normalizedCell
  congr 1
  apply Lp.ext
  filter_upwards [cellVector_ae (F.L n) (F.K n) μ 0 1 i,
    (indicatorConstLp_coeFn (μ:=μ) (s:=cell F n i) (p:=2) (c:=(1:ℂ))
      (hs:=coset_meas _ _) (hμs:=(coset_compact _ _).measure_ne_top))] with x h h'
  change _ = indicatorConstLp 2 _ _ (1:ℂ) x
  rw [h,h']
  have one : (LCAReality.phase (1:LCAReality.Dual G))=fun _ => (1:ℂ) := funext fun _ => rfl
  simp [region,one]

omit [T2Space G] [SecondCountableTopology G] [SFinite μ] in
theorem span_cells (F : Filtration G) (n : ℕ) :
    LinearMap.range (embedCells (F.L n) (F.K n) μ).toLinearMap = window F μ n := by
  let H := F.L n
  let K := F.K n
  let J := embedCells H K μ
  let _ : Finite (I H K) := finite_core H K
  let _ : Fintype (I H K) := Fintype.ofFinite _
  have eq (i : I H K) : J (lp.single 2 i 1)=(scale μ H:ℂ) • vector F μ n i.toAdd :=
    (embed_single H K μ i.toAdd).trans (normalized_vector μ F n i.toAdd)
  apply le_antisymm
  · rintro _ ⟨f,rfl⟩
    have sm := (lp.hasSum_single (p:=2) (by norm_num) f).tsum_eq
    rw [tsum_fintype] at sm
    change J f ∈ window F μ n
    rw [←sm,map_sum]
    apply Submodule.sum_mem
    intro i _
    have lin : lp.single 2 i (f i) = f i • (lp.single 2 i (1:ℂ) : Discrete.L2 (I H K)) := by
      rw [←lp.single_smul]; simp
    rw [lin,map_smul,eq]
    exact (window F μ n).smul_mem _ ((window F μ n).smul_mem _ (Submodule.subset_span (mem_range_self _)))
  · apply Submodule.span_le.mpr
    rintro _ ⟨i,rfl⟩
    have nz : (scale μ H:ℂ) ≠ 0 := by
      have hp : 0<μ.real (H.val:Set G) := ENNReal.toReal_pos (H.val.isOpen.measure_pos μ ⟨0,H.val.zero_mem⟩).ne' H.property.measure_ne_top
      exact_mod_cast (inv_ne_zero (Real.sqrt_pos.mpr hp).ne' : (Real.sqrt (μ.real (H.val:Set G)))⁻¹≠0)
    refine ⟨(scale μ H:ℂ)⁻¹ • lp.single 2 (.ofAdd i) 1,?_⟩
    change J ((scale μ H:ℂ)⁻¹ • _)=_
    rw [map_smul,eq,smul_smul,inv_mul_cancel₀ nz,one_smul]
    rfl

end KDClosure.ReducedWindows
