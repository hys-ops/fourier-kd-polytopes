import KDCoreOrder
import Mathlib.Topology.Compactness.Bases

noncomputable section
namespace KDClosure.ReducedWindows
open CompactCore ActualCore Set Topology Filter
variable {X : Type*} [AddCommGroup X] [TopologicalSpace X] [IsTopologicalAddGroup X]

omit [IsTopologicalAddGroup X] in
/-- In a second-countable space all compact-open subgroups can be enumerated:
their carriers are finite unions in a single countable topological basis. -/
theorem countable_opens [SecondCountableTopology X] : Countable (CO X) := by
  classical
  let b := TopologicalSpace.countableBasis X
  have encode (K : CO X) : ∃ s : Finset b, (K.val : Set X)=(s:Set b).sUnion :=
    eq_sUnion_finset_of_isTopologicalBasis_of_isCompact_open b (TopologicalSpace.isBasis_countableBasis X)
      (K.val:Set X) K.property K.val.isOpen
  choose f rep using encode
  have hi : Function.Injective f := by
    intro K H eqn
    exact Subtype.ext (SetLike.ext' ((rep K).trans (eqn ▸ (rep H).symm)))
  exact hi.countable

private def lower (a : ℕ → CO X) : ℕ → CO X
  | 0 => a 0
  | n+1 => meet (lower a n) (a (n+1))
private def upper (a : ℕ → CO X) : ℕ → CO X
  | 0 => a 0
  | n+1 => join (upper a n) (a (n+1))
private theorem lower_anti (a : ℕ → CO X) : Antitone (lower a) :=
  antitone_nat_of_succ_le fun _ => (inf_le_left : (_ ⊓ _ : OpenAddSubgroup X) ≤ _)
private theorem upper_mono (a : ℕ → CO X) : Monotone (upper a) :=
  monotone_nat_of_le_succ fun _ => (le_sup_left : (_ : OpenAddSubgroup X) ≤ _ ⊔ _)
private theorem lower_le (a : ℕ → CO X) (n : ℕ) : lower a n≤a n := by
  cases n with
  | zero => rfl
  | succ n => exact (inf_le_right : (_ ⊓ _ : OpenAddSubgroup X) ≤ _)
private theorem le_upper (a : ℕ → CO X) (n : ℕ) : a n≤upper a n := by
  cases n with
  | zero => rfl
  | succ n => exact (le_sup_right : (_ : OpenAddSubgroup X) ≤ _ ⊔ _)

structure Filtration (X : Type*) [AddCommGroup X] [TopologicalSpace X] [IsTopologicalAddGroup X] where
  L : ℕ → CO X
  K : ℕ → CO X
  down : Antitone L
  up : Monotone K
  within : ∀ n,L n≤K n
  cover : ∀ x : X,∃ n,x∈(K n).val
  small : ∀ V ∈ 𝓝 (0:X), ∃ n, ((L n).val:Set X) ⊆ V

private theorem small_of_separates (L : ℕ → CO X) (down : Antitone L)
    (sep : ∀ x : X, x≠0 → ∃ n,x∉(L n).val) (V : Set X) (hv : V∈𝓝 (0:X)) :
    ∃ n,((L n).val:Set X) ⊆ V := by
  obtain ⟨W,wV,wo,zw⟩ := mem_nhds_iff.mp hv
  have cp := (L 0).property.inter_right wo.isClosed_compl
  let T (n : ℕ) := ((L n).val : Set X)ᶜ
  have d : Directed (·⊆·) T := fun i j => ⟨max i j,compl_subset_compl.mpr (down (le_max_left _ _)),
    compl_subset_compl.mpr (down (le_max_right _ _))⟩
  have hs : ((L 0).val : Set X) ∩ Wᶜ ⊆ ⋃ i, T i := by
    intro x hx; exact mem_iUnion.mpr (sep x (fun he => hx.2 (he ▸ zw)))
  obtain ⟨n,hn⟩ := cp.elim_directed_cover T (fun i => (L i).val.isClosed.isOpen_compl) hs d
  refine ⟨n,fun x hx => wV ?_⟩
  by_contra hw
  exact hn ⟨down (Nat.zero_le n) hx,hw⟩ hx

private theorem from_family {I : Type*} [Countable I] [Nonempty I] (a : I → CO X)
    (cover : ∀ x : X,∃ i,x∈(a i).val) (sep : ∀ x : X, x≠0 → ∃ i,x∉(a i).val) :
    Nonempty (Filtration X) := by
  obtain ⟨u,hu⟩ := exists_surjective_nat I
  let f := a ∘ u
  refine ⟨⟨lower f,upper f,lower_anti f,upper_mono f,
    fun n => (lower_le f n).trans (le_upper f n),?_,small_of_separates _ (lower_anti f) ?_⟩⟩
  · intro x; obtain ⟨i,hi⟩ := cover x; obtain ⟨n,rfl⟩ := hu i
    exact ⟨n,le_upper f n hi⟩
  · intro x hx; obtain ⟨i,hi⟩ := sep x hx; obtain ⟨n,rfl⟩ := hu i
    exact ⟨n,fun h => hi (lower_le f n h)⟩

/-- Concrete cofinal finite windows in the actual reduced group U/(⋂K),
with both directions free and without a discrete or compact assumption on it. -/
theorem reduced_filtration (G : Type*) [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
    [SecondCountableTopology G] [Nonempty (CO G)] : Nonempty (Filtration (C G)) := by
  let _ : Countable (CO G) := countable_opens
  exact from_family (block G) (block_cover G) (fun x hx => blocks_separate G hx)

end KDClosure.ReducedWindows
