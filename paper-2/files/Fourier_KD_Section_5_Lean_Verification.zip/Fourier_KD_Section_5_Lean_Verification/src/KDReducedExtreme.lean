import KDReducedWOT
import KDChainLimitEndpoint

noncomputable section
namespace KDClosure.ReducedWindows
open MeasureTheory CompactCore CompactCoset LCAQuotient Set Topology
open scoped ComplexOrder KDClosure.SubgroupMeasure
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
  [T2Space G] [MeasurableSpace G] [BorelSpace G] [SecondCountableTopology G]
  (μ : Measure G) [μ.IsAddHaarMeasure] [SigmaFinite μ]
  (ν : Measure (LCAReality.Dual G)) [ν.IsHaarMeasure] [SFinite ν]
  (F : LCAReality.FourierRealization μ ν)

/-- On an actual two-sided compact-open filtration a physical extreme has rank
at most one, including when the group is neither compact nor discrete. -/
theorem rank_le_one (W : Filtration G) (chain : ∀ P Q : CO G,P≤Q ∨ Q≤P)
    {T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ} (ex : T∈(ambientStates μ ν F).extremePoints ℝ) :
    Module.rank ℂ (LinearMap.range T.toLinearMap)≤1 :=
  ChainLimit.Kernel.rank_le_one_of_tendsto μ ν F ex (A:=fun n => sandwich μ W n T)
    (physical_projection_hull μ ν F W chain T ex.1) (sandwich_WOT μ W T)

theorem no_infinite (W : Filtration G) (chain : ∀ P Q : CO G,P≤Q ∨ Q≤P) :
    ¬HasInfiniteExtreme μ ν F := by
  rintro ⟨T,ex,inf⟩
  exact inf (Module.rank_lt_aleph0_iff.mp ((rank_le_one μ ν F W chain ex).trans_lt (by norm_num)))

section Core
variable (X : Type*) [AddCommGroup X] [TopologicalSpace X] [IsTopologicalAddGroup X]
  [SecondCountableTopology X] [Nonempty (CO X)]
local instance : IsClosed (ActualCore.allK X : Set (ActualCore.base X)) := ActualCore.allK_closed X
local instance : SecondCountableTopology (ActualCore.C X) :=
  by
    let _ : SecondCountableTopology (ActualCore.base X) := TopologicalSpace.secondCountableTopology_induced _ X (fun x : ActualCore.base X => (x:X))
    exact (QuotientAddGroup.isQuotientMap_mk _).secondCountableTopology QuotientAddGroup.isOpenMap_coe
local instance : MeasurableSpace (ActualCore.C X) := borel _
local instance : BorelSpace (ActualCore.C X) := ⟨rfl⟩

omit [SecondCountableTopology X] in
theorem core_chain (chain : ∀ P Q : CO X,P≤Q ∨ Q≤P) :
    ∀ P Q : CO (ActualCore.C X), P≤Q ∨ Q≤P := by
  rintro P Q
  obtain ⟨A,rfl⟩ := ActualCore.block_surjective X P
  obtain ⟨B,rfl⟩ := ActualCore.block_surjective X Q
  exact (chain A B).imp ((ActualCore.block_le_iff X _ _).mpr) ((ActualCore.block_le_iff X _ _).mpr)

/-- Chain necessity on the canonical reduced group U/(intersection of all K).
Every compact-open subgroup and its placement in the filtration is derived
from the original ambient group. -/
theorem core_rank_le_one
    (η : Measure (ActualCore.C X)) [η.IsAddHaarMeasure]
    (ζ : Measure (LCAReality.Dual (ActualCore.C X))) [ζ.IsHaarMeasure] [SFinite ζ]
    (J : LCAReality.FourierRealization η ζ) (chain : ∀ P Q : CO X,P≤Q ∨ Q≤P)
    {T : Lp ℂ 2 η →L[ℂ] Lp ℂ 2 η} (ex : T∈(ambientStates η ζ J).extremePoints ℝ) :
    Module.rank ℂ (LinearMap.range T.toLinearMap)≤1 :=
  by
  let W := Classical.choice (reduced_filtration X)
  let _ : IsLocallyFiniteMeasure η := locallyFinite W η
  let _ : SigmaCompactSpace (ActualCore.C X) := ⟨⟨fun n => ((W.K n).val : Set _),fun n => (W.K n).property,iUnion_eq_univ_iff.mpr W.cover⟩⟩
  exact rank_le_one η ζ J W (core_chain X chain) ex

end Core
end KDClosure.ReducedWindows
