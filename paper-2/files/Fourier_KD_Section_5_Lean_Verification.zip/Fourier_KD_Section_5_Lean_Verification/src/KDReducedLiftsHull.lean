import KDReducedCellLift
import KDLCAQuotientState
noncomputable section
namespace KDClosure.ReducedWindows
open MeasureTheory CompactCore CompactCoset ChainLimit LCAQuotient Set Discrete Matrix
open scoped Classical BigOperators InnerProductSpace ComplexOrder ENNReal KDClosure.SubgroupMeasure
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
    [MeasurableSpace G] [BorelSpace G] [MeasurableAdd G] [T2Space G] [SecondCountableTopology G]
    (μ : Measure G) [SFinite μ] [μ.IsAddHaarMeasure] (ν : Measure (LCAReality.Dual G))
    [SFinite ν] [ν.IsHaarMeasure]
abbrev generators (F : LCAReality.FourierRealization μ ν) :=
  insert (0:Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ) {S | S ∈ ambientStates μ ν F ∧ Module.rank ℂ (LinearMap.range S.toLinearMap) ≤ 1}

variable (H K : CO G)
local instance : Fintype (CoreQuot H K) := @Fintype.ofFinite _ (finite_core H K)
local instance : DiscreteTopology (Qm H) := QuotientGroup.discreteTopology (openMul H).isOpen
local instance : Countable (Qm H) := DiscreteReduction.countable H

omit [T2Space G] in
/-- Every pure matrix on the finite quotient section has a literal
rank-at-most-one, trace-one physical KD lift; the discrete intermediate
operator has the exact padded entries. -/
theorem lift_pure (F : LCAReality.FourierRealization μ ν) (P : Matrix (CoreQuot H K) (CoreQuot H K) ℂ)
    (hp : P∈ChainLimit.Finite.pureSet (CoreQuot H K)) :
    ∃ R : Discrete.L2 (Qm H) →L[ℂ] Discrete.L2 (Qm H),
      entries R = pad (⟨fun i => mEmb H K (.ofAdd i),sectionEmb_inj H K⟩ : CoreQuot H K ↪ Qm H) P ∧
      LCAQuotient.push μ H R ∈ generators μ ν F := by
  classical
  obtain ⟨R,st,eqn⟩ := pad_pure_state (mEmb H K) (sectionEmb_inj H K) P hp
  refine ⟨R,eqn,Set.mem_insert_of_mem _ ⟨(LCAQuotient.push_mem_iff μ ν H F R).mp st,?_⟩⟩
  have low : Module.rank ℂ (LinearMap.range R.toLinearMap) ≤ 1 := by
    apply (minors_iff_operator_rank_le_one R).mp
    obtain ⟨v,hv,_⟩ := hp
    rw [eqn,hv]
    exact padded_outer_minors _ _
  let J : Discrete.L2 (Qm H) →L[ℂ] Lp ℂ 2 μ := (LCAQuotient.inclusion μ H).toContinuousLinearMap
  have iso := IsometricSupport.rangeEquiv J (LCAQuotient.inclusion μ H).isometry R
  exact iso.rank_eq ▸ low

omit [T2Space G] in
/-- Lift the whole matrix convex hull, retaining individual normalized
physical generators and a single zero for subnormalization. -/
theorem padded_hull (F : LCAReality.FourierRealization μ ν) (P : Matrix (CoreQuot H K) (CoreQuot H K) ℂ)
    (hp : P ∈ convexHull ℝ (insert 0 (ChainLimit.Finite.pureSet (CoreQuot H K)))) :
    ∃ R : Discrete.L2 (Qm H) →L[ℂ] Discrete.L2 (Qm H),
      entries R = pad (⟨fun i => mEmb H K (.ofAdd i),sectionEmb_inj H K⟩ : CoreQuot H K ↪ Qm H) P ∧
      LCAQuotient.push μ H R ∈ convexHull ℝ (generators μ ν F) := by
  classical
  let e : CoreQuot H K ↪ Qm H := ⟨fun i => mEmb H K (.ofAdd i),sectionEmb_inj H K⟩
  let good : Set (Matrix (CoreQuot H K) (CoreQuot H K) ℂ) :=
    {P | ∃ R : Discrete.L2 (Qm H) →L[ℂ] Discrete.L2 (Qm H), entries R=pad e P ∧
        LCAQuotient.push μ H R ∈ convexHull ℝ (generators μ ν F)}
  have cv : Convex ℝ good := by
    rintro A ⟨R,hR,rR⟩ B ⟨S,hS,rS⟩ a b ha hb ab
    refine ⟨a • R+b • S,?_,?_⟩
    · simp only [map_add,map_smul,hR,hS]
    · have lin : LCAQuotient.push μ H (a • R+b • S)=a • LCAQuotient.push μ H R+b • LCAQuotient.push μ H S := by
        ext z : 1
        let J : Discrete.L2 (Qm H) →L[ℂ] Lp ℂ 2 μ := (LCAQuotient.inclusion μ H).toContinuousLinearMap
        change J (a • R (J.adjoint z)+b • S (J.adjoint z))=a • J (R (J.adjoint z))+b • J (S (J.adjoint z))
        rw [J.map_add,J.map_smul_of_tower,J.map_smul_of_tower]
      rw [lin]; exact (convex_convexHull _ _) rR rS ha hb ab
  apply convexHull_min ?_ cv hp
  rintro A (rfl|pure)
  · refine ⟨0,by simp,subset_convexHull _ _ ?_⟩
    change (LCAQuotient.push μ H 0) ∈ generators μ ν F
    have z : LCAQuotient.push μ H 0=0 := by ext f : 1; simp [LCAQuotient.push,IsometricSupport.lift]
    rw [z]; exact mem_insert _ _
  · obtain ⟨R,eqn,st⟩ := lift_pure μ ν H K F A pure
    exact ⟨R,eqn,subset_convexHull _ _ st⟩
end KDClosure.ReducedWindows
