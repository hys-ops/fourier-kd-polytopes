import KDReducedLiftsHull
noncomputable section
namespace KDClosure.ReducedWindows
open MeasureTheory CompactCore CompactCoset ChainLimit LCAQuotient Set Discrete Matrix IsometricSupport
open scoped Classical BigOperators InnerProductSpace ComplexOrder ENNReal KDClosure.SubgroupMeasure
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
    [MeasurableSpace G] [BorelSpace G] [MeasurableAdd G] [SecondCountableTopology G]
    (μ : Measure G) [SFinite μ] [μ.IsAddHaarMeasure] (ν : Measure (LCAReality.Dual G))
    [SFinite ν] [ν.IsHaarMeasure]
variable (H K : CO G)
local instance : Fintype (CoreQuot H K) := @Fintype.ofFinite _ (finite_core H K)
local instance : DiscreteTopology (Qm H) := QuotientGroup.discreteTopology (openMul H).isOpen
local instance : Countable (Qm H) := DiscreteReduction.countable H
local notation "E" => Lp ℂ 2 μ
abbrev frame := (embedCells H K μ).toContinuousLinearMap

omit [SecondCountableTopology G] [SFinite μ] in
theorem block_entries (T : E →L[ℂ] E) (i j : I H K) :
    entries (compress (frame μ H K) T) (i,j)=normalizedBlock H K μ T 0 1 i.toAdd j.toAdd := by
  change inner ℂ (lp.single 2 i 1) ((frame μ H K).adjoint (T ((frame μ H K) (lp.single 2 j 1))))=_
  rw [(frame μ H K).adjoint_inner_right]
  change inner ℂ (embedCells H K μ (lp.single 2 i 1)) (T (embedCells H K μ (lp.single 2 j 1)))=_
  exact congrArg₂ (fun a b : E => inner ℂ a (T b)) (embed_single H K μ i.toAdd) (embed_single H K μ j.toAdd)

omit [SecondCountableTopology G] [SFinite μ] in
theorem pad_entries (T : E →L[ℂ] E) :
    entries (DiscreteEmbedding.push (ixEmb H K) (compress (frame μ H K) T)) =
    pad (⟨fun i => mEmb H K (.ofAdd i),sectionEmb_inj H K⟩ : CoreQuot H K ↪ Qm H)
      (normalizedBlock H K μ T 0 1) := by
  let e : I H K ↪ Qm H := ixEmb H K
  let a : CoreQuot H K ↪ Qm H := ⟨fun i => mEmb H K (.ofAdd i),sectionEmb_inj H K⟩
  funext z
  obtain ⟨x,y⟩ := z
  by_cases hx : x∈range e
  · obtain ⟨i,rfl⟩ := hx
    by_cases hy : y∈range e
    · obtain ⟨j,rfl⟩ := hy
      exact ((DiscreteEmbedding.entries_on e _ _ _).trans (block_entries μ H K T i j)).trans
        (pad_on a _ i.toAdd j.toAdd).symm
    · exact (DiscreteEmbedding.entries_off_right e _ _ _ hy).trans (pad_off_right a _ _ _ hy).symm
  · exact (DiscreteEmbedding.entries_off_left e _ _ _ hx).trans (pad_off_left a _ _ _ hx).symm

/-- Central lift of a certified finite block is an explicit physical sub-mixture.
This variant allows the finite matrix to be obtained from another state's
translation or modulation. -/
theorem sandwich_of_block_hull (F : LCAReality.FourierRealization μ ν) (T : E →L[ℂ] E)
    (inHull : normalizedBlock H K μ T 0 1 ∈ convexHull ℝ (insert 0 (ChainLimit.Finite.pureSet (CoreQuot H K)))) :
    lift (frame μ H K) (compress (frame μ H K) T) ∈ convexHull ℝ (generators μ ν F) := by
  obtain ⟨R,er,hin⟩ := padded_hull μ ν H K F _ inHull
  have he := entries_injective ((pad_entries μ H K T).trans er.symm)
  rw [←he] at hin
  have eqn : LCAQuotient.push μ H (DiscreteEmbedding.push (ixEmb H K) (compress (frame μ H K) T)) =
    lift (frame μ H K) (compress (frame μ H K) T) := by
    let A : Discrete.L2 (I H K) →L[ℂ] Discrete.L2 (Qm H) := (DiscreteEmbedding.inclusion (ixEmb H K)).toContinuousLinearMap
    let B : Discrete.L2 (Qm H) →L[ℂ] E := (LCAQuotient.inclusion μ H).toContinuousLinearMap
    change B ∘L (A ∘L _ ∘L A.adjoint) ∘L B.adjoint = (B ∘L A) ∘L _ ∘L (B ∘L A).adjoint
    rw [ContinuousLinearMap.adjoint_comp]
    rfl
  exact (congrArg (fun S => S∈convexHull ℝ (generators μ ν F)) eqn).mp hin

section Isometry
variable {V W : Type*} [NormedAddCommGroup V] [NormedAddCommGroup W]
    [InnerProductSpace ℂ V] [InnerProductSpace ℂ W] [CompleteSpace V] [CompleteSpace W]
theorem projector_apply (i : V →ₗᵢ[ℂ] W) [(LinearMap.range i.toLinearMap).HasOrthogonalProjection] (x : W) :
    (LinearMap.range i.toLinearMap).starProjection x=i (i.toContinuousLinearMap.adjoint x) := by
  apply (LinearMap.range i.toLinearMap).eq_starProjection_of_mem_of_inner_eq_zero ⟨_,rfl⟩
  rintro _ ⟨y,rfl⟩
  change inner ℂ (x-i (i.toContinuousLinearMap.adjoint x)) (i y)=0
  rw [inner_sub_left,i.inner_map_map]
  exact sub_eq_zero.mpr (i.toContinuousLinearMap.adjoint_inner_left y x).symm
end Isometry

variable (F : LCAReality.FourierRealization μ ν) (W : Filtration G)
theorem physical_projection_hull (chain : ∀ P Q : CO G,P≤Q ∨ Q≤P)
    (T : E →L[ℂ] E) (state : T ∈ ambientStates μ ν F) (n : ℕ) :
    (window W μ n).starProjection ∘L T ∘L (window W μ n).starProjection ∈
      convexHull ℝ (generators μ ν F) := by
  let Jn := embedCells (W.L n) (W.K n) μ
  have inc := sandwich_of_block_hull μ ν (W.L n) (W.K n) F T
    (normalizedBlock_hull (W.L n) (W.K n) μ ν F T state (W.within n) chain 0 1)
  have ran : LinearMap.range Jn.toLinearMap=window W μ n := span_cells μ W n
  let _ : (LinearMap.range Jn.toLinearMap).HasOrthogonalProjection := ran.symm ▸ inferInstanceAs ((window W μ n).HasOrthogonalProjection)
  have f (x : E) : (window W μ n).starProjection x=Jn (Jn.toContinuousLinearMap.adjoint x) := by
    simpa only [ran] using projector_apply Jn x
  convert inc using 1
  ext x : 1
  change (window W μ n).starProjection (T ((window W μ n).starProjection x))=_
  rw [f,f]
  rfl

end KDClosure.ReducedWindows
