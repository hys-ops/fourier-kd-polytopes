import KDReducedPartialCells

noncomputable section
namespace KDClosure.ReducedWindows
open MeasureTheory CompactCore LCAQuotient Set Filter Topology
open scoped InnerProductSpace KDClosure.SubgroupMeasure
section Hilbert
variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E] [CompleteSpace E]

abbrev closedSup (V : ℕ → Submodule ℂ E) := (⨆ n,V n).topologicalClosure

/-- An increasing family of closed Hilbert subspaces can exhaust only part
of the ambient space. The true projection limit is the closed supremum. -/
theorem tendsto_sup_projection (V : ℕ→Submodule ℂ E) [∀ n,(V n).HasOrthogonalProjection]
    (mono : Monotone V) (x : E) :
    Tendsto (fun n => (V n).starProjection x) atTop (𝓝 ((closedSup V).starProjection x)) := by
  let Q := closedSup V
  have hle (n:ℕ) : V n≤Q := (le_iSup V n).trans (⨆ n,V n).le_topologicalClosure
  have hc : Q.starProjection x ∈ closure ((⨆ n,V n : Submodule ℂ E) : Set E) :=
    Q.starProjection_apply_mem x
  have eqn (n:ℕ) : (V n).starProjection (Q.starProjection x)=(V n).starProjection x :=
    DFunLike.congr_fun (Submodule.starProjection_comp_starProjection_of_le (hle n)) x
  rw [Metric.tendsto_nhds]
  intro ε ep
  obtain ⟨z,hz,near⟩ := Metric.mem_closure_iff.mp hc (ε/2) (by linarith)
  obtain ⟨k,hk⟩ := (Submodule.mem_iSup_of_directed _ mono.directed_le).mp hz
  filter_upwards [eventually_ge_atTop k] with n hn
  have fix := (V n).starProjection_eq_self_iff.mpr (mono hn hk)
  have lip := (V n).lipschitzWith_starProjection.dist_le_mul (Q.starProjection x) z
  rw [fix,eqn] at lip
  simp only [NNReal.coe_one,one_mul] at lip
  calc dist ((V n).starProjection x) (Q.starProjection x) ≤ dist ((V n).starProjection x) z+dist z (Q.starProjection x) := dist_triangle _ _ _
       _ < ε := by rw [dist_comm z (Q.starProjection x)]; linarith

theorem partial_WOT (V : ℕ→Submodule ℂ E) [∀ n,(V n).HasOrthogonalProjection]
    (mono : Monotone V) (T : E →L[ℂ] E) (pos : T.IsPositive)
    (capture : ∀ x, Tendsto (fun n => (V n).starProjection (T x)) atTop (𝓝 (T x)))
    (x y : E) :
    Tendsto (fun n => inner ℂ x ((V n).starProjection (T ((V n).starProjection y))))
      atTop (𝓝 (inner ℂ x (T y))) := by
  let Q := closedSup V
  have fix (z:E) : Q.starProjection (T z)=T z :=
    tendsto_nhds_unique (tendsto_sup_projection V mono (T z)) (capture z)
  have comp (z:E) : T (Q.starProjection z)=T z := by
    apply ext_inner_left ℂ; intro u
    rw [←pos.inner_left_eq_inner_right,←Q.inner_starProjection_left_eq_right,fix,pos.inner_left_eq_inner_right]
  have h := (tendsto_sup_projection V mono x).inner (𝕜:=ℂ)
    (T.continuous.continuousAt.tendsto.comp (tendsto_sup_projection V mono y))
  change Tendsto _ _ (𝓝 (inner ℂ (Q.starProjection x) (T (Q.starProjection y)))) at h
  rw [comp,Q.inner_starProjection_left_eq_right,fix] at h
  exact h.congr' (Eventually.of_forall fun n => (V n).inner_starProjection_left_eq_right _ _)
end Hilbert

variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
    [MeasurableSpace G] [BorelSpace G] [SecondCountableTopology G]
    (μ : Measure G) [μ.IsAddHaarMeasure] [SigmaFinite μ]
    (ν : Measure (LCAReality.Dual G)) [ν.IsHaarMeasure] [SFinite ν]
    (F : LCAReality.FourierRealization μ ν)
local notation "E" => Lp ℂ 2 μ

theorem partial_projection_hull (H K : CO G) (hk : H≤K) (chain : ∀ P Q : CO G,P≤Q ∨ Q≤P)
    {T : E →L[ℂ] E} (state : T∈ambientStates μ ν F) :
    (cellSpace μ H K).starProjection ∘L T ∘L (cellSpace μ H K).starProjection ∈
      convexHull ℝ (generators μ ν F) := by
  have inc := sandwich_of_block_hull μ ν H K F T
    (ChainLimit.normalizedBlock_hull H K μ ν F T state hk chain 0 1)
  convert inc using 1
  ext x : 1
  change (cellSpace μ H K).starProjection (T ((cellSpace μ H K).starProjection x))=_
  rw [projector_apply,projector_apply]
  rfl

/-- Capture of the operator range suffices; position and frequency sectors
outside these central finite cells are allowed to remain in the Hilbert space. -/
theorem partial_rank_le_one (W : ManyOpen.Windows G) (chain : ∀ P Q : CO G,P≤Q ∨ Q≤P)
    {T : E →L[ℂ] E} (ex : T∈(ambientStates μ ν F).extremePoints ℝ)
    (capture : ∀ x, Tendsto (fun n => (cellSpace μ (W.L n) (W.K n)).starProjection (T x))
      atTop (𝓝 (T x))) : Module.rank ℂ (LinearMap.range T.toLinearMap)≤1 := by
  let V (n:ℕ) := cellSpace μ (W.L n) (W.K n)
  have mono : Monotone V := fun i j ij => cellSpace_mono μ (W.within i) (W.within j) (W.down ij) (W.up ij)
  exact ChainLimit.Kernel.rank_le_one_of_tendsto μ ν F ex
    (A:=fun n => (V n).starProjection ∘L T ∘L (V n).starProjection)
    (fun n => partial_projection_hull μ ν F _ _ (W.within n) chain ex.1)
    (partial_WOT V mono T ex.1.1 capture)

end KDClosure.ReducedWindows
