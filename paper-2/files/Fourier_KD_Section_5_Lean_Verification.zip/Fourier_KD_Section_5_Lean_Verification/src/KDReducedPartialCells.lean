import KDReducedExtreme
import KDManyAmbientWindows

noncomputable section
namespace KDClosure.ReducedWindows
open MeasureTheory Set Filter Topology CompactCore CompactCoset LCAQuotient DiscreteEmbedding
open scoped Classical KDClosure.SubgroupMeasure
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
    [MeasurableSpace G] [BorelSpace G] [MeasurableAdd G] [SecondCountableTopology G]
    (μ : Measure G) [μ.IsAddHaarMeasure]

abbrev cellSpace (H K : CO G) := LinearMap.range (embedCells H K μ).toLinearMap

omit [SecondCountableTopology G] in
instance cellSpace_finite (H K : CO G) : FiniteDimensional ℂ (cellSpace μ H K) := by
  let _ : Finite (I H K) := finite_core H K
  let _ : Fintype (I H K) := Fintype.ofFinite _
  let coords : Discrete.L2 (I H K) →ₗ[ℂ] (I H K→ℂ) :=
    { toFun := fun f => (f : I H K→ℂ), map_add' := fun _ _ => rfl, map_smul' := fun _ _ => rfl }
  let _ : FiniteDimensional ℂ (Discrete.L2 (I H K)) := FiniteDimensional.of_injective coords (fun _ _ eqn => lp.ext eqn)
  exact Module.Finite.range _

private def stepValue (H K : CO G) (v : Discrete.L2 (I H K)) (x : G) : ℂ :=
  DiscreteEmbedding.inclusion (ixEmb H K) v (π H x) * (scale μ H:ℂ)

private theorem step_ae (H K : CO G) (v : Discrete.L2 (I H K)) :
    (embedCells H K μ v : G→ℂ) =ᵐ[μ] stepValue μ H K v := by
  let _ : Countable (Q H) := DiscreteReduction.countable H
  exact inclusion_ae μ H _

omit [IsTopologicalAddGroup G] [BorelSpace G] [MeasurableAdd G] [SecondCountableTopology G] [μ.IsAddHaarMeasure] in
private theorem step_off (H K : CO G) (u : H≤K) (v : Discrete.L2 (I H K)) {x : G}
    (outside : x∉K.val) : stepValue μ H K v x=0 := by
  have h : (π H x : Qm H) ∉ Set.range (ixEmb H K) := by
    rintro ⟨i,hi⟩
    change sectionEmb H K i.toAdd=π H x at hi
    rw [sectionEmb_rep] at hi
    have hh := u (QuotientAddGroup.eq_iff_sub_mem.mp hi.symm)
    exact outside (by simpa using K.val.add_mem hh (representative H K i.toAdd).property)
  exact mul_eq_zero_of_left (DiscreteEmbedding.inclusion_off (ixEmb H K) v h) _

omit [SecondCountableTopology G] [IsTopologicalAddGroup G] [BorelSpace G] [MeasurableAdd G] in
private theorem scale_ne (H : CO G) : (scale μ H:ℂ)≠0 := by
  have hp : 0<μ.real (H.val:Set G) := ENNReal.toReal_pos (H.val.isOpen.measure_pos μ ⟨0,H.val.zero_mem⟩).ne' H.property.measure_ne_top
  exact_mod_cast (inv_ne_zero (Real.sqrt_pos.mpr hp).ne' : (Real.sqrt (μ.real (H.val:Set G)))⁻¹≠0)

theorem mem_cellSpace_of_step (H K : CO G) (le : H≤K) {f : Lp ℂ 2 μ} (g : G→ℂ)
    (eqn : (f : G→ℂ)=ᵐ[μ] g)
    (outside : ∀ x, x∉K.val → g x=0) (stable : ∀ x y : G, x-y∈H.val → g x=g y) :
    f∈cellSpace μ H K := by
  let _ : Finite (I H K) := finite_core H K
  let vals (i : I H K) := g (representative H K i.toAdd:G)/(scale μ H:ℂ)
  let v : Discrete.L2 (I H K) := ⟨vals,Memℓp.all _⟩
  refine ⟨v,Lp.ext ?_⟩
  apply (step_ae μ H K v).trans
  apply Filter.EventuallyEq.trans _ eqn.symm
  apply Filter.Eventually.of_forall
  intro x
  by_cases hx : x∈K.val
  · let i := quotientIndex H K x hx
    have eqπ : sectionEmb H K i=π H x := by rfl
    have eqr := eqπ
    rw [sectionEmb_rep] at eqr
    have hxg := stable _ _ (QuotientAddGroup.eq_iff_sub_mem.mp eqr)
    change DiscreteEmbedding.inclusion (ixEmb H K) v (π H x) * (scale μ H:ℂ)=_
    rw [←eqπ]
    change DiscreteEmbedding.inclusion (ixEmb H K) v (ixEmb H K (.ofAdd i)) * (scale μ H:ℂ)=_
    rw [inclusion_on]
    change (g (representative H K i:G)/(scale μ H:ℂ))*(scale μ H:ℂ)=_
    rw [div_mul_cancel₀ _ (scale_ne μ H),hxg]
  · exact (step_off μ H K le v hx).trans (outside _ hx).symm

theorem cellSpace_mono {H K L M : CO G} (hk : H≤K) (lm : L≤M) (lh : L≤H) (km : K≤M) :
    cellSpace μ H K≤cellSpace μ L M := by
  rintro _ ⟨v,rfl⟩
  refine mem_cellSpace_of_step μ L M lm (stepValue μ H K v) (step_ae μ H K v)
    (fun _ hx => step_off μ H K hk v (fun a => hx (km a))) ?_
  intro x y h
  have eqn : π H x=π H y := QuotientAddGroup.eq_iff_sub_mem.mpr (lh h)
  simp only [stepValue,eqn]

end KDClosure.ReducedWindows
