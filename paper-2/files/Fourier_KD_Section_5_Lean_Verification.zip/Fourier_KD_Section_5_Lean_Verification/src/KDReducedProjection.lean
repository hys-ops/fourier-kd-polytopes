import KDReducedTotal
noncomputable section
namespace KDClosure.ReducedWindows
open Set Filter Topology CompactCoset CompactCore MeasureTheory
open scoped ENNReal BigOperators InnerProductSpace Classical Pointwise
variable {X : Type*} [AddCommGroup X] [TopologicalSpace X] [IsTopologicalAddGroup X]
  [T2Space X] [MeasurableSpace X] [BorelSpace X]
  (F : Filtration X) (μ : Measure X) [μ.IsAddHaarMeasure]

omit [T2Space X] [MeasurableSpace X] [BorelSpace X] in
theorem thick_cell_fixed {m n : ℕ} (mn : m≤n) (i : Idx F m) :
    thick F (cell F m i) n=cell F m i := by
  apply le_antisymm _ (subset_thick _ _ _)
  rintro _ ⟨a,ha,b,hb,rfl⟩
  let r := (representative (F.L m) (F.K m) i:X)
  change a+b-r∈(F.L m).val
  change a-r∈(F.L m).val at ha
  rw [show a+b-r=(a-r)+b by abel]
  exact (F.L m).val.add_mem ha (F.down mn hb)

omit [T2Space X] in
theorem windows_mono : Monotone (window F μ) := by
  intro m n mn
  apply Submodule.span_le.mpr
  rintro _ ⟨i,rfl⟩
  rw [←(window F μ n).orthogonal_orthogonal]
  intro f hf
  apply inner_eq_zero_symm.mp
  rw [vector_integral]
  have inside : cell F m i ⊆ ((F.K n).val:Set X) := (cell_inside F m i).trans (F.up mn)
  simpa only [thick_cell_fixed F mn] using thick_integral_zero F μ n inside f hf

/-- The finite sections are strongly exhaustive: each *orthogonal projection*
converges to the identity on every physical L² vector. -/
theorem strong_projections (x : Lp ℂ 2 μ) :
    Tendsto (fun n => (window F μ n).starProjection x) atTop (𝓝 x) := by
  have hD := dense_windows F μ
  have hc : x ∈ closure ((⨆ n,window F μ n : Submodule ℂ (Lp ℂ 2 μ)) : Set (Lp ℂ 2 μ)) := by
    change x∈(⨆ n,window F μ n).topologicalClosure
    rw [hD]; trivial
  rw [Metric.tendsto_nhds]
  intro ε ep
  obtain ⟨z,hz,near⟩ := Metric.mem_closure_iff.mp hc (ε/2) (by linarith)
  obtain ⟨k,hk⟩ := (Submodule.mem_iSup_of_directed _ (windows_mono F μ).directed_le).mp hz
  filter_upwards [eventually_ge_atTop k] with n hn
  have fix := (window F μ n).starProjection_eq_self_iff.mpr (windows_mono F μ hn hk)
  have lip := (window F μ n).lipschitzWith_starProjection.dist_le_mul x z
  rw [fix] at lip
  simp only [NNReal.coe_one,one_mul] at lip
  calc dist ((window F μ n).starProjection x) x ≤ dist ((window F μ n).starProjection x) z+dist z x := dist_triangle _ _ _
       _ < ε := by rw [dist_comm z x]; linarith

end KDClosure.ReducedWindows
