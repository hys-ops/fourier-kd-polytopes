import KDReducedPartial
noncomputable section
namespace KDClosure.ReducedWindows
open MeasureTheory Set LCAQuotient
open scoped KDClosure.SubgroupMeasure
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
    [MeasurableSpace G] [BorelSpace G]
    (μ : Measure G) (ν : Measure (LCAReality.Dual G)) (F : LCAReality.FourierRealization μ ν)
omit [IsTopologicalAddGroup G] [BorelSpace G] in
theorem state_one_le_rank {T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ} (state : T∈ambientStates μ ν F) :
    1≤Module.rank ℂ (LinearMap.range T.toLinearMap) := by
  have nonzero : ∃ x,T x ≠ 0 := by
    by_contra! bad
    have eqn : T=0 := ContinuousLinearMap.ext bad
    rw [eqn] at state
    have bd : (0:ℝ) ∈ upperBounds (LCAQuotientTrace.frameMass (0 : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ)) := by
      rintro r ⟨n,v,_,rfl⟩; simp
    exact (not_le_of_gt zero_lt_one) (state.2.1.2 bd)
  obtain ⟨x,hx⟩ := nonzero
  exact Cardinal.one_le_iff_pos.mpr (rank_pos_iff_exists_ne_zero.mpr ⟨⟨T x,x,rfl⟩,fun e => hx (congrArg Subtype.val e)⟩)
end KDClosure.ReducedWindows
