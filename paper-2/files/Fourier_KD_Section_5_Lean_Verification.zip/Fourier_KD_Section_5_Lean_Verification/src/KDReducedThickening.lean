import KDReducedCofinal
import KDCompactCosetRow
import Mathlib.MeasureTheory.Function.L2Space
noncomputable section
namespace KDClosure.ReducedWindows
open CompactCore CompactCoset Set MeasureTheory Filter Topology
open scoped BigOperators Classical Pointwise ENNReal
variable {X : Type*} [AddCommGroup X] [TopologicalSpace X] [IsTopologicalAddGroup X]
variable (F : Filtration X)

def thick (S : Set X) (n : ℕ) := S + ((F.L n).val : Set X)

theorem thick_anti (S : Set X) : Antitone (thick F S) := fun _ _ h => Set.add_subset_add_left (F.down h)
theorem subset_thick (S : Set X) (n : ℕ) : S ⊆ thick F S n := fun y hy =>
  ⟨y,hy,0,(F.L n).val.zero_mem,add_zero y⟩
theorem thick_compact {S : Set X} (h : IsCompact S) (n : ℕ) : IsCompact (thick F S n) :=
  h.add (F.L n).property

theorem thick_inter {S : Set X} (h : IsClosed S) : ⋂ n,thick F S n = S := by
  ext x
  constructor
  · intro hx
    by_contra no
    have op : IsOpen ((fun y : X => x-y) ⁻¹' Sᶜ) := h.isOpen_compl.preimage (continuous_const.sub continuous_id)
    obtain ⟨n,hn⟩ := F.small _ (op.mem_nhds (by simpa using no))
    obtain ⟨a,ha,b,hb,e⟩ := mem_iInter.mp hx n
    have := hn hb
    change x-b ∉ S at this
    exact this (by simpa [←e] using ha)
  · exact fun hx => mem_iInter.mpr fun n => subset_thick F S n hx

theorem compact_inside {S : Set X} (h : IsCompact S) : ∃ n,S⊆((F.K n).val:Set X) :=
  h.elim_directed_cover (fun n => ((F.K n).val:Set X)) (fun n => (F.K n).val.isOpen)
    (fun x _ => mem_iUnion.mpr (F.cover x)) (fun i j => ⟨max i j,F.up (le_max_left _ _),F.up (le_max_right _ _)⟩)

variable [T2Space X] [MeasurableSpace X] [BorelSpace X] [MeasurableAdd X]
abbrev Idx (n : ℕ) := CoreQuot (F.L n) (F.K n)
local instance ix (n : ℕ) : Fintype (Idx F n) := @Fintype.ofFinite _ (finite_core _ _)
abbrev cell (n : ℕ) (i : Idx F n) : Set X := coset (F.L n) (representative (F.L n) (F.K n) i : X)

omit [T2Space X] [MeasurableSpace X] [BorelSpace X] [MeasurableAdd X] in
theorem cell_inside (n : ℕ) (i : Idx F n) : cell F n i ⊆ ((F.K n).val:Set X) := by
  intro x hx
  let c := representative (F.L n) (F.K n) i
  have d : x-c.val ∈ (F.K n).val := F.within _ hx
  simpa using (F.K n).val.add_mem d c.property

omit [T2Space X] [MeasurableSpace X] [BorelSpace X] [MeasurableAdd X] in
theorem cell_iff (n : ℕ) (i : Idx F n) {x : X} (h : x ∈ (F.K n).val) :
    x∈cell F n i ↔ quotientIndex (F.L n) (F.K n) x h=i := by
  nth_rw 2 [←representative_spec (F.L n) (F.K n) i]
  exact (QuotientAddGroup.eq_iff_sub_mem (N:=((subgroup (F.L n)).addSubgroupOf (subgroup (F.K n))))
    (x:=(⟨x,h⟩:subgroup (F.K n))) (y:=representative (F.L n) (F.K n) i)).symm

omit [T2Space X] [MeasurableSpace X] [BorelSpace X] [MeasurableAdd X] in
/-- A thickening inside its physical support window consists of entire
finite-quotient cells. Membership is tested at any representative. -/
theorem thick_cell {S : Set X} (n : ℕ) (hS : S⊆((F.K n).val:Set X)) :
    thick F S n = ⋃ i : {i : Idx F n // (representative (F.L n) (F.K n) i : X) ∈ thick F S n},cell F n i.val := by
  ext x
  constructor
  · rintro ⟨a,ha,b,hb,rfl⟩
    have h : a+b ∈ (F.K n).val := (F.K n).val.add_mem (hS ha) (F.within n hb)
    let i := quotientIndex (F.L n) (F.K n) (a+b) h
    have hh : a+b ∈ cell F n i := (cell_iff F n i h).mpr rfl
    let r := (representative (F.L n) (F.K n) i:X)
    have hr : r-a ∈ (F.L n).val := by
      change a+b-r∈(F.L n).val at hh
      rw [show r-a=b-(a+b-r) by abel]; exact (F.L n).val.sub_mem hb hh
    exact mem_iUnion.mpr ⟨⟨i,a,ha,r-a,hr,show a+(r-a)=r by abel⟩,hh⟩
  · intro hx
    obtain ⟨i,hi⟩ := mem_iUnion.mp hx
    obtain ⟨a,ha,b,hb,e⟩ := i.property
    change a+b=(representative (F.L n) (F.K n) i.val:X) at e
    refine ⟨a,ha,x-a,?_,by abel⟩
    have hm : x-(representative (F.L n) (F.K n) i.val:X)∈(F.L n).val := hi
    rw [show x-a=(x-(representative (F.L n) (F.K n) i.val:X))+b by rw [←e]; abel]
    exact (F.L n).val.add_mem hm hb

omit [T2Space X] [MeasurableSpace X] [BorelSpace X] [MeasurableAdd X] in
theorem disjoint_cells {n : ℕ} {i j : Idx F n} (ne : i≠j) : Disjoint (cell F n i) (cell F n j) := by
  rw [Set.disjoint_left]
  intro x hi hj
  have hx := cell_inside F n i hi
  exact ne (((cell_iff F n i hx).mp hi).symm.trans ((cell_iff F n j hx).mp hj))

end KDClosure.ReducedWindows
