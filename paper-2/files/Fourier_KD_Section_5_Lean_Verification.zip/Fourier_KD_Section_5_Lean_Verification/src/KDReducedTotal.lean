import KDReducedThickening
import Mathlib.MeasureTheory.Function.AEEqOfIntegral
import Mathlib.Analysis.InnerProductSpace.Projection.Submodule
noncomputable section
namespace KDClosure.ReducedWindows
open Set Filter Topology CompactCoset CompactCore MeasureTheory
open scoped ENNReal BigOperators InnerProductSpace Classical Pointwise
variable {X : Type*} [AddCommGroup X] [TopologicalSpace X] [IsTopologicalAddGroup X]
  [T2Space X] [MeasurableSpace X] [BorelSpace X]
  (F : Filtration X) (μ : Measure X) [μ.IsAddHaarMeasure]

def vector (n : ℕ) (i : Idx F n) : Lp ℂ 2 μ :=
  indicatorConstLp (s:=cell F n i) 2 (coset_meas (F.L n) _) (coset_compact (F.L n) _).measure_ne_top (1:ℂ)

def window (n : ℕ) : Submodule ℂ (Lp ℂ 2 μ) := Submodule.span ℂ (range (vector F μ n))

instance dim (n : ℕ) : FiniteDimensional ℂ (window F μ n) := by
  let _ : Finite (Idx F n) := finite_core _ _
  exact FiniteDimensional.span_of_finite _ (Set.finite_range _)

omit [T2Space X] in
theorem vector_integral (n : ℕ) (i : Idx F n) (f : Lp ℂ 2 μ) :
    inner ℂ (vector F μ n i) f=∫ x in cell F n i, f x ∂μ :=
  L2.inner_indicatorConstLp_one _ _ _

include F in
omit [T2Space X] [BorelSpace X] in
theorem locallyFinite : IsLocallyFiniteMeasure μ := by
  constructor
  intro x
  let H := F.L 0
  have op : IsOpen (coset H x) := H.val.isOpen.preimage (continuous_id.sub continuous_const)
  exact ⟨coset H x,op.mem_nhds (by change x-x∈H.val; simp),(coset_compact H x).measure_lt_top⟩

omit [T2Space X] in
theorem thick_integral_zero (n : ℕ) {S : Set X} (hS : S⊆((F.K n).val:Set X))
    (f : Lp ℂ 2 μ) (hf : f∈(window F μ n)ᗮ) :
    ∫ x in thick F S n,f x ∂μ = 0 := by
  classical
  let _ : IsLocallyFiniteMeasure μ := locallyFinite F μ
  let _ : Finite (Idx F n) := finite_core _ _
  let _ : Fintype (Idx F n) := Fintype.ofFinite _
  rw [thick_cell F n hS]
  rw [integral_iUnion_fintype]
  · apply Finset.sum_eq_zero
    intro i _
    rw [←vector_integral]
    exact hf _ (Submodule.subset_span (mem_range_self i.val))
  · exact fun i => coset_meas _ _
  · exact fun i j ne => disjoint_cells F (fun eq => ne (Subtype.ext eq))
  · exact fun i => ((Lp.memLp f).locallyIntegrable (by norm_num)).integrableOn_isCompact (coset_compact _ _)

/-- A vector orthogonal to all actual finite-window indicators vanishes.
This works for the Haar measure on a genuinely two-sided noncompact core. -/
theorem vectors_total (f : Lp ℂ 2 μ) (hf : ∀ n,f∈(window F μ n)ᗮ) : f=0 := by
  have cover : ⋃ n,((F.K n).val:Set X)=univ := iUnion_eq_univ_iff.mpr F.cover
  let _ : SigmaCompactSpace X := ⟨⟨fun n => ((F.K n).val:Set X),fun n => (F.K n).property,cover⟩⟩
  let _ : IsLocallyFiniteMeasure μ := locallyFinite F μ
  have localInt : LocallyIntegrable (f : X → ℂ) μ := (Lp.memLp f).locallyIntegrable (by norm_num : (1:ℝ≥0∞)≤2)
  apply Lp.ext
  apply Filter.EventuallyEq.trans _ (Lp.coeFn_zero ℂ 2 μ).symm
  apply ae_eq_zero_of_forall_setIntegral_isCompact_eq_zero' localInt
  intro S hs
  obtain ⟨N,hN⟩ := compact_inside F hs
  have ht := tendsto_setIntegral_of_antitone (fun n => (thick_compact F hs n).measurableSet)
    (thick_anti F S) ⟨0,localInt.integrableOn_isCompact (thick_compact F hs 0)⟩
  rw [thick_inter F hs.isClosed] at ht
  have hz : (fun n => ∫ x in thick F S n, f x ∂μ) =ᶠ[atTop] fun _ => (0:ℂ) := by
    filter_upwards [eventually_ge_atTop N] with n hn
    exact thick_integral_zero F μ n (fun x hx => F.up hn (hN hx)) f (hf n)
  exact tendsto_nhds_unique ht (tendsto_const_nhds.congr' hz.symm)

theorem dense_windows : (⨆ n,window F μ n).topologicalClosure=⊤ := by
  have orth : (⨆ n,window F μ n)ᗮ=⊥ := by
    apply bot_unique
    intro x hx
    apply vectors_total F μ x
    rw [←Submodule.iInf_orthogonal] at hx
    exact fun n => (iInf_le (fun n => (window F μ n)ᗮ) n) hx
  rw [←Submodule.orthogonal_orthogonal_eq_closure,orth,Submodule.bot_orthogonal_eq_top]

end KDClosure.ReducedWindows
