import KDReducedPad
noncomputable section
namespace KDClosure.ReducedWindows
open MeasureTheory Set Filter Topology CompactCore LCAQuotient
open scoped BigOperators ComplexOrder InnerProductSpace KDClosure.SubgroupMeasure
variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
    [T2Space G] [MeasurableSpace G] [BorelSpace G]
    (μ : Measure G) [μ.IsAddHaarMeasure] (W : Filtration G)

abbrev sandwich (n : ℕ) (T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ) :=
  (window W μ n).starProjection ∘L T ∘L (window W μ n).starProjection

theorem sandwich_WOT (T : Lp ℂ 2 μ →L[ℂ] Lp ℂ 2 μ) (x y : Lp ℂ 2 μ) :
    Tendsto (fun n => inner ℂ x (sandwich μ W n T y)) atTop (𝓝 (inner ℂ x (T y))) := by
  have h := (strong_projections W μ x).inner (𝕜:=ℂ)
    (T.continuous.continuousAt.tendsto.comp (strong_projections W μ y))
  apply h.congr'
  exact Eventually.of_forall (fun n => (window W μ n).inner_starProjection_left_eq_right _ _)

end KDClosure.ReducedWindows
