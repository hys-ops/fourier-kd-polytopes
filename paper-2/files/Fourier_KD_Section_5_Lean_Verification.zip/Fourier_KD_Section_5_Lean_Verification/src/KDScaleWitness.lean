import KDSingleHeadWitness
import KDPhysicalBudget

namespace KDClosure
open Matrix Discrete
open scoped ComplexOrder BigOperators
variable {p q : ℕ} [Fact p.Prime] [Fact q.Prime]

theorem extend_scale {D I : Type*} (e : I → D) (C : Matrix I I ℂ) (b : ℝ) :
    extendMatrix e (b • C) = b • extendMatrix e C := by
  classical
  funext z
  by_cases hx : z.1 ∈ Set.range e <;> by_cases hy : z.2 ∈ Set.range e <;>
    simp [extendMatrix,hx,hy]

theorem table_scale {m : ℕ} [NeZero m] {D : Type*} (e : ZMod m × ZMod q → D) (A : D×D → ℂ)
    (b : ℝ) (x t k v) :
    table (rowsOf e (b • A)) x t k v = (b:ℂ)*table (rowsOf e A) x t k v := by
  simp only [table,transRow,ZMod.dft_apply,rowsOf,Pi.smul_apply,Complex.real_smul,smul_eq_mul,Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro i _
  apply Finset.sum_congr rfl
  intro j _
  ring

/-- Uniform positive fibre mass replaces a prescribed visible coordinate.
A single scaling constant pays for every finite trace. -/
theorem unscaled_operator (pq : p≠q) (l : ℕ) (hl : 0<l) (hlt : l<p)
    (s : ℕ → ℕ) (hs : StrictMono s) (χ : ℕ → AddChar (ZMod p) ℂ) (a : ℕ → ℂ)
    (ha : ∀ j, a j ≠ 0) (d₁ d₂ : Additive (pRoots p) → ℂ) (h₁ : ∀ x, d₁ x ≠ 0)
    (h₂ : ∀ x, d₂ x ≠ 0) (c : ℂ) (hc : c ≠ 0) (B : ℝ) (hB : 0<B)
    (cert : ∀ K : ℕ, ∃ N ≥ K, ∃ C : Matrix (Head p q N) (Head p q N) ℂ,
      C.PosSemidef ∧ (∑ i, (C i i).re ≤ B) ∧ (2 ≤ ∑ t, (C (0,t) (0,t)).re) ∧
      let e := fun i => (cyclicMixedHead p q i : Head p q i → MixedD p q)
      let A := extendMatrix (e N) C
      (∀ x t k v, 0 ≤ table (rowsOf (e N) A) x t k v) ∧
      (∀ x t k v, Protected (color (p:=p) N l) x t v → table (rowsOf (e N) A) x t k v=0) ∧
      (∀ j≤K, testValue e (.quad (s j) (birthVector s χ a d₁ d₂ c j)) A = 0)) :
    ∃ T ∈ (physicalTests p q).extremePoints ℝ, T.IsPositive ∧
      (∑' x : MixedD p q, (inner ℂ (lp.single 2 x (1:ℂ)) (T (lp.single 2 x (1:ℂ)))).re)=1 ∧
      ¬ FiniteDimensional ℂ (LinearMap.range T.toLinearMap) := by
  classical
  choose N hN C hc' using cert
  let u := 2 / (q:ℝ)
  have hq : (0:ℝ)<q := by exact_mod_cast (Fact.out : Nat.Prime q).pos
  have hu : 0<u := by dsimp [u]; positivity
  have many (k) : u*(Fintype.card (ZMod q):ℝ) ≤ ∑ t, ((C k) (0,t) (0,t)).re := by
    rw [ZMod.card]; simpa [u,hq.ne'] using (hc' k).2.2.1
  obtain ⟨t,freq⟩ := fixed_visible _ u many
  let b := B⁻¹
  have hb : 0<b := inv_pos.mpr hB
  let e := fun i => (cyclicMixedHead p q i : Head p q i → MixedD p q)
  apply single_head_witness_operator pq l hl hlt s hs χ a ha d₁ d₂ h₁ h₂ c hc (0,t) (b*u) (mul_pos hb hu)
  intro K
  obtain ⟨k,le,visible⟩ := freq K
  obtain ⟨ps,tr,_,pos,mask,birth⟩ := hc' k
  refine ⟨N k,le.trans (hN k), b • C k, ps.smul hb.le,?_,?_,?_,?_,?_⟩
  · simp only [Matrix.smul_apply,Complex.real_smul,Complex.re_ofReal_mul,←Finset.mul_sum]
    exact (mul_le_mul_of_nonneg_left tr hb.le).trans_eq (inv_mul_cancel₀ hB.ne')
  · change b*u ≤ (extendMatrix (e (N k)) (b • C k) ((0,t),(0,t))).re
    have ez : e (N k) (0,t) = (0,t) := by
      change (rootHead (le_iSup (fun i : ℕ => rootsOfUnity (p^i) ℂ) (N k+1)) 0,t) = (0,t)
      rw [map_zero]
    rw [←ez,extendMatrix_on _ (cyclicMixedHead_injective _ _ _)]; simpa using mul_le_mul_of_nonneg_left visible hb.le
  · intro x z k' v
    rw [extend_scale,table_scale]
    exact mul_nonneg (by exact_mod_cast hb.le) (pos x z k' v)
  · intro x z k' v h
    rw [extend_scale,table_scale,mask _ _ _ _ h,mul_zero]
  · intro j hj
    rw [extend_scale,map_smul,birth _ (hj.trans le),smul_zero]

end KDClosure
