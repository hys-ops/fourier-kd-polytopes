import KDGlobalPeriod
import KDGroupTower

namespace KDClosure
open Set Function

variable {p q : ℕ} [Fact p.Prime] [Fact q.Prime]

omit [Fact p.Prime] in
private theorem pow_change {n N : ℕ} (le : n ≤ N) :
    p^(N+1) = p^(n+1)*p^(N-n) := by
  rw [←pow_add]; congr 1; omega

private def scaleIndex {n N : ℕ} (x : ZMod (p^(n+1))) : ZMod (p^(N+1)) :=
  ((p^(N-n)*x.val : ℕ) : ZMod (p^(N+1)))

private theorem scale_val {n N : ℕ} (le : n ≤ N) (x : ZMod (p^(n+1))) :
    (scaleIndex (N:=N) x).val = p^(N-n)*x.val := by
  apply ZMod.val_natCast_of_lt
  rw [pow_change (p:=p) le,mul_comm (p^(n+1))]
  exact Nat.mul_lt_mul_of_pos_left x.val_lt (pow_pos (Fact.out : Nat.Prime p).pos _)

omit [Fact q.Prime] in
private theorem scale_commutes {n N : ℕ} (le : n ≤ N) (x : ZMod (p^(n+1))) (t : ZMod q) :
    cyclicMixedHead p q N (scaleIndex x,t) = cyclicMixedHead p q n (x,t) := by
  apply Prod.ext
  · exact compatible_rootHead (le_iSup (fun j : ℕ => rootsOfUnity (p^j) ℂ) (n+1)) (le_iSup (fun j : ℕ => rootsOfUnity (p^j) ℂ) (N+1)) (pow_pos (Fact.out : Nat.Prime p).pos _) (pow_change le) _ _
      (scale_val le x)
  · rfl

private def headInclusion {n N : ℕ} (le : n ≤ N) : Head p q n ↪ Head p q N where
  toFun x := (scaleIndex x.1,x.2)
  inj' := by
    intro x y h
    apply cyclicMixedHead_injective p q n
    exact (scale_commutes le x.1 x.2).symm.trans
      ((congrArg (cyclicMixedHead p q N) h).trans (scale_commutes le y.1 y.2))

private theorem upper_digit_zero {n N : ℕ} (lt : n < N) (x : ZMod (p^(n+1))) :
    ((scaleIndex (N:=N) x).val : ZMod p) = 0 := by
  rw [scale_val lt.le,Nat.cast_mul,Nat.cast_pow,ZMod.natCast_self,zero_pow (by omega : N-n≠0),zero_mul]

/-- The reciprocal diagonal weights are functions of the physical group point.
They can include the fixed transverse channel normalization factors. -/
noncomputable def alongHead (d : Additive (pRoots p) → ℂ) (n : ℕ) :
    ZMod (p^(n+1)) → ℂ := fun x => d (rootHead (le_iSup (fun i : ℕ => rootsOfUnity (p^i) ℂ) (n+1)) x)

private theorem along_scale (d : Additive (pRoots p) → ℂ) {n N : ℕ} (le : n ≤ N)
    (x : ZMod (p^(n+1))) : alongHead d N (scaleIndex x) = alongHead d n x :=
  congrArg d (congrArg Prod.fst (scale_commutes (q:=p) le x 0))

private noncomputable def packetPlus (d₁ d₂ : Additive (pRoots p) → ℂ) (c : ℂ) (n : ℕ) :
    Head p q n → ℂ := headVec (alongHead d₁ n) ((Real.sqrt (q:ℝ) : ℂ)⁻¹) +
      c • headVec (alongHead d₂ n) (-((Real.sqrt (q:ℝ) : ℂ)⁻¹))

private noncomputable def packetMinus (d₁ d₂ : Additive (pRoots p) → ℂ) (c : ℂ) (n : ℕ) :
    Head p q n → ℂ := headVec (alongHead d₁ n) ((Real.sqrt (q:ℝ) : ℂ)⁻¹) -
      c • headVec (alongHead d₂ n) (-((Real.sqrt (q:ℝ) : ℂ)⁻¹))

/-- One finite birth-level quadratic test. The phase is a character of the
top quotient. Odd and even packets impose opposite fixed transverse signs. -/
noncomputable def birthVector (s : ℕ → ℕ) (χ : ℕ → AddChar (ZMod p) ℂ)
    (a : ℕ → ℂ) (d₁ d₂ : Additive (pRoots p) → ℂ) (c : ℂ)
    (j : ℕ) (i : Head p q (s j)) : ℂ :=
  a j * χ j (i.1.val : ZMod p) *
    (if j%2=0 then packetPlus d₁ d₂ c (s j) i else packetMinus d₁ d₂ c (s j) i)

private theorem birth_restrict (s : ℕ → ℕ) (χ : ℕ → AddChar (ZMod p) ℂ) (a : ℕ → ℂ)
    (d₁ d₂ : Additive (pRoots p) → ℂ) (c : ℂ) {n j : ℕ} (lt : n<s j) :
    birthVector s χ a d₁ d₂ c j ∘ headInclusion (q:=q) lt.le =
    a j • (if j%2=0 then packetPlus d₁ d₂ c n else packetMinus d₁ d₂ c n) := by
  funext ⟨x,t⟩
  change a j * χ j ((scaleIndex (N:=s j) x).val : ZMod p) *
      (if j%2=0 then packetPlus d₁ d₂ c (s j) (scaleIndex x,t)
       else packetMinus d₁ d₂ c (s j) (scaleIndex x,t)) = _
  rw [upper_digit_zero lt,AddChar.map_zero_eq_one,mul_one]
  by_cases parity : j%2=0 <;>
    simp only [parity,ite_true,ite_false,packetPlus,packetMinus,headVec,Pi.smul_apply,
      Pi.add_apply,Pi.sub_apply,smul_eq_mul,along_scale _ lt.le]
  
/-- Countable enumeration of just the requested masks and the birth tests;
arbitrary complex test vectors do not need to form a countable type. -/
theorem exists_scheduled_tests (l : ℕ) (s : ℕ → ℕ) (hs : StrictMono s)
    (χ : ℕ → AddChar (ZMod p) ℂ) (a : ℕ → ℂ) (ha : ∀ j, a j ≠ 0)
    (d₁ d₂ : Additive (pRoots p) → ℂ) (h₁ : ∀ x, d₁ x ≠ 0) (h₂ : ∀ x, d₂ x ≠ 0)
    (c : ℂ) (hc : c ≠ 0) :
    ∃ τ : ℕ → TowerTest p q,
      (∀ u, (∃ j, τ u = .quad (s j) (birthVector s χ a d₁ d₂ c j)) ∨
        ∃ n x t k v, Protected (color (p:=p) n l) x t v ∧ τ u = .kd n x t k v) ∧
      (∀ j, ∃ u, τ u = .quad (s j) (birthVector s χ a d₁ d₂ c j)) ∧
      (∀ n, Nonempty (PairedPackets (fun i => cyclicMixedHead p q i) τ n)) ∧
      (∀ n x t k v, Protected (color (p:=p) n l) x t v → ∃ j, τ j = .kd n x t k v) := by
  classical
  let Masks := (n : ℕ) × {z : Head p q n × Head p q n // Protected (color (p:=p) n l) z.1.1 z.1.2 z.2.2}
  let Data := ℕ ⊕ Masks
  let _ : Nonempty Data := ⟨Sum.inl 0⟩
  obtain ⟨decode,cover⟩ := exists_surjective_nat Data
  let test : Data → TowerTest p q
    | .inl j => .quad (s j) (birthVector s χ a d₁ d₂ c j)
    | .inr ⟨n,z⟩ => .kd n z.1.1.1 z.1.1.2 z.1.2.1 z.1.2.2
  let τ := test ∘ decode
  refine ⟨τ,?_,?_,?_,?_⟩
  · intro u
    change (∃ j, test (decode u) = _) ∨ _
    cases h : decode u with
    | inl j => exact Or.inl ⟨j,rfl⟩
    | inr z =>
      rcases z with ⟨n,⟨⟨⟨x,t⟩,⟨k,v⟩⟩,prot⟩⟩
      exact Or.inr ⟨n,x,t,k,v,prot,by simp [τ,h,test]⟩
  · intro j
    obtain ⟨u,hu⟩ := cover (.inl j)
    exact ⟨u,by simp [τ,hu,test]⟩
  · intro n
    have mk (j : ℕ) (hj : n<s j) : LaterPacket (fun i => cyclicMixedHead p q i) τ n
        (if j%2=0 then packetPlus d₁ d₂ c n else packetMinus d₁ d₂ c n) := by
      exact ⟨s j, headInclusion hj.le,fun i => scale_commutes hj.le i.1 i.2,
             birthVector s χ a d₁ d₂ c j,(by obtain ⟨u,hu⟩ := cover (.inl j); exact ⟨u,by simp [τ,hu,test]⟩),
             a j,ha j,birth_restrict s χ a d₁ d₂ c hj⟩
    refine ⟨⟨alongHead d₁ n,alongHead d₂ n,fun _ => h₁ _,fun _ => h₂ _,c,hc,?_,?_⟩⟩
    · have h := mk (2*(n+1)) (lt_of_lt_of_le (by dsimp only [id]; omega) (hs.id_le _))
      simpa [packetPlus] using h
    · have h := mk (2*(n+1)+1) (lt_of_lt_of_le (by dsimp only [id]; omega) (hs.id_le _))
      simpa [packetMinus] using h
  · intro n x t k v prot
    obtain ⟨j,hj⟩ := cover (.inr ⟨n,⟨((x,t),(k,v)),prot⟩⟩)
    exact ⟨j,by simp [τ,hj,test]⟩

/-- Uniform finite, physically indexed test layers suffice. The quantifier K
bounds the birth index for packet tests and the cyclic head for mask tests.
The ambient slice membership of each witness is a separate assumption. -/
def LayerZeros (l : ℕ) (s : ℕ → ℕ) (χ : ℕ → AddChar (ZMod p) ℂ) (a : ℕ → ℂ)
    (d₁ d₂ : Additive (pRoots p) → ℂ) (c : ℂ) (K : ℕ)
    (A : (Additive (pRoots p) × ZMod q) × (Additive (pRoots p) × ZMod q) → ℂ) : Prop :=
  (∀ j≤K, testValue (fun i => cyclicMixedHead p q i)
           (.quad (s j) (birthVector s χ a d₁ d₂ c j)) A = 0) ∧
  (∀ n≤K, ∀ x t k v, Protected (color (p:=p) n l) x t v →
           testValue (fun i => cyclicMixedHead p q i) (.kd n x t k v) A = 0)

omit [Fact q.Prime] in
theorem all_cyclic_heads_increasing :
    Monotone (fun n => range (cyclicMixedHead p q n)) := by
  rintro n N le _ ⟨⟨x,t⟩,rfl⟩
  exact ⟨(scaleIndex x,t),scale_commutes le x t⟩

omit [Fact q.Prime] in
theorem all_cyclic_heads_exhaust (z : Additive (pRoots p) × ZMod q) :
    ∃ n, z ∈ range (cyclicMixedHead p q n) := by
  obtain ⟨n,hn⟩ := (mem_pRoots_iff p z.1.toMul.val).mp z.1.toMul.property
  obtain ⟨x,hx⟩ := (range_rootHead (le_iSup (fun i : ℕ => rootsOfUnity (p^i) ℂ) (n+1)) z.1).mpr
    (rootsMonotone p (Nat.le_succ n) hn)
  exact ⟨n,(x,z.2),Prod.ext hx rfl⟩

/-- The mixed Prüfer group on its actual additive charts, with alternating
quotient characters and protected masks at each ordinary cyclic head. -/
theorem scheduled_extreme_infinite_support (pq : p≠q) (l : ℕ) (hl : 0<l) (hlt : l<p)
    (s : ℕ → ℕ) (hs : StrictMono s) (χ : ℕ → AddChar (ZMod p) ℂ)
    (a : ℕ → ℂ) (ha : ∀ j, a j ≠ 0) (d₁ d₂ : Additive (pRoots p) → ℂ)
    (h₁ : ∀ x, d₁ x ≠ 0) (h₂ : ∀ x, d₂ x ≠ 0) (c : ℂ) (hc : c ≠ 0)
    (o : Additive (pRoots p) × ZMod q) (δ : ℝ) (hδ : 0<δ)
    (per : ∀ A ∈ cornerSlice (fun i => cyclicMixedHead p q i),
      ∀ n, Periodic (rowsOf (cyclicMixedHead p q n) A))
    (feasible : ∀ K, ∃ A ∈ cornerSlice (fun i => cyclicMixedHead p q i),
      δ ≤ (A (o,o)).re ∧ LayerZeros l s χ a d₁ d₂ c K A) :
    ∃ B ∈ (cornerSlice (fun i => cyclicMixedHead p q i)).extremePoints ℝ,
      0 < (B (o,o)).re ∧ (columnSupport B).Infinite ∧ ∀ K, LayerZeros l s χ a d₁ d₂ c K B := by
  classical
  obtain ⟨τ,listed,births,paired,mask⟩ := exists_scheduled_tests (q:=q) l s hs χ a ha d₁ d₂ h₁ h₂ c hc
  let e := fun i => (cyclicMixedHead p q i : Head p q i → _)
  have one (i : ℕ) : ∃ k : ℕ, ∀ K ≥ k, ∀ A, LayerZeros l s χ a d₁ d₂ c K A →
      testValue e (τ i) A = 0 := by
    rcases listed i with ⟨j,hj⟩|⟨n,x,t,k,v,hv,hn⟩
    · exact ⟨j,fun K hk A hA => hj.symm ▸ hA.1 j hk⟩
    · exact ⟨n,fun K hk A hA => hn.symm ▸ hA.2 n hk x t k v hv⟩
  choose bound dominates using one
  have witness (k : ℕ) : ∃ A ∈ cornerSlice e, δ ≤ (A (o,o)).re ∧ ∀ j ≤ k, testValue e (τ j) A = 0 := by
    let K := (Finset.range (k+1)).sup bound
    obtain ⟨A,hA,visible,allzero⟩ := feasible K
    exact ⟨A,hA,visible,fun j hj => dominates j K
      (Finset.le_sup (f:=bound) (Finset.mem_range.mpr (by omega)) ) A allzero⟩
  obtain ⟨B,hB,visible,inf,hz⟩ := mixed_tower_extreme_infinite_support e τ pq hl hlt
    (cyclicMixedHead_injective p q) all_cyclic_heads_increasing all_cyclic_heads_exhaust
    (fun n => Classical.choice (paired n)) mask per o δ hδ witness
  refine ⟨B,hB,visible,inf,?_⟩
  intro K
  refine ⟨?_,?_⟩
  · intro j _
    obtain ⟨i,hi⟩ := births j
    exact hi ▸ hz i
  · intro n _ x t k v hv
    obtain ⟨i,hi⟩ := mask n x t k v hv
    exact hi ▸ hz i

end KDClosure
