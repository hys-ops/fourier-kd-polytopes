import KDWaveSupport
import KDPhysicalLift
import KDScheduledFace

namespace KDClosure.ScheduledNull
open PhysicalLift WaveSupport AmbientFourier Matrix Classical
open scoped BigOperators

variable {p q : ℕ} [Fact p.Prime] [Fact q.Prime]

def schedule (m j : ℕ) := (j+1)*(m+1)
def oddSign {n : ℕ} (j : Fin n) : Bool := decide (j.val%2≠0)
noncomputable def ratio (a r : ℝ) : ℝ := (1-a*r)/Real.sqrt (1-(a*r)^2)
noncomputable def avgColor (p l : ℕ) : ℝ := 2*(l:ℝ)/p-1

theorem scale_ratio {L : ℕ} [NeZero L] (f : ℕ → ℝ) (hf : ∀ i, 0<f i) (hm : Monotone f)
    (l : ℕ) (hl : l<p) (rsmall : (avgColor p l)^2 < 1) (j : ℕ) :
    columnScale (p:=p) (L:=L) f (-a q) l j =
    (ratio (a q) (avgColor p l) : ℂ) * columnScale (p:=p) (L:=L) f (a q) l j := by
  obtain ⟨ha,ha1,_⟩ := a_properties (q:=q)
  have aa : (a q)^2 < 1 := by nlinarith [mul_pos (sub_pos.mpr ha1) (show 0<1+a q by linarith)]
  have hL : 1≤(L:ℝ) := by exact_mod_cast (Nat.pos_of_ne_zero (NeZero.ne L))
  have mu := (reciprocal_bounds (1/(L:ℝ)) f (by positivity)
    ((div_le_one (by positivity)).mpr hL) hf hm (j+1)).1
  let χ := fun _ : ℕ => negativeDigit p
  have nz : ∀ j, χ j≠1 := fun _ => negativeDigit_nontrivial
  have plus := paperChannelMass (L:=L) χ nz f (a q) aa.ne l hl j
  have minus := paperChannelMass (L:=L) χ nz f (-a q) (by simpa using aa.ne) l hl j
  have rootSq := Real.sq_sqrt (by linarith : 0≤1-(a q)^2)
  have prop := (paperSaturatedScales ha ha1 rsmall mu).2
  rw [rootSq] at prop
  simp only [columnScale,plus,minus,neg_mul,sub_neg_eq_add,neg_sq]
  simpa only [ratio,avgColor,Complex.ofReal_mul] using congrArg Complex.ofReal prop

theorem schedule_increasing (m : ℕ) : StrictMono (schedule m) :=
  fun _ _ h => Nat.mul_lt_mul_of_pos_right (Nat.succ_lt_succ h) (Nat.succ_pos m)

/-- Each actual mounted column is evaluated rowwise in the e+,e- basis. -/
theorem mounted_entry {X J : Type*} [Fintype X] [DecidableEq X]
    (U V : Matrix X J ℂ) (x : X × ZMod q) (j : J) :
    (embedding (X:=X) q * fromRows U (-V)) x j =
      e q (a q) x.2 * U x.1 j - e q (-a q) x.2 * V x.1 j := by
  simp [embedding,Matrix.mul_apply,mount,ite_mul,sub_eq_add_neg]

/-- Ambient inverse weights with their transverse normalization already included.
This normalization is the constant which changes when the proof uses headVec. -/
noncomputable def factor (_q : ℕ) (s : ℝ) (W : Additive (pRoots p) → ℝ)
    (z : Additive (pRoots p)) : ℂ := (PhysicalLift.c s : ℂ) * (W z : ℂ)

noncomputable def amp (p q m l : ℕ) [NeZero p] (f : ℕ → ℝ) (j : ℕ) : ℂ :=
  (packetNormInv p (p^m) j : ℂ) * columnScale (p:=p) (L:=p^m) f (a q) l j

theorem amp_nonzero (m l : ℕ) (f : ℕ → ℝ) (hf : ∀ j, 0<f j) (hm : Monotone f) (j : ℕ) :
    amp p q m l f j ≠ 0 := by
  obtain ⟨ha,ha1,_⟩ := a_properties (q:=q)
  apply mul_ne_zero
  · apply Complex.ofReal_ne_zero.mpr
    apply invroot_ne_zero
    exact Nat.cast_pos.mpr (Nat.pos_of_ne_zero (NeZero.ne _))
  · apply Complex.ofReal_ne_zero.mpr
    apply invroot_ne_zero
    exact cyclicMass_pos f hf hm (paperChannelStat (a q) l)
      (paperChannelStat_pos (by linarith) ha1 l) j

omit [Fact p.Prime] [Fact q.Prime] in
theorem factor_nonzero {s : ℝ} (lo : -1<s) (W : Additive (pRoots p) → ℝ)
    (hw : ∀ z, 0<W z) (z : Additive (pRoots p)) : factor q s W z ≠ 0 := by
  apply mul_ne_zero (Complex.ofReal_ne_zero.mpr (invroot_ne_zero (by linarith : 0<2*(1+s))))
    (Complex.ofReal_ne_zero.mpr (hw z).ne')

omit [Fact p.Prime] in
theorem ratio_positive (l : ℕ) (hr : (avgColor p l)^2<1) : 0<ratio (a q) (avgColor p l) := by
  obtain ⟨ha,ha1,_⟩ := a_properties (q:=q)
  exact (packetConstants (μ:=1) ha ha1 hr zero_lt_one).2.2.1

noncomputable def value (m : ℕ) (χamp : ℕ → ℂ)
    (D₁ D₂ : Additive (pRoots p) → ℂ) (c₀ : ℂ) (j : ℕ) (it : Additive (pRoots p) × ZMod q) : ℂ :=
  if ambientInside p (1+schedule m j) it.1 then χamp j * childPhase p (schedule m j) it.1 *
    (D₁ it.1 * channel q (a q:ℂ) it.2 +
     (if j%2=0 then c₀ else -c₀) * (D₂ it.1 * channel q (-(a q:ℂ)) it.2)) else 0

/-- The normalized packet amplitudes on sparse residues. -/
private theorem digit_packet (m j n : ℕ) (hj : j<n) (x : ZMod (levelSize p (p^m) n)) :
    cyclicPacket (L:=p^m) (fun _ => negativeDigit p) j n x =
      (packetNormInv p (p^m) j : ℂ) *
      (if ambientInside p (1+schedule m j) (sparseRootHead p m n x)
       then childPhase p (schedule m j) (sparseRootHead p m n x) else 0) := by
  rw [cyclicPacket,rawPacket_formula m j n hj]
  simp only [sparsePoint,Equiv.apply_symm_apply,schedule]
  by_cases h : ambientInside p (1+(j+1)*(m+1)) (sparseRootHead p m n x) <;> simp [h]

def realizes (m l : ℕ) (a₀ : ℝ) (f : ℕ → ℝ) (W : Additive (pRoots p) → ℝ) : Prop :=
  ∀ n x, W (sparseRootHead p m n x) = cyclicRealDensity f (paperChannelStat a₀ l) n x

theorem realize {a₀ : ℝ} (ha : -1<a₀) (ha' : a₀<1) (m l : ℕ)
    (f : ℕ → ℝ) (hf : ∀ j, 0<f j) (hm : Monotone f) :
    ∃ W : Additive (pRoots p) → ℝ, (∀ z, 0<W z) ∧ realizes m l a₀ f W := by
  obtain ⟨W,pos,eq⟩ := global_inverse_channel (p:=p) m l a₀ ha ha' f hf hm
  refine ⟨W,pos,fun n x => ?_⟩
  have h := eq n ((encodeLevel p (p^m) n).symm x)
  simp only [sparsePoint,Equiv.apply_symm_apply] at h
  rw [h,cyclicRealDensity,paperChannelStat]; ring

/-- Exact identification with the embedded null vector of finiteOriginalPSD, on
the complete ambient prefix, including rows outside its birth subgroup. -/
theorem mounted_value (m l : ℕ) (hl : l<p) (rsmall : (avgColor p l)^2<1)
    (f : ℕ → ℝ) (hf : ∀ i, 0<f i) (hm : Monotone f)
    (W₁ W₂ : Additive (pRoots p) → ℝ) (d₁ : realizes m l (a q) f W₁)
    (d₂ : realizes m l (-a q) f W₂) (w₁ : ∀ z, 0<W₁ z) (w₂ : ∀ z, 0<W₂ z)
    (n : ℕ) (x : ZMod (levelSize p (p^m) n) × ZMod q) (j : Fin n) :
    (embedding (X:=ZMod (levelSize p (p^m) n)) q * channelNull (L:=p^m) q (fun _ => negativeDigit p) f l n oddSign) x j =
      value m (amp p q m l f) (factor q (a q) W₁) (factor q (-a q) W₂)
      (ratio (a q) (avgColor p l)) j.val (sparseRootHead p m n x.1,x.2) := by
  rw [channelNull,mounted_entry]
  have first := invroot_inv_sq (w₁ (sparseRootHead p m n x.1)).le
  have second := invroot_inv_sq (w₂ (sparseRootHead p m n x.1)).le
  simp only [physicalNull,channelRoot,first,second,wave,digit_packet m _ _ j.isLt,
    ←d₁ n x.1,←d₂ n x.1, signedScale,oddSign,scale_ratio (L:=p^m) (q:=q) f hf hm l hl rsmall,
    value,amp,factor,e,Complex.ofReal_neg]
  by_cases ins : ambientInside p (1+schedule m j.val) (sparseRootHead p m n x.1) <;>
    by_cases parity : j.val%2=0 <;> simp [ins,parity] <;> ring

private theorem full_phase (k : ℕ) (x : ZMod (p^(k+1))) :
    childPhase p k (powerChart p (k+1) x) = negativeDigit p (x.val : ZMod p) := by
  rw [childPhase,AddChar.map_neg_eq_inv,negativeDigit_eval,AddChar.map_neg_eq_inv,_root_.inv_inj]
  change (ZMod.stdAddChar x)^(p^k) = ZMod.stdAddChar (x.val : ZMod p)
  simp only [ZMod.stdAddChar_apply]
  rw [ZMod.toCircle_natCast (N:=p) x.val,ZMod.toCircle_apply x,←Complex.exp_nat_mul]
  congr 1
  have nz : (p:ℂ)≠0 := Nat.cast_ne_zero.mpr (Fact.out : Nat.Prime p).ne_zero
  push_cast; rw [pow_succ (p:ℂ) k]; field_simp

private theorem chart_occ (k : ℕ) (x : ZMod (p^(k+1))) :
    ambientInside p (1+k) (powerChart p (k+1) x) := by
  rw [Nat.add_comm 1 k]
  exact (range_rootHead (le_iSup (fun i : ℕ => rootsOfUnity (p^i) ℂ) (k+1)) _).mp
    (Set.mem_range_self x)

/-- On the entire actual birth head, the mounted value is the scheduled test
vector used for selecting the exposed face. -/
theorem value_birth (m : ℕ) (b : ℕ → ℂ) (D₁ D₂ : Additive (pRoots p) → ℂ)
    (c₀ : ℂ) (j : ℕ) (x : Head p q (schedule m j)) :
    value m b D₁ D₂ c₀ j (cyclicMixedHead p q (schedule m j) x) =
      birthVector (schedule m) (fun _ => negativeDigit p) b D₁ D₂ c₀ j x := by
  obtain ⟨z,t⟩ := x
  let k := schedule m j
  change (if ambientInside p (1+k) (powerChart p (k+1) z) then
    b j * childPhase p k (powerChart p (k+1) z) *
    (D₁ (powerChart p (k+1) z) * channel q (a q:ℂ) t +
    (if j%2=0 then c₀ else -c₀) * (D₂ (powerChart p (k+1) z) * channel q (-(a q:ℂ)) t))
    else 0) = _
  rw [if_pos (chart_occ k z),full_phase]
  rw [show (a q:ℂ) = (Real.sqrt (q:ℝ):ℂ)⁻¹ from Complex.ofReal_inv _]
  by_cases h : j%2=0
  · simp only [birthVector,h,if_true]
    rfl
  · simp only [birthVector,h,if_false]
    change _ = b j * negativeDigit p _ * (_ - c₀ * _)
    simp only [sub_eq_add_neg,neg_mul]
    rfl

/-- A purely finite summation lemma. If a full matrix kills a column, the
principal corner kills its restriction when the column vanishes off that corner. -/
theorem corner_annihilates {I X : Type*} [Fintype I] [Fintype X] (i : I ↪ X)
    (C : Matrix X X ℂ) (v : I → ℂ) (V : X → ℂ)
    (inside : ∀ k, V (i k) = v k) (outside : ∀ x ∉ Set.range i, V x=0)
    (null : C *ᵥ V=0) : C.submatrix i i *ᵥ v = 0 := by
  ext x
  have e : (∑ k, C (i x) (i k)*v k) = ∑ z, C (i x) z*V z := by
    apply Fintype.sum_of_injective i i.injective
    · intro z h; simp [outside z h]
    · intro k; rw [inside]
  exact e.trans (congrFun null (i x))

/-- The actual mixed-head quadratic test after a scalar normalization of the
finite physical candidate, for every requested birth already present at cutoff. -/
theorem original_birth_zero (m l : ℕ) (hl : l<p) (rsmall : (avgColor p l)^2<1)
    (f : ℕ → ℝ) (hf : ∀ i, 0<f i) (hm : Monotone f)
    (W₁ W₂ : Additive (pRoots p) → ℝ) (d₁ : realizes m l (a q) f W₁)
    (d₂ : realizes m l (-a q) f W₂) (w₁ : ∀ z, 0<W₁ z) (w₂ : ∀ z, 0<W₂ z)
    (n : ℕ) (j : Fin n) (γ : ℂ)
    (A : (Additive (pRoots p) × ZMod q) × (Additive (pRoots p) × ZMod q) → ℂ)
    (rep : ∀ x y, A (mixedRootHead p q m n x,mixedRootHead p q m n y) =
      γ * actualMatrix (q:=q) (originalWeight (p:=p) (L:=p^m) f n) (signFlag l n)
        (perturbation (L:=p^m) q (fun _ => negativeDigit p) f l n oddSign) x y) :
    testValue (fun i => cyclicMixedHead p q i)
      (.quad (schedule m j) (birthVector (schedule m) (fun _ => negativeDigit p)
      (amp p q m l f) (factor q (a q) W₁) (factor q (-a q) W₂)
      (ratio (a q) (avgColor p l)) j)) A = 0 := by
  let E := mixedRootHead p q m n
  let F := cyclicMixedHead p q (schedule m j)
  let s := schedule m j
  let V := value (p:=p) (q:=q) m (amp p q m l f) (factor q (a q) W₁) (factor q (-a q) W₂)
             (ratio (a q) (avgColor p l)) j
  let v := birthVector (q:=q) (schedule m) (fun _ => negativeDigit p)
      (amp p q m l f) (factor q (a q) W₁) (factor q (-a q) W₂)
      (ratio (a q) (avgColor p l)) j
  let C := actualMatrix (q:=q) (originalWeight (p:=p) (L:=p^m) f n) (signFlag l n)
        (perturbation (L:=p^m) q (fun _ => negativeDigit p) f l n oddSign)
  have lift (z : Head p q s) : ∃ y, E y=F z := by
    have ins := chart_occ (p:=p) s z.1
    obtain ⟨w,hw⟩ := (inside_sparse_iff m (j.val+1) _).mp ins
    exact mixedRootHead_mono p q m j.isLt
      ⟨(encodeLevel p (p^m) (j.val+1) w,z.2),Prod.ext hw rfl⟩
  choose inc ih using lift
  let i : Head p q s ↪ (ZMod (levelSize p (p^m) n) × ZMod q) :=
    ⟨inc,fun a b h => cyclicMixedHead_injective p q s ((ih a).symm.trans ((congrArg E h).trans (ih b)))⟩
  have agree (z) : V (E (i z))=v z := (congrArg V (ih z)).trans (value_birth ..)
  have outside (x) (hx : x ∉ Set.range i) : V (E x)=0 := by
    have h : ¬ambientInside p (1+s) (E x).1 := by
      intro occ
      rw [Nat.add_comm 1 s] at occ
      obtain ⟨z,hz⟩ := (range_rootHead (le_iSup (fun t : ℕ => rootsOfUnity (p^t) ℂ) (s+1)) (E x).1).mpr occ
      apply hx
      refine ⟨(z,(E x).2),mixedRootHead_injective p q m n ((ih _).trans ?_)⟩
      exact Prod.ext hz rfl
    exact if_neg h
  let N := embedding (X:=ZMod (levelSize p (p^m) n)) q *
       channelNull (L:=p^m) q (fun _ => negativeDigit p) f l n oddSign
  have vals (x) : N x j=V (E x) := mounted_value m l hl rsmall f hf hm W₁ W₂ d₁ d₂ w₁ w₂ n x j
  have nul : C*N=0 := (finiteOriginalPSD (L:=p^m) (fun _ => negativeDigit p)
    (fun _ => negativeDigit_nontrivial) f hf hm l n oddSign).2
  have col : C *ᵥ (fun x => V (E x))=0 := by
    ext x
    have h := congrFun (congrFun nul x) j
    change (∑ y, C x y * V (E y)) = 0
    simpa only [Matrix.mul_apply,vals,Matrix.zero_apply] using h
  have small := corner_annihilates i C v (fun x => V (E x)) agree outside col
  have mat : positionCorner (fun k => cyclicMixedHead p q k) s A = γ • C.submatrix i i := by
    ext x y
    change A (F x,F y)=γ * C (inc x) (inc y)
    rw [←ih x,←ih y]
    exact rep _ _
  rw [qTest_eval,←corner_form]
  change (star v ⬝ᵥ (positionCorner (fun k => cyclicMixedHead p q k) s A *ᵥ v)).re=0
  rw [mat,smul_mulVec,small,smul_zero,dotProduct_zero]
  rfl

end KDClosure.ScheduledNull
