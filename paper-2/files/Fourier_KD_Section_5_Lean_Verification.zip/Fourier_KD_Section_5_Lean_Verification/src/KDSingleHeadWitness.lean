import KDHeadCompression
import KDFiniteWitnessOperator
import Mathlib.Analysis.Matrix.Order

namespace KDClosure
open Set Matrix Discrete
open scoped ComplexOrder MatrixOrder BigOperators

/-- A normalized finite PSD matrix has every entry inside the coordinate box.
The bound follows from Cauchy--Schwarz on a Gram factor and the trace budget. -/
theorem finite_psd_entry_bound {I : Type*} [Fintype I] (C : Matrix I I ℂ) (ps : C.PosSemidef)
    (tr : ∑ i, (C i i).re ≤ 1) (i j : I) : ‖C i j‖ ≤ 1 := by
  classical
  obtain ⟨B,h⟩ := CStarAlgebra.nonneg_iff_eq_star_mul_self.mp ps.nonneg
  let w (i : I) : EuclideanSpace ℂ I := WithLp.toLp 2 (fun k => B k i)
  have gram (i j : I) : inner ℂ (w i) (w j) = C i j := by
    rw [h]
    simp only [PiLp.inner_apply,RCLike.inner_apply,Matrix.mul_apply,Matrix.star_eq_conjTranspose,
      Matrix.conjTranspose_apply]
    apply Finset.sum_congr rfl
    intro k _
    change B k j * star (B k i) = star (B k i)*B k j
    ring
  have sq (i : I) : ‖w i‖^2 = (C i i).re := by rw [norm_sq_eq_re_inner (𝕜:=ℂ),gram]; rfl
  have bound (k : I) : ‖w k‖ ≤ 1 := by
    have le := (Finset.single_le_sum (fun (i:I) (_:i∈Finset.univ) =>
      (Complex.nonneg_iff.mp (ps.diag_nonneg (i:=i))).1) (Finset.mem_univ k)).trans tr
    nlinarith [sq k]
  rw [←gram]
  exact (norm_inner_le_norm _ _).trans (by simpa using mul_le_mul (bound i) (bound j) (norm_nonneg _) zero_le_one)

variable {p q : ℕ} [Fact p.Prime] [Fact q.Prime]

theorem lift_head_injective {n N : ℕ} (h : n≤N) : Function.Injective (lift_head (p:=p) (q:=q) h) := by
  intro i j hij
  apply cyclicMixedHead_injective p q n
  exact (lift_head_point h i.1 i.2).symm.trans ((congrArg (cyclicMixedHead p q N) hij).trans
      (lift_head_point h j.1 j.2))

/-- Ordinary trace and PSD descend to any earlier chart of the physical group. -/
theorem earlier_pos_trace {n N : ℕ} (h : n≤N) (C : Matrix (Head p q N) (Head p q N) ℂ)
    (ps : C.PosSemidef) (tr : ∑ i, (C i i).re ≤ 1)
    (A : MixedD p q × MixedD p q → ℂ)
    (rep : ∀ i j, A (cyclicMixedHead p q N i,cyclicMixedHead p q N j) = C i j) :
    (∀ u, 0 ≤ (cornerQ (fun i => cyclicMixedHead p q i) n u A).re) ∧
      cornerTrace (fun i => cyclicMixedHead p q i) n A ≤ 1 := by
  let f := lift_head (p:=p) (q:=q) h
  let r : Head p q n ↪ Head p q N := ⟨f,lift_head_injective h⟩
  let e := fun i => (cyclicMixedHead p q i : Head p q i → _)
  have small (i j : Head p q n) : A (e n i,e n j)=C (f i) (f j) := by
    exact ((congrArg₂ (fun i j => A (i,j)) (lift_head_point h i.1 i.2)
      (lift_head_point h j.1 j.2)).symm).trans (rep _ _)
  constructor
  · intro u
    have form : positionCorner e n A = C.submatrix f f := by ext i j; exact small i j
    rw [←corner_form (e:=e) n,form]
    exact (Complex.nonneg_iff.mp ((ps.submatrix f).dotProduct_mulVec_nonneg u)).1
  · change ∑ i, (A (e n i,e n i)).re ≤ 1
    simp_rw [small]
    calc
      _ = ∑ i ∈ Finset.univ.map r, (C i i).re := by simp [r]
      _ ≤ ∑ i, (C i i).re := Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _)
        (fun i _ _ => (Complex.nonneg_iff.mp (ps.diag_nonneg (i:=i))).1)
      _ ≤ 1 := tr

/-- Single top-head criterion. All positivity, reality, masks and trace tests
at every smaller head are consequences. The remaining layer-specific tests
are exactly the finitely many visible birth quadratures of this witness. -/
theorem single_head_witness_operator (pq : p≠q)
    (l : ℕ) (hl : 0<l) (hlt : l<p) (s : ℕ → ℕ) (hs : StrictMono s)
    (χ : ℕ → AddChar (ZMod p) ℂ) (a : ℕ → ℂ) (ha : ∀ j, a j ≠ 0)
    (d₁ d₂ : Additive (pRoots p) → ℂ) (h₁ : ∀ x, d₁ x ≠ 0) (h₂ : ∀ x, d₂ x ≠ 0)
    (c : ℂ) (hc : c ≠ 0) (o : MixedD p q) (δ : ℝ) (hδ : 0<δ)
    (witness : ∀ K, ∃ N ≥ K, ∃ C : Matrix (Head p q N) (Head p q N) ℂ,
      C.PosSemidef ∧ (∑ i, (C i i).re ≤ 1) ∧
      let e := fun i => (cyclicMixedHead p q i : Head p q i → MixedD p q)
      let A := extendMatrix (e N) C
      δ ≤ (A (o,o)).re ∧
      (∀ x t k v, 0 ≤ table (rowsOf (e N) A) x t k v) ∧
      (∀ x t k v, Protected (color (p:=p) N l) x t v → table (rowsOf (e N) A) x t k v=0) ∧
      (∀ j≤K, testValue e (.quad (s j) (birthVector s χ a d₁ d₂ c j)) A = 0)) :
    ∃ T ∈ (physicalTests p q).extremePoints ℝ, T.IsPositive ∧
      (∑' x : MixedD p q, (inner ℂ (lp.single 2 x (1:ℂ)) (T (lp.single 2 x (1:ℂ)))).re) = 1 ∧
      ¬ FiniteDimensional ℂ (LinearMap.range T.toLinearMap) := by
  apply finite_witness_operator p q pq l hl hlt s hs χ a ha d₁ d₂ h₁ h₂ c hc o δ hδ
  intro K
  obtain ⟨N,hN,C,ps,tr,diag,pos,mask,birth⟩ := witness K
  let e := fun i => (cyclicMixedHead p q i : Head p q i → MixedD p q)
  let A := extendMatrix (e N) C
  have eq := extendMatrix_on (e N) (cyclicMixedHead_injective p q N) C
  have tables (n : ℕ) (hn : n≤N) := earlier_table_nonneg_mask hn l C A eq pos mask
  refine ⟨N,C,finite_psd_entry_bound C ps tr,ps.isHermitian,diag,?_⟩
  intro n hn
  have ht := earlier_pos_trace (hn.trans hN) C ps tr A eq
  refine ⟨⟨ht.1,ht.2,fun x t k v => (Complex.nonneg_iff.mp ((tables n (hn.trans hN) x t k v).1)).1,
    fun x t k v => (Complex.nonneg_iff.mp ((tables n (hn.trans hN) x t k v).1)).2.symm⟩,?_⟩
  refine ⟨fun j hj => birth j (hj.trans hn),?_⟩
  intro m hm x t k v hv
  rw [kdTest_eval,(tables m ((hm.trans hn).trans hN) x t k v).2 hv,Complex.zero_re]

end KDClosure
