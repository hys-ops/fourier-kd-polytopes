import KDVisibility
import KDActualPacketRow
namespace KDClosure
open AtomBridge AmbientFourier WaveSupport
variable {p : ℕ} [Fact p.Prime]

theorem weight_le_fresh {L : ℕ} [NeZero L] (n : ℕ) (x : Level p L n) :
    weight p L (fresh p L) n x ≤ fresh p L n := by
  have hf := fresh_props (p:=p) (L:=L)
  have hL : 1 ≤ (L:ℝ) := by exact_mod_cast Nat.pos_of_ne_zero (NeZero.ne L)
  have hθ : 1/(L:ℝ) ≤ 1 := (div_le_one (by positivity)).mpr hL
  induction n with
  | zero => rfl
  | succ n ih =>
    rcases x with ⟨b,g,x⟩
    simp only [weight,extendWeight]
    split_ifs
    · exact (ih x).trans (hf.2 (Nat.le_succ n))
    · exact le_rfl
    · rw [mean_eq_mix]
      exact (reciprocal_bounds (1/(L:ℝ)) _ (by positivity) hθ hf.1 hf.2 (n+1)).2.1

theorem chart_sparsePoint (m n : ℕ) (x : Level p (p^m) n) :
    powerChart p (1+n*(m+1)) (reindex (size_prime_power p m n) (encodeLevel p (p^m) n x)) =
      sparsePoint p m n x :=
  (reindex_chart (size_prime_power p m n) _ _ _).symm

/-- Original positive baseline d on the whole Prüfer group. It has finite
total mass, equals one at zero, and every active layer has its stated strict
amplitude margin on all later cyclic matrices. -/
theorem global_baseline (m : ℕ) (κ : ℝ) (hL : 1<p^m)
    (bound : ∀ j, κ / reciprocalMean (1/((p^m:ℕ):ℝ)) (fresh p (p^m)) j <
      1 / fresh p (p^m) j) :
    ∃ d : Additive (pRoots p) → ℝ, (∀ z, 0<d z) ∧ d 0=1 ∧
      (∀ n x, d (sparsePoint p m n x) = 1 / weight p (p^m) (fresh p (p^m)) n x) ∧
      (∀ n, ∑ x : ZMod (p^(1+n*(m+1))), d (powerChart p (1+n*(m+1)) x) ≤
        (p:ℝ) + ∑' j, shellMass p (p^m) j) ∧
      ∀ j z, ambientInside p (1+(j+1)*(m+1)) z →
        κ / reciprocalMean (1/((p^m:ℕ):ℝ)) (fresh p (p^m)) (j+1) < d z := by
  let f := fresh p (p^m)
  obtain ⟨W,_,h⟩ := global_weight_label (p:=p) m f
  let d (z : Additive (pRoots p)) := 1 / W z
  have eqn (n) (x : Level p (p^m) n) :
      d (sparsePoint p m n x)=1/weight p (p^m) f n x := by simp only [d,(h n x).1]
  have posW (n : ℕ) (x : Level p (p^m) n) := weights_positive f fresh_props.1 fresh_props.2 n x
  have pos (z) : 0 < d z := by
    obtain ⟨n,x,rfl⟩ := sparsePoint_surjective (p:=p) m z
    rw [eqn]; exact one_div_pos.mpr (posW n x)
  have zero : d 0 = 1 := by
    have z := eqn 0 (0 : ZMod p)
    change d (sparseRootHead p m 0 0) = 1 / f 0 at z
    simpa [f,fresh] using z
  refine ⟨d,pos,zero,eqn,?_,?_⟩
  · intro n
    let e := (encodeLevel p (p^m) n).trans (reindex (size_prime_power p m n)).toEquiv
    rw [←Equiv.sum_comp e (fun x => d (powerChart p (1+n*(m+1)) x))]
    change (∑ x, d (powerChart p _ (reindex _ (encodeLevel p (p^m) n x)))) ≤ _
    simp only [chart_sparsePoint,eqn]
    exact uniform_levelMass hL n
  · intro j z hz
    obtain ⟨x,rfl⟩ := (inside_sparse_iff m (j+1) z).mp hz
    rw [eqn]
    exact (bound (j+1)).trans_le (one_div_le_one_div_of_le (posW _ x) (weight_le_fresh _ _))

end KDClosure
