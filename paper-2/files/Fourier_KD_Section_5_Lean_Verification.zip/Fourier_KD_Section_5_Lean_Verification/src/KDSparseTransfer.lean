import KDFiniteSparseKD
import KDPhysicalBudget
import KDScheduledNull
import KDSingleHeadWitness

namespace KDClosure.SparseTransfer
open Matrix Set PhysicalLift WaveSupport AtomBridge
open scoped ComplexOrder BigOperators
variable {p q : ℕ} [Fact p.Prime] [Fact q.Prime]

abbrev topLevel (m n : ℕ) := n*(m+1)

/-- Align the two equivalent ways of writing the dense cyclic exponent. -/
def shift (p m n : ℕ) : ZMod (p^(topLevel m n+1)) ≃+* ZMod (p^(1+n*(m+1))) :=
  reindex (congrArg (fun t => p^t) (Nat.add_comm ..))

def toNative (p m n : ℕ) : ZMod (p^(topLevel m n+1)) ≃+* ZMod (levelSize p (p^m) n) :=
  (shift p m n).trans (reindex (size_prime_power p m n)).symm

def toNativePair (p q m n : ℕ) : Head p q (topLevel m n) ≃ (ZMod (levelSize p (p^m) n) × ZMod q) :=
  (toNative p m n).toEquiv.prodCongr (Equiv.refl _)

noncomputable def nativeOriginal (p q m l n : ℕ) [Fact p.Prime] [Fact q.Prime] :=
  actualMatrix (q:=q) (originalWeight (p:=p) (L:=p^m) (fresh p (p^m)) n) (signFlag l n)
    (perturbation q (fun _ => negativeDigit p) (fresh p (p^m)) l n ScheduledNull.oddSign)

noncomputable def topOriginal (p q m l n : ℕ) [Fact p.Prime] [Fact q.Prime] :=
  (nativeOriginal p q m l n).submatrix (toNativePair p q m n) (toNativePair p q m n)

private theorem sign_eq (n : ℕ) : @ScheduledNull.oddSign n = (fun j => SparseKD.plus j.val) := by
  funext j; unfold ScheduledNull.oddSign SparseKD.plus
  congr 1; apply propext; omega

omit [Fact q.Prime] in
theorem nativeChart (m n : ℕ) (z : Head p q (topLevel m n)) :
    cyclicMixedHead p q (topLevel m n) z = mixedRootHead p q m n (toNativePair p q m n z) := by
  apply Prod.ext
  swap
  · rfl
  have hn : rootsOfUnity (levelSize p (p^m) n) ℂ ≤ pRoots p := by
    rw [size_prime_power]; exact le_iSup (fun j : ℕ => rootsOfUnity (p^j) ℂ) _
  change rootHead (le_iSup (fun j : ℕ => rootsOfUnity (p^j) ℂ) (topLevel m n+1)) z.1 = rootHead hn ((reindex (size_prime_power p m n)).symm (shift p m n z.1))
  calc _ = rootHead (le_iSup (fun j : ℕ => rootsOfUnity (p^j) ℂ) (1+n*(m+1))) (shift p m n z.1) :=
           reindex_chart (congrArg (fun t => p^t) (Nat.add_comm ..)) (le_iSup (fun j : ℕ => rootsOfUnity (p^j) ℂ) (topLevel m n+1)) (le_iSup (fun j : ℕ => rootsOfUnity (p^j) ℂ) (1+n*(m+1))) _
       _ = _ := by
          rw [reindex_chart (size_prime_power p m n) hn (le_iSup (fun j : ℕ => rootsOfUnity (p^j) ℂ) (1+n*(m+1)))]
          rw [RingEquiv.apply_symm_apply]

theorem native_rep (m l n : ℕ) (A : MixedD p q × MixedD p q → ℂ) (γ : ℂ)
    (rep : ∀ i j, A (cyclicMixedHead p q (topLevel m n) i,cyclicMixedHead p q (topLevel m n) j) =
      γ * topOriginal p q m l n i j) (i j) :
    A (mixedRootHead p q m n i,mixedRootHead p q m n j)=γ*nativeOriginal p q m l n i j := by
  let b := toNativePair p q m n
  have hi := nativeChart m n (b.symm i)
  have hj := nativeChart m n (b.symm j)
  change _ = mixedRootHead p q m n (b (b.symm i)) at hi
  change _ = mixedRootHead p q m n (b (b.symm j)) at hj
  rw [b.apply_symm_apply] at hi hj
  rw [←hi,←hj,rep]
  change _ * nativeOriginal p q m l n (b (b.symm i)) (b (b.symm j)) = _
  rw [b.apply_symm_apply,b.apply_symm_apply]

private theorem reindex_val {a b : ℕ} (h : a=b) (x : ZMod a) : (reindex h x).val=x.val := by
  subst b; rfl

private theorem reindex_val_symm {a b : ℕ} (h : a=b) (x : ZMod b) : ((reindex h).symm x).val=x.val := by
  subst b; rfl

private theorem color_agrees (m l n : ℕ) (x : ZMod (p^(topLevel m n+1))) :
    SparseKD.localSign p m l n (shift p m n x) ↔ color (p:=p) (topLevel m n) l x := by
  let y := (encodeLevel p (p^m) n).symm (toNative p m n x)
  change decide ((baseLabel p (p^m) n y).val < l)=true ↔ x.val < l*p^(topLevel m n)
  rw [decide_eq_true_eq,←physical_color n l y]
  have val : (encodeLevel p (p^m) n y).val=x.val := by
    dsimp only [y]; rw [Equiv.apply_symm_apply]
    exact (reindex_val_symm (size_prime_power p m n) _).trans (reindex_val _ _)
  have power : (p*p^m)^n=p^(topLevel m n) := by
    rw [mul_comm p,←pow_succ,←pow_mul,Nat.mul_comm (m+1) n]
  rw [val,power]

private theorem transport_table {M M' : ℕ} [NeZero M] [NeZero M'] (h : M=M')
    (F : Blocks M' q) (x : ZMod M) (t : ZMod q) (k : ZMod M) (s : ZMod q) :
    table (fun a d b v => F (reindex h a) (reindex h d) b v) x t k s =
    table F (reindex h x) t (reindex h k) s := by subst M'; rfl

/-- One literal unnormalized top matrix, precisely the ordinary cyclic-head
reindex of the PSD and physical wavelet witness. -/
theorem top_certificate {l : ℕ} (hl : 0<l) (_hlt : l<p) (m n : ℕ) (hL : 1<p^m)
    (kd : ∀ (x k : ZMod (p^(1+n*(m+1)))) (t s : ZMod q),
        let z := table (SparseKD.originalRows p q m l n (fresh p (p^m))) x t k s
        0≤z.re ∧ z.im=0 ∧ (z=0 ↔ Protected (SparseKD.localSign p m l n) x t s)) :
    let C := topOriginal p q m l n
    let e := fun i => (cyclicMixedHead p q i : Head p q i → MixedD p q)
    let A := extendMatrix (e (topLevel m n)) C
    C.PosSemidef ∧ (∑ i, (C i i).re) ≤ (2*q:ℝ)*((p:ℝ)+∑' j,shellMass p (p^m) j) ∧
    (∑ t, (C (0,t) (0,t)).re)=2 ∧
    (∀ x t k v, 0 ≤ table (rowsOf (e (topLevel m n)) A) x t k v) ∧
    (∀ x t k v, Protected (color (p:=p) (topLevel m n) l) x t v →
        table (rowsOf (e (topLevel m n)) A) x t k v=0) ∧
    (∀ i j, A (mixedRootHead p q m n i,mixedRootHead p q m n j) = 1*nativeOriginal p q m l n i j) := by
  dsimp only
  let C := topOriginal p q m l n
  let e := fun i => (cyclicMixedHead p q i : Head p q i → MixedD p q)
  let A := extendMatrix (e (topLevel m n)) C
  let b := toNativePair p q m n
  let F := SparseKD.originalRows p q m l n (fresh p (p^m))
  have rep := extendMatrix_on (e (topLevel m n)) (cyclicMixedHead_injective p q _) C
  have form : rowsOf (e (topLevel m n)) A =
      fun a d b v => F (shift p m n a) (shift p m n d) b v := by
    funext x h t u
    change A (e _ (x,t),e _ (x+h,u))=_
    trans C (x,t) (x+h,u)
    · exact rep _ _
    change actualMatrix _ _ (perturbation q _ _ _ _ ScheduledNull.oddSign) _ _ =
      actualMatrix _ _ (perturbation q _ _ _ _ (fun i => SparseKD.plus i.val)) _ _
    rw [sign_eq]
    simp [toNativePair,toNative,SparseKD.back]
  have formulas (x t k v) : table (rowsOf (e (topLevel m n)) A) x t k v =
       table F (shift p m n x) t (shift p m n k) v := by
    rw [form]
    exact transport_table _ F x t k v
  have ps := (finiteOriginalPSD (p:=p) (q:=q) (L:=p^m) (fun _ => negativeDigit p)
    (fun _ => negativeDigit_nontrivial) (fresh p (p^m)) fresh_props.1 fresh_props.2 l n ScheduledNull.oddSign).1
  have budget := actual_unnormalized_budget (p:=p) (q:=q) (L:=p^m) hL n l hl
    (perturbation q (fun _ => negativeDigit p) (fresh p (p^m)) l n ScheduledNull.oddSign)
  refine ⟨ps.submatrix b,?_,?_,?_,?_,?_⟩
  · exact (b.sum_comp (fun i => (nativeOriginal p q m l n i i).re)).le.trans budget.1
  · change (∑ t, (nativeOriginal p q m l n (toNative p m n 0,t) (toNative p m n 0,t)).re)=2
    rw [map_zero]; exact budget.2
  · intro x t k v
    change 0 ≤ table (rowsOf (e (topLevel m n)) A) x t k v
    rw [formulas]
    obtain ⟨h₁,h₂,_⟩ := kd (shift p m n x) (shift p m n k) t v
    exact Complex.nonneg_iff.mpr ⟨h₁,h₂.symm⟩
  · intro x t k v h
    change table (rowsOf (e (topLevel m n)) A) x t k v=0
    rw [formulas]
    apply (kd (shift p m n x) (shift p m n k) t v).2.2.mpr
    simpa only [Protected,color_agrees] using h
  · exact native_rep m l n A 1 (fun i j => (rep i j).trans (one_mul _).symm)

end KDClosure.SparseTransfer
