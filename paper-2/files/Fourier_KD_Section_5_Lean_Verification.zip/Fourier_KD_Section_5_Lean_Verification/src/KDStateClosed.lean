import KDStateClosedTrace
import KDChainLimitEndpoint

/-! For the physical KD section, trace-norm limits of mixtures of normalized
pure states are again normalized physical states. No chain hypothesis is needed. -/
noncomputable section
namespace KDClosure.Hull
open Classical Set Filter MeasureTheory LCAQuotient LCAReality ChainLimit.Kernel
open scoped ComplexOrder InnerProductSpace ENNReal Topology KDClosure.SubgroupMeasure

variable {G : Type*} [AddCommGroup G] [TopologicalSpace G] [IsTopologicalAddGroup G]
    [LocallyCompactSpace G] [SecondCountableTopology G] [MeasurableSpace G] [BorelSpace G]
variable (μ : Measure G) [μ.IsAddHaarMeasure] (ν : Measure (LCAReality.Dual G)) [SFinite ν]
    (F : FourierRealization μ ν)

theorem ambientStates_convex : Convex ℝ (ambientStates μ ν F) := by
  intro T hT U hU a c ha hc sum
  obtain ⟨k,act,_,_⟩ := hT.2.2
  obtain ⟨l,act',_,_⟩ := hU.2.2
  obtain rfl := (op_eq_of_acts μ act).symm
  obtain rfl := (op_eq_of_acts μ act').symm
  have mix : op μ (a • k+c • l) = a • op μ k+c • op μ l := by
    change ((operatorMap μ).restrictScalars ℝ) (a • k+c • l) = _
    rw [map_add,map_smul,map_smul]; rfl
  rw [←mix]
  apply (ambient_iff μ ν _).mpr
  refine ⟨substate_convex μ ν F ((ambient_iff μ ν _).mp hT).1 ((ambient_iff μ ν _).mp hU).1 ha hc sum,?_⟩
  rw [mix]
  exact positive_trace_one_mix hT.1 hU.1 hT.2.1 hU.2.1 ha hc sum

theorem traceClosure_subset_ambientStates {s : Set (H μ →L[ℂ] H μ)}
    (hs : s ⊆ ambientStates μ ν F) : traceClosure s ⊆ ambientStates μ ν F := by
  intro T near
  have cont : Continuous (coord μ) := by
    apply continuous_pi
    intro z
    change Continuous (fun A : H μ →L[ℂ] H μ => inner ℂ z.1 (A z.2))
    fun_prop
  have sub : coord μ '' s ⊆ cmap μ '' substate μ ν F := by
    rintro _ ⟨U,hU,rfl⟩
    obtain ⟨k,act,_,_⟩ := (hs hU).2.2
    have eqn := op_eq_of_acts μ act
    exact ⟨k,((ambient_iff μ ν k).mp (eqn.symm ▸ hs hU)).1,congrArg (coord μ) eqn⟩
  have coordmem := closure_minimal sub (compact_coords μ ν F).isClosed
    (image_closure_subset_closure_image cont (mem_image_of_mem (coord μ) (traceClosure_subset_normClosure s near)))
  obtain ⟨k,hk,eqn⟩ := coordmem
  have opEq : op μ k = T := coord_inj μ eqn
  obtain rfl := opEq.symm
  apply (ambient_iff μ ν _).mpr
  exact ⟨hk,fun _ ⟨n,u,on,e⟩ => e ▸ hk.2.1 n u on,trace_one_lower_of_traceClosure (fun _ h => (hs h).2.1) near⟩

theorem closed_hull_ambientPure_subset :
    traceClosure (convexHull ℝ (ambientPure μ ν F)) ⊆ ambientStates μ ν F :=
  traceClosure_subset_ambientStates μ ν F (convexHull_min (fun _ h => h.1) (ambientStates_convex μ ν F))

end KDClosure.Hull
