import KDAllAmbientPure
import KDChainLimitTraceFace
import KDCompactFourierTransfer

/-! Variational trace closure controls the operator norm and preserves normalization.
The proof of affinity uses a single Hilbert basis and absolutely summable positive diagonals. -/
noncomputable section
namespace KDClosure.Hull
open Classical Set Filter CompactFourier Discrete ChainLimit
open scoped ComplexOrder InnerProductSpace ENNReal Topology

variable {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℂ X] [CompleteSpace X]

theorem norm_le_of_traceVariational_lt {A : X →L[ℂ] X} {ε : ℝ} (hε : 0 < ε)
    (h : traceVariational A < ENNReal.ofReal ε) : ‖A‖ ≤ ε := by
  apply ContinuousLinearMap.opNorm_le_of_re_inner_le hε.le
  intro x y hx hy
  have h' := (unit_entry_le A x y hx hy).trans_lt h
  rw [←ofReal_norm, ENNReal.ofReal_lt_ofReal_iff hε] at h'
  exact (Complex.re_le_norm _).trans ((norm_inner_symm (𝕜 := ℂ) _ _).le.trans h'.le)

theorem traceClosure_subset_normClosure (s : Set (X →L[ℂ] X)) : traceClosure s ⊆ closure s := by
  intro T h
  apply Metric.mem_closure_iff.mpr
  intro ε hε
  obtain ⟨A,hA,hs⟩ := h (ε/2) (half_pos hε)
  exact ⟨A,hA,by rw [dist_comm,dist_eq_norm]; exact (norm_le_of_traceVariational_lt (half_pos hε) hs).trans_lt (half_lt_self hε)⟩

theorem trace_one_lower_of_traceClosure {s : Set (X →L[ℂ] X)}
    (normalized : ∀ A∈s, IsLUB (LCAQuotientTrace.frameMass A) 1)
    {T : X →L[ℂ] X} (h : T ∈ traceClosure s) :
    ∀ v ∈ upperBounds (LCAQuotientTrace.frameMass T), 1 ≤ v := by
  intro v hv
  by_contra! hlt
  let ε := (1-v)/2
  have hp : 0<ε := by dsimp [ε]; linarith
  obtain ⟨A,hA,near⟩ := h ε hp
  have upper : v+ε ∈ upperBounds (LCAQuotientTrace.frameMass A) := by
    rintro _ ⟨n,u,hu,rfl⟩
    have e := (frame_sum_le (A-T) hu hu).trans_lt near
    have f : ∑ i, ‖inner ℂ (u i) ((A-T) (u i))‖ < ε := by
      apply (ENNReal.ofReal_lt_ofReal_iff hp).mp
      simpa only [ENNReal.ofReal_sum_of_nonneg (fun _ _ => norm_nonneg _), ofReal_norm] using e
    have d := Finset.sum_le_sum (s := Finset.univ) (fun (i : Fin n) _ =>
      Complex.re_le_norm (inner ℂ (u i) ((A-T) (u i))))
    simp only [sub_apply,inner_sub_right,Complex.sub_re,Finset.sum_sub_distrib] at d f
    have tv := hv ⟨n,u,hu,rfl⟩
    linarith
  have bad := (normalized A hA).2 upper
  dsimp [ε] at bad
  linarith

private theorem basis_hasSum {I : Type*} [DecidableEq I] (b : HilbertBasis I ℂ X)
    (T : X →L[ℂ] X) (p : T.IsPositive) (r : ℝ) :
    IsLUB (LCAQuotientTrace.frameMass T) r ↔
      HasSum (fun i => (entries (unitaryPush b.repr T) (i,i)).re) r := by
  have e : finiteFrameMass (unitaryPush b.repr T) = LCAQuotientTrace.frameMass T :=
    frameMass_unitary b.repr T
  rw [← e]
  exact trace_hasSum ((positive_unitary_iff b.repr T).mpr p)

theorem positive_trace_one_mix {T U : X →L[ℂ] X} (p : T.IsPositive) (q : U.IsPositive)
    (ht : IsLUB (LCAQuotientTrace.frameMass T) 1) (hu : IsLUB (LCAQuotientTrace.frameMass U) 1)
    {a c : ℝ} (ha : 0≤a) (hc : 0≤c) (sum : a+c=1) :
    IsLUB (LCAQuotientTrace.frameMass (a • T + c • U)) 1 := by
  classical
  obtain ⟨I,b,_⟩ := exists_hilbertBasis ℂ X
  have ps : (a • T+c • U).IsPositive := by
    rw [←algebraMap_smul ℂ a,←algebraMap_smul ℂ c]
    exact (p.smul_of_nonneg (Complex.zero_le_real.mpr ha)).add (q.smul_of_nonneg (Complex.zero_le_real.mpr hc))
  apply (basis_hasSum b _ ps _).mpr
  have h := (((basis_hasSum b _ p _).mp ht).mul_left a).add (((basis_hasSum b _ q _).mp hu).mul_left c)
  have mix : unitaryPush b.repr (a • T+c • U) =
      a • unitaryPush b.repr T+c • unitaryPush b.repr U := by
    ext x : 1
    simp [unitaryPush]
  simpa only [mix,map_add,map_smul,Pi.add_apply,Pi.smul_apply,Complex.add_re,Complex.smul_re,smul_eq_mul,mul_one,sum] using h

end KDClosure.Hull
