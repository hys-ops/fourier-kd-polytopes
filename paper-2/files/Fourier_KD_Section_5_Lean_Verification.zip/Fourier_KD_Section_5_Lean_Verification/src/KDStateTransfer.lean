import KDConcreteMixed
import Mathlib.Analysis.InnerProductSpace.GramMatrix

noncomputable section
namespace KDClosure
open Set Discrete Matrix ContinuousLinearMap
open scoped InnerProductSpace ComplexOrder BigOperators ENNReal

private theorem positive_gram_factor {H : Type*} [NormedAddCommGroup H]
    [InnerProductSpace ℂ H] [CompleteSpace H] (T : H →L[ℂ] H) (pos : T.IsPositive) :
    ∃ S, T=star S*S := CStarAlgebra.nonneg_iff_eq_star_mul_self.mp
        ((ContinuousLinearMap.nonneg_iff_isPositive T).mpr pos)

/-- Every positive trace-one operator already satisfies the Hermiticity,
quadratic positivity, finite trace budget and uniform entry cap of the
coordinate slice. Thus the only further tests are its finite Fourier tables. -/
theorem operator_mem_cornerSlice_iff_KD {D : Type*} [DecidableEq D]
    {p q : ℕ} [Fact p.Prime] [Fact q.Prime] (e : ∀ n : ℕ, Head p q n → D)
    (inj : ∀ n, Function.Injective (e n))
    (T : L2 D →L[ℂ] L2 D) (pos : T.IsPositive) (tr : IsLUB (finiteFrameMass T) 1) :
    entries T ∈ cornerSlice e ↔
      ∀ n x t k s, 0 ≤ table (rowsOf (e n) (entries T)) x t k s := by
  constructor
  · intro h n x t k s
    exact Complex.nonneg_iff.mpr ⟨h.2.2.2.2.1 n x t k s,(h.2.2.2.2.2 n x t k s).symm⟩
  · intro kd
    have sumDiag := (boundedFrames_iff_diagonal pos).mp ⟨1,tr.1⟩
    have mass : (∑' i, (entries T (i,i)).re)=1 := (trace_isLUB pos sumDiag).unique tr
    obtain ⟨S,hS⟩ := positive_gram_factor T pos
    let base (i : D) := (lp.single 2 i (1:ℂ) : L2 D)
    let w (i : D) := S (base i)
    have gram (x y : D) : inner ℂ (w x) (w y) = entries T (x,y) := by
      change inner ℂ (S (base x)) (S (base y)) = inner ℂ (base x) (T (base y))
      rw [hS]
      exact (S.adjoint_inner_right _ _).symm
    have diag (i : D) : ‖w i‖^2=(entries T (i,i)).re := by
      rw [norm_sq_eq_re_inner (𝕜:=ℂ),gram]; rfl
    have hn (i : D) : 0 ≤ (entries T (i,i)).re := (diag i) ▸ sq_nonneg _
    have bound (i : D) : ‖w i‖ ≤ 1 := by
      have t := (sumDiag.le_tsum i (fun z _ => hn z)).trans_eq mass
      nlinarith [diag i]
    refine ⟨?_,?_,?_,?_,fun n x t k s => (Complex.nonneg_iff.mp (kd n x t k s)).1,
      fun n x t k s => (Complex.nonneg_iff.mp (kd n x t k s)).2.symm⟩
    · rintro ⟨i,j⟩
      rw [←gram]
      exact (norm_inner_le_norm _ _).trans (by simpa using mul_le_mul (bound i) (bound j) (norm_nonneg _) zero_le_one)
    · intro i j
      rw [←gram,←gram]; exact inner_conj_symm _ _
    · intro n u
      have g : positionCorner e n (entries T) = Matrix.gram ℂ (w ∘ e n) := by
        ext i j; exact (gram _ _).symm
      rw [←corner_form e n,g]
      exact (Complex.nonneg_iff.mp ((Matrix.posSemidef_gram ℂ _).dotProduct_mulVec_nonneg u)).1
    · intro n
      let r : Head p q n ↪ D := ⟨e n,inj n⟩
      have le := sumDiag.sum_le_tsum (Finset.univ.map r) (fun i _ => hn i)
      rw [mass] at le
      simpa [cornerTrace,r] using le

/-- Positive, normalized operators subjected only to ordinary finite Fourier
KD nonnegativity (the complex order imposes reality as well). -/
def finiteTableStates (p q : ℕ) [Fact p.Prime] [Fact q.Prime] :
    Set (L2 (MixedD p q) →L[ℂ] L2 (MixedD p q)) := by
  classical
  exact {T | T.IsPositive ∧ IsLUB (finiteFrameMass T) 1 ∧
    ∀ n x t k s, 0 ≤ table (rowsOf (cyclicMixedHead p q n) (entries T)) x t k s}

theorem finiteFourierStates_eq_finiteTableStates (p q : ℕ) [Fact p.Prime] [Fact q.Prime] :
    ConcreteMixed.finiteFourierStates p q = finiteTableStates p q := by
  classical
  ext T
  change (entries T ∈ cornerSlice (fun n => cyclicMixedHead p q n) ∧ T.IsPositive ∧ IsLUB _ 1) ↔
    T.IsPositive ∧ IsLUB _ 1 ∧ _
  constructor
  · rintro ⟨h,ps,tr⟩
    exact ⟨ps,tr,(operator_mem_cornerSlice_iff_KD _ (cyclicMixedHead_injective p q) T ps tr).mp h⟩
  · rintro ⟨ps,tr,h⟩
    exact ⟨(operator_mem_cornerSlice_iff_KD _ (cyclicMixedHead_injective p q) T ps tr).mpr h,ps,tr⟩

theorem mixed_prime_finite_table_state {p q : ℕ} [Fact p.Prime] [Fact q.Prime] (pq : p≠q) :
    ∃ T ∈ (finiteTableStates p q).extremePoints ℝ, T.IsPositive ∧
      IsLUB (finiteFrameMass T) 1 ∧ ¬FiniteDimensional ℂ (LinearMap.range T.toLinearMap) := by
  rw [←finiteFourierStates_eq_finiteTableStates]
  exact ConcreteMixed.mixed_prime_trace_one_state pq

end KDClosure
