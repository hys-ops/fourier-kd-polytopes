import Mathlib.MeasureTheory.Measure.Haar.Unique
import Mathlib.Topology.Algebra.PontryaginDual
import KDOpenCharacterExtension
import Mathlib.MeasureTheory.Function.LpSpace.Basic
import Mathlib.Analysis.Complex.Order

/-! Restriction of characters of a discrete group, with normalized dual Haar
measures. Functions on the small dual pull back without changing their law. -/
noncomputable section
namespace KDClosure.SubgroupMeasure
open MeasureTheory Set
open scoped Topology ComplexOrder

variable {G : Type*} [CommGroup G] [TopologicalSpace G]

scoped instance dualMeasurable (G : Type*) [CommGroup G] [TopologicalSpace G] :
    MeasurableSpace (PontryaginDual G) := borel _
scoped instance dualBorel (G : Type*) [CommGroup G] [TopologicalSpace G] :
    BorelSpace (PontryaginDual G) := ⟨rfl⟩

def restrictChar (H : Subgroup G) : PontryaginDual G →ₜ* PontryaginDual H :=
  PontryaginDual.map (⟨H.subtype,continuous_subtype_val⟩ : H →ₜ* G)

@[simp] theorem restrictChar_apply (H : Subgroup G) (χ : PontryaginDual G) (x : H) :
    restrictChar H χ x = χ (x:G) := rfl

variable [DiscreteTopology G]

private def fullCompact (G : Type*) [CommGroup G] [TopologicalSpace G] [DiscreteTopology G] :
    TopologicalSpace.PositiveCompacts (PontryaginDual G) :=
  ⟨⟨Set.univ,isCompact_univ⟩,by simp⟩

/-- Normalization on the whole compact dual fixes its Haar mass at one. -/
def dualHaar (G : Type*) [CommGroup G] [TopologicalSpace G] [DiscreteTopology G] :
    Measure (PontryaginDual G) := Measure.haarMeasure (fullCompact G)

instance : IsProbabilityMeasure (dualHaar G) := ⟨Measure.haarMeasure_self⟩
instance : Measure.IsHaarMeasure (dualHaar G) :=
  inferInstanceAs (Measure.IsHaarMeasure (Measure.haarMeasure (fullCompact G)))

theorem restriction_onto (H : Subgroup G) : Function.Surjective (restrictChar H) := by
  let U : OpenSubgroup G := ⟨H,isOpen_discrete _⟩
  intro φ
  obtain ⟨ψ,hψ⟩ := OpenCharacter.extends_of_open U φ
  exact ⟨ψ,PontryaginDual.ext fun x => hψ x⟩

/-- The group homomorphism used for pullback is the actual restriction of
continuous circle-valued characters in the compact-open topology. -/
theorem restriction_preserves_haar (H : Subgroup G) :
    MeasurePreserving (restrictChar H) (dualHaar G) (dualHaar H) :=
  MonoidHom.measurePreserving (f := (restrictChar H).toMonoidHom) (restrictChar H).continuous (restriction_onto H) (by simp)

/-- Pullback along a law-preserving map reflects and preserves almost-everywhere
properties, including properties only measurable in the completed target. -/
theorem ae_reflection {X Y : Type*} [MeasurableSpace X] [MeasurableSpace Y]
    {μ : Measure X} {ν : Measure Y} {f : X → Y} (h : MeasurePreserving f μ ν)
    {P : Y → Prop} (hp : NullMeasurableSet {y | P y} ν) :
    (∀ᵐ x ∂μ, P (f x)) ↔ ∀ᵐ y ∂ν, P y := by
  rw [← h.map_eq] at hp ⊢
  change μ (f ⁻¹' {y | P y}ᶜ) = 0 ↔ μ.map f {y | P y}ᶜ = 0
  rw [Measure.map_apply₀ h.measurable.aemeasurable hp.compl]

theorem restrict_ae_iff (H : Subgroup G) {P : PontryaginDual H → Prop}
    (hp : NullMeasurableSet {χ | P χ} (dualHaar H)) :
    (∀ᵐ χ ∂dualHaar G, P (restrictChar H χ)) ↔ ∀ᵐ φ ∂dualHaar H, P φ :=
  ae_reflection (restriction_preserves_haar H) hp

/-- The L² pullback preserves norm and reflects the real, nonnegative cone
a.e., including equality of zero imaginary parts. -/
def pullL2 (H : Subgroup G) :
    Lp ℂ 2 (dualHaar H) →ₗᵢ[ℂ] Lp ℂ 2 (dualHaar G) :=
  Lp.compMeasurePreservingₗᵢ ℂ (restrictChar H) (restriction_preserves_haar H)

theorem pullL2_nonneg_iff (H : Subgroup G) (f : Lp ℂ 2 (dualHaar H)) :
    (∀ᵐ χ ∂dualHaar G, 0 ≤ pullL2 H f χ) ↔ ∀ᵐ φ ∂dualHaar H, 0 ≤ f φ := by
  have hset : MeasurableSet {z : ℂ | 0 ≤ z} := by
    simp only [Complex.nonneg_iff,Set.ofPred_and]
    exact (measurableSet_le measurable_const Complex.continuous_re.measurable).inter
      (measurableSet_eq_fun measurable_const Complex.continuous_im.measurable)
  have hp : NullMeasurableSet {φ | 0 ≤ f φ} (dualHaar H) :=
    ((Lp.stronglyMeasurable f).measurable hset).nullMeasurableSet
  rw [← restrict_ae_iff H hp]
  apply Filter.eventually_congr
  filter_upwards [Lp.coeFn_compMeasurePreserving f (restriction_preserves_haar H)] with χ hχ
  change (0 ≤ (Lp.compMeasurePreserving _ _ f) χ) ↔ _
  rw [hχ]
  rfl

end KDClosure.SubgroupMeasure
