import KDExclusion
import Mathlib.Analysis.Fourier.FiniteAbelian.Orthogonality

namespace KDClosure
open Matrix
open scoped ComplexOrder BigOperators
variable {m q : ℕ} [NeZero m] [Fact q.Prime]

/-- The pair of characters actually used by the two finite negative DFTs. -/
noncomputable def frequency (k : ZMod m × ZMod q) : AddChar (ZMod m × ZMod q) ℂ where
  toFun z := ZMod.stdAddChar (-(z.1*k.1))*ZMod.stdAddChar (-(z.2*k.2))
  map_zero_eq_one' := by simp
  map_add_eq_mul' x y := by
    simp only [Prod.fst_add,Prod.snd_add,add_mul,neg_add,AddChar.map_add_eq_mul]
    ring

theorem all_frequencies : Function.Surjective (frequency (m:=m) (q:=q)) := by
  have hi : Function.Injective (frequency (m:=m) (q:=q)) := by
    intro k l he
    have hp := congrArg (fun χ : AddChar (ZMod m × ZMod q) ℂ => χ (1,0)) he
    have hq := congrArg (fun χ : AddChar (ZMod m × ZMod q) ℂ => χ (0,1)) he
    simp [frequency,ZMod.injective_stdAddChar.eq_iff] at hp hq
    exact Prod.ext hp hq
  exact ((Fintype.bijective_iff_injective_and_card _).mpr
    ⟨hi,(Fintype.card_le_of_injective _ hi).antisymm (AddChar.card_addChar_le _ _)⟩).2

theorem table_old_symbol (F : Blocks m q) (x t k s) :
    table F x t k s = ∑ y, physical F (x,t) y * frequency (k,s) (y-(x,t)) := by
  let z := (x,t)
  rw [← Equiv.sum_comp (Equiv.addLeft z) (fun y => physical F z y * frequency (k,s) (y-z))]
  simp only [table,transRow,ZMod.dft_apply,smul_eq_mul,Finset.mul_sum,Fintype.sum_prod_type]
  apply Finset.sum_congr rfl; intro h _
  apply Finset.sum_congr rfl; intro v _
  simp [z,physical,frequency]; ring

/-- The premise on arbitrary characters in KDAtoms.hermitian_period is supplied
exactly by positivity of the new finite product table. -/
theorem symbol_nonneg_iff (F : Blocks m q) :
    (∀ z χ, 0 ≤ ∑ y, physical F z y * (χ : AddChar (ZMod m × ZMod q) ℂ) (y-z)) ↔
      (∀ x t k s, 0 ≤ table F x t k s) := by
  constructor
  · intro h x t k s; rw [table_old_symbol]; exact h _ _
  · intro h z χ
    obtain ⟨⟨k,s⟩,rfl⟩ := all_frequencies χ
    exact (table_old_symbol F z.1 z.2 k s) ▸ h z.1 z.2 k s

omit [NeZero m] in
theorem period_matches_old_rows (F : Blocks m q) :
    Periodic F ↔ ∀ d z : ZMod m × ZMod q,
      physical F (z+d) ((z+d)+d) = physical F z (z+d) := by
  constructor
  · intro h d z; simpa [physical] using h z.1 d.1 z.2 d.2
  · intro h x k t v; simpa [physical] using h (k,v) (x,t)

end KDClosure
