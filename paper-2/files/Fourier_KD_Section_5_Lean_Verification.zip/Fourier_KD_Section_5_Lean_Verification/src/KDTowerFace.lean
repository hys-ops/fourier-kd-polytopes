import KDCoordinateSlice

namespace KDClosure
open Set
open scoped BigOperators
variable {D : Type*} {p q : ℕ} [Fact p.Prime] [Fact q.Prime]
variable (e : ∀ n : ℕ, Head p q n → D)

noncomputable def evalCoord (i : D×D) : (D×D → ℂ) →L[ℝ] ℂ :=
  ContinuousLinearMap.proj i

inductive TowerTest (p q : ℕ) where
  | kd (n : ℕ) (x : ZMod (p^(n+1))) (t : ZMod q) (k : ZMod (p^(n+1))) (s : ZMod q)
  | quad (n : ℕ) (v : Head p q n → ℂ)

noncomputable def testValue : TowerTest p q → (D×D → ℂ) →L[ℝ] ℝ
  | .kd n x t k s => Complex.reCLM.comp
      (∑ h : ZMod (p^(n+1)), ∑ v : ZMod q,
        ((ZMod.stdAddChar (-(h*k))) * (ZMod.stdAddChar (-(v*s)))) •
        evalCoord (e n (x,t),e n (x+h,t+v)))
  | .quad n v => Complex.reCLM.comp
      (∑ i, ∑ j, (star (v i)*v j) • evalCoord (e n i,e n j))

theorem kdTest_eval (n : ℕ) (x : ZMod (p^(n+1))) (t : ZMod q)
    (k : ZMod (p^(n+1))) (s : ZMod q) (A : D×D → ℂ) :
    testValue e (.kd n x t k s) A = (table (rowsOf (e n) A) x t k s).re := by
  simp only [testValue,ContinuousLinearMap.comp_apply, _root_.sum_apply, _root_.smul_apply,
    evalCoord,ContinuousLinearMap.proj_apply,table,transRow,ZMod.dft_apply,rowsOf,
    smul_eq_mul,Finset.mul_sum,mul_assoc]
  rfl

theorem qTest_eval (n : ℕ) (v : Head p q n → ℂ) (A : D×D → ℂ) :
    testValue e (.quad n v) A = (cornerQ e n v A).re := by
  simp only [testValue,ContinuousLinearMap.comp_apply, _root_.sum_apply, _root_.smul_apply,
    evalCoord,ContinuousLinearMap.proj_apply,smul_eq_mul,cornerQ]
  apply congrArg Complex.re
  apply Finset.sum_congr rfl; intro i _
  apply Finset.sum_congr rfl; intro j _
  ring

theorem test_nonneg (τ : TowerTest p q) (A : D×D → ℂ) (ha : A ∈ cornerSlice e) :
    0 ≤ testValue e τ A := by
  cases τ with
  | kd n x t k s => rw [kdTest_eval]; exact ha.2.2.2.2.1 n x t k s
  | quad n v => rw [qTest_eval]; exact ha.2.2.1 n v

/-- Uniform finite-prefix feasibility suffices; one need not guess an extreme
state, or assume that limits of extreme points remain extreme. -/
theorem towerExtreme (τ : ℕ → TowerTest p q) (o : D) (δ : ℝ) (hδ : 0 < δ)
    (feasible : ∀ n : ℕ, ∃ A ∈ cornerSlice e,
      δ ≤ (A (o,o)).re ∧ ∀ j ≤ n, testValue e (τ j) A = 0) :
    ∃ B ∈ (cornerSlice e).extremePoints ℝ, 0 < (B (o,o)).re ∧
      ∀ j, testValue e (τ j) B = 0 := by
  let S (n : ℕ) := {A ∈ cornerSlice e | δ ≤ (A (o,o)).re ∧
     ∀ j ≤ n, testValue e (τ j) A = 0}
  have cl (n) : IsClosed (S n) := by
    apply (compact_cornerSlice e).isClosed.inter
    apply IsClosed.inter
    · exact isClosed_le continuous_const (Complex.continuous_re.comp (continuous_apply _))
    · change IsClosed {A | ∀ j, ∀ _ : j ≤ n, testValue e (τ j) A = 0}
      simp only [Set.ofPred_forall]
      exact isClosed_iInter fun j => isClosed_iInter fun _ =>
        isClosed_eq (testValue e (τ j)).continuous continuous_const
  have cm : IsCompact (S 0) := (compact_cornerSlice e).of_isClosed_subset (cl _) (fun _ h => h.1)
  obtain ⟨a,ha⟩ := IsCompact.nonempty_iInter_of_sequence_nonempty_isCompact_isClosed S
    (fun _ _ h => ⟨h.1,h.2.1,fun j hj => h.2.2 j (Nat.le_succ_of_le hj)⟩)
    (fun n => by obtain ⟨A,hA,h,hh⟩ := feasible n; exact ⟨A,hA,h,hh⟩) cm cl
  have hx (n) := Set.mem_iInter.mp ha n
  exact extremeWithZeros (cornerSlice e) (compact_cornerSlice e) (fun j => testValue e (τ j))
    (fun j => test_nonneg e (τ j)) (Complex.reCLM.comp (evalCoord (o,o))) (hx 0).1
    (fun j => (hx j).2.2 j le_rfl) (hδ.trans_le (hx 0).2.1)

end KDClosure
