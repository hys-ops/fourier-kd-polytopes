import KDLayerMap
import Mathlib.Analysis.SpecificLimits.Basic

namespace KDClosure
open scoped BigOperators
variable {p L : ℕ} [NeZero p] [NeZero L]
omit [NeZero p] [NeZero L] in
theorem size_formula (j : ℕ) : levelSize p L j = p*(p*L)^j := by
  induction j with
  | zero => simp [levelSize]
  | succ j ih => rw [levelSize,ih,pow_succ]; ring

noncomputable def fresh (p L : ℕ) : ℕ → ℝ
  | 0 => 1
  | j+1 => (levelSize p L (j+1) : ℝ)^2

theorem fresh_props : (∀ j, 0 < fresh p L j) ∧ Monotone (fresh p L) := by
  have hn (j : ℕ) : 0 < (levelSize p L j : ℝ) :=
    Nat.cast_pos.mpr (Nat.pos_of_ne_zero (NeZero.ne _))
  have hp : 1 ≤ (p:ℝ) := by exact_mod_cast (Nat.pos_of_ne_zero (NeZero.ne p))
  have hL : 1 ≤ (L:ℝ) := by exact_mod_cast (Nat.pos_of_ne_zero (NeZero.ne L))
  constructor
  · intro j; cases j with
    | zero => exact zero_lt_one
    | succ j => exact sq_pos_of_pos (hn _)
  · apply monotone_nat_of_le_succ
    intro j
    cases j with
    | zero =>
      have he : 1 ≤ (levelSize p L 1 : ℝ) := by exact_mod_cast
            (Nat.pos_of_ne_zero (NeZero.ne (levelSize p L 1)))
      exact one_le_pow₀ he
    | succ j =>
      apply pow_le_pow_left₀ (hn (j+1)).le
      change (levelSize p L (j+1) : ℝ) ≤ ((levelSize p L (j+1)*L*p : ℕ):ℝ)
      push_cast
      exact le_trans (le_mul_of_one_le_right (hn _).le hL)
        (le_mul_of_one_le_right (by positivity) hp)

/-- The exact trace sum over genuinely new positions in each layer. -/
noncomputable def shellMass (p L : ℕ) [NeZero p] [NeZero L] (j : ℕ) : ℝ :=
  ∑ x : ZMod p × (ZMod L × Level p L j),
     if x.1=0 ∧ x.2.1=0 then 0 else 1/weight p L (fresh p L) (j+1) x

theorem shell_bound (hl : 1 < L) (j : ℕ) :
    0 ≤ shellMass p L j ∧ shellMass p L j ≤
      (1-1/(L:ℝ))⁻¹ / (levelSize p L (j+1):ℝ) := by
  let θ := 1/(L:ℝ)
  have hL : 1 < (L:ℝ) := by exact_mod_cast hl
  have ht : 0≤θ := by dsimp [θ]; positivity
  have hs : θ<1 := by simpa [θ, one_div] using inv_lt_one_of_one_lt₀ hL
  have hf := fresh_props (p:=p) (L:=L)
  have hν := reciprocal_bounds θ (fresh p L) ht hs.le hf.1 hf.2 (j+1)
  let f := fresh p L (j+1)
  let dmin := (1-θ)*f
  have hd : 0 < dmin := mul_pos (sub_pos.mpr hs) (hf.1 _)
  have lower (b : ZMod p) (g : ZMod L) (x : Level p L j) (h : ¬(b=0 ∧ g=0)) :
      dmin ≤ weight p L (fresh p L) (j+1) (b,g,x) := by
    by_cases hb : b=0
    · have hg : g≠0 := fun he => h ⟨hb,he⟩
      simp only [weight,extendWeight,hb,hg,if_true,if_false]
      dsimp [dmin,f]
      nlinarith [mul_nonneg ht (hf.1 (j+1)).le]
    · simp only [weight,extendWeight,hb,if_false,mean_eq_mix]
      exact hν.2.2
  have bound (x : ZMod p × (ZMod L × Level p L j)) :
      let s := if x.1=0 ∧ x.2.1=0 then 0 else 1/weight p L (fresh p L) (j+1) x
      0 ≤ s ∧ s ≤ 1/dmin := by
    dsimp only
    split_ifs with h
    · exact ⟨le_rfl,by positivity⟩
    · have lo := lower x.1 x.2.1 x.2.2 h
      exact ⟨one_div_nonneg.mpr (hd.le.trans lo),one_div_le_one_div_of_le hd lo⟩
  refine ⟨Finset.sum_nonneg (fun i _ => (bound i).1), ?_⟩
  have hcard : Fintype.card (ZMod p × (ZMod L × Level p L j)) = levelSize p L (j+1) :=
    (Fintype.card_congr (encodeLevel p L (j+1))).trans (ZMod.card _)
  have ha := Finset.sum_le_sum (s:=Finset.univ) (fun i _ => (bound i).2)
  simp only [Finset.sum_const,Finset.card_univ,hcard,nsmul_eq_mul] at ha
  refine ha.trans_eq ?_
  change (levelSize p L (j+1):ℝ)*(1/((1-θ)*(levelSize p L (j+1):ℝ)^2)) =
    (1-θ)⁻¹ / (levelSize p L (j+1):ℝ)
  have hz : (levelSize p L (j+1):ℝ) ≠ 0 := Nat.cast_ne_zero.mpr (NeZero.ne _)
  field_simp

theorem summable_shellMass (hl : 1 < L) : Summable (shellMass p L) := by
  have hp : 0 < p := Nat.pos_of_ne_zero (NeZero.ne p)
  have hpL : 1 < ((p*L:ℕ):ℝ) := by
    exact_mod_cast (hl.trans_le (by simpa using Nat.mul_le_mul_right L hp))
  let r : ℝ := ((p*L:ℕ):ℝ)⁻¹
  have hr : ‖r‖ < 1 := by
    dsimp [r]; rw [abs_of_pos (by positivity)]; exact inv_lt_one_of_one_lt₀ hpL
  have hs := (summable_geometric_of_norm_lt_one hr).mul_left ((1-1/(L:ℝ))⁻¹*(p:ℝ)⁻¹*r)
  apply Summable.of_nonneg_of_le (fun j => (shell_bound hl j).1) _ hs
  intro j
  refine (shell_bound hl j).2.trans_eq ?_
  rw [size_formula]; dsimp [r]; push_cast; simp only [div_eq_mul_inv,mul_inv_rev,pow_succ]
  ring

end KDClosure
