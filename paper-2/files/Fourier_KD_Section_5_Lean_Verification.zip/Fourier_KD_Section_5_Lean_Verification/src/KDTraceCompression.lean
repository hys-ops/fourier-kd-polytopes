import KDIsometricSupport
import Mathlib.Analysis.Normed.Group.Basic

/-! The variational 1-trace seminorm (extended-valued): the supremum of the
absolute matrix diagonal sums over two finite orthonormal frames. This is not
the operator norm nor the Hilbert--Schmidt norm. We derive data processing and
the one-frame matrix estimates directly from this definition. -/
noncomputable section
set_option linter.unusedSectionVars false
namespace KDClosure.Hull
open scoped ENNReal InnerProductSpace
open Classical
variable {X Y : Type*} [NormedAddCommGroup X] [InnerProductSpace ℂ X]
    [NormedAddCommGroup Y] [InnerProductSpace ℂ Y] [CompleteSpace X] [CompleteSpace Y]

def traceVariational (A : X →L[ℂ] X) : ℝ≥0∞ :=
  ⨆ (n : ℕ) (u : Fin n → X) (_ : Orthonormal ℂ u)
    (v : Fin n → X) (_ : Orthonormal ℂ v), ∑ i : Fin n, ‖inner ℂ (v i) (A (u i))‖ₑ

theorem frame_sum_le (A : X →L[ℂ] X) {n : ℕ} {u v : Fin n → X}
    (hu : Orthonormal ℂ u) (hv : Orthonormal ℂ v) :
    ∑ i, ‖inner ℂ (v i) (A (u i))‖ₑ ≤ traceVariational A :=
  le_iSup_of_le n (le_iSup_of_le u (le_iSup_of_le hu (le_iSup_of_le v (le_iSup_of_le hv le_rfl))))

/-- Trace-norm contraction for the actual support compression. No finite-dimensional
bound, assumed continuity or assumed norm inequality is used. -/
theorem traceVariational_compress_le (J : X →ₗᵢ[ℂ] Y) (A : Y →L[ℂ] Y) :
    traceVariational (IsometricSupport.compress J.toContinuousLinearMap A) ≤ traceVariational A := by
  apply iSup_le
  intro n
  apply iSup_le
  intro u
  apply iSup_le
  intro hu
  apply iSup_le
  intro v
  apply iSup_le
  intro hv
  calc
    _ = ∑ i, ‖inner ℂ (J (v i)) (A (J (u i)))‖ₑ := Finset.sum_congr rfl (fun i _ => by
      change ‖inner ℂ (v i) (J.toContinuousLinearMap.adjoint (A (J (u i))))‖ₑ = _
      rw [ContinuousLinearMap.adjoint_inner_right]; rfl)
    _ ≤ _ := frame_sum_le A (hu.comp_linearIsometry J) (hv.comp_linearIsometry J)

theorem traceVariational_compress_dist (J : X →ₗᵢ[ℂ] Y) (A B : Y →L[ℂ] Y) :
    traceVariational (IsometricSupport.compress J.toContinuousLinearMap A -
      IsometricSupport.compress J.toContinuousLinearMap B) ≤ traceVariational (A-B) := by
  have eqn : IsometricSupport.compress J.toContinuousLinearMap A -
      IsometricSupport.compress J.toContinuousLinearMap B = IsometricSupport.compress J.toContinuousLinearMap (A-B) := by
    ext x
    change J.toContinuousLinearMap.adjoint (A (J x)) - J.toContinuousLinearMap.adjoint (B (J x)) =
      J.toContinuousLinearMap.adjoint (A (J x) - B (J x))
    rw [map_sub]
  rw [eqn]; exact traceVariational_compress_le J _

theorem unit_entry_le (A : X →L[ℂ] X) (x y : X) (hx : ‖x‖=1) (hy : ‖y‖=1) :
    ‖inner ℂ y (A x)‖ₑ ≤ traceVariational A := by
  have orth (a : X) (ha : ‖a‖=1) : Orthonormal ℂ (fun _ : Fin 1 => a) := by
    rw [orthonormal_iff_ite]
    intro i j
    have e : i=j := Subsingleton.elim _ _
    rw [if_pos e]
    simp [inner_self_eq_norm_sq_to_K,ha]
  simpa using frame_sum_le A (orth x hx) (orth y hy)

end KDClosure.Hull
