import KDPositiveCompact

/-! Normalization in physical quantum conventions: this is the full trace
norm, not the statistical trace distance (which is half that norm). -/
noncomputable section
namespace KDClosure.Hull
open Set Tight
open scoped InnerProductSpace ENNReal
variable {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℂ H] [CompleteSpace H]

theorem positive_frame_variation_le (A : H →L[ℂ] H) (p : A.IsPositive)
    (budget : 1∈upperBounds (Mass A)) {n : ℕ} {u v : Fin n → H} (hu : Orthonormal ℂ u) (hv : Orthonormal ℂ v) :
    ∑ i, ‖inner ℂ (v i) (A (u i))‖ ≤ 1 := by
  classical
  obtain ⟨I,b,_⟩ := exists_hilbertBasis ℂ H
  obtain ⟨R,hr⟩ := root_factor A p
  have eu := (frame_energy b ∅ p budget hr hu).1
  have ev := (frame_energy b ∅ p budget hr hv).1
  simp only [hr,R.adjoint_inner_right]
  have h := (Finset.sum_le_sum fun (i : Fin n) (_ : i∈Finset.univ) =>
    norm_inner_le_norm (𝕜:=ℂ) (R (v i)) (R (u i))).trans
      ((Real.sum_mul_le_sqrt_mul_sqrt _ _ _).trans
      (mul_le_mul (Real.sqrt_le_sqrt ev) (Real.sqrt_le_sqrt eu) (Real.sqrt_nonneg _) (Real.sqrt_nonneg _)))
  simpa using h

theorem traceVariational_positive_trace_one (A : H →L[ℂ] H) (p : A.IsPositive)
    (ht : IsLUB (Mass A) 1) : traceVariational A=1 := by
  have budget : traceVariational A≤1 := by
    unfold traceVariational
    refine iSup_le fun n => iSup_le fun u => iSup_le fun hu => iSup_le fun v => iSup_le fun hv => ?_
    simpa only [ENNReal.ofReal_sum_of_nonneg (fun _ _ => norm_nonneg _),ofReal_norm,ENNReal.ofReal_one] using
      ENNReal.ofReal_le_ofReal (positive_frame_variation_le A p ht.1 hu hv)
  apply le_antisymm budget
  have notInf := ne_top_of_le_ne_top ENNReal.one_ne_top budget
  rw [←ENNReal.ofReal_one,ENNReal.ofReal_le_iff_le_toReal notInf]
  apply ht.2
  rintro _ ⟨n,u,on,rfl⟩
  have test := frame_sum_le A on on
  have nn : 0 ≤ ∑ j, ‖inner ℂ (u j) (A (u j))‖ := Finset.sum_nonneg fun _ _ => norm_nonneg _
  have vr : ∑ j, ‖inner ℂ (u j) (A (u j))‖ ≤ (traceVariational A).toReal := by
    apply (ENNReal.ofReal_le_iff_le_toReal notInf).mp
    simpa only [ENNReal.ofReal_sum_of_nonneg (fun _ _ => norm_nonneg _),ofReal_norm] using test
  exact (Finset.sum_le_sum (fun j _ => Complex.re_le_norm (inner ℂ (u j) (A (u j))))).trans vr

theorem distance_between_states_le_two (A B : H →L[ℂ] H) (p : A.IsPositive) (q : B.IsPositive)
    (ha : 1∈upperBounds (Mass A)) (hb : 1∈upperBounds (Mass B)) : traceVariational (A-B)≤2 := by
  unfold traceVariational
  refine iSup_le fun n => iSup_le fun u => iSup_le fun hu => iSup_le fun v => iSup_le fun hv => ?_
  have sa := positive_frame_variation_le A p ha hu hv
  have sb := positive_frame_variation_le B q hb hu hv
  have bound : ∑ i, ‖inner ℂ (v i) ((A-B) (u i))‖ ≤ 2 := by
    simp only [sub_apply,inner_sub_right]
    calc
      _ ≤ ∑ i, (‖inner ℂ (v i) (A (u i))‖+‖inner ℂ (v i) (B (u i))‖) := Finset.sum_le_sum fun _ _ => norm_sub_le _ _
      _ ≤ _ := by rw [Finset.sum_add_distrib]; linarith
  simpa only [ENNReal.ofReal_sum_of_nonneg (fun _ _ => norm_nonneg _),ofReal_norm,ENNReal.ofReal_ofNat] using
    ENNReal.ofReal_le_ofReal bound
end KDClosure.Hull
#print axioms KDClosure.Hull.traceVariational_positive_trace_one
#print axioms KDClosure.Hull.distance_between_states_le_two
