import KDTraceCompression
import KDLCAQuotientTrace
import KDCompactFourierTransfer
/-! Finite-coordinate tightness for positive substates, in the two-frame
variational trace gauge. All estimates use the actual intrinsic frame mass. -/
noncomputable section
namespace KDClosure.Hull.Tight
open Set ContinuousLinearMap
open scoped InnerProductSpace BigOperators ComplexOrder ENNReal
variable {H I : Type*} [NormedAddCommGroup H] [InnerProductSpace ℂ H] [CompleteSpace H]

abbrev Mass (A : H →L[ℂ] H) := LCAQuotientTrace.frameMass A

def diag (b : HilbertBasis I ℂ H) (A : H →L[ℂ] H) (i : I) : ℝ :=
  (inner ℂ (b i) (A (b i))).re

omit [CompleteSpace H] in
theorem diag_nonneg (b : HilbertBasis I ℂ H) {A : H →L[ℂ] H} (p : A.IsPositive) (i : I) :
    0 ≤ diag b A i := p.re_inner_nonneg_right _

omit [CompleteSpace H] in
private theorem coord_diag [DecidableEq I] (b : HilbertBasis I ℂ H) (A : H →L[ℂ] H) (i : I) :
    (Discrete.entries (CompactFourier.unitaryPush b.repr A) (i,i)).re = diag b A i := by
  change (inner ℂ (lp.single 2 i (1:ℂ)) (b.repr (A (b.repr.symm (lp.single 2 i (1:ℂ)))))).re = _
  rw [← b.repr_self,b.repr.symm_apply_apply,b.repr.inner_map_map]
  rfl

theorem diag_spec (b : HilbertBasis I ℂ H) {A : H →L[ℂ] H} (p : A.IsPositive) :
    (BddAbove (Mass A) ↔ Summable (diag b A)) ∧
    (Summable (diag b A) → IsLUB (Mass A) (∑' i, diag b A i)) := by
  classical
  let U := CompactFourier.unitaryPush b.repr A
  have pu : U.IsPositive := (CompactFourier.positive_unitary_iff b.repr A).mpr p
  have e : Discrete.finiteFrameMass U = Mass A := CompactFourier.frameMass_unitary b.repr A
  have d : (fun i => (Discrete.entries U (i,i)).re) = diag b A := funext (coord_diag b A)
  rw [←e,←d]
  exact ⟨Discrete.boundedFrames_iff_diagonal pu, Discrete.trace_isLUB pu⟩

def cut (b : HilbertBasis I ℂ H) (s : Finset I) : H →L[ℂ] H :=
  ∑ i ∈ s, InnerProductSpace.rankOne ℂ (b i) (b i)

omit [CompleteSpace H] in
theorem cut_basis (b : HilbertBasis I ℂ H) (s : Finset I) (i : I) [Decidable (i ∈ s)] :
    cut b s (b i) = if i ∈ s then b i else 0 := by
  classical
  simp only [cut,_root_.sum_apply,InnerProductSpace.rankOne_apply,
    orthonormal_iff_ite.mp b.orthonormal]
  simp [ite_smul]

theorem root_factor (A : H →L[ℂ] H) (p : A.IsPositive) :
    ∃ R : H →L[ℂ] H, ∀ v, A v = R.adjoint (R v) := by
  let R := CFC.sqrt A
  have sa : R.adjoint = R := (CFC.sqrt_nonneg A).star_eq
  refine ⟨R, fun x => ?_⟩
  rw [sa]
  exact DFunLike.congr_fun (CFC.sqrt_mul_sqrt_self A ((nonneg_iff_isPositive A).mpr p)).symm x

theorem frame_sq_of_diag (b : HilbertBasis I ℂ H) (B : H →L[ℂ] H)
    (hs : Summable (fun i => ‖B (b i)‖ ^ 2)) {n : ℕ} {v : Fin n → H} (hv : Orthonormal ℂ v) :
    ∑ j, ‖B (v j)‖^2 ≤ ∑' i, ‖B (b i)‖^2 := by
  let A := B.adjoint ∘L B
  have p : A.IsPositive := B.isPositive_adjoint_comp_self
  have normSq (x : H) : (inner ℂ x (A x)).re = ‖B x‖^2 := by
    rw [show A x = B.adjoint (B x) from rfl,B.adjoint_inner_right]
    exact (norm_sq_eq_re_inner (𝕜:=ℂ) _).symm
  have d : diag b A = fun i => ‖B (b i)‖^2 := funext (fun i => normSq (b i))
  have lub := (diag_spec b p).2 (d.symm ▸ hs)
  rw [d] at lub
  exact lub.1 ⟨n,v,hv,Finset.sum_congr rfl fun i _ => normSq (v i)⟩

end KDClosure.Hull.Tight
