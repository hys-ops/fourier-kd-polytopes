import KDTraceTightWOT

noncomputable section
namespace KDClosure.Hull.Tight
open Set Filter
open scoped InnerProductSpace Topology ENNReal
variable {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℂ H] [CompleteSpace H]

/-- Literal convergence to zero in the extended-valued two-frame variational
trace norm, even when the ambient Hilbert space is nonseparable. -/
theorem wot_tendsto_trace {J : Type*} {l : Filter J} (A : J → H →L[ℂ] H) (T : H →L[ℂ] H)
    (pa : ∀ j, (A j).IsPositive) (ba : ∀ j, 1 ∈ upperBounds (Mass (A j)))
    (pt : T.IsPositive) (bt : IsLUB (Mass T) 1)
    (hw : ∀ x y, Tendsto (fun j => inner ℂ x (A j y)) l (𝓝 (inner ℂ x (T y)))) :
    Tendsto (fun j => traceVariational (A j - T)) l (𝓝 0) := by
  apply ENNReal.tendsto_nhds_zero.mpr
  intro ε pos
  by_cases inf : ε = ⊤
  · simp [inf]
  have realpos := ENNReal.toReal_pos pos.ne' inf
  filter_upwards [wot_trace_eventually_lt A T pa ba pt bt hw ε.toReal realpos] with j hj
  simpa only [ENNReal.ofReal_toReal inf] using hj.le

#print axioms wot_tendsto_trace
end KDClosure.Hull.Tight
