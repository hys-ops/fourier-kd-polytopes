import KDTraceTight
noncomputable section
namespace KDClosure.Hull.Tight
open Set ContinuousLinearMap
open scoped InnerProductSpace BigOperators ComplexOrder ENNReal
variable {H I : Type*} [NormedAddCommGroup H] [InnerProductSpace ℂ H] [CompleteSpace H]

/-- Parseval plus positivity: discarding a finite coordinate window costs
at most the intrinsic trace budget less the measured mass of the window. -/
theorem frame_energy (b : HilbertBasis I ℂ H) (s : Finset I) {A R : H →L[ℂ] H}
    (p : A.IsPositive) (ht : 1 ∈ upperBounds (Mass A))
    (hr : ∀ x, A x = R.adjoint (R x))
    {n : ℕ} {v : Fin n → H} (hv : Orthonormal ℂ v) :
    (∑ j, ‖R (v j)‖^2 ≤ 1) ∧
    (∑ j, ‖R (cut b s (v j))‖^2 ≤ 1) ∧
    ∑ j, ‖R (v j - cut b s (v j))‖^2 ≤ 1 - ∑ i ∈ s, diag b A i := by
  classical
  let P := cut b s
  let U := R ∘L P
  let V := R ∘L (1-P)
  have eqR (i : I) : ‖R (b i)‖^2 = diag b A i := by
    rw [diag,hr,R.adjoint_inner_right]
    exact norm_sq_eq_re_inner (𝕜:=ℂ) _
  have hsd := (diag_spec b p).1.mp ⟨1,ht⟩
  have budget := ((diag_spec b p).2 hsd).2 ht
  have eU (i : I) : ‖U (b i)‖^2 = if i ∈ s then diag b A i else 0 := by
    change ‖R (cut b s (b i))‖^2 = _
    rw [cut_basis]
    split_ifs <;> simp [eqR]
  have eV (i : I) : ‖V (b i)‖^2 = diag b A i - ‖U (b i)‖^2 := by
    change ‖R (b i - cut b s (b i))‖^2 = _
    rw [cut_basis,eU]
    split_ifs <;> simp [eqR]
  have su : HasSum (fun i => ‖U (b i)‖^2) (∑ i ∈ s, diag b A i) := by
    have h : HasSum (fun i => ‖U (b i)‖^2) (∑ i ∈ s, ‖U (b i)‖^2) := hasSum_sum_of_ne_finset_zero
      (fun i hi => by rw [eU,if_neg hi])
    have eqn : (∑ i ∈ s, ‖U (b i)‖^2) = ∑ i ∈ s, diag b A i := Finset.sum_congr rfl fun i hi => (eU i).trans (if_pos hi)
    exact eqn ▸ h
  have sv : HasSum (fun i => ‖V (b i)‖^2) ((∑' i, diag b A i) - ∑ i ∈ s, diag b A i) :=
    (hsd.hasSum.sub su).congr_fun (fun i => eV i)
  have sR : Summable (fun i => ‖R (b i)‖^2) := (funext eqR).symm ▸ hsd
  have hbudget : ∑ i ∈ s, diag b A i ≤ 1 :=
    (hsd.sum_le_tsum _ (fun i _ => diag_nonneg b p i)).trans budget
  constructor
  · simpa only [eqR] using (frame_sq_of_diag b R sR hv).trans (by simpa only [eqR] using budget)
  constructor
  · exact (frame_sq_of_diag b U su.summable hv).trans (su.tsum_eq.le.trans hbudget)
  · exact (frame_sq_of_diag b V sv.summable hv).trans (sv.tsum_eq.le.trans (sub_le_sub_right budget _))

omit [CompleteSpace H] in
private theorem inner_CS {n : ℕ} (x y : Fin n → H) {X Y : ℝ}
    (hx : ∑ i, ‖x i‖^2 ≤ X) (hy : ∑ i, ‖y i‖^2 ≤ Y) :
    ∑ i, ‖inner ℂ (x i) (y i)‖ ≤ Real.sqrt X * Real.sqrt Y :=
  (Finset.sum_le_sum (fun i _ => norm_inner_le_norm (𝕜:=ℂ) (x i) (y i))).trans
    ((Real.sum_mul_le_sqrt_mul_sqrt _ _ _).trans
    (mul_le_mul (Real.sqrt_le_sqrt hx) (Real.sqrt_le_sqrt hy) (Real.sqrt_nonneg _) (Real.sqrt_nonneg _)))

theorem frame_tail (b : HilbertBasis I ℂ H) (s : Finset I) {A : H →L[ℂ] H}
    (p : A.IsPositive) (ht : 1 ∈ upperBounds (Mass A))
    {n : ℕ} {u v : Fin n → H} (hu : Orthonormal ℂ u) (hv : Orthonormal ℂ v) :
    ∑ j, ‖inner ℂ (v j) (A (u j)) - inner ℂ (cut b s (v j)) (A (cut b s (u j)))‖ ≤
      2 * Real.sqrt (1 - ∑ i ∈ s, diag b A i) := by
  obtain ⟨R,hr⟩ := root_factor A p
  have allU := frame_energy b s p ht hr hu
  have allV := frame_energy b s p ht hr hv
  let P := cut b s
  have dec (x y : H) :
      inner ℂ y (A x) - inner ℂ (P y) (A (P x)) =
      inner ℂ (R (y-P y)) (R x) + inner ℂ (R (P y)) (R (x-P x)) := by
    simp only [hr,R.adjoint_inner_right,map_sub,inner_sub_left,inner_sub_right]
    abel
  change ∑ j, ‖inner ℂ (v j) (A (u j)) - inner ℂ (P (v j)) (A (P (u j)))‖ ≤ _
  simp_rw [dec]
  calc
    _ ≤ ∑ j, (‖inner ℂ (R (v j-P (v j))) (R (u j))‖ +
      ‖inner ℂ (R (P (v j))) (R (u j-P (u j)))‖) := Finset.sum_le_sum fun _ _ => norm_add_le _ _
    _ ≤ _ := by
      rw [Finset.sum_add_distrib,two_mul]
      apply add_le_add
      · simpa only [Real.sqrt_one,mul_one] using inner_CS _ _ allV.2.2 allU.1
      · simpa only [Real.sqrt_one,one_mul] using inner_CS _ _ allV.2.1 allU.2.2

end KDClosure.Hull.Tight
