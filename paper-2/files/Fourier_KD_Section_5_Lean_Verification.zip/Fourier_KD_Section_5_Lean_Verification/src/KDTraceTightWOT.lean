import KDTraceTightTail
import KDFiniteHead

/-! For any net of positive substates with weak operator limit a full state,
no diagonal mass escapes and convergence holds in the variational trace norm. -/
noncomputable section
namespace KDClosure.Hull.Tight
open Set Filter ContinuousLinearMap
open scoped InnerProductSpace Topology BigOperators ENNReal
variable {H I : Type*} [NormedAddCommGroup H] [InnerProductSpace ℂ H] [CompleteSpace H]

def tailCost (b : HilbertBasis I ℂ H) (s : Finset I) (A : H →L[ℂ] H) : ℝ :=
  2 * Real.sqrt (1 - ∑ i ∈ s, diag b A i)

def headCost (b : HilbertBasis I ℂ H) (s : Finset I) (D : H →L[ℂ] H) : ℝ :=
  ∑ i ∈ s, ∑ j ∈ s, ‖inner ℂ (b i) (D (b j))‖

theorem distance_bound (b : HilbertBasis I ℂ H) (s : Finset I) {A T : H →L[ℂ] H}
    (pa : A.IsPositive) (ba : 1 ∈ upperBounds (Mass A))
    (pt : T.IsPositive) (bt : 1 ∈ upperBounds (Mass T)) :
    traceVariational (A-T) ≤ ENNReal.ofReal (tailCost b s A + headCost b s (A-T) + tailCost b s T) := by
  unfold traceVariational
  refine iSup_le fun n => iSup_le fun u => iSup_le fun hu => iSup_le fun v => iSup_le fun hv => ?_
  let P := cut b s
  have hx := frame_tail b s pa ba hu hv
  have hy := frame_tail b s pt bt hu hv
  have hmid := Head.finite_head b b.orthonormal s (A-T) hu hv
  have hm : ∑ j, ‖inner ℂ (P (v j)) ((A-T) (P (u j)))‖ ≤ headCost b s (A-T) := by
    simpa only [P,cut,_root_.sum_apply,InnerProductSpace.rankOne_apply,headCost] using hmid
  have hb (x y : H) : ‖inner ℂ y ((A-T) x)‖ ≤
      ‖inner ℂ y (A x) - inner ℂ (P y) (A (P x))‖ +
      ‖inner ℂ (P y) ((A-T) (P x))‖ +
      ‖inner ℂ y (T x) - inner ℂ (P y) (T (P x))‖ := by
    let a := inner ℂ y (A x) - inner ℂ (P y) (A (P x))
    let c := inner ℂ (P y) ((A-T) (P x))
    let d := inner ℂ y (T x) - inner ℂ (P y) (T (P x))
    have he : inner ℂ y ((A-T) x) = a+c-d := by simp only [a,c,d,sub_apply,inner_sub_right]; abel
    rw [he]
    exact (norm_sub_le _ _).trans (add_le_add (norm_add_le _ _) le_rfl)
  simp only [←ofReal_norm,←ENNReal.ofReal_sum_of_nonneg (fun _ _ => norm_nonneg _)]
  apply ENNReal.ofReal_le_ofReal
  refine (Finset.sum_le_sum fun j _ => hb (u j) (v j)).trans ?_
  simp only [Finset.sum_add_distrib]
  exact add_le_add (add_le_add hx hm) hy

/-- Weak operator convergence of positive substates becomes variational trace
convergence at a trace-one positive operator; no separability or sequence
assumption is needed. -/
theorem wot_trace_eventually_lt {J : Type*} {l : Filter J} (A : J → H →L[ℂ] H) (T : H →L[ℂ] H)
    (pa : ∀ j, (A j).IsPositive) (ba : ∀ j, 1 ∈ upperBounds (Mass (A j)))
    (pt : T.IsPositive) (bt : IsLUB (Mass T) 1)
    (hw : ∀ x y, Tendsto (fun j => inner ℂ x (A j y)) l (𝓝 (inner ℂ x (T y))))
    (ε : ℝ) (hε : 0 < ε) :
    ∀ᶠ j in l, traceVariational (A j - T) < ENNReal.ofReal ε := by
  classical
  obtain ⟨I,b,_⟩ := exists_hilbertBasis ℂ H
  have hsd := (diag_spec b pt).1.mp ⟨1,bt.1⟩
  have has : HasSum (diag b T) 1 := ((diag_spec b pt).2 hsd).unique bt ▸ hsd.hasSum
  have taper : Tendsto (fun s => tailCost b s T) atTop (𝓝 0) := by
    have h : Tendsto (fun s : Finset I => 1 - ∑ i ∈ s, diag b T i) atTop (𝓝 (1-1 : ℝ)) :=
      tendsto_const_nhds.sub has
    simpa [tailCost] using (tendsto_const_nhds (x:=(2:ℝ))).mul ((Real.continuous_sqrt.tendsto _).comp h)
  obtain ⟨s,hs⟩ := (taper.eventually_lt_const (show (0:ℝ)<ε/2 by positivity)).exists
  have dconv : Tendsto (fun j => ∑ i ∈ s, diag b (A j) i) l (𝓝 (∑ i ∈ s, diag b T i)) :=
    tendsto_finsetSum s fun i _ => (Complex.continuous_re.tendsto _).comp (hw (b i) (b i))
  have tailconv : Tendsto (fun j => tailCost b s (A j)) l (𝓝 (tailCost b s T)) :=
    tendsto_const_nhds.mul ((Real.continuous_sqrt.tendsto _).comp (tendsto_const_nhds.sub dconv))
  have headconv := Head.entries_tendsto b s A T hw
  have conv : Tendsto (fun j => tailCost b s (A j) + headCost b s (A j-T) + tailCost b s T)
      l (𝓝 (tailCost b s T + 0 + tailCost b s T)) := (tailconv.add headconv).add tendsto_const_nhds
  filter_upwards [conv.eventually_lt_const (show tailCost b s T + 0 + tailCost b s T < ε by linarith)] with j hj
  exact (distance_bound b s (pa j) (ba j) pt bt.1).trans_lt ((ENNReal.ofReal_lt_ofReal_iff hε).mpr hj)

end KDClosure.Hull.Tight
