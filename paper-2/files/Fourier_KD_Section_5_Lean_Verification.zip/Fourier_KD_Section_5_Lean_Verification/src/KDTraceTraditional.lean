import KDTraceTight
import Mathlib.Analysis.InnerProductSpace.SingularValues

/-! Comparison of the variational trace gauge with the weighted Hilbert sum for a diagonal operator. -/
noncomputable section
namespace KDClosure.Hull
open Classical Set Filter
open scoped InnerProductSpace ENNReal Topology BigOperators

variable {H I : Type*} [NormedAddCommGroup H] [InnerProductSpace ℂ H] [CompleteSpace H]

omit [CompleteSpace H] in
private theorem frame_inner_prod_le_one {n : ℕ} {u v : Fin n → H}
    (hu : Orthonormal ℂ u) (hv : Orthonormal ℂ v) {w z : H}
    (hw : ‖w‖=1) (hz : ‖z‖=1) :
    ∑ j, ‖inner ℂ (u j) w‖ * ‖inner ℂ z (v j)‖ ≤ 1 := by
  have hs1 : ∑ j, ‖inner ℂ (u j) w‖ ^ 2 ≤ 1 := by
    simpa only [hw,one_pow] using hu.sum_inner_products_le w (s:=Finset.univ)
  have hs2 : ∑ j, ‖inner ℂ z (v j)‖ ^ 2 ≤ 1 := by
    simpa only [← norm_inner_symm (𝕜:=ℂ) z, hz,one_pow] using hv.sum_inner_products_le z (s:=Finset.univ)
  have cs := Real.sum_mul_le_sqrt_mul_sqrt Finset.univ (fun j => ‖inner ℂ (u j) w‖) (fun j => ‖inner ℂ z (v j)‖)
  exact cs.trans (by
    simpa only [Real.sqrt_one,mul_one] using
      mul_le_mul (Real.sqrt_le_sqrt hs1) (Real.sqrt_le_sqrt hs2) (Real.sqrt_nonneg _) (Real.sqrt_nonneg _))

/-- A diagonal operator has extended trace norm given by the sum of the absolute
diagonal values, including the case of a divergent sum. -/
theorem traceVariational_eq_abs_tsum_of_eigenbasis (A : H →L[ℂ] H)
    (b : HilbertBasis I ℂ H) (evals : I → ℂ) (eigen : ∀ i, A (b i) = evals i • b i) :
    traceVariational A = ∑' i, ‖evals i‖ₑ := by
  classical
  apply le_antisymm
  · apply iSup_le; intro n; apply iSup_le; intro u; apply iSup_le; intro hu
    apply iSup_le; intro v; apply iSup_le; intro hv
    let p (s : Finset I) (j : Fin n) := ∑ i ∈ s, b.repr (u j) i • A (b i)
    have pLim (j : Fin n) : Tendsto (fun s : Finset I => p s j) atTop (𝓝 (A (u j))) := by
      exact ((b.hasSum_repr (u j)).mapL A).congr_fun (fun i => (map_smul A _ _).symm)
    have lim : Tendsto (fun s : Finset I => ∑ j, ‖inner ℂ (v j) (p s j)‖ₑ) atTop
        (𝓝 (∑ j, ‖inner ℂ (v j) (A (u j))‖ₑ)) := by
      exact tendsto_finsetSum _ fun j _ => (continuous_enorm.tendsto _).comp
        (((innerSL ℂ (v j)).continuous.tendsto _).comp (pLim j))
    apply le_of_tendsto' lim
    intro s
    calc
      _ ≤ ∑ i ∈ s, ‖evals i‖ₑ := by
        have bd : ∑ j, ‖inner ℂ (v j) (p s j)‖ ≤ ∑ i ∈ s, ‖evals i‖ := calc
          _ ≤ ∑ j : Fin n, ∑ i ∈ s, ‖evals i‖ * (‖inner ℂ (v j) (b i)‖ * ‖inner ℂ (b i) (u j)‖) := by
            apply Finset.sum_le_sum
            intro j _
            simp only [p,inner_sum,inner_smul_right,eigen,HilbertBasis.repr_apply_apply]
            exact (norm_sum_le _ _).trans_eq (Finset.sum_congr rfl (fun i _ => by simp only [norm_mul]; ring))
          _ = ∑ i ∈ s, ‖evals i‖ * ∑ j : Fin n, ‖inner ℂ (v j) (b i)‖ * ‖inner ℂ (b i) (u j)‖ := by
            rw [Finset.sum_comm]; simp only [Finset.mul_sum]
          _ ≤ _ := by
            apply Finset.sum_le_sum
            intro i _
            have h := frame_inner_prod_le_one hv hu (b.orthonormal.1 i) (b.orthonormal.1 i)
            simpa only [mul_one] using mul_le_mul_of_nonneg_left h (norm_nonneg (evals i))
        simpa only [ENNReal.ofReal_sum_of_nonneg (fun _ _ => norm_nonneg _),ofReal_norm] using ENNReal.ofReal_le_ofReal bd
      _ ≤ _ := ENNReal.sum_le_tsum _
  · rw [ENNReal.tsum_eq_iSup_sum]
    apply iSup_le; intro s
    let e : Fin s.card ≃ s := (Finset.equivFin s).symm
    let v : Fin s.card → H := fun j => b (e j)
    have hv : Orthonormal ℂ v := b.orthonormal.comp _ (Subtype.val_injective.comp e.injective)
    have le := frame_sum_le A hv hv
    have eqn (j : Fin s.card) : inner ℂ (v j) (A (v j)) = evals (e j) := by
      simp only [v,eigen,inner_smul_right,inner_self_eq_one_of_norm_eq_one (b.orthonormal.1 _),mul_one]
    simp only [eqn] at le
    rw [← Finset.sum_coe_sort]
    exact (Equiv.sum_comp e (fun i : s => ‖evals i‖ₑ)) ▸ le

end KDClosure.Hull
