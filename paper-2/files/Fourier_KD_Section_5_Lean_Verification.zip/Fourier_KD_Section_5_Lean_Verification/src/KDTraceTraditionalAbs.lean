import KDTraceTraditionalGeneral
import KDTraceTraditionalMass

/-! Comparison to the conventional `Tr (sqrt (A†A))`, without a polar-decomposition axiom. -/
noncomputable section
namespace KDClosure.Hull
open Classical Set ContinuousLinearMap
open scoped InnerProductSpace ENNReal Topology ComplexOrder

universe u
variable {X : Type u} [NormedAddCommGroup X] [InnerProductSpace ℂ X] [CompleteSpace X]

def traceAbs (A : X →L[ℂ] X) : X →L[ℂ] X := CFC.sqrt (A.adjoint ∘L A)

theorem traceAbs_pos (A : X →L[ℂ] X) : (traceAbs A).IsPositive :=
  (nonneg_iff_isPositive _).mp (CFC.sqrt_nonneg _)

theorem traceAbs_on_singular_eigenvector (A : X →L[ℂ] X) (v : X) {s : ℝ} (hs : 0 ≤ s)
    (e : (A.adjoint ∘L A) v = (s:ℂ)^2 • v) : traceAbs A v = (s:ℂ) • v := by
  let R := traceAbs A
  have pr : R.IsPositive := traceAbs_pos A
  have ra : R.adjoint = R := pr.isSymmetric.isSelfAdjoint.adjoint_eq
  have hv : R (R v) = (s:ℂ)^2 • v := by
    have sq := CFC.sqrt_mul_sqrt_self (A.adjoint ∘L A)
      ((nonneg_iff_isPositive _).mpr A.isPositive_adjoint_comp_self)
    exact (DFunLike.congr_fun sq v).trans e
  rcases hs.eq_or_lt with z|hp
  · have zz : R (R v) = 0 := by simpa [←z] using hv
    have h : ‖R v‖ ^ 2 = 0 := calc
      _ = (inner ℂ (R v) (R v)).re := norm_sq_eq_re_inner (𝕜:=ℂ) _
      _ = (inner ℂ v (R.adjoint (R v))).re := congrArg Complex.re (R.adjoint_inner_right v (R v)).symm
      _ = 0 := by rw [ra,zz,inner_zero_right,Complex.zero_re]
    have rv : R v = 0 := (norm_eq_zero.mp (sq_eq_zero_iff.mp h))
    change R v = _
    simp [rv,←z]
  · let y := R v - (s:ℂ) • v
    have eY : R y = ((-s:ℝ):ℂ) • y := by
      simp only [y,map_sub,map_smul,hv,Complex.ofReal_neg,neg_smul,smul_sub,smul_smul,pow_two,neg_mul]
      abel
    have b := pr.re_inner_nonneg_right y
    change 0 ≤ (inner ℂ y (R y)).re at b
    rw [eY,inner_smul_right,Complex.re_ofReal_mul] at b
    have h : (inner ℂ y y).re = ‖y‖ ^ 2 := (norm_sq_eq_re_inner (𝕜:=ℂ) _).symm
    rw [h] at b
    have eq : ‖y‖ = 0 := by
      by_contra! hn
      exact (not_le_of_gt (mul_pos hp (sq_pos_of_ne_zero hn))) (by linarith)
    exact sub_eq_zero.mp (norm_eq_zero.mp eq)

theorem traceVariational_eq_traceVariational_abs_of_compact (A : X →L[ℂ] X) (hc : IsCompactOperator A) :
    traceVariational A = traceVariational (traceAbs A) := by
  obtain ⟨I,b,s,hn,he,ht⟩ := traceVariational_compact_singular_sum A hc
  rw [ht,traceVariational_eq_abs_tsum_of_eigenbasis (traceAbs A) b (fun i => (s i:ℂ))
    (fun i => traceAbs_on_singular_eigenvector A (b i) (hn i) (he i))]
  exact tsum_congr (fun i => by rw [←ofReal_norm,Complex.norm_of_nonneg (hn i)])

theorem traceVariational_eq_trace_abs_of_compact (A : X →L[ℂ] X) (hc : IsCompactOperator A)
    (ht : traceVariational A ≠ ⊤) :
    ∃ t : ℝ, IsLUB (Tight.Mass (traceAbs A)) t ∧ traceVariational A = ENNReal.ofReal t := by
  obtain ⟨I,b,s,hn,he,tr⟩ := traceVariational_compact_singular_sum A hc
  have d (i : I) : Tight.diag b (traceAbs A) i = s i := by
    rw [Tight.diag,traceAbs_on_singular_eigenvector A (b i) (hn i) (he i),inner_smul_right,
      inner_self_eq_one_of_norm_eq_one (b.orthonormal.1 i),mul_one,Complex.ofReal_re]
  have db : (fun i => ‖s i‖ₑ) = fun i => ENNReal.ofReal (s i) := by
    funext i
    rw [←ofReal_norm,Real.norm_of_nonneg (hn i)]
  have su : Summable s := by
    have sums := (tsum_enorm_ne_top_iff_summable_norm (f:=s)).mp (by rwa [db,←tr])
    exact sums.congr (fun i => Real.norm_of_nonneg (hn i))
  have h := (Tight.diag_spec b (traceAbs_pos A)).2 (show Summable (Tight.diag b (traceAbs A)) from
    su.congr (fun i => (d i).symm))
  exact ⟨_,h,(traceVariational_eq_traceVariational_abs_of_compact A hc).trans
    (traceVariational_eq_intrinsic_positive_trace (traceAbs_pos A) h)⟩

end KDClosure.Hull
