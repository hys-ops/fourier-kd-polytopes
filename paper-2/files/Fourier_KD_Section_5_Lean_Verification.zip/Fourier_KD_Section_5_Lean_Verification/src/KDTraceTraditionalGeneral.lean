import KDTraceTraditionalSpectral

/-! Comparison of the variational trace gauge with the weighted Hilbert sum for a diagonal operator. -/
noncomputable section
namespace KDClosure.Hull
open Classical Set Filter
open scoped InnerProductSpace ENNReal Topology BigOperators

variable {H I : Type*} [NormedAddCommGroup H] [InnerProductSpace ℂ H] [CompleteSpace H]

omit [CompleteSpace H] in
private theorem frame_inner_prod_le_one' {n : ℕ} {u v : Fin n → H}
    (hu : Orthonormal ℂ u) (hv : Orthonormal ℂ v) {w z : H}
    (hw : ‖w‖=1) (hz : ‖z‖ ≤ 1) :
    ∑ j, ‖inner ℂ (u j) w‖ * ‖inner ℂ z (v j)‖ ≤ 1 := by
  have hs1 : ∑ j, ‖inner ℂ (u j) w‖ ^ 2 ≤ 1 := by
    simpa only [hw,one_pow] using hu.sum_inner_products_le w (s:=Finset.univ)
  have hs2 : ∑ j, ‖inner ℂ z (v j)‖ ^ 2 ≤ 1 := by
    simpa only [← norm_inner_symm (𝕜:=ℂ) z] using
      (hv.sum_inner_products_le z (s:=Finset.univ)).trans (by nlinarith [norm_nonneg z])
  have cs := Real.sum_mul_le_sqrt_mul_sqrt Finset.univ (fun j => ‖inner ℂ (u j) w‖) (fun j => ‖inner ℂ z (v j)‖)
  exact cs.trans (by
    simpa only [Real.sqrt_one,mul_one] using
      mul_le_mul (Real.sqrt_le_sqrt hs1) (Real.sqrt_le_sqrt hs2) (Real.sqrt_nonneg _) (Real.sqrt_nonneg _))

/-- An actual left/right singular system determines the gauge. Zero singular values
need not have matching output vectors. -/
theorem traceVariational_eq_tsum_of_singular_system (A : H →L[ℂ] H)
    (b : HilbertBasis I ℂ H) (evals : I → ℂ) (c : I → H)
    (nc : ∀ i, ‖c i‖ ≤ 1) (on : Orthonormal ℂ (fun i : {i // evals i ≠ 0} => c i))
    (eigen : ∀ i, A (b i) = evals i • c i) :
    traceVariational A = ∑' i, ‖evals i‖ₑ := by
  classical
  apply le_antisymm
  · apply iSup_le; intro n; apply iSup_le; intro u; apply iSup_le; intro hu
    apply iSup_le; intro v; apply iSup_le; intro hv
    let p (s : Finset I) (j : Fin n) := ∑ i ∈ s, b.repr (u j) i • A (b i)
    have pLim (j : Fin n) : Tendsto (fun s : Finset I => p s j) atTop (𝓝 (A (u j))) := by
      exact ((b.hasSum_repr (u j)).mapL A).congr_fun (fun i => (map_smul A _ _).symm)
    have lim : Tendsto (fun s : Finset I => ∑ j, ‖inner ℂ (v j) (p s j)‖ₑ) atTop
        (𝓝 (∑ j, ‖inner ℂ (v j) (A (u j))‖ₑ)) := by
      exact tendsto_finsetSum _ fun j _ => (continuous_enorm.tendsto _).comp
        (((innerSL ℂ (v j)).continuous.tendsto _).comp (pLim j))
    apply le_of_tendsto' lim
    intro s
    calc
      _ ≤ ∑ i ∈ s, ‖evals i‖ₑ := by
        have bd : ∑ j, ‖inner ℂ (v j) (p s j)‖ ≤ ∑ i ∈ s, ‖evals i‖ := calc
          _ ≤ ∑ j : Fin n, ∑ i ∈ s, ‖evals i‖ * (‖inner ℂ (v j) (c i)‖ * ‖inner ℂ (b i) (u j)‖) := by
            apply Finset.sum_le_sum
            intro j _
            simp only [p,inner_sum,inner_smul_right,eigen,HilbertBasis.repr_apply_apply]
            exact (norm_sum_le _ _).trans_eq (Finset.sum_congr rfl (fun i _ => by simp only [norm_mul]; ring))
          _ = ∑ i ∈ s, ‖evals i‖ * ∑ j : Fin n, ‖inner ℂ (v j) (c i)‖ * ‖inner ℂ (b i) (u j)‖ := by
            rw [Finset.sum_comm]; simp only [Finset.mul_sum]
          _ ≤ _ := by
            apply Finset.sum_le_sum
            intro i _
            have h := frame_inner_prod_le_one' hu hv (b.orthonormal.1 i) (nc i)
            simpa only [mul_one,norm_inner_symm (𝕜:=ℂ) (b i),norm_inner_symm (𝕜:=ℂ) (c i),mul_comm] using mul_le_mul_of_nonneg_left h (norm_nonneg (evals i))
        simpa only [ENNReal.ofReal_sum_of_nonneg (fun _ _ => norm_nonneg _),ofReal_norm] using ENNReal.ofReal_le_ofReal bd
      _ ≤ _ := ENNReal.sum_le_tsum _
  · rw [ENNReal.tsum_eq_iSup_sum]
    apply iSup_le; intro s
    let t := s.filter (fun i => evals i ≠ 0)
    have eq : ∑ i ∈ s, ‖evals i‖ₑ = ∑ i ∈ t, ‖evals i‖ₑ := by
      rw [Finset.sum_filter]
      exact Finset.sum_congr rfl fun i _ => by
        split_ifs with h
        · rfl
        · rw [not_not.mp h,enorm_zero]
    rw [eq]
    let e : Fin t.card ≃ t := (Finset.equivFin t).symm
    let g : Fin t.card → {i // evals i ≠ 0} := fun j =>
      ⟨e j, (Finset.mem_filter.mp (e j).property).2⟩
    have gi : Function.Injective g := fun _ _ h => e.injective (Subtype.ext (congrArg (fun x : {i // evals i ≠ 0} => x.val) h))
    let u : Fin t.card → H := fun j => b (e j)
    let v : Fin t.card → H := fun j => c (e j)
    have hu : Orthonormal ℂ u := b.orthonormal.comp _ (Subtype.val_injective.comp e.injective)
    have hv : Orthonormal ℂ v := on.comp g gi
    have le := frame_sum_le A hu hv
    have entry (j : Fin t.card) : inner ℂ (v j) (A (u j)) = evals (e j) := by
      simp only [u,v,eigen,inner_smul_right,inner_self_eq_one_of_norm_eq_one (hv.1 j),mul_one]
    simp only [entry] at le
    rw [← Finset.sum_coe_sort]
    exact (Equiv.sum_comp e (fun i : t => ‖evals i‖ₑ)) ▸ le


universe u

/-- For every compact operator, the gauge is its standard extended trace
norm: the sum of the square roots of the eigenvalues of (A^*A), with
multiplicity in a complete Hilbert basis. No symmetry assumption on (A). -/
theorem traceVariational_compact_singular_sum {X : Type u}
    [NormedAddCommGroup X] [InnerProductSpace ℂ X] [CompleteSpace X]
    (A : X →L[ℂ] X) (hc : IsCompactOperator A) :
    ∃ (I : Type u) (b : HilbertBasis I ℂ X) (s : I → ℝ),
      (∀ i, 0 ≤ s i) ∧
      (∀ i, (A.adjoint ∘L A) (b i) = ((s i)^2 : ℂ) • b i) ∧
      traceVariational A = ∑' i, ENNReal.ofReal (s i) := by
  classical
  let B := A.adjoint ∘L A
  have bc : IsCompactOperator B := hc.clm_comp A.adjoint
  have bsp : B.IsPositive := A.isPositive_adjoint_comp_self
  obtain ⟨I,b,e,he⟩ := compact_eigenbasis B bc bsp.isSymmetric
  let s (i : I) : ℝ := ‖A (b i)‖
  let c (i : I) : X := ((s i : ℂ)⁻¹) • A (b i)
  have zeroi (i : I) (h : s i = 0) : A (b i) = 0 := norm_eq_zero.mp h
  have eb (i j : I) : inner ℂ (A (b i)) (A (b j)) = e j * inner ℂ (b i) (b j) := by
    rw [← A.adjoint_inner_right, show A.adjoint (A (b j)) = B (b j) from rfl,he,inner_smul_right]
  have es (i : I) : e i = (s i : ℂ)^2 := by
    have h := eb i i
    rw [inner_self_eq_norm_sq_to_K,inner_self_eq_one_of_norm_eq_one (b.orthonormal.1 i),mul_one] at h
    exact h.symm
  have cnorm_nonzero (i : I) (h : s i ≠ 0) : ‖c i‖ = 1 := by
    dsimp only [c]
    rw [norm_smul,norm_inv,Complex.norm_of_nonneg (norm_nonneg (A (b i)))]
    exact inv_mul_cancel₀ h
  have cnorm (i : I) : ‖c i‖ ≤ 1 := by
    by_cases h : s i = 0
    · simp [c,h]
    · exact (cnorm_nonzero i h).le
  have on : Orthonormal ℂ (fun i : {i // (s i : ℂ) ≠ 0} => c i) := by
    rw [orthonormal_iff_ite]
    intro i j
    by_cases eq : i=j
    · subst j
      rw [if_pos rfl]
      exact inner_self_eq_one_of_norm_eq_one (cnorm_nonzero i (Complex.ofReal_ne_zero.mp i.property))
    · rw [if_neg eq]
      change inner ℂ (c i) (c j) = 0
      have ne : i.val ≠ j.val := fun h => eq (Subtype.ext h)
      dsimp only [c]
      rw [inner_smul_left,inner_smul_right,eb,orthonormal_iff_ite.mp b.orthonormal,if_neg ne]
      simp
  have svd (i : I) : A (b i) = (s i : ℂ) • c i := by
    by_cases h : s i = 0
    · simp [c,h,zeroi i h]
    · dsimp only [c]
      rw [smul_smul,mul_inv_cancel₀ (Complex.ofReal_ne_zero.mpr h),one_smul]
  refine ⟨I,b,s,fun i => norm_nonneg _,fun i => (he i).trans ?_,?_⟩
  · exact congrArg (fun z : ℂ => z • b i) (es i)
  · have en (i : I) : ‖(s i : ℂ)‖ₑ = ENNReal.ofReal (s i) := by
      rw [←ofReal_norm,Complex.norm_of_nonneg (norm_nonneg (A (b i)))]
    simpa only [en] using traceVariational_eq_tsum_of_singular_system A b (fun i => (s i:ℂ)) c cnorm on svd

end KDClosure.Hull
