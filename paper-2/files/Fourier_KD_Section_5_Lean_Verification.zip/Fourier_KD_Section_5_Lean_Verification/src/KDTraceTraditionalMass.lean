import KDTraceTraditional

/-! On positive bounded-trace operators, the two-frame trace norm is the intrinsic trace. -/
noncomputable section
namespace KDClosure.Hull
open Classical Set ContinuousLinearMap
open scoped InnerProductSpace ENNReal Topology ComplexOrder

variable {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℂ H] [CompleteSpace H]

theorem traceVariational_eq_intrinsic_positive_trace {A : H →L[ℂ] H} (p : A.IsPositive)
    {t : ℝ} (ht : IsLUB (Tight.Mass A) t) : traceVariational A = ENNReal.ofReal t := by
  classical
  have nz : 0 ∈ Tight.Mass A := ⟨0,fun i => Fin.elim0 i,
    orthonormal_iff_ite.mpr (fun i => Fin.elim0 i),Finset.sum_empty⟩
  have tn : 0 ≤ t := ht.1 nz
  apply le_antisymm
  · obtain ⟨R,hr⟩ := Tight.root_factor A p
    have bd {n : ℕ} {u : Fin n → H} (on : Orthonormal ℂ u) :
        ∑ j, ‖R (u j)‖ ^ 2 ≤ t := by
      have h := ht.1 ⟨n,u,on,rfl⟩
      have eqn (j : Fin n) : (inner ℂ (u j) (A (u j))).re = ‖R (u j)‖ ^ 2 := by
        rw [hr,R.adjoint_inner_right]
        exact (norm_sq_eq_re_inner (𝕜:=ℂ) _).symm
      simpa only [eqn] using h
    apply iSup_le; intro n; apply iSup_le; intro u; apply iSup_le; intro hu
    apply iSup_le; intro v; apply iSup_le; intro hv
    have normbd : ∑ j, ‖inner ℂ (v j) (A (u j))‖ ≤ t := calc
      _ ≤ ∑ j, ‖R (v j)‖ * ‖R (u j)‖ := by
        apply Finset.sum_le_sum; intro j _
        rw [hr,R.adjoint_inner_right]
        exact norm_inner_le_norm _ _
      _ ≤ _ := by
        apply (Real.sum_mul_le_sqrt_mul_sqrt _ _ _).trans
        rw [←Real.mul_self_sqrt tn]
        exact mul_le_mul (Real.sqrt_le_sqrt (bd hv)) (Real.sqrt_le_sqrt (bd hu))
          (Real.sqrt_nonneg _) (Real.sqrt_nonneg _)
    simpa only [ENNReal.ofReal_sum_of_nonneg (fun _ _ => norm_nonneg _),ofReal_norm] using ENNReal.ofReal_le_ofReal normbd
  · by_cases h : traceVariational A = ⊤
    · rw [h]; exact le_top
    have lb : traceVariational A = ENNReal.ofReal (traceVariational A).toReal :=
      (ENNReal.ofReal_toReal h).symm
    apply le_trans (ENNReal.ofReal_le_ofReal (ht.2 ?_)) lb.symm.le
    rintro _ ⟨n,u,hu,rfl⟩
    have base := frame_sum_le A hu hu
    have norm_eq (i : Fin n) : ‖inner ℂ (u i) (A (u i))‖ = (inner ℂ (u i) (A (u i))).re := by
      let z := inner ℂ (u i) (A (u i))
      have zp : 0 ≤ z := p.inner_nonneg_right _
      have eq : (z.re : ℂ) = z := Complex.ext rfl (by simpa only [Complex.ofReal_im] using (Complex.nonneg_iff.mp zp).2)
      exact congrArg norm eq |>.symm.trans (Complex.norm_of_nonneg (Complex.nonneg_iff.mp zp).1)
    have tn' : 0 ≤ ∑ j, (inner ℂ (u j) (A (u j))).re :=
      Finset.sum_nonneg fun i _ => p.re_inner_nonneg_right _
    have fact : ENNReal.ofReal (∑ j, (inner ℂ (u j) (A (u j))).re) ≤ traceVariational A := by
      simpa only [←norm_eq, ENNReal.ofReal_sum_of_nonneg (fun _ _ => norm_nonneg _),ofReal_norm] using base
    have hf := (ENNReal.toReal_le_toReal ENNReal.ofReal_ne_top h).mpr fact
    simpa only [ENNReal.toReal_ofReal tn'] using hf

end KDClosure.Hull
