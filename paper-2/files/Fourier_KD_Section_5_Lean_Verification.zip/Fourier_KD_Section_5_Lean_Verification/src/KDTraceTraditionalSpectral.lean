import KDTraceTraditional

/-! Extract a Hilbert eigenbasis from Mathlib's compact self-adjoint spectral
theorem, and identify the singular values, with multiplicity, as square roots
of the Hilbert eigenbasis values for (A^*A). -/
noncomputable section
namespace KDClosure.Hull
open Classical Set Filter Submodule Module.End ContinuousLinearMap
open scoped InnerProductSpace ENNReal

universe u
variable {H : Type u} [NormedAddCommGroup H] [InnerProductSpace ℂ H] [CompleteSpace H]

set_option maxHeartbeats 900000 in
theorem compact_eigenbasis (A : H →L[ℂ] H) (hc : IsCompactOperator A)
    (hs : A.IsSymmetric) :
    ∃ (I : Type u) (b : HilbertBasis I ℂ H) (e : I → ℂ), ∀ i, A (b i) = e i • b i := by
  let E (z : ℂ) := eigenspace A.toLinearMap z
  have complete (z : ℂ) : CompleteSpace (E z) := by
    change CompleteSpace (eigenspace A.toLinearMap z)
    infer_instance
  have roots (z : ℂ) : ∃ (I : Type u) (b : HilbertBasis I ℂ (E z)), True := by
    obtain ⟨I,b,_⟩ := exists_hilbertBasis ℂ (E z)
    exact ⟨I,b,trivial⟩
  choose I b _ using roots
  let v (i : Σ z, I z) : H := (b i.1 i.2 : H)
  have on : Orthonormal ℂ v := by
    rw [orthonormal_iff_ite]
    rintro ⟨z,i⟩ ⟨z',j⟩
    by_cases he : z=z'
    · subst z'
      have eq : (Sigma.mk z i = Sigma.mk z j) ↔ i=j := by simp
      simpa only [v,eq,Submodule.coe_inner] using (orthonormal_iff_ite.mp (b z).orthonormal i j)
    · have hn : Sigma.mk z i ≠ Sigma.mk z' j := fun eq => he (congrArg Sigma.fst eq)
      rw [if_neg hn]
      exact hs.orthogonalFamily_eigenspaces he (b z i) (b z' j)
  have span_le' (z : ℂ) : E z ≤ (Submodule.span ℂ (Set.range v)).topologicalClosure := by
    intro w hw
    let a : E z := ⟨w,hw⟩
    have hl : HasSum (fun i => (b z).repr a i • v ⟨z,i⟩) w := by
      exact ((b z).hasSum_repr a).mapL (E z).subtypeL
    apply mem_closure_of_tendsto hl
    exact Eventually.of_forall fun s => Submodule.sum_mem _ fun i _ =>
      Submodule.smul_mem _ _ (Submodule.subset_span ⟨⟨z,i⟩,rfl⟩)
  have all_span : (Submodule.span ℂ (Set.range v))ᗮ = ⊥ := by
    have aux : (⨆ z, E z) ≤ (Submodule.span ℂ (Set.range v)).topologicalClosure := iSup_le span_le'
    have le := Submodule.orthogonal_le aux
    rw [Submodule.orthogonal_closure, show (⨆ z, E z)ᗮ = ⊥ from
      A.orthogonalComplement_iSup_eigenspaces_eq_bot hc hs] at le
    exact le_antisymm le bot_le
  let B : HilbertBasis (Σ z, I z) ℂ H := HilbertBasis.mkOfOrthogonalEqBot on all_span
  have bv : ⇑B = v := HilbertBasis.coe_mkOfOrthogonalEqBot on all_span
  refine ⟨_,B,Sigma.fst,?_⟩
  intro i
  have hi : B i = v i := congrFun bv i
  have ev : A (v i) = i.1 • v i := (mem_eigenspace_iff.mp (b i.1 i.2).property)
  exact (congrArg (fun x : H => A x) hi).trans (ev.trans (congrArg (fun x : H => i.1 • x) hi.symm))


/-- On a compact self-adjoint operator the variational trace gauge is exactly
the extended sum of the eigenvalues of `A.adjoint ∘L A` to the power one-half,
counted on a Hilbert eigenbasis. The compact spectral theorem supplies the
basis, so no singular-system assumption is left to the caller. -/
theorem traceVariational_compact_symmetric_singular_sum (A : H →L[ℂ] H)
    (hc : IsCompactOperator A) (hs : A.IsSymmetric) :
    ∃ (I : Type u) (b : HilbertBasis I ℂ H) (s : I → ℝ),
      (∀ i, 0 ≤ s i) ∧
      (∀ i, (A.adjoint ∘L A) (b i) = ((s i)^2 : ℂ) • b i) ∧
      traceVariational A = ∑' i, ENNReal.ofReal (s i) := by
  obtain ⟨I,b,e,he⟩ := compact_eigenbasis A hc hs
  refine ⟨I,b,fun i => ‖e i‖,fun i => norm_nonneg _,?_,?_⟩
  · intro i
    rw [ContinuousLinearMap.comp_apply,hs.isSelfAdjoint.adjoint_eq,he,map_smul,he,smul_smul]
    have eigval : HasEigenvalue A.toLinearMap (e i) :=
      hasEigenvalue_of_hasEigenvector ⟨mem_eigenspace_iff.mpr (he i),b.orthonormal.ne_zero i⟩
    have realval := hs.conj_eigenvalue_eq_self eigval
    have nSq : ((‖e i‖ : ℝ) : ℂ)^2 = e i * e i := by
      rw [← Complex.ofReal_pow, ← Complex.normSq_eq_norm_sq, ← Complex.mul_conj,realval]
    rw [nSq]
  · simpa only [ofReal_norm] using traceVariational_eq_abs_tsum_of_eigenbasis A b e he

end KDClosure.Hull
