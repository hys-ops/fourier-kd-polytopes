import KDFrequencyMasks
import KDExclusion

namespace KDClosure
open Matrix Frequency
open scoped BigOperators
variable {q : ℕ} [Fact q.Prime]

/-- The action on an arbitrary transverse column in the original q coordinates. -/
theorem transverse_UV (v : ZMod q → ℂ) (t : ZMod q) :
    (U q *ᵥ v) t = (if t=0 then v 0 else 0) ∧
    (V q *ᵥ v) t = (q:ℂ)⁻¹*(∑ u, v u) := by
  constructor
  · by_cases ht : t=0 <;> simp [U,mulVec,dotProduct,ht,ite_mul]
  · simp [V,mulVec,dotProduct,Finset.mul_sum]

/-- For either signed root z of q z² = 1, e+z·1 is an eigenvector of U+V.
The difference U−V sends this vector into the opposite channel. -/
theorem transverse_channels (z : ℂ) (hz : (q:ℂ)*z^2=1) (t : ZMod q) :
    ((U q + V q) *ᵥ channel q z) t = (1+z)*channel q z t ∧
    ((U q - V q) *ᵥ channel q z) t = (1+z)*channel q (-z) t := by
  have hq : (q:ℂ) ≠ 0 := Nat.cast_ne_zero.mpr (Fact.out : Nat.Prime q).ne_zero
  have hi : (q:ℂ)⁻¹=z^2 := by apply (inv_eq_one_div _).trans; field_simp; linear_combination -hz
  have h := transverse_UV (channel q z) t
  rw [add_mulVec,sub_mulVec,Pi.add_apply,Pi.sub_apply,h.1,h.2,sum_channel]
  rw [mul_add,mul_one,←mul_assoc,inv_mul_cancel₀ hq,one_mul,hi]
  by_cases ht : t=0 <;> simp [channel,ht] <;> constructor <;> ring

theorem transverse_complement (v : ZMod q → ℂ) (h0 : v 0 = 0)
    (hs : ∑ u, v u = 0) : (U q) *ᵥ v = 0 ∧ (V q) *ᵥ v = 0 := by
  constructor
  · ext t; simp [(transverse_UV v t).1,h0]
  · ext t; simp [(transverse_UV v t).2,hs]

/-- Every physical q-column splits as e and the constant column, plus a
column on which both packets vanish. q=2 is included. -/
theorem transverse_split (v : ZMod q → ℂ) :
    ∃ α β : ℂ, ∃ w : ZMod q → ℂ,
      w 0=0 ∧ (∑ u, w u)=0 ∧ ∀ t, v t = (if t=0 then α else 0)+β+w t := by
  have hq : (q:ℂ)-1 ≠ 0 := by
    intro h
    have e := congrArg Complex.re (sub_eq_zero.mp h)
    simp at e
    exact (Fact.out : Nat.Prime q).ne_one e
  let β : ℂ := ((∑ t, v t)-v 0)/((q:ℂ)-1)
  let α : ℂ := v 0-β
  let w : ZMod q → ℂ := fun t => v t-(if t=0 then α else 0)-β
  refine ⟨α,β,w,?_,?_,?_⟩
  · simp [w,α]
  · simp only [w,Finset.sum_sub_distrib,Finset.sum_ite_eq',Finset.mem_univ,
      if_true,Finset.sum_const,Finset.card_univ,ZMod.card,nsmul_eq_mul]
    dsimp only [α,β]; field_simp; ring
  · intro t; simp [w]

end KDClosure
