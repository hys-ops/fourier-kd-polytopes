import KDOperatorSupport
import Mathlib.RingTheory.RootsOfUnity.Basic

namespace KDClosure
open Set
/-- Roots-of-unity realization inside the complex units; the Hilbert space
uses the underlying discrete group. -/
noncomputable def pRoots (p : ℕ) : Subgroup ℂˣ := ⨆ n : ℕ, rootsOfUnity (p^n) ℂ

theorem finite_two_roots (K : Subgroup ℂˣ) :
    {x : Additive K | x+x=0}.Finite := by
  let V (x : Additive K) : ℂ := ((x.toMul.val : ℂˣ) : ℂ)
  have hi : Function.Injective V := fun _ _ e => Subtype.ext (Units.ext e)
  apply (((Set.finite_singleton (1:ℂ)).insert (-1)).preimage hi.injOn).subset
  intro x hx
  have h : V x * V x = 1 := congrArg V hx
  rcases mul_self_eq_one_iff.mp h with e | e <;> simp [Set.mem_preimage,V] at e ⊢ <;> tauto

theorem mixed_two_finite (p q : ℕ) [NeZero q] :
    {x : Additive (pRoots p) × ZMod q | x+x=0}.Finite := by
  apply ((finite_two_roots (pRoots p)).prod (Set.toFinite (Set.univ : Set (ZMod q)))).subset
  intro x hx
  exact ⟨congrArg Prod.fst hx, Set.mem_univ _⟩

/-- Operator-range version specialized to the discrete mixed-prime group. -/
theorem mixed_operator_support (p q : ℕ) [NeZero q]
    {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℂ H] [CompleteSpace H]
    (T : H →L[ℂ] H) [FiniteDimensional ℂ (LinearMap.range T.toLinearMap)] (pos : T.IsPositive)
    (e : Additive (pRoots p) × ZMod q → H)
    (traceFinite : Summable fun x => (inner ℂ (e x) (T (e x))).re)
    (period : ∀ x y, inner ℂ (e x) (T (e y)) = inner ℂ (e y) (T (e (y+y-x)))) :
    {y | T (e y) ≠ 0}.Finite :=
  finite_operator_support T pos e traceFinite period (mixed_two_finite p q)

end KDClosure
