import KDGap
import KDTransverse

namespace KDClosure
open Matrix Frequency
open scoped BigOperators
variable {p q N : ℕ} [Fact p.Prime] [Fact q.Prime]

omit [Fact p.Prime] in
theorem transverse_traces :
    (∑ t : ZMod q, U q t t) = 1 ∧ (∑ t : ZMod q, V q t t) = 1 ∧
    (∑ t : ZMod q, ident q t t) = (q:ℂ) := by
  have hq : (q:ℂ)≠0 := Nat.cast_ne_zero.mpr (Fact.out : Nat.Prime q).ne_zero
  simp [U,V,ident,nsmul_eq_mul,hq]

/-- The trace at one position is independent of every oscillating coefficient.
At a positive-colour position of unit weight it equals two at every depth. -/
theorem finite_witness_position_trace (J : Finset ℕ) (y : ℕ → ℝ) (d : ZMod (p^N) → ℝ)
    (pos : ZMod (p^N) → Prop) [DecidablePred pos] (x : ZMod (p^N)) :
    (∑ t, physical (finiteWitness (q:=q) J y d pos) (x,t) (x,t)) =
      (d x:ℂ)*(if pos x then 2 else 2*(q:ℂ)-2) := by
  obtain ⟨hU,hV,hI⟩ := transverse_traces (q:=q)
  simp only [physical,finiteWitness,factored,Pi.add_apply,Matrix.add_apply,
    Matrix.sub_apply,sub_self,if_true,Finset.sum_add_distrib,
    ←Finset.mul_sum, Finset.sum_sub_distrib,hU,hV,sub_self,mul_zero,add_zero]
  congr 1
  by_cases hx : pos x <;> simp [baseBlock,hx,Finset.sum_add_distrib,Finset.sum_sub_distrib,
    Matrix.add_apply,Matrix.sub_apply,hU,hV,hI] <;> ring

/-- A lower bound on a finite set of diagonals suffices for a *fixed*
visible coordinate on arbitrarily long prefixes. -/
theorem fixed_visible {I : Type*} [Fintype I] [Nonempty I] (a : ℕ → I → ℝ) (c : ℝ)
    (ht : ∀ n, c*(Fintype.card I:ℝ) ≤ ∑ i, a n i) :
    ∃ i, ∀ K : ℕ, ∃ n≥K, c ≤ a n i := by
  classical
  by_contra! h
  choose cutoff bound using h
  let n := Finset.univ.sup cutoff
  have small (i : I) : a n i < c := bound i n (Finset.le_sup (f:=cutoff) (Finset.mem_univ i))
  have hs := Finset.sum_lt_sum_of_nonempty Finset.univ_nonempty (fun i _ => small i)
  simp only [Finset.sum_const,Finset.card_univ,nsmul_eq_mul] at hs
  linarith [ht n]

variable {L : ℕ} [NeZero L]
noncomputable def levelMass (p L : ℕ) [NeZero p] [NeZero L] (n : ℕ) : ℝ :=
  ∑ x : Level p L n, 1/weight p L (fresh p L) n x

theorem levelMass_succ (n : ℕ) :
    levelMass p L (n+1) = levelMass p L n + shellMass p L n := by
  classical
  let val (x : ZMod p × (ZMod L × Level p L n)) : ℝ := 1 / weight p L (fresh p L) (n+1) x
  have part (x : ZMod p × (ZMod L × Level p L n)) : val x =
      (if x.1=0 ∧ x.2.1=0 then 1 / weight p L (fresh p L) n x.2.2 else 0) +
      (if x.1=0 ∧ x.2.1=0 then 0 else val x) := by
    rcases x with ⟨b,g,x⟩
    by_cases hb : b=0 <;> by_cases hg : g=0 <;> simp [val,weight,extendWeight,hb,hg]
  change (∑ x : ZMod p × (ZMod L × Level p L n), val x) = _
  rw [Finset.sum_congr rfl (fun x _ => part x),Finset.sum_add_distrib]
  congr 1
  simp [Fintype.sum_prod_type,levelMass,Finset.sum_ite_irrel,ite_and]

theorem uniform_levelMass (hL : 1<L) (n : ℕ) :
    levelMass p L n ≤ (p:ℝ) + ∑' j, shellMass p L j := by
  have eq : levelMass p L n = (p:ℝ) + ∑ j ∈ Finset.range n, shellMass p L j := by
    induction n with
    | zero =>
      simp [levelMass,Level,weight,fresh]
      exact ZMod.card p
    | succ n ih => rw [levelMass_succ,ih,Finset.sum_range_succ,add_assoc]
  rw [eq]
  exact add_le_add_right ((summable_shellMass hL).sum_le_tsum _ (fun i _ => (shell_bound hL i).1)) _

end KDClosure
