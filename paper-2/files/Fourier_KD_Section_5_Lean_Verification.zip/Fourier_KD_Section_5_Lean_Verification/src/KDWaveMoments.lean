import KDTraceBudget
import KDCosetPackets
import Mathlib.Order.Interval.Finset.Fin

namespace KDClosure
open scoped BigOperators
variable {p L : ℕ} [NeZero p] [NeZero L]

/-- Packet j is born at level j+1 and is subsequently extended by zero. -/
noncomputable def rawPacket (χ : ℕ → AddChar (ZMod p) ℂ) (j : ℕ) :
    (n : ℕ) → Level p L n → ℂ
  | 0, _ => 0
  | n+1, x =>
    if j = n then χ j x.1
    else if x.1 = 0 then (if x.2.1 = 0 then rawPacket χ j n x.2.2 else 0) else 0

/-- The multiplier u can contain either sign and the channel denominator. -/
noncomputable def packetDensity (f : ℕ → ℝ) (u : ZMod p → ℝ) (n : ℕ) (x : Level p L n) : ℂ :=
  ((u (baseLabel p L n x) * weight p L f n x : ℝ) : ℂ)

theorem density_on_old (f : ℕ → ℝ) (u : ZMod p → ℝ) (n : ℕ) (x : Level p L n) :
    packetDensity f u (n+1) (0,0,x) = packetDensity f u n x := by
  simp [packetDensity,baseLabel,weight,extendWeight]

theorem sum_child_density (f : ℕ → ℝ) (u : ZMod p → ℝ) (n : ℕ) (b : ZMod p) :
    ∑ g : ZMod L, ∑ x : Level p L n, packetDensity f u (n+1) (b,g,x) =
       (((L:ℝ) * (∑ x : Level p L n, u (baseLabel p L n x)) *
          nextMean L (reciprocalMean (1/(L:ℝ)) f n) (f (n+1))) : ℝ) := by
  change ∑ g : ZMod L, ∑ x : Level p L n,
    ((u (baseLabel p L n x) * extendWeight (weight p L f n) _ (f (n+1)) b g x : ℝ) : ℂ) = _
  push_cast
  exact_mod_cast equal_child_mass (weight p L f n) (fun x => u (baseLabel p L n x))
    (reciprocalMean (1/(L:ℝ)) f n) (f (n+1)) (weight_moment p L f u n) b

/-- A packet has zero weighted mean at every subsequent cutoff. -/
theorem packet_mean_zero (χ : ℕ → AddChar (ZMod p) ℂ) (nz : ∀ j, χ j ≠ 1)
    (f : ℕ → ℝ) (u : ZMod p → ℝ) (j n : ℕ) (hj : j < n) :
    (∑ x : Level p L n, rawPacket χ j n x * packetDensity f u n x) = 0 := by
  induction n with
  | zero => omega
  | succ n ih =>
    change ∑ x : ZMod p × (ZMod L × Level p L n), rawPacket χ j (n+1) x * _ = _
    rw [Fintype.sum_prod_type]
    simp only [Fintype.sum_prod_type]
    by_cases he : j=n
    · subst j
      simp only [rawPacket, if_true]
      simp_rw [← Finset.mul_sum, sum_child_density]
      rw [← Finset.sum_mul, AddChar.sum_eq_zero_of_ne_one (nz n), zero_mul]
    · simp only [rawPacket, if_neg he, ite_mul, zero_mul]
      simp [Finset.sum_ite_irrel, density_on_old, ih (by omega)]

noncomputable def gramEntry (χ : ℕ → AddChar (ZMod p) ℂ) (f : ℕ → ℝ)
    (u : ZMod p → ℝ) (i j n : ℕ) : ℂ :=
  ∑ x : Level p L n, star (rawPacket χ i n x) * rawPacket χ j n x * packetDensity f u n x

theorem gram_star (χ : ℕ → AddChar (ZMod p) ℂ) (f : ℕ → ℝ)
    (u : ZMod p → ℝ) (i j n : ℕ) :
    star (gramEntry (L:=L) χ f u i j n) = gramEntry (L:=L) χ f u j i n := by
  have hstar (x : Level p L n) : star (packetDensity f u n x) = packetDensity f u n x := Complex.conj_ofReal _
  simp only [gramEntry,star_sum,star_mul,star_star,hstar]
  apply Finset.sum_congr rfl
  intro x _
  ring

theorem gram_old (χ : ℕ → AddChar (ZMod p) ℂ) (f : ℕ → ℝ)
    (u : ZMod p → ℝ) (i j n : ℕ) (hi : i ≠ n) (hj : j ≠ n) :
    gramEntry (L:=L) χ f u i j (n+1) = gramEntry (L:=L) χ f u i j n := by
  unfold gramEntry
  change ∑ x : ZMod p × (ZMod L × Level p L n), _ = _
  simp only [Fintype.sum_prod_type, rawPacket,if_neg hi,if_neg hj]
  simp [apply_ite, ite_mul, Finset.sum_ite_irrel, density_on_old]

theorem gram_later_zero (χ : ℕ → AddChar (ZMod p) ℂ) (nz : ∀ j, χ j ≠ 1)
    (f : ℕ → ℝ) (u : ZMod p → ℝ) (i j n : ℕ) (hji : j < i) (hn : i < n) :
    gramEntry (L:=L) χ f u i j n = 0 := by
  induction n with
  | zero => omega
  | succ n ih =>
    by_cases hi : i=n
    · subst i
      unfold gramEntry
      change ∑ x : ZMod p × (ZMod L × Level p L n), _ = _
      have hj : j ≠ n := by omega
      simp only [Fintype.sum_prod_type,rawPacket,if_true,if_neg hj]
      simpa [mul_ite,ite_mul, Finset.sum_ite_irrel,density_on_old] using
        packet_mean_zero (L:=L) χ nz f u j n hji
    · rw [gram_old χ f u i j n hi (by omega)]
      exact ih (by omega)

theorem gram_diag_birth (χ : ℕ → AddChar (ZMod p) ℂ) (f : ℕ → ℝ)
    (u : ZMod p → ℝ) (j : ℕ) :
    gramEntry (L:=L) χ f u j j (j+1) =
      (((∑ x : Level p L (j+1), u (baseLabel p L (j+1) x)) *
       reciprocalMean (1/(L:ℝ)) f (j+1)) : ℝ) := by
  have unit (t : ZMod p) : star (χ j t) * χ j t = 1 := by
    rw [Complex.star_def, Complex.conj_mul', (χ j).norm_apply]
    norm_num
  unfold gramEntry
  simp only [rawPacket, if_true, unit,one_mul,packetDensity]
  exact_mod_cast weight_moment p L f u (j+1)

theorem gram_diag (χ : ℕ → AddChar (ZMod p) ℂ) (f : ℕ → ℝ)
    (u : ZMod p → ℝ) (j n : ℕ) (hj : j < n) :
    gramEntry (L:=L) χ f u j j n =
      (((∑ x : Level p L (j+1), u (baseLabel p L (j+1) x)) *
       reciprocalMean (1/(L:ℝ)) f (j+1)) : ℝ) := by
  induction n with
  | zero => omega
  | succ n ih =>
    by_cases he : j=n
    · subst n; exact gram_diag_birth χ f u _
    · rw [gram_old χ f u j j n he he]; exact ih (by omega)

theorem gram_all_levels (χ : ℕ → AddChar (ZMod p) ℂ) (nz : ∀ j, χ j ≠ 1)
    (f : ℕ → ℝ) (u : ZMod p → ℝ) (i j n : ℕ) (hi : i<n) (hj : j<n) :
    gramEntry (L:=L) χ f u i j n =
      if i=j then (((∑ x : Level p L (j+1), u (baseLabel p L (j+1) x)) *
                       reciprocalMean (1/(L:ℝ)) f (j+1)) : ℝ) else 0 := by
  split_ifs with e
  · subst i; exact gram_diag χ f u j n hj
  · rcases lt_or_gt_of_ne e with h|h
    · rw [←gram_star, gram_later_zero χ nz f u j i n h hj, star_zero]; norm_num
    · exact gram_later_zero χ nz f u i j n h hi

/-- The digit character is the quotient character on ordinary residues mod p. -/
theorem packet_birth_phase (χ : ℕ → AddChar (ZMod p) ℂ) (j : ℕ) (b : ZMod p)
    (g : ZMod L) (x : Level p L j) :
    rawPacket χ j (j+1) (b,g,x) =
       χ j ((encodeLevel p L (j+1) (b,g,x)).val : ZMod p) := by
  simp [rawPacket,encode_succ]

theorem sum_baseLabel (u : ZMod p → ℝ) (n : ℕ) :
    (∑ x : Level p L n, u (baseLabel p L n x)) = (p*L:ℝ)^n * ∑ t, u t := by
  induction n with
  | zero => simp [baseLabel]; rfl
  | succ n ih =>
    change (∑ x : ZMod p × (ZMod L × Level p L n), u (baseLabel p L n x.2.2)) = _
    simp [Fintype.sum_prod_type, ih,nsmul_eq_mul,pow_succ]; ring

noncomputable def packetNormInv (p L j : ℕ) : ℝ :=
  (Real.sqrt (levelSize p L (j+1) : ℝ))⁻¹

noncomputable def cyclicPacket (χ : ℕ → AddChar (ZMod p) ℂ) (j n : ℕ)
    (x : ZMod (levelSize p L n)) : ℂ :=
  (packetNormInv p L j : ℂ) * rawPacket χ j n ((encodeLevel p L n).symm x)

noncomputable def cyclicDensity (f : ℕ → ℝ) (u : ZMod p → ℝ) (n : ℕ)
    (x : ZMod (levelSize p L n)) : ℂ := packetDensity f u n ((encodeLevel p L n).symm x)

/-- The weighted Gram matrix of the normalized physical packets on the ordinary
cyclic head. The density is the reciprocally balanced positive baseline times u;
u can be any real-valued base statistic. No Gram identities or orthogonality
conditions are assumptions. -/
theorem cyclic_gram (χ : ℕ → AddChar (ZMod p) ℂ) (nz : ∀ j, χ j ≠ 1)
    (f : ℕ → ℝ) (u : ZMod p → ℝ) (i j n : ℕ) (hi : i<n) (hj : j<n) :
    (∑ x : ZMod (levelSize p L n),
        star (cyclicPacket χ i n x) * cyclicPacket χ j n x * cyclicDensity f u n x) =
      if i=j then (((∑ t, u t)/(p:ℝ) * reciprocalMean (1/(L:ℝ)) f (j+1)) : ℝ) else 0 := by
  rw [← Equiv.sum_comp (encodeLevel p L n)]
  simp only [cyclicPacket,cyclicDensity,Equiv.symm_apply_apply]
  have factor (x : Level p L n) :
      star ((packetNormInv p L i : ℂ) * rawPacket χ i n x) *
      ((packetNormInv p L j : ℂ) * rawPacket χ j n x) * packetDensity f u n x =
      ((packetNormInv p L i : ℂ)*(packetNormInv p L j : ℂ)) *
      (star (rawPacket χ i n x) * rawPacket χ j n x * packetDensity f u n x) := by
    rw [star_mul,show star (packetNormInv p L i : ℂ) = (packetNormInv p L i : ℂ)
      from Complex.conj_ofReal _]; ring
  simp_rw [factor, ← Finset.mul_sum]
  change _ * gramEntry (L:=L) χ f u i j n = _
  rw [gram_all_levels χ nz f u i j n hi hj]
  split_ifs with he
  · subst i
    rw [sum_baseLabel]
    norm_cast
    have hp : (p:ℝ) ≠ 0 := Nat.cast_ne_zero.mpr (NeZero.ne p)
    have hl : (L:ℝ) ≠ 0 := Nat.cast_ne_zero.mpr (NeZero.ne L)
    have hs : 0 < (levelSize p L (j+1):ℝ) :=
      Nat.cast_pos.mpr (Nat.pos_of_ne_zero (NeZero.ne _))
    dsimp [packetNormInv]
    rw [←mul_inv,←sq,Real.sq_sqrt hs.le, size_formula]
    push_cast; field_simp
  · simp

noncomputable def signLabel (l : ℕ) (t : ZMod p) : ℝ := if t.val < l then 1 else -1

theorem sign_mean {l : ℕ} (hl : l < p) :
    (∑ t : ZMod p, signLabel l t) = 2*(l:ℝ)-p := by
  let a : Fin p := ⟨l,hl⟩
  have count : (∑ t : ZMod p, (if t.val < l then (1:ℝ) else 0)) = (l:ℝ) := by
    rw [←Equiv.sum_comp (zvalEquiv p).symm]
    have ev (i : Fin p) : ((zvalEquiv p).symm i).val = i.val := ZMod.val_natCast_of_lt i.isLt
    simp only [ev,Finset.sum_boole]
    have he : Finset.univ.filter (fun i : Fin p => i.val < l) = Finset.Iio a := by
      ext i; simp [a]; rfl
    rw [he,Fin.card_Iio]
  have one (t : ZMod p) : signLabel l t = 2*(if t.val < l then 1 else 0)-1 := by
    by_cases h : t.val < l <;> simp [signLabel,h]; norm_num
  simp_rw [one,Finset.sum_sub_distrib,←Finset.mul_sum,count]
  simp

/-- Eq. (4) for the literal inverse diagonal weights of the original text,
on every physical finite cyclic head. The norm factor in cyclicPacket is the
normalization at its birth, not at the larger testing cutoff. Replacing a by
-a gives the second channel. -/
theorem cyclic_channel_gram (χ : ℕ → AddChar (ZMod p) ℂ) (nz : ∀ j, χ j ≠ 1)
    (f : ℕ → ℝ) (a : ℝ) (ha : a^2 ≠ 1) (l : ℕ) (hl : l<p)
    (i j n : ℕ) (hi : i<n) (hj : j<n) :
    (∑ x : ZMod (levelSize p L n), star (cyclicPacket χ i n x) * cyclicPacket χ j n x *
      (((weight p L f n ((encodeLevel p L n).symm x)) /
        (1 + a*signLabel l (baseLabel p L n ((encodeLevel p L n).symm x)))) : ℝ)) =
    if i=j then ((reciprocalMean (1/(L:ℝ)) f (j+1) *
         (1-a*(2*l/(p:ℝ)-1))/(1-a^2)) : ℝ) else 0 := by
  let u := fun t : ZMod p => (1-a*signLabel l t)/(1-a^2)
  have denom : 1-a^2 ≠ 0 := sub_ne_zero.mpr (Ne.symm ha)
  have hplus : 1+a ≠ 0 := by intro h; apply ha; nlinarith [show a = -1 by linarith]
  have hminus : 1-a ≠ 0 := by intro h; apply ha; nlinarith [show a = 1 by linarith]
  have iden (t : ZMod p) : u t = 1/(1+a*signLabel l t) := by
    by_cases h : t.val < l
    · simp only [u, signLabel, if_pos h, mul_one]; field_simp; ring
    · simp only [u, signLabel, if_neg h, mul_neg, mul_one, sub_neg_eq_add,←sub_eq_add_neg]
      field_simp; ring
  have matchD (x : ZMod (levelSize p L n)) :
      cyclicDensity f u n x =
        (((weight p L f n ((encodeLevel p L n).symm x)) /
         (1 + a*signLabel l (baseLabel p L n ((encodeLevel p L n).symm x)))) : ℝ) := by
    dsimp only [cyclicDensity,packetDensity]
    rw [iden]; congr 1; ring
  simp_rw [← matchD]
  rw [cyclic_gram χ nz f u i j n hi hj]
  split_ifs with h
  · apply congrArg Complex.ofReal
    dsimp only [u]
    simp only [←Finset.sum_div,Finset.sum_sub_distrib,←Finset.mul_sum,sign_mean hl,
      Finset.sum_const,Finset.card_univ,ZMod.card,nsmul_eq_mul,mul_one]
    have hp : (p:ℝ) ≠ 0 := Nat.cast_ne_zero.mpr (NeZero.ne p)
    field_simp
  · rfl
end KDClosure
