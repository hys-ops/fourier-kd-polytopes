import KDPhysicalPackets
import KDGroupTower

namespace KDClosure

variable {p : ℕ} [NeZero p]

/-- Physical position represented by array digits at the j-th sparse head. -/
noncomputable def sparsePoint (p : ℕ) [NeZero p] (m j : ℕ)
    (x : Level p (p^m) j) : Additive (pRoots p) :=
  sparseRootHead p m j (encodeLevel p (p^m) j x)

theorem sparsePoint_injective (m j : ℕ) : Function.Injective (sparsePoint p m j) :=
  (sparseRootHead_injective p m j).comp (encodeLevel p (p^m) j).injective

theorem sparsePoint_surjective (m : ℕ) (z : Additive (pRoots p)) :
    ∃ j, ∃ x : Level p (p^m) j, sparsePoint p m j x = z := by
  obtain ⟨j,y,hy⟩ := sparseRootHead_exhausts p m z
  exact ⟨j,(encodeLevel p (p^m) j).symm y,by simpa [sparsePoint] using hy⟩

/-- Any compatible sequence of digit functions defines one function on the
actual Prüfer group. Its restriction to every sparse head is exact. -/
theorem descend_sparse {α : Type*} (m : ℕ) (u : ∀ j, Level p (p^m) j → α)
    (coh : ∀ j x, u (j+1) (0,0,x) = u j x) :
    ∃ U : Additive (pRoots p) → α, ∀ j x, U (sparsePoint p m j x) = u j x := by
  classical
  have lift {j k : ℕ} (h : j≤k) (x : Level p (p^m) j) :
      ∃ y : Level p (p^m) k, sparsePoint p m k y = sparsePoint p m j x ∧ u k y = u j x := by
    induction k,h using Nat.le_induction with
    | base => exact ⟨x,rfl,rfl⟩
    | succ k _ ih =>
      obtain ⟨y,hy,hv⟩ := ih
      exact ⟨(0,0,y),(sparse_old_compatible p m k y).trans hy,(coh k y).trans hv⟩
  have agrees {j k : ℕ} (x : Level p (p^m) j) (y : Level p (p^m) k)
      (h : sparsePoint p m j x = sparsePoint p m k y) : u j x = u k y := by
    obtain ⟨z,hz,huz⟩ := lift (le_max_left j k) x
    obtain ⟨w,hw,huw⟩ := lift (le_max_right j k) y
    have eq := sparsePoint_injective m (max j k) (hz.trans (h.trans hw.symm))
    exact huz.symm.trans ((congrArg _ eq).trans huw)
  choose lev pt hp using sparsePoint_surjective (p:=p) m
  exact ⟨fun z => u (lev z) (pt z), fun j x => agrees _ x (hp _)⟩

/-- Both positional functions used by the two-channel null tests descend
simultaneously; the same sign and weights are used by all birth levels. -/
theorem global_weight_label (m : ℕ) (f : ℕ → ℝ) :
    ∃ W : Additive (pRoots p) → ℝ, ∃ B : Additive (pRoots p) → ZMod p,
      ∀ j x, W (sparsePoint p m j x) = weight p (p^m) f j x ∧
             B (sparsePoint p m j x) = baseLabel p (p^m) j x := by
  let u (j) (x : Level p (p^m) j) := (weight p (p^m) f j x, baseLabel p (p^m) j x)
  obtain ⟨g,hg⟩ := descend_sparse m u (fun j x => by simp [u,weight,extendWeight,baseLabel])
  exact ⟨fun z => (g z).1, fun z => (g z).2,
    fun j x => ⟨congrArg Prod.fst (hg j x),congrArg Prod.snd (hg j x)⟩⟩

/-- Once a physical point from an older head is used in a later packet, its
normalized value is the birth constant. The array support and all intermediate
old-head embeddings are taken through the actual group. -/
theorem cyclicPacket_old_head (m : ℕ) (χ : ℕ → AddChar (ZMod p) ℂ) {n j : ℕ} (hj : n≤j)
    (x : Level p (p^m) n) :
    ∃ y : Level p (p^m) (j+1), sparsePoint p m (j+1) y = sparsePoint p m n x ∧
      cyclicPacket χ j (j+1) (encodeLevel p (p^m) (j+1) y) = (packetNormInv p (p^m) j : ℂ) := by
  have lift : ∃ z : Level p (p^m) j, sparsePoint p m j z = sparsePoint p m n x := by
    induction j,hj using Nat.le_induction with
    | base => exact ⟨x,rfl⟩
    | succ k _ ih =>
      obtain ⟨y,hy⟩ := ih
      exact ⟨(0,0,y),(sparse_old_compatible p m k y).trans hy⟩
  obtain ⟨z,hz⟩ := lift
  have ev (y : Level p (p^m) (j+1)) :
      cyclicPacket χ j (j+1) (encodeLevel p (p^m) (j+1) y) =
      (packetNormInv p (p^m) j : ℂ) * rawPacket χ j (j+1) y := by simp [cyclicPacket]
  exact ⟨(0,0,z),(sparse_old_compatible p m j z).trans hz,
    (ev (0,0,z)).trans (by simp [rawPacket])⟩

/-- A single positive reciprocal channel function works simultaneously on all
physical sparse heads. Specialize with a and -a for the two channels and
multiply by a fixed positive transverse normalization if required. -/
theorem global_inverse_channel (m l : ℕ) (a : ℝ) (ha : -1<a) (ha' : a<1)
    (f : ℕ → ℝ) (hf : ∀ j, 0<f j) (hm : Monotone f) :
    ∃ d : Additive (pRoots p) → ℝ, (∀ z, 0 < d z) ∧
      ∀ j x, d (sparsePoint p m j x) =
        weight p (p^m) f j x / (1+a*signLabel l (baseLabel p (p^m) j x)) := by
  obtain ⟨W,B,hWB⟩ := global_weight_label (p:=p) m f
  refine ⟨fun z => W z/(1+a*signLabel l (B z)),?_,?_⟩
  · intro z
    obtain ⟨j,x,rfl⟩ := sparsePoint_surjective (p:=p) m z
    simp only [(hWB j x).1,(hWB j x).2]
    apply div_pos (weights_positive f hf hm j x)
    unfold signLabel
    split_ifs <;> linarith
  · intro j x; simp only [(hWB j x).1,(hWB j x).2]

end KDClosure
