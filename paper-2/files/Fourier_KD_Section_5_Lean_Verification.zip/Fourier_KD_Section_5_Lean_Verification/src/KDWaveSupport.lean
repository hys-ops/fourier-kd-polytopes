import KDWaveRestrictions
import KDAmbientFourier

namespace KDClosure.WaveSupport
open AmbientFourier Classical
variable {p : ℕ} [Fact p.Prime]

/-- The physical quotient character with the negative DFT convention. -/
noncomputable def negativeDigit (p : ℕ) [NeZero p] : AddChar (ZMod p) ℂ :=
  ZMod.stdAddChar.compAddMonoidHom (-AddMonoidHom.id _)

theorem negativeDigit_eval (b : ZMod p) : negativeDigit p b = ZMod.stdAddChar (-b) := rfl

theorem negativeDigit_nontrivial : negativeDigit p ≠ 1 := by
  intro h
  have he := DFunLike.congr_fun h (1:ZMod p)
  change ZMod.stdAddChar (-(1:ZMod p)) = 1 at he
  rw [← (ZMod.stdAddChar (N:=p)).map_zero_eq_one, ZMod.injective_stdAddChar.eq_iff] at he
  simp at he

/-- The coordinate membership predicate really is membership of the physical
point in the corresponding sparse head. -/
theorem inside_sparse_iff (m j : ℕ) (z : Additive (pRoots p)) :
    ambientInside p (1+j*(m+1)) z ↔ ∃ x : Level p (p^m) j, sparsePoint p m j x = z := by
  have eq : z ∈ Set.range (sparseRootHead p m j) ↔ ambientInside p (1+j*(m+1)) z := by
    change z ∈ Set.range (rootHead _) ↔ _
    rw [range_rootHead,size_prime_power]
    rfl
  constructor
  · intro h
    obtain ⟨y,hy⟩ := eq.mpr h
    exact ⟨(encodeLevel p (p^m) j).symm y,by simpa [sparsePoint] using hy⟩
  · rintro ⟨x,rfl⟩
    exact eq.mp (Set.mem_range_self _)

/-- The physical p^(N-1)-power phase equals the negative digit character mod p
at the birth head. The denominator cancellation is done before modular reduction. -/
theorem phase_at_birth (m j : ℕ) (x : Level p (p^m) j) :
    childPhase p (j*(m+1)) (sparsePoint p m j x) =
      negativeDigit p ((encodeLevel p (p^m) j x).val : ZMod p) := by
  let a := p^(j*(m+1))
  let z := encodeLevel p (p^m) j x
  have cap : levelSize p (p^m) j = p*a := by simpa [a,pow_add] using size_prime_power p m j
  have ha : (a:ℂ) ≠ 0 := Nat.cast_ne_zero.mpr (pow_ne_zero _ (Fact.out : Nat.Prime p).ne_zero)
  rw [childPhase,AddChar.map_neg_eq_inv,negativeDigit_eval,AddChar.map_neg_eq_inv,inv_inj]
  change (ZMod.stdAddChar z)^a = _
  change (ZMod.stdAddChar z)^a = ZMod.stdAddChar (z.val : ZMod p)
  simp only [ZMod.stdAddChar_apply]
  rw [ZMod.toCircle_natCast (N:=p) z.val,ZMod.toCircle_apply z,← Complex.exp_nat_mul]
  congr 1
  have cap' : (levelSize p (p^m) j : ℂ) = (p:ℂ)*(a:ℂ) := by exact_mod_cast cap
  rw [cap']; field_simp

/-- When evaluated on ordinary cyclic residues, the digit packet equals the
ambient subgroup indicator times the prescribed negative child character. -/
theorem rawPacket_formula (m j n : ℕ) (hj : j<n) (x : Level p (p^m) n) :
    rawPacket (fun _ => negativeDigit p) j n x =
      if ambientInside p (1+(j+1)*(m+1)) (sparsePoint p m n x) then
        childPhase p ((j+1)*(m+1)) (sparsePoint p m n x) else 0 := by
  classical
  induction n with
  | zero => omega
  | succ n ih =>
    obtain ⟨b,g,x⟩ := x
    by_cases he : j=n
    · subst j
      have ins := (inside_sparse_iff m (n+1) (sparsePoint p m (n+1) (b,g,x))).2 ⟨_,rfl⟩
      rw [if_pos ins]
      exact (packet_birth_phase (fun _ => negativeDigit p) n b g x).trans
        (phase_at_birth m (n+1) (b,g,x)).symm
    · have lt : j<n := by omega
      by_cases bc : b=0 ∧ g=0
      · obtain ⟨rfl,rfl⟩ := bc
        rw [show sparsePoint p m (n+1) (0,0,x) = sparsePoint p m n x from sparse_old_compatible p m n x]
        simpa [rawPacket,he] using ih lt x
      · have out : ¬ambientInside p (1+(j+1)*(m+1)) (sparsePoint p m (n+1) (b,g,x)) := by
          intro h
          have hin := rootsMonotone p (Nat.add_le_add_left (Nat.mul_le_mul_right _ lt) 1) h
          obtain ⟨y,hy⟩ := (inside_sparse_iff m n _).1 hin
          have hxy := sparsePoint_injective m (n+1) ((sparse_old_compatible p m n y).trans hy)
          exact bc ⟨(congrArg Prod.fst hxy).symm,(congrArg (fun z => z.2.1) hxy).symm⟩
        rw [if_neg out]
        by_cases hb : b=0
        · simp [rawPacket,he,hb,show g≠0 from fun hg => bc ⟨hb,hg⟩]
        · simp [rawPacket,he,hb]

end KDClosure.WaveSupport
