import KDPackets
import Mathlib.Data.ZMod.Basic

namespace KDClosure
open scoped BigOperators
variable {p L : ℕ} [NeZero p] [NeZero L] {X : Type*} [Fintype X]

noncomputable def nextMean (L : ℕ) (v fresh : ℝ) := (v+((L:ℝ)-1)*fresh)/L

/-- Reciprocal weights in one actual layer extension. The zero/zero child is
the embedded old head. The other children have the old-child harmonic mean. -/
noncomputable def extendWeight (w : X → ℝ) (v fresh : ℝ) (b : ZMod p)
    (g : ZMod L) (x : X) : ℝ :=
  if b=0 then if g=0 then w x else fresh else nextMean L v fresh

theorem mean_eq_mix (v fresh : ℝ) :
    nextMean L v fresh = (1/(L:ℝ))*v + (1-1/(L:ℝ))*fresh := by
  have hn : (L:ℝ) ≠ 0 := Nat.cast_ne_zero.mpr (NeZero.ne L)
  unfold nextMean
  field_simp

omit [NeZero p] in
/-- Applies to both u=1 and u=the position sign. Equal signed totals are
preserved on every child, including the one containing the old head. -/
theorem equal_child_mass (w u : X → ℝ) (v fresh : ℝ)
    (old : ∑ x, u x * w x = (∑ x, u x)*v) (b : ZMod p) :
    ∑ g : ZMod L, ∑ x, u x * extendWeight w v fresh b g x =
      (L:ℝ)*(∑ x, u x)*nextMean L v fresh := by
  have hn : (L:ℝ) ≠ 0 := Nat.cast_ne_zero.mpr (NeZero.ne L)
  by_cases hb : b=0
  · subst b
    have point (g : ZMod L) : (∑ x, u x * extendWeight (p:=p) w v fresh 0 g x) =
      (∑ x,u x)*fresh + (if g=0 then (∑ x,u x)*(v-fresh) else 0) := by
        by_cases hg : g=0
        · simp [extendWeight,hg,old]; ring
        · simp [extendWeight,hg,←Finset.sum_mul]
    rw [Finset.sum_congr rfl (fun g _ => point g),Finset.sum_add_distrib]
    simp [nsmul_eq_mul,nextMean]
    field_simp; ring
  · simp [extendWeight,hb,←Finset.sum_mul,nsmul_eq_mul]; ring

noncomputable def Level (p L : ℕ) : ℕ → Type
  | 0 => ZMod p
  | n+1 => ZMod p × (ZMod L × Level p L n)

noncomputable instance levelFin (p L : ℕ) [NeZero p] [NeZero L] :
    ∀ n, Fintype (Level p L n)
  | 0 => inferInstanceAs (Fintype (ZMod p))
  | n+1 =>
    let _ := levelFin p L n
    inferInstanceAs (Fintype (ZMod p × (ZMod L × Level p L n)))

noncomputable def baseLabel (p L : ℕ) : (n : ℕ) → Level p L n → ZMod p
  | 0,x => x
  | n+1,x => baseLabel p L n x.2.2

noncomputable def weight (p L : ℕ) [NeZero p] [NeZero L] (f : ℕ → ℝ) :
    (n : ℕ) → Level p L n → ℝ
  | 0,_ => f 0
  | n+1,x => extendWeight (weight p L f n) (reciprocalMean (1/(L:ℝ)) f n)
                 (f (n+1)) x.1 x.2.1 x.2.2

/-- Each descendant copies its base label. At every depth, not merely a fixed
test depth, the reciprocal-weight mean against any base label statistic factors. -/
theorem weight_moment (p L : ℕ) [NeZero p] [NeZero L] (f : ℕ → ℝ) (u : ZMod p → ℝ)
    (n : ℕ) : (∑ x : Level p L n, u (baseLabel p L n x)*weight p L f n x) =
      (∑ x : Level p L n, u (baseLabel p L n x)) * reciprocalMean (1/(L:ℝ)) f n := by
  induction n with
  | zero => exact (Finset.sum_mul ..).symm
  | succ n ih =>
    change (∑ x : ZMod p × (ZMod L × Level p L n), u (baseLabel p L n x.2.2) *
       extendWeight (weight p L f n) _ (f (n+1)) x.1 x.2.1 x.2.2) =
       (∑ x : ZMod p × (ZMod L × Level p L n), u (baseLabel p L n x.2.2)) * _
    simp only [Fintype.sum_prod_type]
    simp_rw [equal_child_mass _ _ _ _ ih]
    simp [nsmul_eq_mul,mean_eq_mix,reciprocalMean]; ring

end KDClosure
