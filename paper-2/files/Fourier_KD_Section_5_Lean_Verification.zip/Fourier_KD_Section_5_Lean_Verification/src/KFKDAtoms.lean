module
public import KFKDFrame
@[expose] public section
noncomputable section
set_option autoImplicit false
set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false
set_option linter.deprecated false
namespace KFS5KDAtoms
open KFS5KDOperator KFS5KDFourier KFS5KDPure KFS5KDPair KFS5KDFrame KFS5KDTransfer Matrix Classical
open scoped ComplexOrder ComplexConjugate MatrixOrder
variable {G I : Type*} [AddCommGroup G] [Fintype G] [DecidableEq G] [Fintype I]

def row (A : Op G) (x d : G) := A x (x+d)
theorem row_amp (A : Op G) (x : G) (k : AddChar G ℂ) : amp (row A x) k=symbol A x k := by
  change (∑ d, A x (x+d)*k d)=_
  simpa [symbol] using Equiv.sum_comp (Equiv.addLeft x) (fun y => A x y*k (y-x))

theorem row_unique (F : Frame G I) {u v : G→ℂ}
    (h : ∀ i, amp u (F.char i)=amp v (F.char i)) : u=v := by
  funext x
  apply mul_left_cancel₀ (a:=(Fintype.card G : ℂ)) (Nat.cast_ne_zero.mpr Fintype.card_ne_zero)
  rw [← reconstruct F,← reconstruct F]; simp only [h]

theorem symbol_injective (F : Frame G I) {A B : Op G}
    (he : ∀ x i, symbol A x (F.char i)=symbol B x (F.char i)) : A=B := by
  ext x y
  have hh : row A x=row B x := row_unique F (fun i => by simp [row_amp,he])
  simpa [row] using congrFun hh (y-x)

theorem char_conj (k : AddChar G ℂ) (x : G) : star (k x)= k (-x) := by
  rw [AddChar.map_neg_eq_inv]; exact (Complex.inv_eq_conj (k.norm_apply x)).symm

theorem hermitian_period (F : Frame G I) {A : Op G} (her : A.IsHermitian)
    (kd : ∀ x k, 0 ≤ symbol A x k) (d : G) :
    ∀ x, row A (x+d) d=row A x d := by
  have hsym (x : G) : (fun d => star (row A x (-d)))=row A x := by
    apply row_unique F; intro j
    let k := F.char j
    have hstar : star (amp (row A x) k)=amp (row A x) k := by
      rw [row_amp]; exact IsSelfAdjoint.of_nonneg (kd _ _)
    rw [← hstar]; unfold amp
    calc
      _ = ∑ y, star (row A x y)*k (-y) := by
        simpa [k] using Equiv.sum_comp (Equiv.neg G) (fun y => star (row A x y)*k (-y))
      _ = _ := by simp [star_sum,star_mul,char_conj,mul_comm]
  intro x
  have h := congrFun (hsym (x+d)) d
  change star (A (x+d) ((x+d)+ -d))=A (x+d) ((x+d)+d) at h
  simp [row, ← h,her.apply]

def v (U : AddSubgroup G) (a:G) (b:AddChar G ℂ) (x:G) : ℂ :=
  if x-a ∈ U then b (-x) else 0
def atom (U : AddSubgroup G) (a:G) (b:AddChar G ℂ) : Op G :=
  ((Fintype.card U:ℝ)⁻¹) • outer (v U a b)

theorem atom_symbol (U : AddSubgroup G) (a:G) (b:AddChar G ℂ) (x:G) (k:AddChar G ℂ) :
    symbol (atom U a b) x k = (tile U a b x k:ℂ) := by
  classical
  rw [atom,symbol_smul]
  let d := (k-b).compAddMonoidHom U.subtype
  have dz : d=0 ↔ ∀ h∈U,k h=b h := by
    constructor
    · intro h y hy
      have e := congrArg (fun t:AddChar U ℂ => t ⟨y,hy⟩) h
      change (k-b) y=1 at e
      rw [AddChar.sub_apply',div_eq_one_iff_eq (char_ne b y)] at e; exact e
    · intro h; ext y; change (k-b) y=1
      simp [AddChar.sub_apply',h _ y.property,char_ne]
  by_cases hx : x-a ∈ U
  · have eq : (∑ h:U,d h)=symbol (outer (v U a b)) x k := by
      apply Fintype.sum_of_injective (fun h:U => x+h.val)
        (fun {s t} e => Subtype.ext (add_left_cancel e))
      · intro y hy
        have hv : y-a ∉ U := fun e => hy ⟨⟨y-x,by simpa using U.sub_mem e hx⟩,by simp⟩
        simp [outer,v,hv]
      · intro h
        have hv : x+h.val-a ∈ U := by convert U.add_mem hx h.property using 1; abel
        change (k-b) h.val = star (v U a b x)*v U a b (x+h.val)*k ((x+h.val)-x)
        simp [v,hx,hv,char_conj,AddChar.map_add_eq_mul,AddChar.map_neg_eq_inv,
          AddChar.sub_apply',div_eq_mul_inv,char_ne,mul_assoc,mul_comm,mul_left_comm]
    rw [← eq,AddChar.sum_eq_ite]
    by_cases hd : d=0
    · have hh := dz.mp hd
      have et : tile U a b x k=1 := if_pos ⟨hx,hh⟩
      rw [et]; simp [hd,Fintype.card_ne_zero]
    · simp [hd,tile,hx,not_congr dz |>.mp hd]
  · simp [symbol_outer,v,hx,tile]

theorem atom_trace (U : AddSubgroup G) (a:G) (b:AddChar G ℂ) : (atom U a b).trace=1 := by
  classical
  have e : (∑ _h:U,(1:ℂ))=(outer (v U a b)).trace := by
    apply Fintype.sum_of_injective (fun h:U => a+h.val)
      (fun {s t} h => Subtype.ext (add_left_cancel h))
    · intro x hx; have hv : x-a ∉ U := fun h => hx ⟨⟨x-a,h⟩,by simp⟩
      simp [outer,v,hv]
    · intro h; change 1=star (v U a b (a+h.val))*v U a b (a+h.val)
      have ha : a+(h:G)-a ∈ U := by simp
      rw [v,if_pos ha,char_conj,neg_neg,AddChar.map_neg_eq_inv,mul_inv_cancel₀ (char_ne _ _)]
  simp [atom,trace_smul,← e,Complex.real_smul,Fintype.card_ne_zero]

theorem atom_pure (U : AddSubgroup G) (a:G) (b:AddChar G ℂ) : atom U a b ∈ pureSet G := by
  let c : ℝ := (Fintype.card U:ℝ)⁻¹
  have nc : 0≤c := by dsimp [c]; positivity
  refine ⟨fun x => (Real.sqrt c:ℂ)*v U a b x,?_,atom_trace _ _ _,?_⟩
  · ext x y; change (c:ℂ)*(star (v U a b x)*v U a b y)=_
    change _ = star ((Real.sqrt c:ℂ)*v U a b x)*((Real.sqrt c:ℂ)*v U a b y)
    have sq : (Real.sqrt c:ℂ)^2=(c:ℂ) := by exact_mod_cast Real.sq_sqrt nc
    simp only [star_mul,Complex.star_def,Complex.conj_ofReal]; linear_combination -(starRingEnd ℂ) (v U a b x)*v U a b y*sq
  · intro x k; rw [atom_symbol]; unfold tile; split <;> norm_num
end KFS5KDAtoms
#print axioms KFS5KDAtoms.hermitian_period
#print axioms KFS5KDAtoms.atom_pure
