module
public import Mathlib.Algebra.BigOperators.Field
public import Mathlib.Algebra.Field.ZMod
public import Mathlib.Algebra.Group.AddChar
public import Mathlib.Algebra.Module.ZMod
public import Mathlib.Algebra.Star.CHSH
public import Mathlib.Analysis.Convex.Hull
public import Mathlib.Analysis.Matrix.Order
public import Mathlib.Data.Complex.Basic
public import Mathlib.Data.Real.Basic
public import Mathlib.LinearAlgebra.Pi
public import Mathlib.Tactic.Abel
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring
@[expose] public section
set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false



set_option autoImplicit false
noncomputable section
namespace KFS5KD
abbrev Phase (P Q : Type*) := (P × Q) × (P × Q)
abbrev Obs (P Q : Type*) := Phase P Q → ℝ

def signs (a x b y : ℝ) := a*b+a*y+x*b-x*y
def target {P Q : Type*} [Zero P] [DecidableEq P] [Zero Q] [DecidableEq Q] : Obs P Q :=
  fun z => 3 - signs (if z.1.1 = 0 then 1 else -1) (if z.2.1 = 0 then 1 else -1)
      (if z.1.2 = 0 then 1 else -1) (if z.2.2 = 0 then 1 else -1)

theorem target_values {P Q : Type*} [Zero P] [DecidableEq P] [Zero Q] [DecidableEq Q]
    (z : Phase P Q) : target z = 1 ∨ target z = 5 := by
  simp only [target, signs]
  split <;> split <;> split <;> split <;> norm_num

def eps : Bool → ℝ | false => 1 | true => -1
def digit {P : Type*} [Zero P] [One P] : Bool → P | false => 0 | true => 1

def base {P Q : Type*} [Zero P] [One P] [Zero Q] [One Q] : Obs P Q →ₗ[ℝ] ℝ :=
  ∑ a : Bool, ∑ x : Bool, ∑ b : Bool, ∑ y : Bool,
    ((1+signs (eps a) (eps x) (eps b) (eps y))/16 : ℝ) •
      LinearMap.proj (R := ℝ) (φ := fun _ : Phase P Q => ℝ)
        ((digit a,digit b),(digit x,digit y))

def coord {P Q : Type*} (i j : Bool) (z : Phase P Q) : P × Q :=
  ((if i then z.2.1 else z.1.1), (if j then z.2.2 else z.1.2))

theorem base_chart {P Q : Type*} [Zero P] [One P] [Zero Q] [One Q]
    (i j : Bool) (f : P × Q → ℝ) :
    base (fun z => f (coord i j z)) =
    if i && j then (f (0,1) + f (1,0))/2 else (f (0,0) + f (1,1))/2 := by
  cases i <;> cases j <;> simp [base, coord, Fintype.sum_bool, eps, digit, signs, Finset.sum_apply,
    LinearMap.sum_apply, LinearMap.proj_apply] <;> ring

theorem base_chart_nonneg {P Q : Type*} [Zero P] [One P] [Zero Q] [One Q]
    (i j : Bool) (f : P × Q → ℝ) (hf : ∀ t, 0 ≤ f t) :
    0 ≤ base (fun z => f (coord i j z)) := by
  rw [base_chart]; split <;> exact div_nonneg (add_nonneg (hf _) (hf _)) (by norm_num)

theorem base_one {P Q : Type*} [Zero P] [One P] [Zero Q] [One Q] :
    base (P := P) (Q := Q) (fun _ => 1) = 1 := by
  simpa using base_chart (P := P) (Q := Q) false false (fun _ => (1:ℝ))

theorem base_target {P Q : Type*} [Zero P] [One P] [NeZero (1:P)] [DecidableEq P]
    [Zero Q] [One Q] [NeZero (1:Q)] [DecidableEq Q] :
    base (target (P := P) (Q := Q)) = -1 := by
  norm_num [base, target, Fintype.sum_bool, eps, digit, signs, LinearMap.sum_apply,
    LinearMap.proj_apply, NeZero.ne]

def testSign {P : Type*} [Zero P] [DecidableEq P] (x : P) : ℝ := if x=0 then 1 else -1

def corr {P Q : Type*} [Zero P] [DecidableEq P] [Zero Q] [DecidableEq Q] (i j : Bool) : Obs P Q :=
  fun z => testSign (coord i j z).1 * testSign (coord i j z).2

theorem target_eq {P Q : Type*} [Zero P] [DecidableEq P] [Zero Q] [DecidableEq Q] :
    target (P := P) (Q := Q) = (fun _ => (3:ℝ)) - corr false false - corr false true -
        corr true false + corr true true := by
  funext z; simp [target,corr,coord,testSign,signs]; ring

end KFS5KD

end


noncomputable section
set_option autoImplicit false
namespace KFS5KDGeometry
variable {K : Type*} [Field K] [Fintype K]

def mean (f : K → ℝ) : ℝ := (Fintype.card K : ℝ)⁻¹ * ∑ a, f a

theorem mean_const (c : ℝ) : mean (K := K) (fun _ => c) = c := by
  simp [mean, Fintype.card_ne_zero, nsmul_eq_mul, ← mul_assoc]

theorem mean_affine (a b : K) (ha : a ≠ 0) (f : K → ℝ) :
    mean (fun x => f (a*x+b)) = mean f := by
  let e : K ≃ K := (Equiv.mulLeft₀ a ha).trans (Equiv.addRight b)
  exact congrArg (fun t : ℝ => (Fintype.card K : ℝ)⁻¹ * t) (e.sum_comp f)

abbrev Plane (K : Type*) := (K × K) × (K × K)
def labels (s : K) (z : Plane K) : K × K := (z.1.2-s*z.1.1,z.2.1+s*z.2.2)
def sample (s i j u v : K) : Plane K := ((u,s*u+i),(j-s*v,v))

def avg (s : K) (f : Plane K → ℝ) (z : Plane K) : ℝ :=
  mean fun u => mean fun v => f (sample s (labels s z).1 (labels s z).2 u v)

theorem on_own (s : K) (f : K × K → ℝ) :
    avg s (fun z => f (labels s z)) = fun z => f (labels s z) := by
  funext z
  simp [avg,labels,sample,mean_const]

theorem on_other (s t : K) (h : s ≠ t) (f : K × K → ℝ) :
    avg s (fun z => f (labels t z)) = fun _ => mean fun u => mean fun v => f (u,v) := by
  funext z
  unfold avg
  have aux (u v : K) :
      labels t (sample s (labels s z).1 (labels s z).2 u v) =
      ((s-t)*u+(labels s z).1,(t-s)*v+(labels s z).2) := by
    apply Prod.ext <;> dsimp [labels,sample] <;> ring
  simp only [aux]
  change mean (fun u => mean (fun v => f ((s-t)*u+_,(t-s)*v+_))) = _
  have inner (u : K) := mean_affine (t-s) (labels s z).2 (sub_ne_zero.mpr h.symm)
    (fun v => f ((s-t)*u+(labels s z).1,v))
  exact (congrArg mean (funext inner)).trans <| mean_affine (s-t) (labels s z).1 (sub_ne_zero.mpr h) (fun x => mean fun y => f (x,y))

theorem on_xy (s : K) (f : K × K → ℝ) :
    avg s (fun z => f z.1) = fun z => mean fun u => f (u,s*u+(labels s z).1) := by
  funext z; simp [avg,sample,mean_const]

theorem on_kl (s : K) (f : K × K → ℝ) :
    avg s (fun z => f z.2) = fun z => mean fun v => f ((labels s z).2-s*v,v) := by
  funext z; simp [avg,sample,mean_const]

theorem on_xl (s : K) (f : K × K → ℝ) :
    avg s (fun z => f (z.1.1,z.2.2)) = fun _ => mean fun u => mean fun v => f (u,v) := rfl

theorem on_ky (s : K) (hs : s ≠ 0) (f : K × K → ℝ) :
    avg s (fun z => f (z.2.1,z.1.2)) = fun _ => mean fun y => mean fun k => f (k,y) := by
  funext z
  change mean (fun u => mean (fun v => f ((labels s z).2-s*v, s*u+(labels s z).1))) = _
  simp_rw [show ∀ v : K, (labels s z).2 - s*v = (-s)*v+(labels s z).2 by intro v; ring]
  have inner (u : K) := mean_affine (-s) (labels s z).2 (neg_ne_zero.mpr hs)
    (fun v => f (v,s*u+(labels s z).1))
  exact (congrArg mean (funext inner)).trans <| mean_affine s (labels s z).1 hs (fun y => mean fun x => f (x,y))

def meanL : (K → ℝ) →ₗ[ℝ] ℝ where
  toFun := mean
  map_add' f g := by simp [mean,Finset.sum_add_distrib,mul_add]
  map_smul' c f := by simp [mean, ← Finset.mul_sum]; ring

def avgL (s : K) : (Plane K → ℝ) →ₗ[ℝ] (Plane K → ℝ) where
  toFun := avg s
  map_add' f g := by
    funext z
    simp only [avg, Pi.add_apply]
    change meanL (fun u => meanL (_ + _)) = _ + _
    simp only [map_add]
    exact map_add meanL _ _
  map_smul' c f := by
    funext z
    change meanL (fun u => meanL (c • _)) = c * _
    simp only [map_smul]
    exact map_smul meanL _ _

end KFS5KDGeometry

end



noncomputable section
set_option autoImplicit false
namespace KFS5KDPlanes
variable {K : Type*} [Field K]
def row (s : K) : Submodule K (K × K) where
  carrier := {z | z.2 = s*z.1}
  zero_mem' := by simp
  add_mem' := by intro a b ha hb; change a.2+b.2=s*(a.1+b.1); rw [ha,hb,mul_add]
  smul_mem' := by intro c a ha; change c*a.2=s*(c*a.1); rw [ha]; ring
def vertical : Submodule K (K × K) where
  carrier := {z | z.1=0}
  zero_mem' := rfl
  add_mem' := by intro a b ha hb; change a.1+b.1=0; rw [ha,hb,zero_add]
  smul_mem' := by intro c a ha; change c*a.1=0; rw [ha,mul_zero]

theorem lines_exhaust (U : Submodule K (K × K)) :
    U = ⊥ ∨ U = ⊤ ∨ U = vertical ∨ ∃ s, U = row s := by
  classical
  by_cases hv : (0,1) ∈ U
  · have vert (y : K) : (0,y) ∈ U := by simpa using U.smul_mem y hv
    by_cases hh : ∃ z ∈ U, z.1 ≠ 0
    · obtain ⟨⟨a,b⟩,hz,ha⟩ := hh
      have h0 : (a,0) ∈ U := by simpa using U.sub_mem hz (vert b)
      right; left; apply top_unique
      rintro ⟨x,y⟩ _
      have hx : ((x/a)*a,0) ∈ U := by simpa using U.smul_mem (x/a) h0
      simpa [div_mul_cancel₀ x ha] using U.add_mem hx (vert y)
    · right; right; left; ext z
      constructor
      · intro hz; exact Classical.byContradiction (fun hn => hh ⟨z,hz,hn⟩)
      · rcases z with ⟨x,y⟩; intro hz; change x=0 at hz; simpa [hz] using vert y
  · have noVert (y : K) (h : (0,y) ∈ U) : y=0 := by
      by_contra hy; apply hv
      simpa [inv_mul_cancel₀ hy] using U.smul_mem y⁻¹ h
    by_cases hh : ∃ z ∈ U, z.1 ≠ 0
    · obtain ⟨⟨a,b⟩,hz,ha⟩ := hh
      let s := b/a
      have base : (1,s) ∈ U := by simpa [s,div_eq_inv_mul,inv_mul_cancel₀ ha] using U.smul_mem a⁻¹ hz
      have gen (x : K) : (x,s*x) ∈ U := by simpa [mul_comm x s] using U.smul_mem x base
      right; right; right; refine ⟨s,?_⟩
      ext ⟨x,y⟩
      change (x,y) ∈ U ↔ y=s*x
      constructor
      · intro h; apply sub_eq_zero.mp; apply noVert; simpa using U.sub_mem h (gen x)
      · rintro rfl; exact gen x
    · left; apply bot_unique; rintro ⟨x,y⟩ hz
      have hx : x=0 := Classical.byContradiction (fun hn => hh ⟨(x,y),hz,hn⟩)
      subst x
      have hy := noVert y hz
      simp [hy]

def dot (a b : K × K) := a.1*b.1+a.2*b.2

theorem annihilates_row (k : K × K) (s : K) :
    (∀ h ∈ row s, dot k h=0) ↔ k.1+s*k.2=0 := by
  constructor
  · intro ha; have hh : (1,s) ∈ row s := by change s=s*1; simp
    simpa [dot,mul_comm] using ha _ hh
  · intro h z hz; change z.2=s*z.1 at hz; simp only [dot,hz]; linear_combination z.1*h

theorem annihilates_vertical (k : K × K) :
    (∀ h ∈ vertical, dot k h=0) ↔ k.2=0 := by
  constructor
  · intro ha; have hh : ((0,1):K×K) ∈ vertical := rfl
    simpa [dot] using ha _ hh
  · intro hk z hz; change z.1=0 at hz; simp [dot,hz,hk]

theorem annihilates_top (k : K × K) :
    (∀ h ∈ (⊤ : Submodule K (K × K)), dot k h=0) ↔ k=0 := by
  constructor
  · intro ha
    apply Prod.ext
    · simpa [dot] using ha (1,0) trivial
    · simpa [dot] using ha (0,1) trivial
  · rintro rfl _ _; simp [dot]

end KFS5KDPlanes

end


noncomputable section
set_option autoImplicit false
namespace KFS5KD
open KFS5KDGeometry
variable {K : Type*} [Field K] [Fintype K] [DecidableEq K]

/-- Product of the original position and frequency marginals, supported at four points. -/
def independent : Obs K K →ₗ[ℝ] ℝ :=
  ∑ a : Bool, ∑ b : Bool, (1/4 : ℝ) •
    LinearMap.proj (R := ℝ) (φ := fun _ : Phase K K => ℝ)
      ((digit a,digit a),(digit b,digit (!b)))

theorem independent_nonneg (f : Obs K K) (hf : ∀ z, 0 ≤ f z) : 0 ≤ independent f := by
  simp only [independent,LinearMap.sum_apply,LinearMap.smul_apply,LinearMap.proj_apply,
    smul_eq_mul]
  exact Finset.sum_nonneg fun _ _ => Finset.sum_nonneg fun _ _ => mul_nonneg (by norm_num) (hf _)

theorem same_position (f : K × K → ℝ) :
    independent (fun z => f z.1) = base (fun z : Phase K K => f z.1) := by
  rw [show base (fun z : Phase K K => f z.1) = _ from base_chart false false f]
  simp [independent,Fintype.sum_bool,LinearMap.sum_apply,digit,LinearMap.proj_apply]; ring

theorem same_frequency (f : K × K → ℝ) :
    independent (fun z => f z.2) = base (fun z : Phase K K => f z.2) := by
  rw [show base (fun z : Phase K K => f z.2) = _ from base_chart true true f]
  simp [independent,Fintype.sum_bool,LinearMap.sum_apply,digit,LinearMap.proj_apply]; ring

theorem same_constant (c : ℝ) :
    independent (fun _ : Phase K K => c) = base (fun _ : Phase K K => c) :=
  same_position (fun _ => c)

def adjust (s : K) : Obs K K →ₗ[ℝ] ℝ := (independent - base).comp (avgL s)
theorem adjust_apply (s : K) (f : Obs K K) :
    adjust s f = independent (avg s f) - base (avg s f) := rfl
def witness : Obs K K →ₗ[ℝ] ℝ := base + ∑ s : {v : K // v ≠ 0}, adjust s.val

theorem adjust_coord (s : K) (hs : s ≠ 0) (i j : Bool) (f : K × K → ℝ) :
    adjust s (fun z => f (coord i j z)) = 0 := by
  rw [adjust_apply, sub_eq_zero]
  
  cases i <;> cases j
  · change independent (avg s (fun z => f z.1)) = base (avg s (fun z => f z.1))
    rw [on_xy]; exact same_position (K := K) (fun xy => mean (fun u => f (u,s*u+(xy.2-s*xy.1))))
  · change independent (avg s (fun z => f (z.1.1,z.2.2))) = base (avg s (fun z => f (z.1.1,z.2.2)))
    rw [on_xl]; exact same_constant _
  · change independent (avg s (fun z => f (z.2.1,z.1.2))) = base (avg s (fun z => f (z.2.1,z.1.2)))
    rw [on_ky s hs]; exact same_constant _
  · change independent (avg s (fun z => f z.2)) = base (avg s (fun z => f z.2))
    rw [on_kl]; exact same_frequency (K := K) (fun kl => mean (fun v => f (kl.1+s*kl.2-s*v,v)))

theorem witness_coord (i j : Bool) (f : K × K → ℝ) :
    witness (fun z => f (coord i j z)) = base (fun z : Phase K K => f (coord i j z)) := by
  simp only [witness,LinearMap.add_apply,LinearMap.sum_apply]
  rw [Finset.sum_eq_zero (fun s _ => adjust_coord s.val s.property i j f),add_zero]

theorem witness_line (t : K) (ht : t ≠ 0) (f : K × K → ℝ) :
    witness (fun z => f (labels t z)) = independent (fun z => f (labels t z)) := by
  classical
  let k : {v : K // v ≠ 0} := ⟨t,ht⟩
  have other (s : {v : K // v ≠ 0}) (h : s ≠ k) :
      adjust s.val (fun z => f (labels t z)) = 0 := by
    rw [adjust_apply]
    rw [on_other _ _ (fun he => h (Subtype.ext he))]
    exact sub_eq_zero.mpr (same_constant _)
  simp only [witness,LinearMap.add_apply,LinearMap.sum_apply]
  rw [Finset.sum_eq_single k (fun s _ h => other s h) (by simp)]
  rw [adjust_apply]
  change base (fun z : Phase K K => f (labels t z)) +
    (independent (avg t (fun z => f (labels t z))) - base (avg t (fun z => f (labels t z)))) = _
  rw [on_own]; ring

theorem witness_target : witness (target (P := K) (Q := K)) = -1 := by
  have hc (i j : Bool) : witness (corr (P := K) (Q := K) i j) = base (corr i j) :=
    witness_coord i j (fun a : K × K => testSign a.1 * testSign a.2)
  have h3 : witness (fun _ : Phase K K => (3:ℝ)) = base (fun _ : Phase K K => 3) :=
    witness_coord false false (fun _ => 3)
  rw [← base_target (P := K) (Q := K),target_eq]
  simp only [map_add,map_sub,hc,h3]

/-- Full classes of nonnegative functions, including their individual coset indicators. -/
def TileConeGenerators : Set (Obs K K) := {g |
  (∃ (i j : Bool) (f : K × K → ℝ), (∀ a, 0 ≤ f a) ∧ g = fun z => f (coord i j z)) ∨
  (∃ (s : K) (_ : s ≠ 0) (f : K × K → ℝ), (∀ a, 0 ≤ f a) ∧ g = fun z => f (labels s z))}

theorem all_tiles_nonneg {g : Obs K K} (hg : g ∈ TileConeGenerators) : 0 ≤ witness g := by
  rcases hg with ⟨i,j,f,h,rfl⟩ | ⟨s,hs,f,h,rfl⟩
  · rw [witness_coord]; exact base_chart_nonneg _ _ _ h
  · rw [witness_line _ hs]; exact independent_nonneg _ (fun z => h _)

theorem hull_separation {V : Type*} [AddCommGroup V] [Module ℝ V] (L : V →ₗ[ℝ] ℝ)
    (S : Set V) (h : ∀ v ∈ S, 0 ≤ L v) (v : V) (hv : L v < 0) :
    v ∉ convexHull ℝ S := by
  intro hm
  have hcv : Convex ℝ {x : V | 0 ≤ L x} :=
    (convex_Ici (0 : ℝ)).linear_preimage L
  exact (not_lt_of_ge (convexHull_min h hcv hm)) hv

/-- Separation against the four coordinate-context cones for arbitrary local labels. -/
theorem coordinate_separation {P Q : Type*} [Zero P] [One P] [NeZero (1:P)] [DecidableEq P]
    [Zero Q] [One Q] [NeZero (1:Q)] [DecidableEq Q] (c : ℝ) (hc : 0<c) :
    c • target (P := P) (Q := Q) ∉ convexHull ℝ
      {g : Obs P Q | ∃ (i j : Bool) (f : P × Q → ℝ), (∀ a, 0 ≤ f a) ∧ g = fun z => f (coord i j z)} := by
  apply hull_separation base
  · rintro _ ⟨i,j,f,h,rfl⟩; exact base_chart_nonneg i j f h
  · rw [map_smul,base_target,smul_eq_mul]; linarith

theorem equal_prime_separation (c : ℝ) (hc : 0 < c) :
    c • target (P := K) (Q := K) ∉ convexHull ℝ TileConeGenerators := by
  apply hull_separation witness _ (fun _ h => all_tiles_nonneg h)
  rw [map_smul,witness_target,smul_eq_mul]
  linarith

end KFS5KD

end


noncomputable section
set_option autoImplicit false
open KFS5KDGeometry KFS5KDPlanes
namespace KFS5KD
variable {K : Type*} [Field K] [Fintype K] [DecidableEq K]

/-- Indicator in position and frequency of a translate of U × U-perpendicular. -/
def cosetTile (U : Submodule K (K × K)) (a b : K × K) (z : Phase K K) : ℝ :=
  by classical
     exact if z.1-a ∈ U ∧ (∀ h ∈ U, dot (z.2-b) h=0) then 1 else 0

private def flag {α : Type*} [DecidableEq α] (a x : α) : ℝ := if x=a then 1 else 0
private theorem flag_pos {α : Type*} [DecidableEq α] (a x : α) : 0 ≤ flag a x := by
  unfold flag; split <;> norm_num

theorem cosetTile_mem (U : Submodule K (K × K)) (a b : K × K) :
    cosetTile U a b ∈ TileConeGenerators := by
  classical
  rcases lines_exhaust U with rfl | rfl | rfl | ⟨s,rfl⟩
  · left; refine ⟨false,false,flag a,flag_pos a,?_⟩
    funext z; simp [cosetTile,flag,coord,sub_eq_zero,dot]
  · left; refine ⟨true,true,flag b,flag_pos b,?_⟩
    funext z; unfold cosetTile; simp only [annihilates_top]; simp [flag,coord,sub_eq_zero]
  · left; refine ⟨false,true,flag (a.1,b.2),flag_pos _,?_⟩
    funext z; unfold cosetTile; simp only [annihilates_vertical]; simp [flag,coord,vertical,sub_eq_zero,Prod.ext_iff]
  · by_cases hs : s=0
    · subst s
      left; refine ⟨true,false,flag (b.1,a.2),flag_pos _,?_⟩
      funext z; unfold cosetTile; simp only [annihilates_row]; simp [flag,coord,row,sub_eq_zero,Prod.ext_iff,and_comm]
    · right
      refine ⟨s,hs,flag (a.2-s*a.1,b.1+s*b.2),flag_pos _,?_⟩
      funext z
      simp only [cosetTile,flag,labels,annihilates_row,Prod.ext_iff,Prod.fst_sub,Prod.snd_sub]
      congr 1
      apply propext
      change (z.1.2-a.2=s*(z.1.1-a.1) ∧ z.2.1-b.1+s*(z.2.2-b.2)=0) ↔ _
      constructor <;> rintro ⟨h₁,h₂⟩ <;> constructor
      all_goals first | linear_combination h₁ | linear_combination h₂

/-- All affine subgroup tiles, including every entangled/oblique line in characteristic two. -/
theorem outside_all_subspace_tiles (c : ℝ) (hc : 0<c) :
    c • target (P := K) (Q := K) ∉ convexHull ℝ
      {g | ∃ (U : Submodule K (K × K)) (a b : K × K), g=cosetTile U a b} := by
  apply hull_separation witness
  · rintro _ ⟨U,a,b,rfl⟩; exact all_tiles_nonneg (cosetTile_mem U a b)
  · rw [map_smul,witness_target,smul_eq_mul]; linarith

end KFS5KD

end

set_option autoImplicit false
namespace KFS5KDPrimeAxes

theorem field_subgroups (p : ℕ) [Fact p.Prime] (U : AddSubgroup (ZMod p)) :
    U=⊥ ∨ U=⊤ := by
  classical
  by_cases h : ∃ a ∈ U, a ≠ 0
  · obtain ⟨a,ha,hn⟩ := h
    right; apply top_unique; intro x _
    have hmem := ZMod.smul_mem (K := U) ha (x/a)
    simpa [smul_eq_mul,div_mul_cancel₀ _ hn] using hmem
  · left; apply bot_unique; intro x hx
    exact Classical.byContradiction (fun hn => h ⟨x,hx,hn⟩)

theorem independent_factors {p q : ℕ} [hp : Fact p.Prime] [hq : Fact q.Prime]
    (hne : p ≠ q) (U : AddSubgroup (ZMod p × ZMod q)) :
    ∃ (A : AddSubgroup (ZMod p)) (B : AddSubgroup (ZMod q)),
      U=A.prod B ∧ (A=⊥ ∨ A=⊤) ∧ (B=⊥ ∨ B=⊤) := by
  let A := U.comap (AddMonoidHom.inl (ZMod p) (ZMod q))
  let B := U.comap (AddMonoidHom.inr (ZMod p) (ZMod q))
  refine ⟨A,B,?_,field_subgroups p A,field_subgroups q B⟩
  have hqp : (q : ZMod p) ≠ 0 := by
    intro h
    exact hne (((Nat.dvd_prime hq.out).mp ((ZMod.natCast_eq_zero_iff q p).mp h)).resolve_left hp.out.ne_one)
  ext z
  change z ∈ U ↔ (z.1,0) ∈ U ∧ (0,z.2) ∈ U
  obtain ⟨x,y⟩ := z
  constructor
  · intro hz
    have hqmem : ((q : ZMod p)*x, (0:ZMod q)) ∈ U := by
      simpa [nsmul_eq_mul] using U.nsmul_mem hz q
    have hx : (x, (0:ZMod q)) ∈ U := by
      simpa [nsmul_eq_mul,← mul_assoc,inv_mul_cancel₀ hqp] using
        U.nsmul_mem hqmem ((q:ZMod p)⁻¹).val
    exact ⟨hx,by simpa using U.sub_mem hz hx⟩
  · rintro ⟨hx,hy⟩; simpa using U.add_mem hx hy
end KFS5KDPrimeAxes



noncomputable section
set_option autoImplicit false
open scoped MatrixOrder ComplexOrder Kronecker
open Matrix

namespace KFS5KDOperator
abbrev Op (P : Type*) := Matrix P P ℂ

variable {P Q : Type*} [Fintype P] [DecidableEq P] [Fintype Q] [DecidableEq Q]

def atZero [Zero P] : Op P := diagonal fun x => if x=0 then 1 else 0
def flat : Op P := of fun _ _ => (Fintype.card P : ℂ)⁻¹
def reflect (p : Op P) : Op P := p+p-1

theorem atZero_idem [Zero P] : (atZero (P := P)) * atZero = atZero := by
  simp [atZero,diagonal_mul_diagonal,ite_mul]

theorem flat_idem [Nonempty P] : flat (P := P) * flat = flat := by
  ext i j
  simp [flat,mul_apply,nsmul_eq_mul,← mul_assoc,Fintype.card_ne_zero]

theorem atZero_sa [Zero P] : star (atZero (P := P)) = atZero := by
  ext i j
  by_cases h : i=j
  · subst j; by_cases h : i=0 <;> simp [atZero,diagonal_apply,h]
  · simp [atZero,diagonal_apply,h,Ne.symm h]

theorem flat_sa : star (flat (P := P)) = flat := by
  ext i j; simp [star_eq_conjTranspose,conjTranspose_apply,flat]

theorem reflect_inv (p : Op P) (h : p*p=p) : reflect p ^ 2 = 1 := by
  unfold reflect
  simp only [sq,sub_mul,mul_sub,add_mul,mul_add,h,one_mul,mul_one]
  abel

theorem reflect_sa (p : Op P) (h : star p=p) : star (reflect p) = reflect p := by
  simp [reflect,h]

def expr (a x b y : Op P) : Op P := a*b+a*y+x*b-x*y

theorem lifted_tuple (a x : Op P) (b y : Op Q)
    (ha : a^2=1) (hx : x^2=1) (hb : b^2=1) (hy : y^2=1)
    (sa : star a=a) (sx : star x=x) (sb : star b=b) (sy : star y=y) :
    IsCHSHTuple (a ⊗ₖ (1 : Op Q)) (x ⊗ₖ (1 : Op Q)) ((1 : Op P) ⊗ₖ b) ((1 : Op P) ⊗ₖ y) := by
  change aᴴ = a at sa
  change xᴴ = x at sx
  change bᴴ = b at sb
  change yᴴ = y at sy
  rw [sq] at ha hx hb hy
  constructor <;> simp [Matrix.star_eq_conjTranspose,sq,← mul_kronecker_mul,one_kronecker_one,
    ha,hx,hb,hy,conjTranspose_kronecker,sa,sx,sb,sy]

def bell [Zero P] [Zero Q] : Op (P × Q) :=
  (reflect (atZero : Op P)) ⊗ₖ (reflect (atZero : Op Q)) +
  (reflect (atZero : Op P)) ⊗ₖ (reflect (flat : Op Q)) +
  (reflect (flat : Op P)) ⊗ₖ (reflect (atZero : Op Q)) -
  (reflect (flat : Op P)) ⊗ₖ (reflect (flat : Op Q))
def W [Zero P] [Zero Q] : Op (P × Q) := (3 : ℝ) • 1 - bell

theorem W_posDef [Zero P] [Zero Q] : (W (P := P) (Q := Q)).PosDef := by
  have h := lifted_tuple (reflect (atZero : Op P)) (reflect flat)
    (reflect (atZero : Op Q)) (reflect flat) (reflect_inv _ atZero_idem)
    (reflect_inv _ flat_idem) (reflect_inv _ atZero_idem) (reflect_inv _ flat_idem)
    (reflect_sa _ atZero_sa) (reflect_sa _ flat_sa) (reflect_sa _ atZero_sa) (reflect_sa _ flat_sa)
  have hb : bell (P := P) (Q := Q) ≤ (Real.sqrt 2)^3 • (1 : Op (P × Q)) := by
    simpa only [bell,← mul_kronecker_mul,one_mul,mul_one] using tsirelson_inequality _ _ _ _ h
  have gap : 0 < 3-(Real.sqrt 2)^3 := by
    have hsq := Real.sq_sqrt (show (0:ℝ) ≤ 2 by norm_num)
    nlinarith [Real.sqrt_nonneg 2, sq_nonneg (Real.sqrt 2 - 3/2), show (Real.sqrt 2)^3=2*Real.sqrt 2 by rw [pow_succ,hsq]]
  have pos := (PosDef.one (n := P × Q) (R := ℂ)).smul gap
  have eqn : W (P := P) (Q := Q) =
      (3-(Real.sqrt 2)^3) • (1 : Op (P × Q)) + ((Real.sqrt 2)^3 • 1 - bell) := by
    simp only [W,sub_smul]; abel
  rw [eqn]
  exact pos.add_posSemidef (Matrix.le_iff.mp hb)

end KFS5KDOperator

end


noncomputable section
set_option autoImplicit false
open scoped MatrixOrder ComplexOrder Kronecker
open Matrix KFS5KDOperator

namespace KFS5KDFourier
variable {G H : Type*} [AddCommGroup G] [Fintype G] [DecidableEq G]
  [AddCommGroup H] [Fintype H] [DecidableEq H]

/-- The scaled lower KFS5KD distribution, written with the unnormalized character. -/
def symbol (A : Op G) (x : G) (χ : AddChar G ℂ) : ℂ := ∑ y, A x y * χ (y-x)

def pairChar (a : AddChar G ℂ) (b : AddChar H ℂ) : AddChar (G × H) ℂ where
  toFun z := a z.1 * b z.2
  map_zero_eq_one' := by simp
  map_add_eq_mul' x y := by simp [AddChar.map_add_eq_mul]; ring

theorem symbol_add (A B : Op G) (x : G) (χ : AddChar G ℂ) :
    symbol (A+B) x χ = symbol A x χ + symbol B x χ := by
  simp [symbol,add_mul,Finset.sum_add_distrib]
theorem symbol_sub (A B : Op G) (x : G) (χ : AddChar G ℂ) :
    symbol (A-B) x χ = symbol A x χ - symbol B x χ := by
  simp [symbol,sub_mul,Finset.sum_sub_distrib]
theorem symbol_smul (r : ℝ) (A : Op G) (x : G) (χ : AddChar G ℂ) :
    symbol (r • A) x χ = (r : ℂ) * symbol A x χ := by
  simp [symbol,Complex.real_smul,Finset.mul_sum,mul_assoc]
theorem symbol_one (x : G) (χ : AddChar G ℂ) : symbol 1 x χ = 1 := by
  classical
  simp [symbol,one_apply,ite_mul]

theorem symbol_atZero (x : G) (χ : AddChar G ℂ) :
    symbol (atZero : Op G) x χ = if x=0 then 1 else 0 := by
  classical
  simp [symbol,atZero,diagonal_apply,ite_mul]

theorem symbol_flat (x : G) (χ : AddChar G ℂ) :
    symbol (flat : Op G) x χ = if χ=0 then 1 else 0 := by
  classical
  change (∑ y : G, (Fintype.card G : ℂ)⁻¹ * χ (y-x)) = _
  rw [← Finset.mul_sum]
  have hh : (∑ y, χ (y-x)) = ∑ y, χ y :=
    (Equiv.subRight x).sum_comp (fun y => χ y)
  rw [hh,AddChar.sum_eq_ite]
  split_ifs <;> simp [Fintype.card_ne_zero]

theorem symbol_tensor (A : Op G) (B : Op H) (x : G) (y : H) (χ : AddChar G ℂ) (ψ : AddChar H ℂ) :
    symbol (A ⊗ₖ B) (x,y) (pairChar χ ψ) = symbol A x χ * symbol B y ψ := by
  simp only [symbol,Fintype.sum_prod_type,kronecker_apply,pairChar,Prod.fst_sub,Prod.snd_sub]
  rw [Finset.sum_mul]
  apply Finset.sum_congr rfl; intro a _
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl; intro b _
  change A x a * B y b * (χ (a-x) * ψ (b-y)) = _
  ring

def sign (b : Prop) [Decidable b] : ℂ := if b then 1 else -1

theorem symbol_z (x : G) (χ : AddChar G ℂ) :
    symbol (reflect (atZero : Op G)) x χ = sign (x=0) := by
  rw [reflect,symbol_sub,symbol_add,symbol_atZero,symbol_one]
  by_cases h : x=0 <;> simp [sign,h]
theorem symbol_x (x : G) (χ : AddChar G ℂ) [Decidable (χ = 0)] :
    symbol (reflect (flat : Op G)) x χ = sign (χ=0) := by
  classical
  rw [reflect,symbol_sub,symbol_add,symbol_flat,symbol_one]
  by_cases h : χ=0 <;> simp [sign,h]

theorem W_symbol (x : G) (y : H) (χ : AddChar G ℂ) (ψ : AddChar H ℂ)
    [Decidable (χ=0)] [Decidable (ψ=0)] :
    symbol W (x,y) (pairChar χ ψ) =
      3-(sign (x=0)*sign (y=0)+sign (x=0)*sign (ψ=0)+sign (χ=0)*sign (y=0)-sign (χ=0)*sign (ψ=0)) := by
  simp only [W,bell,symbol_sub,symbol_add,symbol_smul,symbol_one,symbol_tensor,symbol_z,symbol_x]
  push_cast; ring

end KFS5KDFourier

end

noncomputable section
set_option autoImplicit false
namespace KFS5KDState
open KFS5KD KFS5KDOperator KFS5KDFourier Matrix
open scoped MatrixOrder ComplexOrder
variable {P Q : Type*} [AddCommGroup P] [Fintype P] [DecidableEq P]
  [AddCommGroup Q] [Fintype Q] [DecidableEq Q]
def scale : ℝ := ((W (P := P) (Q := Q)).trace.re)⁻¹
def rho : Op (P × Q) := scale (P := P) (Q := Q) • W
theorem scale_pos : 0 < scale (P := P) (Q := Q) :=
  inv_pos.mpr ((Complex.pos_iff.mp (W_posDef (P := P) (Q := Q)).trace_pos).1)
theorem rho_posDef : (rho (P := P) (Q := Q)).PosDef :=
  W_posDef.smul scale_pos
theorem rho_trace : (rho (P := P) (Q := Q)).trace = 1 := by
  have h := Complex.pos_iff.mp (W_posDef (P := P) (Q := Q)).trace_pos
  have e : (W (P := P) (Q := Q)).trace = ((W (P := P) (Q := Q)).trace.re : ℂ) :=
    Complex.ext rfl (by simpa using h.2.symm)
  rw [rho,Matrix.trace_smul,scale,Complex.real_smul,e]
  simp [ne_of_gt h.1]

/-- Pair characters exhaust the character group of the product. -/
theorem factor_char (γ : AddChar (P × Q) ℂ) :
    ∃ a b, γ = pairChar a b := by
  let a := γ.compAddMonoidHom (AddMonoidHom.inl P Q)
  let b := γ.compAddMonoidHom (AddMonoidHom.inr P Q)
  refine ⟨a,b,?_⟩; ext z
  change γ z = γ (z.1,0) * γ (0,z.2)
  rw [← AddChar.map_add_eq_mul]; simp

theorem rho_all_KD_positive (x : P × Q) (γ : AddChar (P × Q) ℂ) :
    0 < symbol (rho (P := P) (Q := Q)) x γ := by
  classical
  rcases x with ⟨x,y⟩; obtain ⟨a,b,rfl⟩ := factor_char γ
  rw [rho,symbol_smul,W_symbol]
  have h : 0 < ((scale (P := P) (Q := Q) : ℝ) : ℂ) := Complex.zero_lt_real.mpr scale_pos
  apply mul_pos h
  unfold sign
  split <;> split <;> split <;> split <;> norm_num

theorem symbol_as_target [One P] [One Q] (fp : P ≃+ AddChar P ℂ) (fq : Q ≃+ AddChar Q ℂ)
    (z : Phase P Q) :
    (symbol rho z.1 (pairChar (fp z.2.1) (fq z.2.2))).re =
    scale (P := P) (Q := Q) * KFS5KD.target z := by
  classical
  rcases z with ⟨⟨x,y⟩,k,l⟩
  rw [rho,symbol_smul,W_symbol]
  have hp0 : fp k=0 ↔ k=0 := by rw [← fp.map_zero,fp.injective.eq_iff]
  have hq0 : fq l=0 ↔ l=0 := by rw [← fq.map_zero,fq.injective.eq_iff]
  by_cases h₁ : x = 0 <;> by_cases h₂ : y = 0 <;> by_cases h₃ : k=0 <;> by_cases h₄ : l=0 <;>
    norm_num [sign,KFS5KD.target,KFS5KD.signs,hp0,hq0,h₁,h₂,h₃,h₄,Complex.re_ofReal_mul]

/-- Exact original matrix, positive trace-one and strictly positive Fourier symbol for every character,
    with a symbol outside the hull of subgroup tiles in the plane. -/
theorem Fourier_plane_certificate {K : Type*} [Field K] [Fintype K] [DecidableEq K]
    (e : K ≃+ AddChar K ℂ) :
    (rho (P := K) (Q := K)).PosDef ∧ (rho (P := K) (Q := K)).trace = 1 ∧
    (∀ x γ, 0 < symbol (rho (P := K) (Q := K)) x γ) ∧
    (fun z : Phase K K => (symbol rho z.1 (pairChar (e z.2.1) (e z.2.2))).re) ∉
      convexHull ℝ {g | ∃ (U : Submodule K (K × K)) (a b : K × K), g=cosetTile U a b} := by
  refine ⟨rho_posDef,rho_trace,rho_all_KD_positive,?_⟩
  have hh : (fun z : Phase K K => (symbol rho z.1 (pairChar (e z.2.1) (e z.2.2))).re) =
      scale (P := K) (Q := K) • KFS5KD.target := by
    funext z; exact symbol_as_target e e z
  rw [hh]; exact outside_all_subspace_tiles _ scale_pos

end KFS5KDState

end

#print axioms KFS5KD.witness_line
#print axioms KFS5KD.witness_target
#print axioms KFS5KD.all_tiles_nonneg
#print axioms KFS5KD.equal_prime_separation
#print axioms KFS5KD.coordinate_separation
#print axioms KFS5KD.outside_all_subspace_tiles
#print axioms KFS5KDPrimeAxes.independent_factors
#print axioms KFS5KDOperator.W_posDef
#print axioms KFS5KDFourier.W_symbol
#print axioms KFS5KDState.rho_trace
#print axioms KFS5KDState.rho_all_KD_positive
#print axioms KFS5KDState.Fourier_plane_certificate
