module
public import KFKDRank
@[expose] public section
noncomputable section
set_option autoImplicit false
set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false
namespace KFS5KDBasis
open KFS5KDOperator KFS5KDFourier KFS5KDAtoms KFS5KDRank KFS5KDTransfer KFS5KDGroup Matrix Classical
open scoped ComplexOrder MatrixOrder
variable {G : Type*} [AddCommGroup G] [Fintype G] [DecidableEq G]
def normFactor (G : Type*) [Fintype G] : ℝ := (Real.sqrt (Fintype.card G))⁻¹
def ket (k : AddChar G ℂ) (x : G) : ℂ := (normFactor G:ℂ)*k x
/-- The lower KFS5KD formula <k|x><x|A|k> using the normalized Fourier vector. -/
def lower (A : Op G) (x:G) (k:AddChar G ℂ) : ℂ := star (ket k x)*(A *ᵥ ket k) x

theorem factor (G : Type*) [Fintype G] [Nonempty G] :
    (Fintype.card G : ℂ)*(normFactor G:ℂ)^2=1 := by
  norm_cast
  have h : 0 < (Fintype.card G : ℝ) := Nat.cast_pos.mpr Fintype.card_pos
  simp [normFactor,inv_pow,Real.sq_sqrt h.le,ne_of_gt h]

theorem paper_symbol (A : Op G) (x:G) (k:AddChar G ℂ) :
    (Fintype.card G:ℂ)*lower A x k=symbol A x k := by
  simp only [lower,ket,Matrix.mulVec,dotProduct,star_mul,Complex.star_def,Complex.conj_ofReal]
  rw [Finset.mul_sum,Finset.mul_sum]
  apply Finset.sum_congr rfl; intro y _
  have conj : (starRingEnd ℂ) (k x)=k (-x) := char_conj k x
  rw [conj,sub_eq_add_neg,AddChar.map_add_eq_mul]
  linear_combination A x y*k y*k (-x)*factor G

theorem same_positivity (A : Op G) (x:G) (k:AddChar G ℂ) :
    0 ≤ lower A x k ↔ 0 ≤ symbol A x k := by
  rw [← paper_symbol]
  have h : (0:ℂ) < Fintype.card G := Complex.zero_lt_real.mpr (Nat.cast_pos.mpr Fintype.card_pos)
  constructor
  · exact mul_nonneg h.le
  · intro hh
    have := mul_nonneg (inv_pos.mpr h).le hh
    simpa [← mul_assoc,ne_of_gt h] using this

def paperStates (G : Type*) [AddCommGroup G] [Fintype G] [DecidableEq G] : Set (Op G) :=
  {A | A.PosSemidef ∧ A.trace=1 ∧ ∀ x k, 0≤lower A x k}

theorem states_eq : paperStates G=states G := by
  ext A; simp only [paperStates,states,Set.mem_ofPred_eq,same_positivity]

/-- Manuscript statement with the normalized Fourier matrix elements and the literal matrix rank. -/
theorem paper_classification (G : Type*) [AddCommGroup G] [Fintype G] [DecidableEq G] :
    paperStates G=convexHull ℝ {A : Op G | A ∈ paperStates G ∧ A.rank=1} ↔ exceptional G := by
  rw [states_eq]; exact classification G
theorem paper_strict_converse (hn : ¬ exceptional G) :
    ∃ A : Op G, A.PosDef ∧ A.trace=1 ∧ (∀ x k, 0 < lower A x k) ∧
      A ∉ convexHull ℝ {B : Op G | B ∈ paperStates G ∧ B.rank=1} := by
  obtain ⟨A,hd,ht,hk,hs⟩ := strict_converse hn
  refine ⟨A,hd,ht,?_,?_⟩
  · intro x k
    have hc : (0:ℂ)<Fintype.card G := Complex.zero_lt_real.mpr (Nat.cast_pos.mpr Fintype.card_pos)
    have hp := mul_pos (inv_pos.mpr hc) (hk x k)
    rw [← paper_symbol] at hp
    simpa [← mul_assoc,ne_of_gt hc] using hp
  · rw [states_eq]; exact hs
end KFS5KDBasis
#print axioms KFS5KDBasis.paper_symbol
#print axioms KFS5KDBasis.paper_classification
#print axioms KFS5KDBasis.paper_strict_converse
