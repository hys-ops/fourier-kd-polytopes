module
public import KFKDAtoms
@[expose] public section
noncomputable section
set_option autoImplicit false
set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false
set_option linter.deprecated false
namespace KFS5KDChain
open KFS5KDOperator KFS5KDFourier KFS5KDPure KFS5KDPair KFS5KDAtoms KFS5KDTransfer Matrix Classical
open scoped ComplexOrder MatrixOrder
universe u v
variable {G : Type u} {I : Type v} [AddCommGroup G] [Fintype G] [DecidableEq G] [Fintype I]
abbrev Arr (G I : Type*) := G × I → ℝ
def rel (F : Frame G I) (H : AddSubgroup G) (z t : G×I) :=
  z.1-t.1 ∈ H ∧ ∀ h ∈ H,F.char z.2 h=F.char t.2 h
def eqv (F : Frame G I) (H : AddSubgroup G) : Setoid (G×I) where
  r := rel F H
  iseqv := {
    refl := fun z => ⟨by simp,fun _ _ => rfl⟩
    symm := fun ⟨hp,hk⟩ => ⟨by simpa using H.neg_mem hp,fun x h => (hk x h).symm⟩
    trans := fun ⟨h₁,k₁⟩ ⟨h₂,k₂⟩ => ⟨by simpa using H.add_mem h₁ h₂,fun x h => (k₁ x h).trans (k₂ x h)⟩ }
def Adapt (F : Frame G I) (H : AddSubgroup G) (f : Arr G I) :=
  ∀ z t, rel F H z t → f z=f t

def Cert (F : Frame G I) (f : Arr G I) := ∃ (T : Type (max u v)) (_ : Fintype T)
    (w : T → ℝ) (P : T → Op G), (∀ i, 0 ≤ w i) ∧ (∀ i, P i ∈ pureSet G) ∧
    ∀ z : G×I, (f z : ℂ)=∑ i, (w i:ℂ)*symbol (P i) z.1 (F.char z.2)

theorem ofAdapt (F : Frame G I) (H : AddSubgroup G) {f : Arr G I} (ha : Adapt F H f)
    (hn : ∀ z, 0 ≤ f z) : Cert F f := by
  let R := eqv F H
  let T := Quotient R
  let : Fintype T := Fintype.ofFinite _
  refine ⟨T,inferInstance,fun t => f t.out,fun t => atom H t.out.1 (F.char t.out.2),
    fun _ => hn _,fun _ => atom_pure _ _ _,?_⟩
  intro z; let t : T := Quotient.mk R z
  have iff (s:T) : rel F H z s.out ↔ s=t := by
    change (R.r z s.out) ↔ _
    rw [← Quotient.eq,Quotient.out_eq,eq_comm]
  have he := ha z t.out ((iff t).mpr rfl)
  simp_rw [atom_symbol]
  rw [Finset.sum_eq_single t]
  · have one : tile H t.out.1 (F.char t.out.2) z.1 (F.char z.2)=1 := if_pos ((iff t).mpr rfl)
    simp [he,one]
  · intro i _ hh
    have zero : tile H i.out.1 (F.char i.out.2) z.1 (F.char z.2)=0 := if_neg (fun h => hh ((iff i).mp h))
    simp [zero]
  · simp

theorem cert_add (F : Frame G I) {a b : Arr G I} (ca : Cert F a) (cb : Cert F b) :
    Cert F (a+b) := by
  obtain ⟨S,_,w,P,hw,hP,h₁⟩ := ca
  obtain ⟨T,_,v,Q,hv,hQ,h₂⟩ := cb
  refine ⟨S⊕T,inferInstance,Sum.elim w v,Sum.elim P Q,by rintro (i|i); exact hw i; exact hv i,
    by rintro (i|i); exact hP i; exact hQ i,?_⟩
  intro z; simp [Fintype.sum_sum_type,h₁,h₂]

/-- The minimum over the position coset of K; no arbitrary minimizer is used in its value. -/
def lo (K : AddSubgroup G) (f : Arr G I) (z : G×I) : ℝ :=
  (Finset.univ : Finset K).inf' Finset.univ_nonempty (fun h => f (z.1+h.val,z.2))

theorem lo_le (K : AddSubgroup G) (f : Arr G I) (z : G×I) (h:K) :
    lo K f z ≤ f (z.1+h.val,z.2) := Finset.inf'_le _ (Finset.mem_univ h)
theorem lo_at (K : AddSubgroup G) (f : Arr G I) (z : G×I) :
    ∃ h : K, lo K f z=f (z.1+h.val,z.2) := by
  obtain ⟨h,_,hh⟩ := Finset.exists_mem_eq_inf' Finset.univ_nonempty (fun h:K => f (z.1+h.val,z.2))
  exact ⟨h,hh⟩

theorem lo_same (F : Frame G I) {H K : AddSubgroup G} {f : Arr G I} (ha : Adapt F H f)
    {z t : G×I} (hp : z.1-t.1 ∈ K) (hk : ∀ h ∈ H,F.char z.2 h=F.char t.2 h) :
    lo K f z=lo K f t := by
  have le {b c : G×I} (hp : b.1-c.1 ∈ K)
      (hk : ∀ h ∈ H,F.char b.2 h=F.char c.2 h) : lo K f b ≤ lo K f c := by
    obtain ⟨h,eq⟩ := lo_at K f c
    let h' : K := ⟨h.val-(b.1-c.1),K.sub_mem h.property hp⟩
    calc
      _ ≤ f (b.1+h'.val,b.2) := lo_le K f b h'
      _ = f (c.1+h.val,c.2) := ha _ _ ⟨by dsimp [h']; convert H.zero_mem using 1; abel,hk⟩
      _ = _ := eq.symm
  exact le_antisymm (le hp hk) (le (by simpa using K.neg_mem hp) (fun h hh => (hk h hh).symm))

theorem peel (F : Frame G I) {H K : AddSubgroup G} (hHK : H≤K) {a b : Arr G I}
    (ha : Adapt F H a) (hb : Adapt F K b) :
    Adapt F H (a-lo K a) ∧ Adapt F K (lo K a+b) ∧ ∀ z, 0 ≤ (a-lo K a) z := by
  refine ⟨?_,?_,?_⟩
  · intro z t h; exact congrArg₂ Sub.sub (ha _ _ h) (lo_same F ha (hHK h.1) h.2)
  · intro z t h; exact congrArg₂ HAdd.hAdd (lo_same F ha h.1 (fun x hx => h.2 x (hHK hx))) (hb _ _ h)
  · intro z; exact sub_nonneg.mpr (by simpa using lo_le K a z 0)

def layerSum (s : List (AddSubgroup G × Arr G I)) : Arr G I := (s.map Prod.snd).sum

theorem value_sum {α : Type*} (s : List α) (g : α → Arr G I) (z : G×I) :
    ((s.map g).sum) z=(s.map (fun a => g a z)).sum := by
  induction s with
  | nil => rfl
  | cons a s ih => simp [ih]

theorem layers (F : Frame G I) (s : List (AddSubgroup G × Arr G I))
    (chain : s.Pairwise (fun a b => a.1≤b.1))
    (adapt : ∀ t∈s, Adapt F t.1 t.2) (nonneg : ∀ z, 0≤layerSum s z) : Cert F (layerSum s) := by
  match s with
  | [] => exact ofAdapt F ⊥ (fun _ _ _ => rfl) nonneg
  | [a] => simpa [layerSum] using ofAdapt F a.1 (adapt a (by simp)) (by simpa [layerSum] using nonneg)
  | a::b::tail =>
    let m := lo b.1 a.2
    let b' : AddSubgroup G × Arr G I := (b.1,m+b.2)
    have hf := List.pairwise_cons.mp chain
    have hg := List.pairwise_cons.mp hf.2
    obtain ⟨ph,pk,pz⟩ := peel F (hf.1 b (by simp)) (adapt a (by simp)) (adapt b (by simp))
    have ct := ofAdapt F a.1 ph pz
    have ch' : (b'::tail).Pairwise (fun u v => u.1≤v.1) := List.pairwise_cons.mpr hg
    have ad' : ∀ t∈b'::tail, Adapt F t.1 t.2 := by
      intro t ht; rcases List.mem_cons.mp ht with rfl|h
      · exact pk
      · exact adapt _ (by simp [h])
    have nn' (z : G×I) : 0 ≤ layerSum (b'::tail) z := by
      obtain ⟨h,he⟩ := lo_at b.1 a.2 z
      let t : G×I := (z.1+h.val,z.2)
      have same (c : AddSubgroup G × Arr G I) (hc : c∈b::tail) : c.2 t=c.2 z := by
        apply adapt c (by simp [hc]); refine ⟨?_, fun _ _ => rfl⟩
        have le : b.1≤c.1 := by rcases List.mem_cons.mp hc with rfl|h'; exact le_rfl; exact hg.1 _ h'
        apply le; simp [t]
      have sm : layerSum tail t=layerSum tail z := by
        simp only [layerSum,value_sum]
        apply congrArg List.sum; apply List.map_congr_left
        intro c hc; exact same c (List.mem_cons_of_mem _ hc)
      have hnn := nonneg t
      change 0 ≤ a.2 t + (b.2 t + layerSum tail t) at hnn
      change 0 ≤ (lo b.1 a.2 z + b.2 z) + layerSum tail z
      rw [sm,same b (by simp)] at hnn
      rw [he,add_assoc]; exact hnn
    have smaller :=  layers F (b'::tail) ch' ad' nn'
    convert cert_add F ct smaller using 1
    funext z; simp [layerSum,b',m]; abel
termination_by s.length
decreasing_by simp_wf
end KFS5KDChain
#print axioms KFS5KDChain.layers
