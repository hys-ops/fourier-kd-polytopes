module
public import KFKDNegative
public import KFKDCyclic
public import KDCyclicCompat
@[expose] public section
noncomputable section
set_option autoImplicit false
set_option linter.unusedSectionVars false
namespace KFS5KDClassification
open KFS5KDGroup KFS5KDNegative KFS5KDOperator KFS5KDFourier KFS5KDPair KFS5KDPure KFS5KDFrame KFS5KDCyclic KFS5KDTransfer Matrix
open scoped ComplexOrder MatrixOrder
variable (G : Type*) [AddCommGroup G] [Fintype G] [DecidableEq G]

theorem hasFrame : Nonempty (Frame G G) := by
  classical
  obtain ⟨ι,_,p,hp,e,⟨iso⟩⟩ := AddCommGroup.equiv_directSum_zmod_of_finite G
  let (i:ι) : NeZero (p i^e i) := ⟨pow_ne_zero _ (hp i).ne_zero⟩
  exact ⟨pull (many (fun i => p i^e i)) (iso.trans (DirectSum.addEquivProd _))⟩

theorem chain_of_exceptional (h : exceptional G) (H K : AddSubgroup G) : H≤K ∨ K≤H := by
  rcases h with h|⟨p,k,hp,_,⟨e⟩⟩
  · exact .inl (fun x _ => (Subsingleton.elim x 0) ▸ K.zero_mem)
  · have : IsAddCyclic G := isAddCyclic_of_surjective e.symm e.symm.surjective
    have cd : Nat.card G=p^k := (Nat.card_congr e.toEquiv).trans (Nat.card_zmod _)
    have ord (U : AddSubgroup G) : ∃ s, Nat.card U=p^s := by
      have div := U.card_addSubgroup_dvd_card
      rw [cd] at div
      obtain ⟨s,_,eq⟩ := (Nat.dvd_prime_pow hp).mp div
      exact ⟨s,eq⟩
    obtain ⟨a,ha⟩ := ord H; obtain ⟨b,hb⟩ := ord K
    simp only [KFS5KDCompat.addSubgroup_le_iff_card_dvd,ha,hb]
    rcases le_total a b with h|h
    · exact .inl (pow_dvd_pow _ h)
    · exact .inr (pow_dvd_pow _ h)

/-- All finite abelian groups, with genuine additive characters, trace-one complex PSD matrices,
    and the real convex hull of trace-one nonnegative rank-one projectors. -/
theorem finite_abelian_iff : states G = convexHull ℝ (pureSet G) ↔ exceptional G := by
  constructor
  · intro he; by_contra hn
    obtain ⟨A,hd,ht,hk,hs⟩ := all_nonexceptional G hn
    apply hs; rw [← he]; exact ⟨hd.posSemidef,ht,fun x k => (hk x k).le⟩
  · intro h
    obtain ⟨F⟩ := hasFrame G
    exact Set.Subset.antisymm (fun _ ha => chain_positive F (chain_of_exceptional G h) ha) hull_states
end KFS5KDClassification
#print axioms KFS5KDClassification.finite_abelian_iff
