module
public import KFKDChain
public import Mathlib.GroupTheory.SpecificGroups.Cyclic
public import Mathlib.Algebra.Ring.Periodic
@[expose] public section
noncomputable section
set_option autoImplicit false
set_option linter.unusedSimpArgs false
set_option linter.unusedSectionVars false
namespace KFS5KDCyclic
open KFS5KDOperator KFS5KDFourier KFS5KDPure KFS5KDPair KFS5KDTransfer KFS5KDAtoms KFS5KDChain Matrix Classical
open scoped MatrixOrder ComplexOrder
variable {G I : Type*} [AddCommGroup G] [Fintype G] [DecidableEq G] [Fintype I]

def component (F : Frame G I) (A : Op G) (d : G) : AddSubgroup G × Arr G I :=
  (AddSubgroup.zmultiples d,fun z => (KFS5KDAtoms.row A z.1 d*F.char z.2 d).re)
theorem component_ok (F : Frame G I) {A: Op G} (ha : A∈states G) (d:G) :
    Adapt F (component F A d).1 (component F A d).2 := by
  rintro ⟨x,k⟩ ⟨y,l⟩ ⟨hp,hk⟩
  obtain ⟨n,hn⟩ := AddSubgroup.mem_zmultiples_iff.mp hp
  have hp' : Function.Periodic (fun t => KFS5KDAtoms.row A t d) d := hermitian_period F ha.1.isHermitian ha.2.2 d
  have eq := hp'.zsmul n y
  rw [hn] at eq
  change (KFS5KDAtoms.row A x d * F.char k d).re=(KFS5KDAtoms.row A y d * F.char l d).re
  rw [hk _ (AddSubgroup.mem_zmultiples d),show KFS5KDAtoms.row A x d=KFS5KDAtoms.row A y d by simpa using eq]

theorem cert_hull (F : Frame G I) {A : Op G} (ha : A ∈ states G)
    (hc : Cert F (fun z => (symbol A z.1 (F.char z.2)).re)) :
    A ∈ convexHull ℝ (pureSet G) := by
  obtain ⟨T,_,w,P,hw,hP,hval⟩ := hc
  have mat : ∑ i, w i • P i = A := by
    apply symbol_injective F; intro x j
    have sumsym (s : Finset T) : symbol (∑ i∈s, w i • P i) x (F.char j) =
        ∑ i∈s, (w i:ℂ)*symbol (P i) x (F.char j) := by
      induction s using Finset.induction_on with
      | empty => simp [symbol]
      | insert i s hn ih => simp only [Finset.sum_insert hn,symbol_add,symbol_smul,ih]
    rw [sumsym,← hval (x,j)]
    exact Complex.ext rfl (Complex.nonneg_iff.mp (ha.2.2 x (F.char j))).2
  have csum := congrArg Matrix.trace mat
  have one (i:T) : (P i).trace=1 := by obtain ⟨_,_,h,_⟩ := hP i; exact h
  simp [Matrix.trace_sum,Matrix.trace_smul,one,Complex.real_smul,ha.2.1] at csum
  apply mem_convexHull_of_exists_fintype w P hw _ hP mat
  exact_mod_cast csum

theorem chain_positive (F : Frame G I) (total : ∀ H K : AddSubgroup G, H≤K ∨ K≤H)
    {A : Op G} (ha : A∈states G) : A ∈ convexHull ℝ (pureSet G) := by
  let r := fun d e : G => AddSubgroup.zmultiples d ≤ AddSubgroup.zmultiples e
  let : Std.Total r := ⟨fun a b => total _ _⟩
  let : IsTrans G r := ⟨fun _ _ _ h k => h.trans k⟩
  let l := (Finset.univ : Finset G).toList.insertionSort r
  let s := l.map (component F A)
  have ch : s.Pairwise (fun a b => a.1≤b.1) := by
    simpa only [s,List.pairwise_map,component,r,l] using List.pairwise_insertionSort r (Finset.univ : Finset G).toList
  have ad : ∀ t∈s, Adapt F t.1 t.2 := by
    intro t ht; obtain ⟨d,_,rfl⟩ := List.mem_map.mp ht; exact component_ok F ha _
  have val : layerSum s = fun z => (symbol A z.1 (F.char z.2)).re := by
    funext z
    have hperm := List.perm_insertionSort r (Finset.univ : Finset G).toList
    have sm := (hperm.map (fun d => (KFS5KDAtoms.row A z.1 d*F.char z.2 d).re)).sum_eq
    rw [layerSum,value_sum,← row_amp]
    simpa [s,List.map_map,component,Function.comp_def,amp,Complex.re_sum,l] using sm
  apply cert_hull F ha
  rw [← val]; apply layers F s ch ad
  intro z; rw [val]; exact (Complex.nonneg_iff.mp (ha.2.2 _ _)).1

theorem hull_states : convexHull ℝ (pureSet G) ⊆ states G := by
  apply convexHull_min
  · rintro _ ⟨u,rfl,ht,hk⟩
    exact ⟨Matrix.posSemidef_vecMulVec_star_self u,ht,hk⟩
  · rintro A ⟨pa,ta,ka⟩ B ⟨pb,tb,kb⟩ a b ha hb hab
    refine ⟨(pa.smul ha).add (pb.smul hb),?_,?_⟩
    · simp [Matrix.trace_add,Matrix.trace_smul,ta,tb,Complex.real_smul,← Complex.ofReal_add,hab]
    · intro x k; rw [symbol_add,symbol_smul,symbol_smul]
      exact add_nonneg (mul_nonneg (Complex.zero_le_real.mpr ha) (ka _ _))
        (mul_nonneg (Complex.zero_le_real.mpr hb) (kb _ _))
end KFS5KDCyclic
#print axioms KFS5KDCyclic.chain_positive
