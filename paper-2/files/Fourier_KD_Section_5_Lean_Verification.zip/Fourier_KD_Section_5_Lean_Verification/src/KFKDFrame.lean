module
public import KFKDTransfer
@[expose] public section
noncomputable section
set_option autoImplicit false
set_option linter.deprecated false
set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false
namespace KFS5KDFrame
open KFS5KDPure KFS5KDFourier KFS5KDTransfer KFS5KDPair KFS5KDOperator Matrix Classical
open scoped ComplexOrder MatrixOrder
variable {G H I : Type*} [AddCommGroup G] [Fintype G] [DecidableEq G]
  [AddCommGroup H] [Fintype H] [DecidableEq H] [Fintype I]

def pull (F : Frame H H) (e : G ≃+ H) : Frame G G where
  char i := (F.char (e i)).compAddMonoidHom e.toAddMonoidHom
  orth x := by
    change (∑ i, F.char (e i) (e x))=_
    calc
      _ = ∑ j, F.char j (e x) := e.toEquiv.sum_comp _
      _ = _ := ?_
    rw [F.orth]
    simp [Fintype.card_congr e.toEquiv]

def many [DecidableEq I] (n : I → ℕ) [∀ i, NeZero (n i)] :
    Frame (∀ i, ZMod (n i)) (∀ i, ZMod (n i)) where
  char k := { toFun := fun h => ∏ i, (cyc (n i)).char (k i) (h i)
              map_zero_eq_one' := by simp
              map_add_eq_mul' := by intro x y; simp [AddChar.map_add_eq_mul,Finset.prod_mul_distrib] }
  orth h := by
    change (∑ k : ∀ i, ZMod (n i), ∏ i, (cyc (n i)).char (k i) (h i)) = _
    rw [← Fintype.prod_sum (fun i (j:ZMod (n i)) => (cyc (n i)).char j (h i))]; simp_rw [(cyc _).orth]
    by_cases hh : h=0
    · subst h; simp [Fintype.card_pi]
    · obtain ⟨i,hi⟩ : ∃ i, h i ≠ 0 := by by_contra! e; exact hh (funext e)
      rw [if_neg hh, Finset.prod_eq_zero (Finset.mem_univ i) (by simp [hi])]

theorem extension (F : Frame G I) (f : H →+ G) (hf : Function.Injective f) (b : AddChar H ℂ) :
    ∃ k : AddChar G ℂ, k.compAddMonoidHom f=b := by
  let u : G → ℂ := Function.extend f (fun y => b (-y)) 0
  have inn (x : H) : u (f x) = b (-x) := hf.extend_apply _ _ x
  have out (x : G) (hx : x ∉ Set.range f) : u x=0 := by
    exact Function.extend_apply' _ _ _ (by simpa [Set.mem_range] using hx)
  have uz : u 0=1 := by simpa using inn 0
  obtain ⟨j,hj⟩ : ∃ j, amp u (F.char j) ≠ 0 := by
    by_contra! hn
    have hh := reconstruct F u 0; simp [hn,uz] at hh; exact Nat.cast_ne_zero.mpr Fintype.card_ne_zero hh.symm
  let k := F.char j
  let d : AddChar H ℂ := k.compAddMonoidHom f-b
  have he : (∑ y, d y) = amp u k := by
    apply Fintype.sum_of_injective f hf
    · intro x hx; rw [out _ hx,zero_mul]
    · intro y; rw [inn]; simp [d,AddChar.sub_apply,AddChar.map_neg_eq_inv,mul_comm]
  have hd : d=0 := by
    by_contra hd; have h := AddChar.sum_eq_zero_iff_ne_zero.mpr hd; exact hj (he.symm.trans h)
  exact ⟨k,sub_eq_zero.mp hd⟩

theorem subgroup_negative (F : Frame G I) (f : H →+ G) (hf : Function.Injective f)
    {A : Op H} (h : A ∈ states H) (hn : A ∉ convexHull ℝ (pureSet H)) :
    pad f A ∈ states G ∧ pad f A ∉ convexHull ℝ (pureSet G) :=
  ⟨pad_state f hf h,outside_pad f hf (extension F f hf) hn⟩

def representative (F : Frame G I) (t : G × I × AddSubgroup G) : Op G :=
  let v : G → ℂ := fun x => if x-t.1 ∈ t.2.2 then F.char t.2.1 (-(x-t.1)) else 0
  (outer v).trace⁻¹ • outer v

theorem finite_pure (F : Frame G I) : (pureSet G).Finite := by
  let : Finite (AddSubgroup G) := Finite.of_injective (fun H : AddSubgroup G => (H:Set G))
    SetLike.coe_injective
  apply (Set.finite_range (representative F)).subset
  rintro _ ⟨u,rfl,ht,hp⟩
  have hu : u ≠ 0 := by rintro rfl; simp [outer,trace,Matrix.diag,Matrix.of_apply] at ht
  obtain ⟨a,j,ha,hb,hform⟩ := pure_vector_form F u hu hp
  let H := compatible u (F.char j)
  let v : G → ℂ := fun x => if x-a ∈ H then F.char j (-(x-a)) else 0
  have uv (x : G) : u x = u a * v x := by rw [hform x]; by_cases h : x-a ∈ H <;> simp [v,h,H] at *
  let c := star (u a)*u a
  have m : outer u = c • outer v := by
    ext x y
    change star (u x)*u y=c*(star (v x)*v y)
    rw [uv x,uv y,star_mul]; dsimp [c]; ring
  have ht' : c*(outer v).trace=1 := by simpa [m,trace_smul] using ht
  refine ⟨(a,j,H),?_⟩
  change (outer v).trace⁻¹ • outer v=outer u
  rw [m,← inv_eq_of_mul_eq_one_right ht',inv_inv]

end KFS5KDFrame
#print axioms KFS5KDFrame.extension
#print axioms KFS5KDFrame.finite_pure
