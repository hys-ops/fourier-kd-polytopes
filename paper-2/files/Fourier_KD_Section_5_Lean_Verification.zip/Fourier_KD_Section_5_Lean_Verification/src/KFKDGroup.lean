module
public import KFKDStrict
@[expose] public section
noncomputable section
set_option autoImplicit false
set_option linter.unusedSimpArgs false
set_option linter.unusedSectionVars false
namespace KFS5KDGroup
open KFS5KDPure KFS5KDTransfer KFS5KDFrame KFS5KDPair KFS5KDOperator KFS5KDFourier KFS5KDState Matrix Classical
open scoped MatrixOrder ComplexOrder
variable {G : Type*} [AddCommGroup G] [Fintype G] [DecidableEq G]
def exceptional (G : Type*) [AddCommGroup G] : Prop :=
  Subsingleton G ∨ ∃ (p k : ℕ), Nat.Prime p ∧ 0<k ∧ Nonempty (G ≃+ ZMod (p^k))

theorem smallEmbed (p e : ℕ) [hp : Fact p.Prime] (he : e≠0) :
    ∃ f : ZMod p →+ ZMod (p^e), Function.Injective f := by
  obtain ⟨m,rfl⟩ := Nat.exists_eq_succ_of_ne_zero he
  let t : ZMod (p^(m+1)) := ((p^m:ℕ) : ZMod (p^(m+1)))
  have pt : (p:ℤ) • t=0 := by
    change (p:ℤ) • ((p^m:ℕ) : ZMod (p^(m+1)))=0
    rw [natCast_zsmul,nsmul_eq_mul,← Nat.cast_mul, ← pow_succ', ZMod.natCast_self]
  have nt : t≠0 := by
    change ((p^m : ℕ) : ZMod (p^(m+1))) ≠ 0
    exact fun h => (Nat.not_dvd_of_pos_of_lt (pow_pos hp.out.pos m)
      (Nat.pow_lt_pow_right hp.out.one_lt (Nat.lt_succ_self m))) ((ZMod.natCast_eq_zero_iff ..).mp h)
  let v : { g : ℤ →+ ZMod (p^(m+1)) // g p=0} := ⟨zmultiplesHom _ t,pt⟩
  let f := ZMod.lift p v
  have h1 : f 1=t := by simpa [f,v] using ZMod.lift_coe p v (1:ℤ)
  refine ⟨f,(AddMonoidHom.ker_eq_bot_iff f).mp ?_⟩
  rcases KFS5KDPrimeAxes.field_subgroups p f.ker with h|h
  · exact h
  · have hh : (1 : ZMod p) ∈ f.ker := h ▸ AddSubgroup.mem_top _
    exact (nt (h1.symm.trans hh)).elim

variable {I : Type*} [Fintype I] [DecidableEq I]
theorem pairInto {V : I → Type*} [∀ i, AddCommGroup (V i)] {i j : I} (hij : i≠j)
    {P Q : Type*} [AddCommGroup P] [AddCommGroup Q] (f : P →+ V i) (g : Q →+ V j)
    (hf : Function.Injective f) (hg : Function.Injective g) :
    ∃ u : P×Q →+ ∀ t, V t, Function.Injective u := by
  let u : P×Q →+ ∀ t, V t :=
    { toFun := fun z => Pi.single i (f z.1) + Pi.single j (g z.2)
      map_zero' := by simp
      map_add' := by intro x y; simp [Pi.single_add]; abel }
  refine ⟨u,fun {a b} h => Prod.ext (hf ?_) (hg ?_)⟩
  · simpa [u,Pi.single_eq_of_ne hij] using congrFun h i
  · simpa [u,Pi.single_eq_of_ne hij.symm] using congrFun h j

theorem strict_of_decomp (p e : I → ℕ) (hp : ∀ i, Nat.Prime (p i))
    (iso : G ≃+ ∀ i, ZMod (p i ^ e i)) (hn : ¬ exceptional G) :
    ∃ B : Op G, B.PosDef ∧ B.trace=1 ∧ (∀ x k, 0<symbol B x k) ∧
      B ∉ convexHull ℝ (pureSet G) := by
  let V := fun i => ZMod (p i ^ e i)
  let (i:I) : NeZero (p i^e i) := ⟨pow_ne_zero _ (hp i).ne_zero⟩
  let F := pull (many (fun i => p i^e i)) iso
  have none (i : I) (h : e i=0) : ∀ x y : ZMod (p i^e i), x=y := by
    rw [h,pow_zero]; exact fun _ _ => Subsingleton.elim _ _
  obtain ⟨i,hi⟩ : ∃ i, e i≠0 := by
    by_contra! z
    exact hn (.inl ⟨fun x y => iso.injective (funext (fun i => none i (z i) _ _))⟩)
  obtain ⟨j,hij,hj⟩ : ∃ j, i≠j ∧ e j≠0 := by
    by_contra! only
    let ev : G →+ ZMod (p i^e i) := (Pi.evalAddMonoidHom V i).comp iso.toAddMonoidHom
    have inj : Function.Injective ev := by
      intro x y hh; apply iso.injective; funext j
      by_cases he : i=j
      · subst j; exact hh
      · exact none _ (only j he) _ _
    have sur : Function.Surjective ev := fun x => ⟨iso.symm (Pi.single i x),by simp [ev]⟩
    exact hn (.inr ⟨p i,e i,hp i,Nat.pos_of_ne_zero hi,⟨AddEquiv.ofBijective ev ⟨inj,sur⟩⟩⟩)
  let : Fact (p i).Prime := ⟨hp i⟩
  let : Fact (p j).Prime := ⟨hp j⟩
  obtain ⟨f,hf⟩ := smallEmbed (p i) _ hi
  obtain ⟨g,hg⟩ := smallEmbed (p j) _ hj
  obtain ⟨v,hv⟩ := pairInto (V:=V) hij f g hf hg
  obtain ⟨pos,tr,kd,sep⟩ := all_prime_pairs (p i) (p j)
  obtain ⟨h₁,h₂⟩ := subgroup_negative F (iso.symm.toAddMonoidHom.comp v) (iso.symm.injective.comp hv)
    ⟨pos.posSemidef,tr,fun x k => (kd x k).le⟩ sep
  exact KFS5KDStrict.perturb F h₁ h₂
end KFS5KDGroup
#print axioms KFS5KDGroup.strict_of_decomp
