module
public import KFKDGroup
public import Mathlib.GroupTheory.FiniteAbelian.Basic
@[expose] public section
noncomputable section
set_option autoImplicit false
namespace KFS5KDNegative
open KFS5KDGroup KFS5KDPair KFS5KDOperator KFS5KDFourier
open scoped ComplexOrder MatrixOrder
/-- Every non-exceptional finite abelian group has a positive definite, trace-one, strictly
    KFS5KD-positive matrix outside the convex hull of the positive pure states. -/
theorem all_nonexceptional (G : Type*) [AddCommGroup G] [Fintype G] [DecidableEq G]
    (hn : ¬ exceptional G) :
    ∃ B : Op G, B.PosDef ∧ B.trace=1 ∧ (∀ x k, 0<symbol B x k) ∧
      B ∉ convexHull ℝ (pureSet G) := by
  classical
  obtain ⟨ι,_,p,hp,e,⟨iso⟩⟩ := AddCommGroup.equiv_directSum_zmod_of_finite G
  exact strict_of_decomp p e hp (iso.trans (DirectSum.addEquivProd _)) hn
end KFS5KDNegative
#print axioms KFS5KDNegative.all_nonexceptional
