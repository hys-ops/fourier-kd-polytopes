module
public import KFKDPure
@[expose] public section
noncomputable section
set_option autoImplicit false
set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false
namespace KFS5KDPair
open KFS5KD KFS5KDPure KFS5KDFourier KFS5KDState KFS5KDOperator Matrix Classical
open scoped ComplexOrder MatrixOrder
abbrev C (p : ℕ) := ZMod p
variable {p q : ℕ} [Fact p.Prime] [Fact q.Prime]
def frame (p q : ℕ) [Fact p.Prime] [Fact q.Prime] := prodFrame (cyc p) (cyc q)
def sample : Op (C p × C q) →ₗ[ℝ] Obs (C p) (C q) where
  toFun A z := (symbol A z.1 ((frame p q).char z.2)).re
  map_add' A B := by funext z; simp [symbol_add]
  map_smul' r A := by funext z; simp [symbol_smul,Complex.re_ofReal_mul]

def pureSet (G : Type*) [AddCommGroup G] [Fintype G] [DecidableEq G] : Set (Op G) :=
  {A | ∃ u : G → ℂ, A=outer u ∧ A.trace=1 ∧ ∀ x k, 0 ≤ symbol A x k}

theorem sample_rho : sample (p:=p) (q:=q) rho = scale (P:=C p) (Q:=C q) • target := by
  funext z; rcases z with ⟨⟨x,y⟩,k,l⟩
  change (symbol rho (x,y) (pairChar ((cyc p).char k) ((cyc q).char l))).re = _ * _
  rw [rho,symbol_smul,W_symbol]
  by_cases h₁ : x=0 <;> by_cases h₂ : y=0 <;> by_cases h₃ : k=0 <;> by_cases h₄ : l=0 <;>
    norm_num [sign,KFS5KD.target,KFS5KD.signs,cyc_trivial,h₁,h₂,h₃,h₄,Complex.re_ofReal_mul]

theorem root_injective (n : ℕ) [NeZero n] : Function.Injective (cycRoot n) :=
  AddChar.injective_iff.mpr (fun x h => ((cycPrimitive n).zmod_char_eq_one_iff n x).mp h)

theorem plane_pairing (k b h : C p × C p) :
    (frame p p).char k h=(frame p p).char b h ↔ KFS5KDPlanes.dot (k-b) h=0 := by
  change cycRoot p (k.1*h.1)*cycRoot p (k.2*h.2)=
    cycRoot p (b.1*h.1)*cycRoot p (b.2*h.2) ↔ _
  rw [← AddChar.map_add_eq_mul,← AddChar.map_add_eq_mul,(root_injective p).eq_iff]
  simp only [KFS5KDPlanes.dot,Prod.fst_sub,Prod.snd_sub]; constructor <;> intro e <;> linear_combination e

abbrev sampledTile (H : AddSubgroup (C p × C q)) (a b : C p × C q) : Obs (C p) (C q) :=
  fun z => tile H a ((frame p q).char b) z.1 ((frame p q).char z.2)

theorem plane_tile (H : AddSubgroup (C p × C p)) (a b : C p × C p) :
    sampledTile H a b = cosetTile (H.toZModSubmodule p) a b := by
  funext z
  simp only [sampledTile,tile,cosetTile,plane_pairing]; rfl

theorem axis_pairing (A : AddSubgroup (C p)) (B : AddSubgroup (C q))
    (k b : C p × C q) :
    (∀ h ∈ A.prod B,(frame p q).char k h=(frame p q).char b h) ↔
      (∀ x ∈ A,(cyc p).char k.1 x=(cyc p).char b.1 x) ∧
      (∀ y ∈ B,(cyc q).char k.2 y=(cyc q).char b.2 y) := by
  constructor
  · intro h; constructor
    · intro x hx; simpa [frame,prodFrame,pairChar] using h (x,0) ⟨hx,B.zero_mem⟩
    · intro y hy; simpa [frame,prodFrame,pairChar] using h (0,y) ⟨A.zero_mem,hy⟩
  · rintro ⟨h₁,h₂⟩ ⟨x,y⟩ ⟨hx,hy⟩
    change (cyc p).char k.1 x * (cyc q).char k.2 y = _
    rw [h₁ x hx,h₂ y hy]; rfl

theorem all_eq {n : ℕ} [NeZero n] (a b : C n) :
    (∀ x, (cyc n).char a x=(cyc n).char b x) ↔ a=b := by
  constructor
  · intro h; apply root_injective n; simpa [cyc] using h 1
  · rintro rfl x; rfl

def indicator {α : Type*} [DecidableEq α] (a x : α) : ℝ := if x=a then 1 else 0
theorem ind_pos {α : Type*} [DecidableEq α] (a x : α) : 0 ≤ indicator a x := by
  unfold indicator; split <;> norm_num

theorem axis_tile (hpq : p≠q) (H : AddSubgroup (C p × C q)) (a b : C p × C q) :
    0 ≤ base (sampledTile H a b) := by
  obtain ⟨A,B,rfl,hA,hB⟩ := KFS5KDPrimeAxes.independent_factors hpq H
  have eq : sampledTile (A.prod B) a b = fun z => if
      ((z.1.1-a.1 ∈ A ∧ z.1.2-a.2 ∈ B) ∧
      (∀ x ∈ A,(cyc p).char z.2.1 x=(cyc p).char b.1 x) ∧
      (∀ y ∈ B,(cyc q).char z.2.2 y=(cyc q).char b.2 y)) then (1:ℝ) else 0 := by
    funext z; unfold sampledTile tile; congr 1; exact propext (and_congr_right (fun _ => axis_pairing A B z.2 b))
  rw [eq]
  rcases hA with rfl|rfl <;> rcases hB with rfl|rfl
  all_goals simp only [AddSubgroup.mem_bot,AddSubgroup.mem_top,forall_eq,
    forall_const,true_implies,all_eq,sub_eq_zero,AddChar.map_zero_eq_one,and_self,and_true,true_and]
  · convert base_chart_nonneg false false (indicator a) (ind_pos a) using 1
    congr 1; funext z; simp [indicator,coord,Prod.ext_iff]
  · convert base_chart_nonneg false true (indicator (a.1,b.2)) (ind_pos _) using 1
    congr 1; funext z; simp [indicator,coord,Prod.ext_iff]
  · convert base_chart_nonneg true false (indicator (b.1,a.2)) (ind_pos _) using 1
    congr 1; funext z; simp [indicator,coord,Prod.ext_iff,and_comm]
  · convert base_chart_nonneg true true (indicator b) (ind_pos b) using 1
    congr 1; funext z; simp [indicator,coord,Prod.ext_iff]

theorem outside (L : Obs (C p) (C q) →ₗ[ℝ] ℝ)
    (ht : ∀ (H : AddSubgroup (C p × C q)) (a b), 0 ≤ L (sampledTile H a b))
    (hn : L target = -1) :
    rho (P:=C p) (Q:=C q) ∉ convexHull ℝ (pureSet (C p × C q)) := by
  apply hull_separation (L.comp sample)
  · rintro _ ⟨u,rfl,htr,hp⟩
    have hu : u ≠ 0 := by
      rintro rfl
      have h0 : outer (0 : C p × C q → ℂ) = 0 := by ext i j; simp [outer]
      simp [h0] at htr
    obtain ⟨a,j,H,c,hc,he⟩ := pure_tile (frame p q) u hu hp
    have hh : sample (outer u) = c • sampledTile H a j := by
      funext z; exact he z.1 ((frame p q).char z.2)
    simp only [LinearMap.comp_apply,hh,map_smul,smul_eq_mul]
    exact mul_nonneg hc.le (ht H a j)
  · simp only [LinearMap.comp_apply,sample_rho,map_smul,hn,smul_eq_mul,mul_neg,mul_one]
    exact neg_lt_zero.mpr scale_pos

/-- Strict physical separation from the convex hull of all trace-one KFS5KD-positive pure states,
    for every prime pair including two. Tests all genuine characters. -/
theorem all_prime_pairs (p q : ℕ) [Fact p.Prime] [Fact q.Prime] :
    (rho (P:=C p) (Q:=C q)).PosDef ∧ (rho (P:=C p) (Q:=C q)).trace=1 ∧
    (∀ x k, 0 < symbol (rho (P:=C p) (Q:=C q)) x k) ∧
    rho (P:=C p) (Q:=C q) ∉ convexHull ℝ (pureSet (C p × C q)) := by
  refine ⟨rho_posDef,rho_trace,rho_all_KD_positive,?_⟩
  by_cases h : p=q
  · subst q
    apply outside witness _ witness_target
    intro H a b; rw [plane_tile]; exact all_tiles_nonneg (cosetTile_mem _ _ _)
  · exact outside base (axis_tile h) base_target
end KFS5KDPair
#print axioms KFS5KDPair.all_prime_pairs
