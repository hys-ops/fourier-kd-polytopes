module
public import KFKDAudit
public import Mathlib.NumberTheory.LegendreSymbol.AddCharacter
public import Mathlib.RingTheory.RootsOfUnity.Complex
@[expose] public section
noncomputable section
set_option autoImplicit false
set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false
set_option linter.deprecated false
namespace KFS5KDPure
open KFS5KDOperator KFS5KDFourier Matrix Classical
open scoped ComplexOrder ComplexConjugate
variable {G : Type*} [AddCommGroup G] [Fintype G] [DecidableEq G]

structure Frame (G I : Type*) [AddCommGroup G] [Fintype G] [DecidableEq G] [Fintype I] where
  char : I → AddChar G ℂ
  orth : ∀ x, ∑ i, char i x = if x=0 then (Fintype.card G : ℂ) else 0

def cycRoot (n : ℕ) [NeZero n] : AddChar (ZMod n) ℂ :=
  AddChar.zmodChar n (Complex.isPrimitiveRoot_exp n NeZero.out).pow_eq_one

theorem cycPrimitive (n : ℕ) [NeZero n] : (cycRoot n).IsPrimitive :=
  AddChar.zmodChar_primitive_of_primitive_root n (Complex.isPrimitiveRoot_exp n NeZero.out)

def cyc (n : ℕ) [NeZero n] : Frame (ZMod n) (ZMod n) where
  char := (cycRoot n).mulShift
  orth x := by
    classical
    have hh : (∑ i : ZMod n, (cycRoot n).mulShift i x) = ∑ i, (cycRoot n).mulShift x i :=
      Finset.sum_congr rfl (fun _ _ => by simp [mul_comm])
    rw [hh,AddChar.sum_eq_ite]
    have hz : (cycRoot n).mulShift x = 0 ↔ x=0 := by
      change (cycRoot n).mulShift x = 1 ↔ _
      rw [← (cycRoot n).mulShift_zero, (AddChar.to_mulShift_inj_of_isPrimitive (cycPrimitive n)).eq_iff]
    simp only [hz]

theorem cyc_trivial {n : ℕ} [NeZero n] (x : ZMod n) :
    (cyc n).char x=0 ↔ x=0 := by
  change (cycRoot n).mulShift x = 1 ↔ _
  rw [← (cycRoot n).mulShift_zero, (AddChar.to_mulShift_inj_of_isPrimitive (cycPrimitive n)).eq_iff]

def prodFrame {G H I J : Type*} [AddCommGroup G] [Fintype G] [DecidableEq G]
    [AddCommGroup H] [Fintype H] [DecidableEq H] [Fintype I] [Fintype J]
    (F : Frame G I) (T : Frame H J) : Frame (G × H) (I × J) where
  char k := pairChar (F.char k.1) (T.char k.2)
  orth x := by
    obtain ⟨x,y⟩ := x
    simp only [Fintype.sum_prod_type,pairChar]
    change (∑ i, ∑ j, F.char i x * T.char j y) = _
    simp_rw [← Finset.mul_sum, ← Finset.sum_mul, F.orth, T.orth]
    by_cases hx : x=0 <;> by_cases hy : y=0 <;> simp [hx,hy,Fintype.card_prod,Prod.ext_iff]

variable {I : Type*} [Fintype I]

/-- All outer products occur here, with u the conjugate of the ket in the position basis. -/
def outer (u : G → ℂ) : Op G := of fun x y => star (u x) * u y
def amp (u : G → ℂ) (k : AddChar G ℂ) := ∑ y, u y * k y

theorem symbol_outer (u : G → ℂ) (x : G) (k : AddChar G ℂ) :
    symbol (outer u) x k = star (u x) * k (-x) * amp u k := by
  unfold symbol amp; rw [Finset.mul_sum]
  apply Finset.sum_congr rfl; intro y _
  change star (u x) * u y * k (y-x) = _
  rw [sub_eq_add_neg,AddChar.map_add_eq_mul]; ring

theorem reconstruct (F : Frame G I) (u : G → ℂ) (x : G) :
    (∑ i, amp u (F.char i) * F.char i (-x)) = (Fintype.card G:ℂ) * u x := by
  classical
  simp only [amp,Finset.sum_mul]
  rw [Finset.sum_comm]
  simp_rw [mul_assoc, ← AddChar.map_add_eq_mul, ← Finset.mul_sum, F.orth]
  simp [← sub_eq_add_neg,sub_eq_zero,mul_ite,mul_comm]

theorem pure_product (u : G → ℂ) (positive : ∀ x k, 0 ≤ symbol (outer u) x k)
    (x : G) (k : AddChar G ℂ) :
    symbol (outer u) x k = (‖u x‖ : ℂ) * (‖amp u k‖ : ℂ) := by
  have hn := positive x k
  obtain ⟨r,hr,he⟩ := (RCLike.nonneg_iff_exists_ofReal.mp hn)
  have habs : ‖symbol (outer u) x k‖ = ‖u x‖ * ‖amp u k‖ := by
    simp [symbol_outer,norm_mul,AddChar.norm_apply]
  change (r : ℂ) = symbol (outer u) x k at he
  rw [← he] at habs
  have hh : ‖(r : ℂ)‖ = r := by simpa using (abs_of_nonneg hr)
  rw [hh] at habs
  rw [← he, habs, Complex.ofReal_mul]

theorem char_ne (k : AddChar G ℂ) (x : G) : k x ≠ 0 := by
  intro hx; have hh := k.norm_apply x; simp [hx] at hh

theorem common_phase (u : G → ℂ) (positive : ∀ x k, 0 ≤ symbol (outer u) x k)
    {a x : G} {b k : AddChar G ℂ} (ha : u a ≠ 0) (hx : u x ≠ 0)
    (hb : amp u b ≠ 0) (hk : amp u k ≠ 0) : k (x-a) = b (x-a) := by
  have cross : symbol (outer u) x k * symbol (outer u) a b =
      symbol (outer u) x b * symbol (outer u) a k := by
    simp only [pure_product u positive]; ring
  simp only [symbol_outer] at cross
  have e : k (-x)*b (-a)=b (-x)*k (-a) := by
    apply mul_left_cancel₀ (a := star (u x)*star (u a)*amp u k*amp u b)
      (mul_ne_zero (mul_ne_zero (mul_ne_zero (by simpa using hx) (by simpa using ha)) hk) hb)
    linear_combination cross
  have ep := congrArg Inv.inv e
  simp only [AddChar.map_neg_eq_inv,_root_.mul_inv_rev,inv_inv] at ep
  rw [AddChar.map_sub_eq_div,AddChar.map_sub_eq_div]
  exact (div_eq_div_iff (char_ne _ _) (char_ne _ _)).mpr (by linear_combination ep)

def compatible (u : G → ℂ) (b : AddChar G ℂ) : AddSubgroup G where
  carrier := {h | ∀ k, amp u k ≠ 0 → k h = b h}
  zero_mem' := by simp
  add_mem' := by intro x y hx hy k hk; rw [k.map_add_eq_mul,b.map_add_eq_mul,hx k hk,hy k hk]
  neg_mem' := by intro x hx k hk; rw [k.map_neg_eq_inv,b.map_neg_eq_inv,hx k hk]

theorem translated (F : Frame G I) (u : G → ℂ) (b : AddChar G ℂ) (x h : G) (hh : h ∈ compatible u b) :
    u (x+h) = u x * b (-h) := by
  have he : ∀ k : AddChar G ℂ, amp u k * k (-(x+h)) = (amp u k * k (-x)) * b (-h) := by
    intro k; by_cases hk : amp u k = 0
    · simp [hk]
    · rw [neg_add,k.map_add_eq_mul,k.map_neg_eq_inv h,b.map_neg_eq_inv h,hh k hk,mul_assoc]
  apply mul_left_cancel₀ (a := (Fintype.card G:ℂ)) (Nat.cast_ne_zero.mpr Fintype.card_ne_zero)
  rw [← mul_assoc,← reconstruct F u (x+h),← reconstruct F u x,Finset.sum_mul]
  exact Finset.sum_congr rfl (fun i _ => he (F.char i))

/-- In a KFS5KD-positive pure state the support is a single coset, and the phase is a character. -/
theorem pure_vector_form (F : Frame G I) (u : G → ℂ) (hu : u ≠ 0)
    (positive : ∀ x k, 0 ≤ symbol (outer u) x k) :
    ∃ (a : G) (j : I), u a ≠ 0 ∧ amp u (F.char j) ≠ 0 ∧
      ∀ x, u x = if x-a ∈ compatible u (F.char j) then u a*F.char j (-(x-a)) else 0 := by
  classical
  obtain ⟨a,ha⟩ : ∃ a, u a ≠ 0 := by
    by_contra! hn; exact hu (funext hn)
  obtain ⟨j,hb⟩ : ∃ j, amp u (F.char j) ≠ 0 := by
    by_contra! hn
    have hh := reconstruct F u a
    simp [hn,Fintype.card_ne_zero,ha] at hh
  refine ⟨a,j,ha,hb,?_⟩
  intro x; split_ifs with h
  · simpa using translated F u (F.char j) a (x-a) h
  · exact Classical.byContradiction (fun hne => h (fun k hk => common_phase u positive ha hne hb hk))

def tile (H : AddSubgroup G) (a : G) (b : AddChar G ℂ) (x : G) (k : AddChar G ℂ) : ℝ :=
  if x-a ∈ H ∧ ∀ h ∈ H, k h=b h then 1 else 0

/-- Exact symbol formula up to its positive normalization. No classification of pure states is assumed. -/
theorem pure_tile (F : Frame G I) (u : G → ℂ) (hu : u ≠ 0)
    (hp : ∀ x k, 0 ≤ symbol (outer u) x k) :
    ∃ (a : G) (j : I) (H : AddSubgroup G) (c : ℝ), 0<c ∧
      ∀ x k, (symbol (outer u) x k).re = c * tile H a (F.char j) x k := by
  classical
  obtain ⟨a,j,ha,hb,hform⟩ := pure_vector_form F u hu hp
  let b := F.char j
  let H := compatible u b
  refine ⟨a,j,H,‖u a‖ * ‖amp u b‖,mul_pos (norm_pos_iff.mpr ha) (norm_pos_iff.mpr hb),?_⟩
  intro x k
  simp only [pure_product u hp, ← Complex.ofReal_mul,Complex.ofReal_re,tile]
  by_cases hx : x-a ∈ H
  · have hnorm : ‖u x‖ = ‖u a‖ := by
      rw [hform x, if_pos hx, norm_mul,AddChar.norm_apply,mul_one]
    rw [hnorm]
    by_cases hk : ∀ h ∈ H, k h=b h
    · have he : amp u k * b a = amp u b * k a := by
        unfold amp; rw [Finset.sum_mul,Finset.sum_mul]
        apply Finset.sum_congr rfl; intro y _
        by_cases hy : y-a ∈ H
        · have h := hk (y-a) hy
          rw [AddChar.map_sub_eq_div,AddChar.map_sub_eq_div] at h
          have h' := (div_eq_div_iff (char_ne k a) (char_ne b a)).mp h
          linear_combination u y * h'
        · have hh : u y=0 := by rw [hform y,if_neg hy]
          simp [hh]
      have he' := congrArg norm he
      simp only [norm_mul,AddChar.norm_apply,mul_one] at he'
      rw [if_pos ⟨hx,hk⟩, mul_one, he']
    · have hk0 : amp u k=0 := Classical.byContradiction (fun hn => hk (fun _ hh => hh k hn))
      rw [if_neg (fun h => hk h.2), hk0]; simp
  · have hh : u x=0 := by rw [hform x,if_neg hx]
    rw [if_neg (fun h => hx h.1), hh]; simp

end KFS5KDPure
#print axioms KFS5KDPure.reconstruct
#print axioms KFS5KDPure.common_phase
#print axioms KFS5KDPure.pure_vector_form
#print axioms KFS5KDPure.pure_tile
