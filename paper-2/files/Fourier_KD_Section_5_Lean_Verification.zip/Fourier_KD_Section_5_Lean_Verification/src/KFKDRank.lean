module
public import KFKDClassification
@[expose] public section
noncomputable section
set_option autoImplicit false
set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false
namespace KFS5KDRank
open KFS5KDOperator KFS5KDPure KFS5KDPair KFS5KDTransfer KFS5KDFourier KFS5KDGroup KFS5KDNegative KFS5KDClassification Matrix Classical
open scoped ComplexOrder MatrixOrder
variable {G : Type*} [AddCommGroup G] [Fintype G] [DecidableEq G]

theorem hasEig {A : Op G} (her : A.IsHermitian) (tr : A.trace=1) :
    ∃ i, her.eigenvalues i ≠ 0 := by
  by_contra! hn; rw [her.trace_eq_sum_eigenvalues] at tr; simp [hn] at tr

theorem outer_iff_rank {A : Op G} (ps : A.PosSemidef) (tr : A.trace=1) :
    (∃ u : G → ℂ, A=outer u) ↔ A.rank=1 := by
  classical
  let h := ps.isHermitian
  obtain ⟨j,hj⟩ := hasEig h tr
  constructor
  · rintro ⟨u,hu⟩
    have le : A.rank ≤ 1 := hu ▸ Matrix.rank_vecMulVec_le (star u) u
    have : Nonempty {i // h.eigenvalues i ≠ 0} := ⟨⟨j,hj⟩⟩
    have pos : 0 < A.rank := h.rank_eq_card_non_zero_eigs ▸ Fintype.card_pos
    omega
  · intro hr
    have card : Fintype.card {i // h.eigenvalues i ≠ 0}=1 := h.rank_eq_card_non_zero_eigs.symm.trans hr
    have sub : Subsingleton {i // h.eigenvalues i ≠ 0} := Fintype.card_le_one_iff_subsingleton.mp card.le
    have oth (i:G) (hi:i≠j) : h.eigenvalues i=0 := by
      by_contra hn; exact hi (congrArg Subtype.val (sub.elim ⟨i,hn⟩ ⟨j,hj⟩))
    have e1 : (h.eigenvalues j : ℂ)=1 := by
      have s := h.trace_eq_sum_eigenvalues
      rw [Finset.sum_eq_single j] at s
      · exact s.symm.trans tr
      · intro i _ hn; simp [oth i hn]
      · simp
    let U : Op G := h.eigenvectorUnitary
    refine ⟨fun x => star (U x j),?_⟩
    have spec := h.spectral_theorem
    rw [Unitary.conjStarAlgAut_apply] at spec
    ext x y
    rw [spec]
    change (U * diagonal (fun i : G => (h.eigenvalues i : ℂ)) * Uᴴ) x y =
      star (star (U x j)) * star (U y j)
    rw [Matrix.mul_apply,Finset.sum_eq_single j]
    · simp [Matrix.mul_diagonal,Matrix.conjTranspose_apply,e1,RCLike.ofReal]
    · intro i _ ne; simp [Matrix.mul_diagonal,oth i ne]
    · simp

def rankOne (G : Type*) [AddCommGroup G] [Fintype G] [DecidableEq G] : Set (Op G) :=
  {A | A ∈ states G ∧ A.rank=1}

theorem physical : rankOne G=pureSet G := by
  ext A; constructor
  · rintro ⟨⟨ps,tr,kd⟩,rank⟩; obtain ⟨u,hu⟩ := (outer_iff_rank ps tr).mpr rank
    exact ⟨u,hu,tr,kd⟩
  · rintro ⟨u,rfl,tr,kd⟩
    have ps : (outer u).PosSemidef := Matrix.posSemidef_vecMulVec_star_self u
    exact ⟨⟨ps,tr,kd⟩,(outer_iff_rank ps tr).mp ⟨u,rfl⟩⟩

theorem classification (G : Type*) [AddCommGroup G] [Fintype G] [DecidableEq G] :
    states G=convexHull ℝ (rankOne G) ↔ exceptional G := by
  rw [physical]; exact finite_abelian_iff G

theorem strict_converse (hn : ¬ exceptional G) :
    ∃ A : Op G, A.PosDef ∧ A.trace=1 ∧ (∀ x k, 0 < symbol A x k) ∧
      A ∉ convexHull ℝ (rankOne G) := by
  rw [physical]; exact all_nonexceptional G hn
end KFS5KDRank
#print axioms KFS5KDRank.physical
#print axioms KFS5KDRank.classification
#print axioms KFS5KDRank.strict_converse
