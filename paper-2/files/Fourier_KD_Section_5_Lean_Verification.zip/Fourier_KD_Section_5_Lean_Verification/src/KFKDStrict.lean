module
public import KFKDFrame
public import Mathlib.Analysis.Convex.Topology
@[expose] public section
noncomputable section
set_option autoImplicit false
set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false
namespace KFS5KDStrict
open KFS5KDOperator KFS5KDFourier KFS5KDPair KFS5KDPure KFS5KDTransfer KFS5KDFrame Matrix Classical
open scoped MatrixOrder ComplexOrder Topology
variable {G I : Type*} [AddCommGroup G] [Fintype G] [DecidableEq G] [Fintype I]
def mix (A : Op G) (t : ℝ) : Op G :=
  (t/(Fintype.card G : ℝ)) • (1 : Op G) + (1-t) • A

theorem perturb (F : Frame G I) {A : Op G} (hs : A ∈ states G)
    (hn : A ∉ convexHull ℝ (pureSet G)) :
    ∃ B : Op G, B.PosDef ∧ B.trace=1 ∧ (∀ x k, 0 < symbol B x k) ∧
      B ∉ convexHull ℝ (pureSet G) := by
  obtain ⟨ps,ht,kp⟩ := hs
  have cont : Continuous (mix A) := by unfold mix; fun_prop
  have near : {t : ℝ | mix A t ∉ convexHull ℝ (pureSet G)} ∈ 𝓝 0 :=
    (((finite_pure F).isClosed_convexHull ℝ).isOpen_compl.preimage cont).mem_nhds
      (by simpa [mix] using hn)
  obtain ⟨l,r,⟨hl,hr⟩,hh⟩ := mem_nhds_iff_exists_Ioo_subset.mp near
  obtain ⟨t,ht₀,ht₁⟩ := exists_between (lt_min hr zero_lt_one)
  have tr : t < r := ht₁.trans_le (min_le_left _ _)
  have t1 : t < 1 := ht₁.trans_le (min_le_right _ _)
  have card : 0 < (Fintype.card G : ℝ) := Nat.cast_pos.mpr Fintype.card_pos
  have coeff := div_pos ht₀ card
  refine ⟨mix A t,(Matrix.PosDef.one.smul coeff).add_posSemidef (ps.smul (sub_nonneg.mpr t1.le)),?_,?_,
    hh ⟨hl.trans ht₀,tr⟩⟩
  · simp [mix,Matrix.trace_smul,ht,Complex.real_smul,div_mul_cancel₀ _ (ne_of_gt card)]
  · intro x k; rw [mix,symbol_add,symbol_smul,symbol_one,symbol_smul,mul_one]
    exact add_pos_of_pos_of_nonneg (Complex.zero_lt_real.mpr coeff)
      (mul_nonneg (Complex.zero_le_real.mpr (sub_nonneg.mpr t1.le)) (kp x k))
end KFS5KDStrict
#print axioms KFS5KDStrict.perturb
