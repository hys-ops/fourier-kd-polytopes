module
public import KFKDPair
@[expose] public section
noncomputable section
set_option autoImplicit false
set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false
open scoped ComplexOrder MatrixOrder
namespace KFS5KDTransfer
open KFS5KDOperator KFS5KDFourier KFS5KDPure KFS5KDPair Matrix Classical
variable {H G : Type*} [AddCommGroup H] [Fintype H] [DecidableEq H]
  [AddCommGroup G] [Fintype G] [DecidableEq G]
def J (f : H →+ G) : Matrix G H ℂ := of fun x h => if f h=x then 1 else 0
def pad (f : H →+ G) (A : Op H) : Op G := J f * A * (J f)ᴴ
def cut (f : H →+ G) : Op G →ₗ[ℝ] Op H where
  toFun A := A.submatrix f f
  map_add' _ _ := rfl
  map_smul' _ _ := rfl

theorem pad_at (f : H →+ G) (hf : Function.Injective f) (A : Op H) (x y : H) :
    pad f A (f x) (f y)=A x y := by
  simp [pad,J,Matrix.mul_apply,Matrix.conjTranspose_apply,hf.eq_iff,ite_mul,mul_ite]

theorem pad_off (f : H →+ G) (A : Op H) {x y : G} (h : x ∉ Set.range f ∨ y ∉ Set.range f) :
    pad f A x y = 0 := by
  rcases h with h|h
  · have hh : ∀ i, f i ≠ x := fun i e => h ⟨i,e⟩
    simp [pad,J,Matrix.mul_apply,Matrix.conjTranspose_apply,hh]
  · have hh : ∀ i, f i ≠ y := fun i e => h ⟨i,e⟩
    simp [pad,J,Matrix.mul_apply,Matrix.conjTranspose_apply,hh]

theorem trace_support (f : H →+ G) (hf : Function.Injective f) (A : Op G)
    (h : ∀ y ∉ Set.range f, A y y=0) : (cut f A).trace=A.trace :=
  Fintype.sum_of_injective f hf _ _ h (fun _ => rfl)

theorem cut_pad (f : H →+ G) (hf : Function.Injective f) (A : Op H) : cut f (pad f A)=A := by
  ext x y; exact pad_at f hf A x y

theorem symbol_support (f : H →+ G) (hf : Function.Injective f) (A : Op G)
    (x : H) (k : AddChar G ℂ) (h : ∀ y ∉ Set.range f, A (f x) y=0) :
    symbol (cut f A) x (k.compAddMonoidHom f)=symbol A (f x) k := by
  apply Fintype.sum_of_injective f hf
  · intro y hy; rw [h y hy,zero_mul]
  · intro y; change A (f x) (f y) * k (f (y-x)) = _; rw [map_sub]

def states (G : Type*) [AddCommGroup G] [Fintype G] [DecidableEq G] : Set (Op G) :=
  {A | A.PosSemidef ∧ A.trace=1 ∧ ∀ x k, 0 ≤ symbol A x k}

theorem pad_state (f : H →+ G) (hf : Function.Injective f) {A : Op H} (ha : A ∈ states H) :
    pad f A ∈ states G := by
  obtain ⟨hp,ht,hk⟩ := ha
  refine ⟨hp.mul_mul_conjTranspose_same _,?_,?_⟩
  · rw [← trace_support f hf _ (fun _ h => pad_off f A (.inl h)),cut_pad f hf,ht]
  · intro x k; by_cases h : x ∈ Set.range f
    · obtain ⟨h,rfl⟩ := h
      rw [← symbol_support f hf _ _ _ (fun _ hy => pad_off f A (.inr hy)),cut_pad f hf]
      exact hk _ _
    · simp [symbol, pad_off f A (Or.inl h)]

/-- An exposed zero-diagonal face restricts to the hull of pure states on the subgroup. -/
theorem cut_face (f : H →+ G) (hf : Function.Injective f)
    (extend : ∀ b : AddChar H ℂ, ∃ k : AddChar G ℂ, k.compAddMonoidHom f=b)
    {A : Op G} (ha : A ∈ convexHull ℝ (pureSet G))
    (zero_diag : ∀ x ∉ Set.range f, (A x x).re = 0) :
    cut f A ∈ convexHull ℝ (pureSet H) := by
  let S : Set (Op G) := {B | (∀ x, 0 ≤ (B x x).re) ∧
    ((∀ x ∉ Set.range f, (B x x).re=0) → cut f B ∈ convexHull ℝ (pureSet H))}
  have hb : pureSet G ⊆ S := by
    rintro _ ⟨u,rfl,ht,hk⟩
    have de (x : G) : (outer u x x).re = ‖u x‖^2 := by
      change (star (u x)*u x).re = _; rw [Complex.star_def,mul_comm,Complex.mul_conj]
      simp [Complex.sq_norm]
    refine ⟨fun x => (de x).symm ▸ sq_nonneg _,?_⟩
    intro dz
    have supp : ∀ x ∉ Set.range f, u x=0 := by
      intro x hx; have h := dz x hx; rw [de] at h; simpa using h
    apply subset_convexHull ℝ _; refine ⟨u ∘ f,rfl,?_,?_⟩
    · rw [trace_support f hf _ (fun x hx => by simp [outer,supp x hx]),ht]
    · intro x b; obtain ⟨k,rfl⟩ := extend b
      rw [symbol_support f hf _ x k (fun y hy => by simp [outer,supp y hy])]
      exact hk _ _
  have hc : Convex ℝ S := by
    rw [convex_iff_forall_pos]
    rintro B ⟨bd,bc⟩ D ⟨dd,dc⟩ a b ha hb hab
    have ent (x : G) : ((a • B + b • D) x x).re = a*(B x x).re + b*(D x x).re := by
      simp [Complex.real_smul,Complex.re_ofReal_mul]
    refine ⟨fun x => (ent x).symm ▸ add_nonneg (mul_nonneg ha.le (bd x)) (mul_nonneg hb.le (dd x)),?_⟩
    intro van
    have both (x : G) (hx : x ∉ Set.range f) : (B x x).re=0 ∧ (D x x).re=0 := by
      have eq := van x hx; rw [ent] at eq
      have nn := add_eq_zero_iff_of_nonneg (mul_nonneg ha.le (bd x)) (mul_nonneg hb.le (dd x)) |>.mp eq
      exact ⟨(mul_eq_zero.mp nn.1).resolve_left ha.ne', (mul_eq_zero.mp nn.2).resolve_left hb.ne'⟩
    rw [map_add,map_smul,map_smul]
    exact convex_convexHull ℝ _ (bc (fun x h => (both x h).1)) (dc (fun x h => (both x h).2)) ha.le hb.le hab
  exact (convexHull_min hb hc ha).2 zero_diag

theorem outside_pad (f : H →+ G) (hf : Function.Injective f)
    (extend : ∀ b : AddChar H ℂ, ∃ k : AddChar G ℂ, k.compAddMonoidHom f=b)
    {A : Op H} (ha : A ∉ convexHull ℝ (pureSet H)) :
    pad f A ∉ convexHull ℝ (pureSet G) := by
  intro h
  have h' := cut_face f hf extend h (fun x hx => by rw [pad_off f A (.inl hx)]; rfl)
  exact ha ((cut_pad f hf A) ▸ h')
end KFS5KDTransfer
#print axioms KFS5KDTransfer.cut_face
#print axioms KFS5KDTransfer.pad_state
#print axioms KFS5KDTransfer.outside_pad
