"""Only reuse exact unchanged v3 source DAGs at this Lean/mathlib pin.
The prebuilt .olean directory must match the verified baseline or
else the developer should use replay.sh without the optional cache flags."""
from pathlib import Path
import sys,re,hashlib
new,old,cache=map(Path,sys.argv[1:])
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
baseline='491111cc4af9baef73b24527cdf6a89a38af2a0a9c51385203ae1be186e527a0'
if sha(old/'SOURCES.sha256')!=baseline: raise SystemExit('Not the verified v3 baseline')
before={x.split()[1]:x.split()[0] for x in (old/'SOURCES.sha256').read_text().splitlines()}
accepted=set()
for line in (new/'MANIFEST.tsv').read_text().splitlines()[1:]:
 n=line.split('\t')[-1];name=n+'.lean';p=new/'src'/name
 if name not in before or sha(p)!=before[name] or not (cache/(n+'.olean')).exists():continue
 deps=re.findall(r'^(?:public (?:meta )?)?import\s+(\w+)(?:\s|$)',p.read_text(),re.M)
 if all(d in accepted or not (new/'src'/(d+'.lean')).exists() for d in deps):
  accepted.add(n);print(n)
