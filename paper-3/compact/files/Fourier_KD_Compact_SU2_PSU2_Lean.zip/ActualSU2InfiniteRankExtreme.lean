import Mathlib.Analysis.InnerProductSpace.StarOrder
import Mathlib.Analysis.SpecialFunctions.ContinuousFunctionalCalculus.Rpow.Basic
import Mathlib.MeasureTheory.Integral.DominatedConvergence
import Mathlib.Analysis.InnerProductSpace.Projection.Submodule
import Mathlib.Analysis.InnerProductSpace.Positive
import Mathlib.Analysis.InnerProductSpace.l2Space
import Mathlib.Topology.Algebra.InfiniteSum.Real
import Mathlib.Tactic.Linarith
import Mathlib.MeasureTheory.Function.AEEqOfLIntegral
import Mathlib.MeasureTheory.Integral.Bochner.ContinuousLinearMap
import Mathlib.MeasureTheory.Function.L2Space
import Mathlib.MeasureTheory.Function.LpSeminorm.Indicator
import Mathlib.Analysis.InnerProductSpace.Adjoint
import Mathlib.Algebra.Star.StarProjection
import Mathlib.Analysis.CStarAlgebra.Classes
import Mathlib.MeasureTheory.Measure.Haar.Unique
import Mathlib.MeasureTheory.Group.Measure
import Mathlib.MeasureTheory.Function.ContinuousMapDense
import Mathlib.MeasureTheory.Integral.Prod
import Mathlib.Analysis.Complex.Polynomial.Basic
import Mathlib.Analysis.Normed.Module.FiniteDimension
import Mathlib.Analysis.Normed.Operator.BoundedLinearMaps
import Mathlib.FieldTheory.IsAlgClosed.Spectrum
import Mathlib.LinearAlgebra.Eigenspace.Basic
import Mathlib.LinearAlgebra.Trace
import Mathlib.Tactic.Group
import Mathlib.Topology.CompactOpen
import Mathlib.Dynamics.Ergodic.MeasurePreserving
import Mathlib.MeasureTheory.Measure.Regular
import Mathlib.MeasureTheory.Function.SimpleFuncDenseLp
import Mathlib.MeasureTheory.Group.MeasurableEquiv
import Mathlib.Tactic.NormNum
import Mathlib.Analysis.Normed.Operator.Extend
import Mathlib.Topology.Separation.Basic
import Mathlib.Topology.Connected.TotallyDisconnected
import Mathlib.Analysis.InnerProductSpace.Continuous
import Mathlib.LinearAlgebra.Eigenspace.Minpoly
import Mathlib.Algebra.Order.Ring.Abs
import Mathlib.Algebra.Order.GroupWithZero.Basic
import Mathlib.Tactic.Ring
import Mathlib.Analysis.Fourier.AddCircle
import Mathlib.Analysis.Complex.Order
import Mathlib.Analysis.InnerProductSpace.PiL2
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Star.BigOperators
import Mathlib.LinearAlgebra.Matrix.ToLin
import Mathlib.Analysis.Normed.Operator.Bilinear
import Mathlib.RingTheory.RootsOfUnity.Complex
import Mathlib.Tactic.FieldSimp
import Mathlib.Analysis.Normed.Module.Connected
import Mathlib.LinearAlgebra.UnitaryGroup
import Mathlib.LinearAlgebra.Complex.FiniteDimensional
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.Topology.Instances.Matrix
import Mathlib.Tactic.FinCases
import Mathlib.Analysis.InnerProductSpace.LinearMap
import Mathlib.Topology.Algebra.OpenSubgroup
import Mathlib.Topology.Algebra.Group.Pointwise
import Mathlib.Topology.Connected.Clopen
import Mathlib.Analysis.InnerProductSpace.Projection.Reflection
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SpecialFunctions.Pow.Real
namespace CompactFourierKD
open MeasureTheory
open scoped ComplexInnerProductSpace

noncomputable abbrev PositionL2 {G : Type*} [MeasurableSpace G] (μ : Measure G) := Lp ℂ 2 μ

noncomputable def positionIndicatorLinear {G : Type*} [MeasurableSpace G] (μ : Measure G)
    (E : Set G) (hE : MeasurableSet E) : PositionL2 μ →ₗ[ℂ] PositionL2 μ where
  toFun f := ((Lp.memLp f).indicator hE).toLp (E.indicator f)
  map_add' f g := by
    apply Lp.ext
    filter_upwards [((Lp.memLp (f+g)).indicator hE).coeFn_toLp,
      ((Lp.memLp f).indicator hE).coeFn_toLp,((Lp.memLp g).indicator hE).coeFn_toLp,
      Lp.coeFn_add f g,
      Lp.coeFn_add (((Lp.memLp f).indicator hE).toLp (E.indicator f))
        (((Lp.memLp g).indicator hE).toLp (E.indicator g))] with x hfg hf hg hadd hsum
    simp only [hfg,hsum,Pi.add_apply,hf,hg]
    by_cases hx : x∈E
    · rw [Set.indicator_of_mem hx,Set.indicator_of_mem hx,Set.indicator_of_mem hx,hadd]
      rfl
    · simp [hx]
  map_smul' c f := by
    apply Lp.ext
    filter_upwards [((Lp.memLp (c • f)).indicator hE).coeFn_toLp,
      ((Lp.memLp f).indicator hE).coeFn_toLp,Lp.coeFn_smul c f,
      Lp.coeFn_smul c (((Lp.memLp f).indicator hE).toLp (E.indicator f))]
      with x hcf hf hsmul hprod
    simp only [hcf,hprod,Pi.smul_apply,hf,RingHom.id_apply]
    by_cases hx : x∈E
    · rw [Set.indicator_of_mem hx,Set.indicator_of_mem hx,hsmul]
      rfl
    · simp [hx]

/-- The true position measurement: multiplication by a measurable
set's indicator on Mathlib's Bochner L². -/
noncomputable def positionIndicator {G : Type*} [MeasurableSpace G] (μ : Measure G)
    (E : Set G) (hE : MeasurableSet E) : PositionL2 μ →L[ℂ] PositionL2 μ :=
  (positionIndicatorLinear μ E hE).mkContinuous 1 (fun f => by
    rw [one_mul,Lp.norm_def,Lp.norm_def]
    change (eLpNorm (((Lp.memLp f).indicator hE).toLp (E.indicator f) : G→ℂ) 2 μ).toReal ≤ _
    rw [eLpNorm_congr_ae ((Lp.memLp f).indicator hE).coeFn_toLp]
    exact ENNReal.toReal_mono (Lp.eLpNorm_ne_top f) (eLpNorm_indicator_le _))

theorem positionIndicator_apply_ae {G : Type*} [MeasurableSpace G] (μ : Measure G)
    (E : Set G) (hE : MeasurableSet E) (f : PositionL2 μ) :
    positionIndicator μ E hE f =ᵐ[μ] E.indicator f :=
  ((Lp.memLp f).indicator hE).coeFn_toLp

/-- The operator used in the KD pair is genuinely an orthogonal
projection, not a symbol with an assumed projection operation. -/
theorem positionIndicator_isStarProjection {G : Type*} [MeasurableSpace G]
    (μ : Measure G) (E : Set G) (hE : MeasurableSet E) :
    IsStarProjection (positionIndicator μ E hE) := by
  let M := positionIndicator μ E hE
  have hAe (f : PositionL2 μ) : M f =ᵐ[μ] E.indicator f :=
    positionIndicator_apply_ae μ E hE f
  refine ⟨?_,?_⟩
  · change M*M=M
    ext f
    change (M (M f) : G→ℂ) =ᵐ[μ] M f
    filter_upwards [hAe (M f),hAe f] with x h1 h2
    by_cases hx : x∈E <;> simp [h1,h2,hx]
  · change M.adjoint=M
    apply Eq.symm
    rw [ContinuousLinearMap.eq_adjoint_iff]
    intro f g
    rw [MeasureTheory.L2.inner_def,MeasureTheory.L2.inner_def]
    apply integral_congr_ae
    filter_upwards [hAe f,hAe g] with x hf hg
    rw [hf,hg]
    by_cases hx : x∈E <;> simp [hx]

end CompactFourierKD

/-
Copyright (c) 2024 Yury Kudryashov. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Yury Kudryashov
-/


/-!
# Continuity of the preimage of a set under a measure-preserving continuous function

In this file we prove that the preimage of a null measurable set `s : Set Y`
under a measure-preserving continuous function `f : C(X, Y)` is continuous in `f`
in the sense that `μ ((f a ⁻¹' s) ∆ (g ⁻¹' s))` tends to zero as `f a` tends to `g`.

As a corollary, we show that
for a continuous family of continuous maps `f z : C(X, Y)`,
a null measurable set `s`, and a null measurable set `t` of finite measure,
the set of parameters `z` such that `f z ⁻¹' t` is a.e. equal to `s` is a closed set.
-/


open Filter Set
open scoped ENNReal symmDiff Topology

namespace MeasureTheory

variable {α X Y Z : Type*}
  [TopologicalSpace X] [MeasurableSpace X] [BorelSpace X] [R1Space X]
  [TopologicalSpace Y] [MeasurableSpace Y] [BorelSpace Y] [R1Space Y]
  [TopologicalSpace Z]
  {μ : Measure X} {ν : Measure Y} [μ.InnerRegularCompactLTTop] [IsLocallyFiniteMeasure ν]

/-- Let `X` and `Y` be R₁ topological spaces
with Borel σ-algebras and measures `μ` and `ν`, respectively.
Suppose that `μ` is inner regular for finite measure sets with respect to compact sets
and `ν` is a locally finite measure.
Let `f : α → C(X, Y)` be a family of continuous maps
that converges to a continuous map `g : C(X, Y)` in the compact-open topology along a filter `l`.
Suppose that `g` is a measure-preserving map
and `f a` is a measure-preserving map eventually along `l`.
Then for any finite measure measurable set `s`,
the preimages `f a ⁻¹' s` tend to the preimage `g ⁻¹' s` in measure.
More precisely, the measure of the symmetric difference of these two sets tends to zero. -/
theorem tendsto_measure_symmDiff_preimage_nhds_zero
    {l : Filter α} {f : α → C(X, Y)} {g : C(X, Y)} {s : Set Y} (hfg : Tendsto f l (𝓝 g))
    (hf : ∀ᶠ a in l, MeasurePreserving (f a) μ ν) (hg : MeasurePreserving g μ ν)
    (hs : NullMeasurableSet s ν) (hνs : ν s ≠ ∞) :
    Tendsto (fun a ↦ μ ((f a ⁻¹' s) ∆ (g ⁻¹' s))) l (𝓝 0) := by
  have : ν.InnerRegularCompactLTTop := by
    rw [← hg.map_eq]
    exact .map_of_continuous (map_continuous _)
  rw [ENNReal.tendsto_nhds_zero]
  intro ε hε
  -- Without loss of generality, `s` is an open set.
  wlog hso : IsOpen s generalizing s ε
  · have H : 0 < ε / 3 := ENNReal.div_pos hε.ne' ENNReal.coe_ne_top
    -- Indeed, we can choose an open set `U` such that `ν (U ∆ s) < ε / 3`,
    -- apply the lemma to `U`, then use the triangle inequality for `μ (_ ∆ _)`.
    rcases hs.exists_isOpen_symmDiff_lt hνs H.ne' with ⟨U, hUo, hU, hUs⟩
    have hmU : NullMeasurableSet U ν := hUo.measurableSet.nullMeasurableSet
    replace hUs := hUs.le
    filter_upwards [hf, this hmU hU.ne _ H hUo] with a hfa ha
    calc
      μ ((f a ⁻¹' s) ∆ (g ⁻¹' s))
        ≤ μ ((f a ⁻¹' s) ∆ (f a ⁻¹' U)) + μ ((f a ⁻¹' U) ∆ (g ⁻¹' U))
          + μ ((g ⁻¹' U) ∆ (g ⁻¹' s)) := by
        refine (measure_symmDiff_le _ (g ⁻¹' U) _).trans ?_
        gcongr
        apply measure_symmDiff_le
      _ ≤ ε / 3 + ε / 3 + ε / 3 := by
        gcongr
        · rwa [← preimage_symmDiff, hfa.measure_preimage (hs.symmDiff hmU), symmDiff_comm]
        · rwa [← preimage_symmDiff, hg.measure_preimage (hmU.symmDiff hs)]
      _ = ε := by simp
  -- Take a compact closed subset `K ⊆ g ⁻¹' s` of almost full measure,
  -- `μ (g ⁻¹' s \ K) < ε / 2`.
  have hνs' : μ (g ⁻¹' s) ≠ ∞ := by rwa [hg.measure_preimage hs]
  obtain ⟨K, hKg, hKco, hKcl, hKμ⟩ :
      ∃ K, MapsTo g K s ∧ IsCompact K ∧ IsClosed K ∧ μ (g ⁻¹' s \ K) < ε / 2 :=
    (hg.measurable hso.measurableSet).exists_isCompact_isClosed_sdiff_lt hνs' <| by simp [hε.ne']
  have hKm : NullMeasurableSet K μ := hKcl.nullMeasurableSet
  -- Take `a` such that `f a` is measure preserving and maps `K` to `s`.
  -- This is possible, because `K` is a compact set and `s` is an open set.
  filter_upwards [hf, ContinuousMap.tendsto_nhds_compactOpen.mp hfg K hKco s hso hKg] with a hfa ha
  -- Then each of the sets `g ⁻¹' s ∆ K = g ⁻¹' s \ K` and `f a ⁻¹' s ∆ K = f a ⁻¹' s \ K`
  -- have measure at most `ε / 2`, thus `f a ⁻¹' s ∆ g ⁻¹' s` has measure at most `ε`.
  rw [← ENNReal.add_halves ε]
  refine (measure_symmDiff_le _ K _).trans ?_
  rw [symmDiff_of_ge ha.subset_preimage, symmDiff_of_le hKg.subset_preimage]
  gcongr
  have hK' : μ K ≠ ∞ := ne_top_of_le_ne_top hνs' <| measure_mono hKg.subset_preimage
  rw [measure_sdiff_le_iff_le_add hKm ha.subset_preimage hK', hfa.measure_preimage hs,
    ← hg.measure_preimage hs, ← measure_sdiff_le_iff_le_add hKm hKg.subset_preimage hK']
  exact hKμ.le

set_option backward.isDefEq.respectTransparency false in
/-- Let `f : Z → C(X, Y)` be a continuous (in the compact open topology) family
of continuous measure-preserving maps.
Let `t : Set Y` be a null measurable set of finite measure.
Then for any `s`, the set of parameters `z`
such that the preimage of `t` under `f_z` is a.e. equal to `s`
is a closed set.

In particular, if `X = Y` and `s = t`,
then we see that the a.e. stabilizer of a set is a closed set. -/
theorem isClosed_setOfPred_preimage_ae_eq {f : Z → C(X, Y)} (hf : Continuous f)
    (hfm : ∀ z, MeasurePreserving (f z) μ ν) (s : Set X)
    {t : Set Y} (htm : NullMeasurableSet t ν) (ht : ν t ≠ ∞) :
    IsClosed {z | f z ⁻¹' t =ᵐ[μ] s} := by
  rw [← isOpen_compl_iff, isOpen_iff_mem_nhds]
  intro z hz
  replace hz : ∀ᶠ ε : ℝ≥0∞ in 𝓝 0, ε < μ ((f z ⁻¹' t) ∆ s) := by
    apply gt_mem_nhds
    rwa [pos_iff_ne_zero, ne_eq, measure_symmDiff_eq_zero_iff]
  filter_upwards [(tendsto_measure_symmDiff_preimage_nhds_zero (hf.tendsto z)
    (.of_forall hfm) (hfm z) htm ht).eventually hz] with w hw
  intro (hw' : f w ⁻¹' t =ᵐ[μ] s)
  rw [measure_congr (hw'.symmDiff (ae_eq_refl _)), symmDiff_comm] at hw
  exact hw.false

@[deprecated (since := "2026-07-09")]
alias isClosed_setOf_preimage_ae_eq := isClosed_setOfPred_preimage_ae_eq

end MeasureTheory

/-
Copyright (c) 2024 Yury Kudryashov. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Yury Kudryashov
-/


/-!
# Continuity of `MeasureTheory.Lp.compMeasurePreserving`

In this file we prove that the composition of an `L^p` function `g`
with a continuous measure-preserving map `f` is continuous in both arguments.

First, we prove it for indicator functions,
in terms of convergence of `μ ((f a ⁻¹' s) ∆ (g ⁻¹' s))` to zero.

Then we prove the continuity of the function of two arguments
defined on `MeasureTheory.Lp E p ν × {f : C(X, Y) // MeasurePreserving f μ ν}`.

Finally, we provide dot notation convenience lemmas.
-/


open Filter Set MeasureTheory
open scoped ENNReal Topology symmDiff

variable {X Y : Type*}
  [TopologicalSpace X] [MeasurableSpace X] [BorelSpace X] [R1Space X]
  [TopologicalSpace Y] [MeasurableSpace Y] [BorelSpace Y] [R1Space Y]
  {μ : Measure X} {ν : Measure Y} [μ.InnerRegularCompactLTTop] [IsLocallyFiniteMeasure ν]

namespace MeasureTheory
namespace Lp

variable (μ ν)
variable (E : Type*) [NormedAddCommGroup E] {p : ℝ≥0∞} [Fact (1 ≤ p)]

/-- Let `X` and `Y` be R₁ topological spaces
with Borel σ-algebras and measures `μ` and `ν`, respectively.
Suppose that `μ` is inner regular for finite measure sets with respect to compact sets
and `ν` is a locally finite measure.
Let `1 ≤ p < ∞` be an extended nonnegative real number.
Then the composition of a function `g : Lp E p ν`
and a measure-preserving continuous function `f : C(X, Y)`
is continuous in both variables. -/
theorem compMeasurePreserving_continuous (hp : p ≠ ∞) :
    Continuous fun gf : Lp E p ν × {f : C(X, Y) // MeasurePreserving f μ ν} ↦
      compMeasurePreserving gf.2.1 gf.2.2 gf.1 := by
  have hp₀ : p ≠ 0 := (one_pos.trans_le Fact.out).ne'
  refine continuous_prod_of_dense_continuous_lipschitzWith _ 1
    (MeasureTheory.Lp.simpleFunc.dense hp) ?_ fun f ↦ (isometry_compMeasurePreserving f.2).lipschitz
  intro f hf
  lift f to Lp.simpleFunc E p ν using hf
  induction f using Lp.simpleFunc.induction hp₀ hp with
  | add hfp hgp _ ihf ihg => exact ihf.add ihg
  | @indicatorConst c s hs hνs =>
    dsimp only [Lp.simpleFunc.coe_indicatorConst, Lp.indicatorConstLp_compMeasurePreserving]
    refine continuous_indicatorConstLp_set hp fun f ↦ ?_
    apply tendsto_measure_symmDiff_preimage_nhds_zero continuousAt_subtype_val _ f.2
      hs.nullMeasurableSet hνs.ne
    exact .of_forall Subtype.property

end Lp

end MeasureTheory

variable {E : Type*} [NormedAddCommGroup E] {p : ℝ≥0∞} [Fact (1 ≤ p)]

theorem Filter.Tendsto.compMeasurePreservingLp {α : Type*} {l : Filter α}
    {f : α → Lp E p ν} {f₀ : Lp E p ν} {g : α → C(X, Y)} {g₀ : C(X, Y)}
    (hf : Tendsto f l (𝓝 f₀)) (hg : Tendsto g l (𝓝 g₀))
    (hgm : ∀ a, MeasurePreserving (g a) μ ν) (hgm₀ : MeasurePreserving g₀ μ ν) (hp : p ≠ ∞) :
    Tendsto (fun a ↦ Lp.compMeasurePreserving (g a) (hgm a) (f a)) l
      (𝓝 (Lp.compMeasurePreserving g₀ hgm₀ f₀)) := by
  have := (Lp.compMeasurePreserving_continuous μ ν E hp).tendsto ⟨f₀, g₀, hgm₀⟩
  replace hg : Tendsto (fun a ↦ ⟨g a, hgm a⟩ : α → {g : C(X, Y) // MeasurePreserving g μ ν})
      l (𝓝 ⟨g₀, hgm₀⟩) :=
    tendsto_subtype_rng.2 hg
  convert! this.comp (hf.prodMk_nhds hg)

variable {Z : Type*} [TopologicalSpace Z] {f : Z → Lp E p ν} {g : Z → C(X, Y)} {s : Set Z} {z : Z}

theorem ContinuousWithinAt.compMeasurePreservingLp (hf : ContinuousWithinAt f s z)
    (hg : ContinuousWithinAt g s z) (hgm : ∀ z, MeasurePreserving (g z) μ ν) (hp : p ≠ ∞) :
    ContinuousWithinAt (fun z ↦ Lp.compMeasurePreserving (g z) (hgm z) (f z)) s z :=
  Tendsto.compMeasurePreservingLp hf hg _ _ hp

theorem ContinuousAt.compMeasurePreservingLp (hf : ContinuousAt f z)
    (hg : ContinuousAt g z) (hgm : ∀ z, MeasurePreserving (g z) μ ν) (hp : p ≠ ∞) :
    ContinuousAt (fun z ↦ Lp.compMeasurePreserving (g z) (hgm z) (f z)) z :=
  Tendsto.compMeasurePreservingLp hf hg _ _ hp

theorem ContinuousOn.compMeasurePreservingLp (hf : ContinuousOn f s)
    (hg : ContinuousOn g s) (hgm : ∀ z, MeasurePreserving (g z) μ ν) (hp : p ≠ ∞) :
    ContinuousOn (fun z ↦ Lp.compMeasurePreserving (g z) (hgm z) (f z)) s := fun z hz ↦
  (hf z hz).compMeasurePreservingLp (hg z hz) hgm hp

theorem Continuous.compMeasurePreservingLp (hf : Continuous f) (hg : Continuous g)
    (hgm : ∀ z, MeasurePreserving (g z) μ ν) (hp : p ≠ ∞) :
    Continuous (fun z ↦ Lp.compMeasurePreserving (g z) (hgm z) (f z)) :=
  continuous_iff_continuousAt.mpr fun _ ↦
    hf.continuousAt.compMeasurePreservingLp hg.continuousAt hgm hp

/-
Copyright (c) 2022 Kim Morrison. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Kim Morrison
-/


/-!
# Von Neumann algebras

We give the "abstract" and "concrete" definitions of a von Neumann algebra.
We still have a major project ahead of us to show the equivalence between these definitions!

An abstract von Neumann algebra `WStarAlgebra M` is a C⋆ algebra with a Banach space predual,
per Sakai (1971).

A concrete von Neumann algebra `VonNeumannAlgebra H` (where `H` is a Hilbert space)
is a \*-closed subalgebra of bounded operators on `H` which is equal to its double commutant.

We'll also need to prove the von Neumann double commutant theorem,
that the concrete definition is equivalent to a \*-closed subalgebra which is weakly closed.
-/



universe u v

/-- Sakai's definition of a von Neumann algebra as a C⋆ algebra with a Banach space predual.

So that we can unambiguously talk about these "abstract" von Neumann algebras
in parallel with the "concrete" ones (weakly closed \*-subalgebras of B(H)),
we name this definition `WStarAlgebra`.

Note that for now we only assert the mere existence of predual, rather than picking one.
This may later prove problematic, and need to be revisited.
Picking one may cause problems with definitional unification of different instances.
One the other hand, not picking one means that the weak-\* topology
(which depends on a choice of predual) must be defined using the choice,
and we may be unhappy with the resulting opaqueness of the definition.
-/
class WStarAlgebra (M : Type u) [CStarAlgebra M] : Prop where
  /-- There is a Banach space `X` whose dual is isometrically (conjugate-linearly) isomorphic
  to the `WStarAlgebra`. -/
  exists_predual :
    ∃ (X : Type u) (_ : NormedAddCommGroup X) (_ : NormedSpace ℂ X) (_ : CompleteSpace X),
      Nonempty (StrongDual ℂ X ≃ₗᵢ⋆[ℂ] M)

-- TODO: Without this, `VonNeumannAlgebra` times out. Why?
/-- The double commutant definition of a von Neumann algebra,
as a \*-closed subalgebra of bounded operators on a Hilbert space,
which is equal to its double commutant.

Note that this definition is parameterised by the Hilbert space
on which the algebra faithfully acts, as is standard in the literature.
See `WStarAlgebra` for the abstract notion (a C⋆-algebra with Banach space predual).

Note this is a bundled structure, parameterised by the Hilbert space `H`,
rather than a typeclass on the type of elements.
Thus we can't say that the bounded operators `H →L[ℂ] H` form a `VonNeumannAlgebra`
(although we will later construct the instance `WStarAlgebra (H →L[ℂ] H)`),
and instead will use `⊤ : VonNeumannAlgebra H`.
-/
structure VonNeumannAlgebra (H : Type u) [NormedAddCommGroup H] [InnerProductSpace ℂ H]
    [CompleteSpace H] extends StarSubalgebra ℂ (H →L[ℂ] H) where
  /-- The double commutant (a.k.a. centralizer) of a `VonNeumannAlgebra` is itself. -/
  centralizer_centralizer' : Set.centralizer (Set.centralizer carrier) = carrier

/-- Consider a von Neumann algebra acting on a Hilbert space `H` as a \*-subalgebra of `H →L[ℂ] H`.
(That is, we forget that it is equal to its double commutant
or equivalently that it is closed in the weak and strong operator topologies.)
-/
add_decl_doc VonNeumannAlgebra.toStarSubalgebra

namespace VonNeumannAlgebra

variable {H : Type u} [NormedAddCommGroup H] [InnerProductSpace ℂ H] [CompleteSpace H]

instance instSetLike : SetLike (VonNeumannAlgebra H) (H →L[ℂ] H) where
  coe S := S.carrier
  coe_injective S T h := by obtain ⟨⟨⟨⟨⟨⟨_, _⟩, _⟩, _⟩, _⟩, _⟩, _⟩ := S; cases T; congr

instance : PartialOrder (VonNeumannAlgebra H) := .ofSetLike (VonNeumannAlgebra H) (H →L[ℂ] H)

noncomputable instance instStarMemClass : StarMemClass (VonNeumannAlgebra H) (H →L[ℂ] H) where
  star_mem {s} := s.star_mem'

instance instSubringClass : SubringClass (VonNeumannAlgebra H) (H →L[ℂ] H) where
  add_mem {s} := s.add_mem'
  mul_mem {s} := s.mul_mem'
  one_mem {s} := s.one_mem'
  zero_mem {s} := s.zero_mem'
  neg_mem {s} a ha := show -a ∈ s.toStarSubalgebra from neg_mem ha

@[simp]
theorem mem_carrier {S : VonNeumannAlgebra H} {x : H →L[ℂ] H} :
    x ∈ S.toStarSubalgebra ↔ x ∈ (S : Set (H →L[ℂ] H)) :=
  Iff.rfl

@[simp]
theorem coe_toStarSubalgebra (S : VonNeumannAlgebra H) :
    (S.toStarSubalgebra : Set (H →L[ℂ] H)) = S :=
  rfl

@[simp]
theorem coe_mk (S : StarSubalgebra ℂ (H →L[ℂ] H)) (h) :
    ((⟨S, h⟩ : VonNeumannAlgebra H) : Set (H →L[ℂ] H)) = S :=
  rfl

@[ext]
theorem ext {S T : VonNeumannAlgebra H} (h : ∀ x, x ∈ S ↔ x ∈ T) : S = T :=
  SetLike.ext h

@[simp]
theorem centralizer_centralizer (S : VonNeumannAlgebra H) :
    Set.centralizer (Set.centralizer (S : Set (H →L[ℂ] H))) = S :=
  S.centralizer_centralizer'

/-- The centralizer of a `VonNeumannAlgebra`, as a `VonNeumannAlgebra`. -/
noncomputable def commutant (S : VonNeumannAlgebra H) : VonNeumannAlgebra H where
  toStarSubalgebra := StarSubalgebra.centralizer ℂ (S : Set (H →L[ℂ] H))
  centralizer_centralizer' := by simp

@[simp]
theorem coe_commutant (S : VonNeumannAlgebra H) :
    ↑S.commutant = Set.centralizer (S : Set (H →L[ℂ] H)) := by
  simp [commutant]

@[simp]
theorem mem_commutant_iff {S : VonNeumannAlgebra H} {z : H →L[ℂ] H} :
    z ∈ S.commutant ↔ ∀ g ∈ S, g * z = z * g := by
  rw [← SetLike.mem_coe, coe_commutant]
  rfl

@[simp]
theorem commutant_commutant (S : VonNeumannAlgebra H) : S.commutant.commutant = S :=
  SetLike.coe_injective <| by simp

open ContinuousLinearMap in
/-- An idempotent is an element in a von Neumann algebra if and only if
its range and kernel are invariant under the commutant. -/
theorem IsIdempotentElem.mem_iff {e : H →L[ℂ] H} (h : IsIdempotentElem e)
    (S : VonNeumannAlgebra H) :
    e ∈ S ↔ ∀ y ∈ S.commutant,
      e.range ∈ Module.End.invtSubmodule y ∧ e.ker ∈ Module.End.invtSubmodule y := by
  conv_rhs => simp [← h.commute_iff, Commute.symm_iff (a := e), commute_iff_eq, ← mem_commutant_iff]

open VonNeumannAlgebra ContinuousLinearMap in
/-- A star projection is an element in a von Neumann algebra if and only if
its range is invariant under the commutant. -/
theorem IsStarProjection.mem_iff {e : H →L[ℂ] H} (he : IsStarProjection e)
    (S : VonNeumannAlgebra H) :
    e ∈ S ↔ ∀ y ∈ S.commutant, e.range ∈ Module.End.invtSubmodule y := by
  simp_rw [he.isIdempotentElem.mem_iff, he.isIdempotentElem.range_mem_invtSubmodule_iff,
    he.isIdempotentElem.ker_mem_invtSubmodule_iff, forall_and, and_iff_left_iff_imp, ← mul_def]
  intro h x hx
  simpa [he.isSelfAdjoint.star_eq] using! congr(star $(h _ (star_mem hx)))

end VonNeumannAlgebra


namespace CompactFourierKD
open MeasureTheory Measure
open scoped ComplexInnerProductSpace

section Haar

variable (G : Type*) [Group G] [TopologicalSpace G] [IsTopologicalGroup G]
  [CompactSpace G] [T2Space G] [MeasurableSpace G] [BorelSpace G]

/-- Haar probability, not the unnormalized arbitrary Haar choice. -/
noncomputable def compactKDhaar : Measure G := haarMeasure ⊤

instance : IsHaarMeasure (compactKDhaar G) := by
  unfold compactKDhaar
  infer_instance

instance : IsProbabilityMeasure (compactKDhaar G) := ⟨haarMeasure_self⟩

omit [T2Space G] in
theorem probabilityHaar_isMulRightInvariant (μ : Measure G)
    [IsHaarMeasure μ] [IsProbabilityMeasure μ] : IsMulRightInvariant μ := by
  constructor
  intro g
  let : IsProbabilityMeasure (Measure.map (· * g) μ) :=
    Measure.isProbabilityMeasure_map (measurable_mul_const g).aemeasurable
  exact isHaarMeasure_eq_of_isProbabilityMeasure _ _

noncomputable instance : IsMulRightInvariant (compactKDhaar G) :=
  probabilityHaar_isMulRightInvariant G _

end Haar

section Regular

variable {G : Type*} [Group G] [MeasurableSpace G] [MeasurableMul G]
  (μ : Measure G) [IsMulLeftInvariant μ]

noncomputable abbrev HaarL2 := Lp ℂ 2 μ
noncomputable abbrev HaarOp := HaarL2 μ →L[ℂ] HaarL2 μ

noncomputable def haarLeftRegIso (g : G) : HaarL2 μ →ₗᵢ[ℂ] HaarL2 μ :=
  Lp.compMeasurePreservingₗᵢ ℂ (fun x => g⁻¹*x) (measurePreserving_mul_left μ g⁻¹)

noncomputable def haarLeftReg (g : G) : HaarOp μ :=
  (haarLeftRegIso μ g).toContinuousLinearMap

theorem haarLeftReg_ae (g : G) (f : HaarL2 μ) :
    haarLeftReg μ g f =ᵐ[μ] fun x => f (g⁻¹*x) :=
  Lp.coeFn_compMeasurePreserving f (measurePreserving_mul_left μ g⁻¹)

variable [IsMulRightInvariant μ]

noncomputable def haarRightReg (g : G) : HaarOp μ :=
  (Lp.compMeasurePreservingₗᵢ ℂ (fun x => x*g) (measurePreserving_mul_right μ g) :
    HaarL2 μ →ₗᵢ[ℂ] HaarL2 μ).toContinuousLinearMap

omit [IsMulLeftInvariant μ] in
theorem haarRightReg_ae (g : G) (f : HaarL2 μ) :
    haarRightReg μ g f =ᵐ[μ] fun x => f (x*g) :=
  Lp.coeFn_compMeasurePreserving f (measurePreserving_mul_right μ g)

theorem haarLeftRightCommute (g k : G) :
    Commute (haarLeftReg μ g) (haarRightReg μ k) := by
  apply ContinuousLinearMap.ext
  intro f
  apply Lp.ext
  change (haarLeftReg μ g (haarRightReg μ k f):G→ℂ) =ᵐ[μ]
    haarRightReg μ k (haarLeftReg μ g f)
  filter_upwards [haarLeftReg_ae μ g (haarRightReg μ k f),
    haarRightReg_ae μ k (haarLeftReg μ g f),
    (measurePreserving_mul_left μ g⁻¹).quasiMeasurePreserving.ae_eq_comp (haarRightReg_ae μ k f),
    (measurePreserving_mul_right μ k).quasiMeasurePreserving.ae_eq_comp (haarLeftReg_ae μ g f)]
    with x h1 h2 h3 h4
  dsimp only [Function.comp_apply] at h3 h4
  rw [h1,h2,h3,h4,mul_assoc]

omit [IsMulRightInvariant μ] in
theorem haarLeftReg_inverse (g : G) (f : HaarL2 μ) :
    haarLeftReg μ g⁻¹ (haarLeftReg μ g f)=f := by
  apply Lp.ext
  filter_upwards [haarLeftReg_ae μ g⁻¹ (haarLeftReg μ g f),
    (measurePreserving_mul_left μ (g⁻¹)⁻¹).quasiMeasurePreserving.ae_eq_comp (haarLeftReg_ae μ g f)]
    with x h1 h2
  dsimp only [Function.comp_apply] at h2
  rw [h1,h2,inv_inv,← mul_assoc,inv_mul_cancel,one_mul]

omit [IsMulRightInvariant μ] in
@[simp] theorem star_haarLeftReg (g : G) :
    star (haarLeftReg μ g)=haarLeftReg μ g⁻¹ := by
  rw [ContinuousLinearMap.star_eq_adjoint,eq_comm,ContinuousLinearMap.eq_adjoint_iff]
  intro f h
  calc
    ⟪haarLeftReg μ g⁻¹ f,h⟫ = ⟪haarLeftReg μ g⁻¹ f,haarLeftReg μ g⁻¹ (haarLeftReg μ g h)⟫ :=
      congrArg (fun x => ⟪haarLeftReg μ g⁻¹ f,x⟫) (haarLeftReg_inverse μ g h).symm
    _ = ⟪f,haarLeftReg μ g h⟫ := (haarLeftRegIso μ g⁻¹).inner_map_map f _

omit [IsMulRightInvariant μ] in
/-- Concrete left-regular bicommutant on the actual Haar (L^2). -/
noncomputable def haarGroupVN : VonNeumannAlgebra (HaarL2 μ) where
  toStarSubalgebra :=
    StarSubalgebra.centralizer ℂ
      (StarSubalgebra.centralizer ℂ (Set.range (haarLeftReg μ)) : Set (HaarOp μ))
  centralizer_centralizer' := by
    change (↑(StarSubalgebra.centralizer ℂ
      (↑(StarSubalgebra.centralizer ℂ (Set.range (haarLeftReg μ))) : Set (HaarOp μ))) : Set (HaarOp μ)).centralizer.centralizer =
      (↑(StarSubalgebra.centralizer ℂ
      (↑(StarSubalgebra.centralizer ℂ (Set.range (haarLeftReg μ))) : Set (HaarOp μ))) : Set (HaarOp μ))
    rw [StarSubalgebra.coe_centralizer_centralizer]
    simp

omit [IsMulRightInvariant μ] in
theorem mem_haarGroupVN_iff (A : HaarOp μ) :
    A∈haarGroupVN μ ↔ A∈(Set.range (haarLeftReg μ)).centralizer.centralizer := by
  let L := Set.range (haarLeftReg μ)
  have hstar : star L = L := by
    ext B
    change star B ∈ L ↔ B ∈ L
    constructor
    · rintro ⟨g,hg⟩
      exact ⟨g⁻¹,by rw [←star_haarLeftReg,hg,star_star]⟩
    · rintro ⟨g,rfl⟩
      exact ⟨g⁻¹,(star_haarLeftReg μ g).symm⟩
  change A ∈ (↑(StarSubalgebra.centralizer ℂ
      (↑(StarSubalgebra.centralizer ℂ L) : Set (HaarOp μ))) : Set (HaarOp μ)) ↔
    A∈L.centralizer.centralizer
  rw [StarSubalgebra.coe_centralizer_centralizer,hstar,Set.union_self]

omit [IsMulRightInvariant μ] in
theorem haarLeftReg_mem_haarGroupVN (g : G) : haarLeftReg μ g∈haarGroupVN μ :=
  (mem_haarGroupVN_iff μ _).2 (Set.subset_centralizer_centralizer ⟨g,rfl⟩)

omit [IsMulRightInvariant μ] in
def InHaarFourierCenter (A : HaarOp μ) : Prop :=
  A∈haarGroupVN μ ∧ A∈(haarGroupVN μ).commutant

/-- Genuine central Fourier operators commute with both regular
actions. This is the exact operator premise used by both
profinite cross-coset arguments, without assuming it in the definition. -/
theorem haarFourierCenter_commutes_left_right (A : HaarOp μ)
    (hA : InHaarFourierCenter μ A) (g : G) :
    Commute A (haarLeftReg μ g) ∧ Commute A (haarRightReg μ g) := by
  constructor
  · exact Commute.symm ((VonNeumannAlgebra.mem_commutant_iff.1 hA.2) _
      (haarLeftReg_mem_haarGroupVN μ g))
  · have hR : haarRightReg μ g∈(Set.range (haarLeftReg μ)).centralizer := by
      rintro _ ⟨k,rfl⟩
      exact (haarLeftRightCommute μ k g).eq
    exact Commute.symm ((mem_haarGroupVN_iff μ _).1 hA.1 _ hR)

end Regular

end CompactFourierKD

namespace CompactFourierKD
open MeasureTheory Measure

section CentralConvolution

variable {G : Type*} [Group G] [TopologicalSpace G] [IsTopologicalGroup G]
  [CompactSpace G] [MeasurableSpace G] [BorelSpace G]

local notation "μ" => compactKDhaar G

/-- Strong continuity of genuine left translations on Haar L²,
using the pinned continuous pullback theorem. -/
theorem compactHaar_leftReg_strongContinuous (v : HaarL2 μ) :
    Continuous (fun g : G => haarLeftReg μ g v) := by
  let L (g : G) : C(G,G) := ⟨fun x => g⁻¹*x,by fun_prop⟩
  have hL : Continuous L := by
    apply ContinuousMap.continuous_of_continuous_uncurry
    change Continuous (fun u : G×G => u.1⁻¹*u.2)
    fun_prop
  let : Measure.Regular μ := by unfold compactKDhaar; infer_instance
  have h := (continuous_const : Continuous (fun _ : G => v)).compMeasurePreservingLp hL
    (fun g => measurePreserving_mul_left μ g⁻¹) (by norm_num : (2:ENNReal)≠⊤)
  exact h

omit [CompactSpace G] [BorelSpace G] in
private theorem haarLeftReg_mul_aux {H : Type*} [Group H] [MeasurableSpace H] [MeasurableMul H]
    (ν : Measure H) [IsMulLeftInvariant ν] (g h : H) (v : HaarL2 ν) :
    haarLeftReg ν (g*h) v=haarLeftReg ν g (haarLeftReg ν h v) := by
  apply Lp.ext
  filter_upwards [haarLeftReg_ae ν (g*h) v,haarLeftReg_ae ν g (haarLeftReg ν h v),
    (measurePreserving_mul_left ν g⁻¹).quasiMeasurePreserving.ae_eq_comp
      (haarLeftReg_ae ν h v)] with x h1 h2 h3
  dsimp only [Function.comp_apply] at h3
  rw [h1,h2,h3,mul_inv_rev,mul_assoc]

private theorem haarWeightedTranslation_integrable (χ : C(G,ℂ)) (v : HaarL2 μ) :
    Integrable (fun g : G => χ g • haarLeftReg μ g v) μ :=
  (χ.continuous.smul (compactHaar_leftReg_strongContinuous v)).integrable_of_hasCompactSupport
    (HasCompactSupport.of_compactSpace _)

/-- Strongly averaged convolution, i.e. the genuine operator used
to construct the central projection for one irreducible type. -/
noncomputable def haarWeightedLeftConvolution (χ : C(G,ℂ)) : HaarOp μ :=
  LinearMap.mkContinuous
    { toFun := fun v => ∫ g, χ g • haarLeftReg μ g v ∂μ
      map_add' := fun v w => by
        simp only [map_add,smul_add]
        exact integral_add (haarWeightedTranslation_integrable χ v)
          (haarWeightedTranslation_integrable χ w)
      map_smul' := fun a v => by
        simp only [map_smul,RingHom.id_apply]
        simp_rw [smul_comm (χ _) a,integral_smul] }
    ‖χ‖ (fun v => by
      change ‖∫ g, χ g • haarLeftReg μ g v ∂μ‖≤‖χ‖ * ‖v‖
      have hBound (g : G) : ‖χ g • haarLeftReg μ g v‖ ≤ ‖χ‖*‖v‖ := by
        rw [norm_smul]
        change ‖χ g‖ * ‖haarLeftRegIso μ g v‖ ≤ _
        rw [(haarLeftRegIso μ g).norm_map]
        exact mul_le_mul_of_nonneg_right (χ.norm_coe_le_norm g) (norm_nonneg _)
      have hbnd : ∀ᵐ (g : G) ∂μ, ‖χ g • haarLeftReg μ g v‖ ≤ ‖χ‖*‖v‖ :=
        Filter.Eventually.of_forall hBound
      simpa [Measure.real] using norm_integral_le_of_norm_le_const hbnd)

theorem haarWeightedLeftConvolution_apply (χ : C(G,ℂ)) (v : HaarL2 μ) :
    haarWeightedLeftConvolution χ v=∫ g, χ g • haarLeftReg μ g v ∂μ := rfl

/-- Bounded integration of actual regular translations lies in the
left group von Neumann algebra by its bicommutant definition. -/
theorem haarWeightedLeftConvolution_mem_haarGroupVN (χ : C(G,ℂ)) :
    haarWeightedLeftConvolution χ∈haarGroupVN μ := by
  apply (mem_haarGroupVN_iff μ _).2
  intro B hB
  apply ContinuousLinearMap.ext
  intro v
  change B (haarWeightedLeftConvolution χ v)=haarWeightedLeftConvolution χ (B v)
  rw [haarWeightedLeftConvolution_apply,haarWeightedLeftConvolution_apply,
    ←B.integral_comp_comm (haarWeightedTranslation_integrable χ v)]
  apply integral_congr_ae
  apply Filter.Eventually.of_forall
  intro g
  change B (χ g • haarLeftReg μ g v)=χ g • haarLeftReg μ g (B v)
  rw [map_smul]
  have hh := hB _ ⟨g,rfl⟩
  exact congrArg (fun w : HaarL2 μ => χ g • w) (DFunLike.congr_fun hh.symm v)

/-- Convolution by a continuous class function is in the actual
central Fourier algebra. No compact isotypic completeness is used. -/
theorem haarWeightedLeftConvolution_mem_center (χ : C(G,ℂ))
    (hχ : ∀ g h : G, χ (h*g*h⁻¹)=χ g) :
    InHaarFourierCenter μ (haarWeightedLeftConvolution χ) := by
  refine ⟨haarWeightedLeftConvolution_mem_haarGroupVN χ,?_⟩
  have hC : haarWeightedLeftConvolution χ∈(Set.range (haarLeftReg μ)).centralizer := by
    rintro _ ⟨h,rfl⟩
    apply ContinuousLinearMap.ext
    intro v
    change haarLeftReg μ h (haarWeightedLeftConvolution χ v)=
      haarWeightedLeftConvolution χ (haarLeftReg μ h v)
    rw [haarWeightedLeftConvolution_apply,haarWeightedLeftConvolution_apply,
      ←(haarLeftReg μ h).integral_comp_comm (haarWeightedTranslation_integrable χ v)]
    let K (g : G) := χ g • haarLeftReg μ (g*h) v
    let U := (MeasurableEquiv.mulLeft h).trans (MeasurableEquiv.mulRight h⁻¹)
    have hU : MeasurePreserving U μ μ :=
      (measurePreserving_mul_right μ h⁻¹).comp (measurePreserving_mul_left μ h)
    have hEq := hU.integral_comp' K
    calc
      (∫ g, haarLeftReg μ h (χ g • haarLeftReg μ g v) ∂μ) = ∫ g, K (U g) ∂μ := by
        apply integral_congr_ae
        apply Filter.Eventually.of_forall
        intro g
        simp only [map_smul,←haarLeftReg_mul_aux]
        change χ g • haarLeftReg μ (h*g) v=χ (h*g*h⁻¹) • haarLeftReg μ ((h*g*h⁻¹)*h) v
        rw [hχ,mul_assoc (h*g),inv_mul_cancel,mul_one]
      _ = ∫ g, K g ∂μ := hEq
      _ = ∫ g, χ g • haarLeftReg μ g (haarLeftReg μ h v) ∂μ := by
        simp only [K,haarLeftReg_mul_aux]
  exact VonNeumannAlgebra.mem_commutant_iff.mpr (fun B hB => (mem_haarGroupVN_iff μ B).mp hB _ hC |>.symm)

end CentralConvolution

end CompactFourierKD

namespace CompactFourierKD
open MeasureTheory Measure Module

section CompactSchur

variable {G V W : Type*} [Group G] [TopologicalSpace G] [IsTopologicalGroup G]
  [CompactSpace G] [MeasurableSpace G] [BorelSpace G]
  [NormedAddCommGroup V] [NormedSpace ℂ V] [FiniteDimensional ℂ V]
  [NormedAddCommGroup W] [NormedSpace ℂ W] [FiniteDimensional ℂ W]

/-- Irreducibility using actual invariant subspaces of a continuous
linear representation. -/
def compactRepresentationIrreducible (ρ : G →* (V →L[ℂ] V)) : Prop :=
  ∀ S : Submodule ℂ V, (∀ g v, v∈S → ρ g v∈S) → S=⊥ ∨ S=⊤

/-- Average a conjugated operator in the Bochner sense; this is the
compact analogue of the finite Reynolds intertwiner average. -/
noncomputable def compactHaarAverageIntertwiner
    (μ : Measure G) (ρ : G→*(V→L[ℂ]V)) (σ : G→*(W→L[ℂ]W))
    (T : V→L[ℂ]W) : V→L[ℂ]W :=
  ∫ g, (σ g).comp (T.comp (ρ g⁻¹)) ∂μ

omit [FiniteDimensional ℂ V] [FiniteDimensional ℂ W] in
private theorem compactHaar_conjugatedOperator_integrable
    (μ : Measure G) [IsFiniteMeasure μ]
    (ρ : G→*(V→L[ℂ]V)) (σ : G→*(W→L[ℂ]W))
    (hρ : Continuous ρ) (hσ : Continuous σ) (T : V→L[ℂ]W) :
    Integrable (fun g => (σ g).comp (T.comp (ρ g⁻¹))) μ :=
  (hσ.clm_comp ((hρ.comp continuous_inv).const_clm_comp T)).integrable_of_hasCompactSupport
    (HasCompactSupport.of_compactSpace _)

omit [FiniteDimensional ℂ V] in
theorem compactHaarAverageIntertwiner_apply
    (μ : Measure G) [IsFiniteMeasure μ]
    (ρ : G→*(V→L[ℂ]V)) (σ : G→*(W→L[ℂ]W))
    (hρ : Continuous ρ) (hσ : Continuous σ) (T : V→L[ℂ]W) (v : V) :
    compactHaarAverageIntertwiner μ ρ σ T v =
      ∫ g, σ g (T (ρ g⁻¹ v)) ∂μ := by
  let : CompleteSpace W := FiniteDimensional.complete ℂ W
  exact ((ContinuousLinearMap.apply ℂ W v).integral_comp_comm
    (compactHaar_conjugatedOperator_integrable μ ρ σ hρ hσ T)).symm

omit [FiniteDimensional ℂ V] in
/-- The actual compact Haar average is an intertwiner. -/
theorem compactHaarAverageIntertwiner_intertwines
    (μ : Measure G) [IsFiniteMeasure μ] [IsMulLeftInvariant μ]
    (ρ : G→*(V→L[ℂ]V)) (σ : G→*(W→L[ℂ]W))
    (hρ : Continuous ρ) (hσ : Continuous σ) (T : V→L[ℂ]W)
    (a : G) (v : V) :
    compactHaarAverageIntertwiner μ ρ σ T (ρ a v) =
      σ a (compactHaarAverageIntertwiner μ ρ σ T v) := by
  let : CompleteSpace W := FiniteDimensional.complete ℂ W
  have hInt : Integrable (fun g => σ g (T (ρ g⁻¹ v))) μ :=
    ((ContinuousLinearMap.apply ℂ W v).integrable_comp
      (compactHaar_conjugatedOperator_integrable μ ρ σ hρ hσ T))
  rw [compactHaarAverageIntertwiner_apply μ ρ σ hρ hσ T v,
    compactHaarAverageIntertwiner_apply μ ρ σ hρ hσ T (ρ a v),
    ←(σ a).integral_comp_comm hInt]
  let D (g : G) := σ g (T (ρ g⁻¹ (ρ a v)))
  let L := MeasurableEquiv.mulLeft a
  have hL : MeasurePreserving L μ μ := measurePreserving_mul_left μ a
  have h := hL.integral_comp' D
  rw [←h]
  apply integral_congr_ae
  apply Filter.Eventually.of_forall
  intro g
  change σ (a*g) (T (ρ (a*g)⁻¹ (ρ a v))) = σ a (σ g (T (ρ g⁻¹ v)))
  rw [map_mul,mul_inv_rev,map_mul]
  change σ a (σ g (T (ρ g⁻¹ (ρ a⁻¹ (ρ a v))))) = _
  rw [←show ρ (a⁻¹*a) v=ρ a⁻¹ (ρ a v) by rw [map_mul];rfl,inv_mul_cancel,map_one]
  rfl

omit [TopologicalSpace G] [IsTopologicalGroup G] [CompactSpace G] [MeasurableSpace G] [BorelSpace G] in
/-- Schur scalarity over ℂ, obtained from a nonzero eigenspace
rather than assuming an isotypic decomposition. -/
theorem compactSchur_scalar_of_intertwines [Nontrivial V]
    (ρ : G→*(V→L[ℂ]V)) (hIrr : compactRepresentationIrreducible ρ)
    (T : V→L[ℂ]V) (hInter : ∀ (g : G) (v : V), T (ρ g v)=ρ g (T v)) :
    ∃ c : ℂ, T=c • 1 := by
  have hSpect : (spectrum ℂ T.toLinearMap).Nonempty :=
    spectrum.nonempty_of_isAlgClosed_of_finiteDimensional ℂ T.toLinearMap
  obtain ⟨c,hc⟩ := hSpect
  have hEigen := Module.End.hasEigenvalue_iff_mem_spectrum.mpr hc
  have hStable : ∀ g v, v∈Module.End.eigenspace T.toLinearMap c →
      ρ g v∈Module.End.eigenspace T.toLinearMap c := by
    intro g v hv
    have hv' : T v=c • v := Module.End.mem_eigenspace_iff.mp hv
    apply Module.End.mem_eigenspace_iff.mpr
    change T (ρ g v) = c • ρ g v
    rw [hInter,hv',map_smul]
  have hTop := (hIrr _ hStable).resolve_left (Module.End.hasEigenvalue_iff.mp hEigen)
  refine ⟨c,ContinuousLinearMap.ext fun v => ?_⟩
  have hv : v∈Module.End.eigenspace T.toLinearMap c := hTop.symm ▸ Submodule.mem_top
  exact Module.End.mem_eigenspace_iff.mp hv

omit [TopologicalSpace G] [IsTopologicalGroup G] [CompactSpace G] [MeasurableSpace G] [BorelSpace G] [FiniteDimensional ℂ W] in
/-- Schur zero for a pair of inequivalent bounded finite-dimensional
representations. Equivalence here is an explicit continuous linear
equivalence intertwining every group element. -/
theorem compactSchur_zero_of_inequivalent
    (ρ : G→*(V→L[ℂ]V)) (σ : G→*(W→L[ℂ]W))
    (hρ : compactRepresentationIrreducible ρ) (hσ : compactRepresentationIrreducible σ)
    (hNE : ¬∃ T : V≃L[ℂ]W, ∀ g v, T (ρ g v)=σ g (T v))
    (T : V→L[ℂ]W) (hInter : ∀ g v, T (ρ g v)=σ g (T v)) :
    T=0 := by
  classical
  by_contra hNonzero
  have hKer : T.toLinearMap.ker=⊥ := by
    refine (hρ _ ?_).resolve_right ?_
    · intro g v hv
      change T v=0 at hv
      change T (ρ g v)=0
      rw [hInter,hv,map_zero]
    · intro hTop
      apply hNonzero
      apply ContinuousLinearMap.ext
      intro v
      have hh : v∈T.toLinearMap.ker := hTop.symm ▸ Submodule.mem_top
      exact hh
  have hRange : T.toLinearMap.range=⊤ := by
    refine (hσ _ ?_).resolve_left ?_
    · rintro g _ ⟨v,rfl⟩
      exact ⟨ρ g v,hInter g v⟩
    · intro hBot
      apply hNonzero
      apply ContinuousLinearMap.ext
      intro v
      have hh : T v ∈ T.toLinearMap.range := ⟨v,rfl⟩
      rw [hBot] at hh
      exact (Submodule.mem_bot ℂ).mp hh
  apply hNE
  refine ⟨(LinearEquiv.ofBijective T.toLinearMap
    ⟨LinearMap.ker_eq_bot.mp hKer,LinearMap.range_eq_top.mp hRange⟩).toContinuousLinearEquiv,?_⟩
  exact hInter

end CompactSchur

end CompactFourierKD


namespace CompactFourierKD
open MeasureTheory Measure Module
open scoped BigOperators

section CompactCharacterAction

variable {G V W : Type*} [Group G] [TopologicalSpace G] [IsTopologicalGroup G]
  [CompactSpace G] [MeasurableSpace G] [BorelSpace G]
  [NormedAddCommGroup V] [NormedSpace ℂ V] [FiniteDimensional ℂ V]
  [NormedAddCommGroup W] [NormedSpace ℂ W] [FiniteDimensional ℂ W]

noncomputable def compactContinuousTrace : (V→L[ℂ]V)→L[ℂ]ℂ :=
  ((LinearMap.trace ℂ V).comp (ContinuousLinearMap.coeLM ℂ)).toContinuousLinearMap

/-- Trace of the actual continuous representation matrix. -/
noncomputable def compactRepresentationCharacter (ρ : G→*(V→L[ℂ]V)) (g : G) : ℂ :=
  compactContinuousTrace (ρ g)

omit [TopologicalSpace G] [IsTopologicalGroup G] [CompactSpace G] [MeasurableSpace G] [BorelSpace G] in
theorem compactRepresentationCharacter_class (ρ : G→*(V→L[ℂ]V)) (a g : G) :
    compactRepresentationCharacter ρ (a*g*a⁻¹)=compactRepresentationCharacter ρ g := by
  unfold compactRepresentationCharacter
  change LinearMap.trace ℂ V (ρ (a*g*a⁻¹)).toLinearMap =
    LinearMap.trace ℂ V (ρ g).toLinearMap
  rw [map_mul,map_mul]
  change LinearMap.trace ℂ V (((ρ a).toLinearMap*(ρ g).toLinearMap)*(ρ a⁻¹).toLinearMap) = _
  rw [LinearMap.trace_mul_comm,←mul_assoc]
  change LinearMap.trace ℂ V (((ρ a⁻¹ * ρ a) * ρ g).toLinearMap)=_
  rw [←map_mul,inv_mul_cancel,map_one,one_mul]

private theorem compactHaarAverageIntertwiner_preserves_trace
    (μ : Measure G) [IsProbabilityMeasure μ] (ρ : G→*(V→L[ℂ]V))
    (hρ : Continuous ρ) (T : V→L[ℂ]V) :
    compactContinuousTrace (compactHaarAverageIntertwiner μ ρ ρ T)=compactContinuousTrace T := by
  let : CompleteSpace V := FiniteDimensional.complete ℂ V
  change compactContinuousTrace (∫ g, (ρ g).comp (T.comp (ρ g⁻¹)) ∂μ) = _
  rw [←compactContinuousTrace.integral_comp_comm
    (compactHaar_conjugatedOperator_integrable μ ρ ρ hρ hρ T)]
  have h : ∀ g : G, compactContinuousTrace ((ρ g).comp (T.comp (ρ g⁻¹))) =
      compactContinuousTrace T := by
    intro g
    change LinearMap.trace ℂ V ((ρ g).toLinearMap*(T.toLinearMap*(ρ g⁻¹).toLinearMap)) =
      LinearMap.trace ℂ V T.toLinearMap
    rw [LinearMap.trace_mul_comm,mul_assoc]
    change LinearMap.trace ℂ V ((T*(ρ g⁻¹*ρ g)).toLinearMap)=_
    rw [←map_mul,inv_mul_cancel,map_one,mul_one]
  simp [h,integral_const,Measure.real]

/-- The exact averaging constant for an irreducible complex type. -/
theorem compactHaarAverageIntertwiner_eq_trace_smul [Nontrivial V]
    (μ : Measure G) [IsProbabilityMeasure μ] [IsMulLeftInvariant μ]
    (ρ : G→*(V→L[ℂ]V)) (hρ : Continuous ρ) (hIrr : compactRepresentationIrreducible ρ)
    (T : V→L[ℂ]V) :
    compactHaarAverageIntertwiner μ ρ ρ T =
      (compactContinuousTrace T / (finrank ℂ V : ℂ)) • 1 := by
  obtain ⟨c,hc⟩ := compactSchur_scalar_of_intertwines ρ hIrr _
    (compactHaarAverageIntertwiner_intertwines μ ρ ρ hρ hρ T)
  have ht := compactHaarAverageIntertwiner_preserves_trace μ ρ hρ T
  rw [hc,map_smul] at ht
  change c * LinearMap.trace ℂ V (1 : V→ₗ[ℂ]V) = _ at ht
  rw [LinearMap.trace_one] at ht
  have hd : (finrank ℂ V : ℂ) ≠ 0 := by exact_mod_cast finrank_pos.ne'
  rw [hc,(eq_div_iff hd).mpr ht]

private theorem compactHaar_characterWeight_eq_sum_intertwiners
    {ι : Type*} [Fintype ι] (b : Basis ι ℂ V)
    (μ : Measure G) [IsFiniteMeasure μ]
    (ρ : G→*(V→L[ℂ]V)) (σ : G→*(W→L[ℂ]W))
    (hρ : Continuous ρ) (hσ : Continuous σ) (v : W) :
    (∫ g, compactRepresentationCharacter ρ g⁻¹ • σ g v ∂μ) =
      ∑ i : ι, compactHaarAverageIntertwiner μ ρ σ
        ((b.coord i).toContinuousLinearMap.smulRight v) (b i) := by
  classical
  let : CompleteSpace W := FiniteDimensional.complete ℂ W
  simp_rw [compactHaarAverageIntertwiner_apply μ ρ σ hρ hσ]
  let F (i : ι) (g : G) :=
    σ g (((b.coord i).toContinuousLinearMap.smulRight v) (ρ g⁻¹ (b i)))
  have hF (i : ι) : Integrable (F i) μ :=
    (ContinuousLinearMap.apply ℂ W (b i)).integrable_comp
      (compactHaar_conjugatedOperator_integrable μ ρ σ hρ hσ
        ((b.coord i).toContinuousLinearMap.smulRight v))
  rw [←integral_finsetSum Finset.univ (fun i _ => hF i)]
  apply integral_congr_ae
  apply Filter.Eventually.of_forall
  intro g
  change _ = ∑ i : ι, F i g
  simp only [F,ContinuousLinearMap.smulRight_apply,map_smul,
    ←Finset.sum_smul]
  congr 1
  change LinearMap.trace ℂ V (ρ g⁻¹).toLinearMap =
    ∑ i : ι, b.coord i (ρ g⁻¹ (b i))
  rw [LinearMap.trace_eq_matrix_trace ℂ b]
  simp only [Matrix.trace,Matrix.diag,LinearMap.toMatrix_apply,Basis.coord_apply]
  rfl

/-- Genuine compact Haar matrix coefficient filter: an inverse character
of one irreducible type is exactly zero on an inequivalent type. -/
theorem compactHaar_characterWeight_zero_of_inequivalent
    (μ : Measure G) [IsFiniteMeasure μ] [IsMulLeftInvariant μ]
    (ρ : G→*(V→L[ℂ]V)) (σ : G→*(W→L[ℂ]W))
    (hρ : Continuous ρ) (hσ : Continuous σ)
    (hρi : compactRepresentationIrreducible ρ) (hσi : compactRepresentationIrreducible σ)
    (hNE : ¬∃ T : V≃L[ℂ]W, ∀ g v, T (ρ g v)=σ g (T v))
    (v : W) :
    (∫ g, compactRepresentationCharacter ρ g⁻¹ • σ g v ∂μ)=0 := by
  classical
  rw [compactHaar_characterWeight_eq_sum_intertwiners (finBasis ℂ V) μ ρ σ hρ hσ]
  apply Finset.sum_eq_zero
  intro i _
  rw [compactSchur_zero_of_inequivalent ρ σ hρi hσi hNE _
    (compactHaarAverageIntertwiner_intertwines μ ρ σ hρ hσ _)]
  rfl

/-- Genuine inverse-character kernel acts on its own irreducible representation
by the inverse of its dimension. No isotypic completeness is used. -/
theorem compactHaar_characterWeight_self [Nontrivial V]
    (μ : Measure G) [IsProbabilityMeasure μ] [IsMulLeftInvariant μ]
    (ρ : G→*(V→L[ℂ]V)) (hρ : Continuous ρ) (hIrr : compactRepresentationIrreducible ρ)
    (v : V) :
    (∫ g, compactRepresentationCharacter ρ g⁻¹ • ρ g v ∂μ)=
      (finrank ℂ V : ℂ)⁻¹ • v := by
  classical
  let b := finBasis ℂ V
  rw [compactHaar_characterWeight_eq_sum_intertwiners b μ ρ ρ hρ hρ]
  simp only [compactHaarAverageIntertwiner_eq_trace_smul μ ρ hρ hIrr,
    _root_.smul_apply,one_apply_eq_self]
  have h(i : Fin (finrank ℂ V)) :
      compactContinuousTrace ((b.coord i).toContinuousLinearMap.smulRight v) =
        b.coord i v := by
    change LinearMap.trace ℂ V ((b.coord i).smulRight v)=_
    exact LinearMap.trace_smulRight (b.coord i) v
  simp_rw [h,div_eq_mul_inv,mul_comm _ ((finrank ℂ V : ℂ)⁻¹),mul_smul,←Finset.smul_sum]
  simpa only [Basis.coord_apply] using
    congrArg (fun u : V => (finrank ℂ V : ℂ)⁻¹ • u) (Basis.sum_repr b v)

end CompactCharacterAction

end CompactFourierKD


namespace CompactFourierKD
open MeasureTheory Measure Module

section ContinuousHaarConvolution

variable {G : Type*} [Group G] [TopologicalSpace G] [IsTopologicalGroup G]
  [CompactSpace G] [MeasurableSpace G] [BorelSpace G]
local notation "ν" => compactKDhaar G

noncomputable def compactHaarContinuousConvolutionIntegrand (χ f : C(G,ℂ)) (g : G) :
    C(G,ℂ) :=
  ⟨fun x => χ g * f (g⁻¹*x), continuous_const.mul
    (f.continuous.comp (continuous_const.mul continuous_id))⟩

private theorem compactHaarContinuousConvolutionIntegrand_integrable (χ f : C(G,ℂ)) :
    Integrable (compactHaarContinuousConvolutionIntegrand χ f) ν := by
  have hc : Continuous (compactHaarContinuousConvolutionIntegrand χ f) := by
    apply ContinuousMap.continuous_of_continuous_uncurry
    change Continuous (fun u : G×G => χ u.1 * f (u.1⁻¹*u.2))
    fun_prop
  exact hc.integrable_of_hasCompactSupport (HasCompactSupport.of_compactSpace _)

/-- The actual continuous representative of convolution of two continuous
compact Haar functions. This is not an assumption on representative evaluation. -/
noncomputable def compactHaarContinuousConvolution (χ f : C(G,ℂ)) : C(G,ℂ) :=
  ∫ g, compactHaarContinuousConvolutionIntegrand χ f g ∂ν

theorem compactHaarContinuousConvolution_apply (χ f : C(G,ℂ)) (x : G) :
    compactHaarContinuousConvolution χ f x =
      ∫ g, χ g * f (g⁻¹*x) ∂ν := by
  exact ((ContinuousMap.evalCLM ℂ x).integral_comp_comm
    (compactHaarContinuousConvolutionIntegrand_integrable χ f)).symm

private theorem compactHaarContinuousConvolutionIntegrand_toLp (χ f : C(G,ℂ)) (g : G) :
    ContinuousMap.toLp 2 ν ℂ (compactHaarContinuousConvolutionIntegrand χ f g) =
      χ g • haarLeftReg ν g (ContinuousMap.toLp 2 ν ℂ f) := by
  let T : C(G,ℂ) →L[ℂ] HaarL2 ν := ContinuousMap.toLp 2 ν ℂ
  let V := f.coeFn_toLp ν (𝕜:=ℂ) (p:=2)
  apply Lp.ext
  filter_upwards [ContinuousMap.coeFn_toLp ν (𝕜:=ℂ) (p:=2)
    (compactHaarContinuousConvolutionIntegrand χ f g),
    Lp.coeFn_smul (χ g) (haarLeftReg ν g (T f)),haarLeftReg_ae ν g (T f),
    (measurePreserving_mul_left ν g⁻¹).quasiMeasurePreserving.ae_eq_comp V] with x hx hs hL hv
  dsimp only [Function.comp_apply] at hv
  rw [hx,hs,Pi.smul_apply,smul_eq_mul,hL,hv]
  rfl

/-- Weighted actual Haar L² convolution agrees with the actual continuous
representative when the input is continuous. -/
theorem compactHaarWeightedConvolution_toLp (χ f : C(G,ℂ)) :
    haarWeightedLeftConvolution χ (ContinuousMap.toLp 2 ν ℂ f) =
      ContinuousMap.toLp 2 ν ℂ (compactHaarContinuousConvolution χ f) := by
  let T : C(G,ℂ) →L[ℂ] HaarL2 ν := ContinuousMap.toLp 2 ν ℂ
  rw [haarWeightedLeftConvolution_apply]
  change _ = T (∫ g, compactHaarContinuousConvolutionIntegrand χ f g ∂ν)
  rw [←T.integral_comp_comm (compactHaarContinuousConvolutionIntegrand_integrable χ f)]
  exact integral_congr_ae (Filter.Eventually.of_forall
    (fun g => (compactHaarContinuousConvolutionIntegrand_toLp χ f g).symm))

end ContinuousHaarConvolution

section ActualHaarNamedType

variable {G V W : Type*} [Group G] [TopologicalSpace G] [IsTopologicalGroup G]
  [CompactSpace G] [MeasurableSpace G] [BorelSpace G]
  [NormedAddCommGroup V] [NormedSpace ℂ V] [FiniteDimensional ℂ V]
  [NormedAddCommGroup W] [NormedSpace ℂ W] [FiniteDimensional ℂ W]
local notation "ν" => compactKDhaar G

/-- The exact dimension-normalized inverse-character kernel. -/
noncomputable def compactIrrepHaarKernel (ρ : G→*(V→L[ℂ]V))
    (hρ : Continuous ρ) : C(G,ℂ) :=
  ⟨fun g => (finrank ℂ V : ℂ)*compactRepresentationCharacter ρ g⁻¹,
    continuous_const.mul (compactContinuousTrace.continuous.comp (hρ.comp continuous_inv))⟩

/-- A genuine coefficient of a bounded continuous representation as
a continuous function on the compact group. -/
noncomputable def compactIrrepHaarCoefficient (σ : G→*(W→L[ℂ]W))
    (hσ : Continuous σ) (l : W→L[ℂ]ℂ) (v : W) : C(G,ℂ) :=
  ⟨fun x => l (σ x⁻¹ v), l.continuous.comp ((hσ.comp continuous_inv).clm_apply continuous_const)⟩

theorem compactIrrepHaarKernel_mem_center (ρ : G→*(V→L[ℂ]V)) (hρ : Continuous ρ) :
    InHaarFourierCenter ν (haarWeightedLeftConvolution (compactIrrepHaarKernel ρ hρ)) := by
  apply haarWeightedLeftConvolution_mem_center
  intro g h
  change (finrank ℂ V : ℂ)*compactRepresentationCharacter ρ (h*g*h⁻¹)⁻¹ =
    (finrank ℂ V : ℂ)*compactRepresentationCharacter ρ g⁻¹
  rw [show (h*g*h⁻¹)⁻¹=h*g⁻¹*h⁻¹ by group,compactRepresentationCharacter_class]

private theorem compactIrrepHaarConvolution_eval
    (ρ : G→*(V→L[ℂ]V)) (σ : G→*(W→L[ℂ]W))
    (hρ : Continuous ρ) (hσ : Continuous σ) (l : W→L[ℂ]ℂ) (v : W) (x : G) :
    compactHaarContinuousConvolution (compactIrrepHaarKernel ρ hρ)
      (compactIrrepHaarCoefficient σ hσ l v) x =
      (finrank ℂ V : ℂ)*l (σ x⁻¹ (∫ g, compactRepresentationCharacter ρ g⁻¹ • σ g v ∂ν)) := by
  let S := l.comp (σ x⁻¹)
  let F (g : G) := compactRepresentationCharacter ρ g⁻¹ • σ g v
  have hCont : Continuous F :=
    (compactContinuousTrace.continuous.comp (hρ.comp continuous_inv)).smul
      (hσ.clm_apply continuous_const)
  have hInt : Integrable F ν := hCont.integrable_of_hasCompactSupport (HasCompactSupport.of_compactSpace _)
  let : CompleteSpace W := FiniteDimensional.complete ℂ W
  rw [compactHaarContinuousConvolution_apply]
  change _ = (finrank ℂ V : ℂ) • S (∫ g, F g ∂ν)
  rw [←S.integral_comp_comm hInt,←integral_smul]
  apply integral_congr_ae
  apply Filter.Eventually.of_forall
  intro g
  change ((finrank ℂ V : ℂ)*compactRepresentationCharacter ρ g⁻¹)*
      l (σ (g⁻¹*x)⁻¹ v) =
    (finrank ℂ V : ℂ) • S (compactRepresentationCharacter ρ g⁻¹ • σ g v)
  rw [mul_inv_rev,inv_inv,map_mul,map_smul,smul_eq_mul,smul_eq_mul,mul_assoc]
  rfl

/-- The actual Haar L² central filter fixes every coefficient of its
own type, with no assumed completeness of the character basis. -/
theorem compactIrrepHaarKernel_fixes_own_coefficients [Nontrivial V]
    (ρ : G→*(V→L[ℂ]V)) (hρ : Continuous ρ) (hIrr : compactRepresentationIrreducible ρ)
    (l : V→L[ℂ]ℂ) (v : V) :
    haarWeightedLeftConvolution (compactIrrepHaarKernel ρ hρ)
      (ContinuousMap.toLp 2 ν ℂ (compactIrrepHaarCoefficient ρ hρ l v)) =
      ContinuousMap.toLp 2 ν ℂ (compactIrrepHaarCoefficient ρ hρ l v) := by
  rw [compactHaarWeightedConvolution_toLp]
  congr 1
  ext x
  rw [compactIrrepHaarConvolution_eval,compactHaar_characterWeight_self ν ρ hρ hIrr,map_smul,map_smul]
  have hn : (finrank ℂ V : ℂ)≠0 := by exact_mod_cast finrank_pos.ne'
  rw [smul_eq_mul,←mul_assoc,mul_inv_cancel₀ hn,one_mul]
  rfl

/-- The same exact Haar L² filter annihilates coefficients of every
inequivalent irreducible type. -/
theorem compactIrrepHaarKernel_kills_inequivalent_coefficients
    (ρ : G→*(V→L[ℂ]V)) (σ : G→*(W→L[ℂ]W))
    (hρ : Continuous ρ) (hσ : Continuous σ)
    (hρi : compactRepresentationIrreducible ρ) (hσi : compactRepresentationIrreducible σ)
    (hNE : ¬∃ T : V≃L[ℂ]W, ∀ g v, T (ρ g v)=σ g (T v)) (l : W→L[ℂ]ℂ) (v : W) :
    haarWeightedLeftConvolution (compactIrrepHaarKernel ρ hρ)
      (ContinuousMap.toLp 2 ν ℂ (compactIrrepHaarCoefficient σ hσ l v)) =0 := by
  rw [compactHaarWeightedConvolution_toLp,←map_zero (ContinuousMap.toLp 2 ν ℂ)]
  congr 1
  ext x
  rw [compactIrrepHaarConvolution_eval,
    compactHaar_characterWeight_zero_of_inequivalent ν ρ σ hρ hσ hρi hσi hNE,
    map_zero,map_zero,mul_zero]
  rfl

end ActualHaarNamedType

end CompactFourierKD


namespace CompactFourierKD
open MeasureTheory Measure Module
open scoped BigOperators

section CompactConvolutionComposition

variable {G : Type*} [Group G] [TopologicalSpace G] [IsTopologicalGroup G]
  [CompactSpace G] [MeasurableSpace G] [BorelSpace G]
local notation "ν" => compactKDhaar G

/-- Bochner convolution composition on the entire actual Haar L²
space, not just on the dense coefficient space. -/
theorem compactHaarWeightedConvolution_mul (χ ψ : C(G,ℂ)) :
    haarWeightedLeftConvolution χ * haarWeightedLeftConvolution ψ =
      haarWeightedLeftConvolution (compactHaarContinuousConvolution χ ψ) := by
  apply ContinuousLinearMap.ext
  intro v
  change haarWeightedLeftConvolution χ (haarWeightedLeftConvolution ψ v)=_
  rw [haarWeightedLeftConvolution_apply χ,haarWeightedLeftConvolution_apply (compactHaarContinuousConvolution χ ψ)]
  let F (g h : G) := (χ g*ψ h) • haarLeftReg ν (g*h) v
  have hF (g : G) :
      χ g • haarLeftReg ν g (haarWeightedLeftConvolution ψ v) = ∫ h, F g h ∂ν := by
    rw [haarWeightedLeftConvolution_apply,
      ←(haarLeftReg ν g).integral_comp_comm (haarWeightedTranslation_integrable ψ v),←integral_smul]
    apply integral_congr_ae
    apply Filter.Eventually.of_forall
    intro h
    change χ g • haarLeftReg ν g (ψ h • haarLeftReg ν h v)=F g h
    rw [map_smul,smul_smul,←haarLeftReg_mul_aux]
  let D (g x : G) := (χ g*ψ (g⁻¹*x)) • haarLeftReg ν x v
  have hD (g : G) : (∫ h, F g h ∂ν) = ∫ x, D g x ∂ν := by
    let L := MeasurableEquiv.mulLeft g
    have hL : MeasurePreserving L ν ν := measurePreserving_mul_left ν g
    refine (integral_congr_ae (Filter.Eventually.of_forall fun h => ?_)).trans (hL.integral_comp' (D g))
    change (χ g*ψ h) • haarLeftReg ν (g*h) v =
      (χ g*ψ (g⁻¹*(g*h))) • haarLeftReg ν (g*h) v
    rw [inv_mul_cancel_left]
  simp_rw [hF,hD]
  have hdCont : Continuous (Function.uncurry D) := by
    have hc : Continuous (fun y : G×G => χ y.1*ψ (y.1⁻¹*y.2)) := by fun_prop
    exact hc.smul ((compactHaar_leftReg_strongContinuous v).comp continuous_snd)
  rw [integral_integral_swap_of_hasCompactSupport hdCont (HasCompactSupport.of_compactSpace _)]
  apply integral_congr_ae
  apply Filter.Eventually.of_forall
  intro x
  change (∫ g, D g x ∂ν) = (compactHaarContinuousConvolution χ ψ) x • haarLeftReg ν x v
  rw [compactHaarContinuousConvolution_apply]
  exact integral_smul_const (fun g : G => χ g*ψ (g⁻¹*x)) (haarLeftReg ν x v)

end CompactConvolutionComposition

section CompactCharacterOrthoprojector

variable {G V : Type*} [Group G] [TopologicalSpace G] [IsTopologicalGroup G]
  [CompactSpace G] [MeasurableSpace G] [BorelSpace G]
  [NormedAddCommGroup V] [NormedSpace ℂ V] [FiniteDimensional ℂ V] [Nontrivial V]
local notation "ν" => compactKDhaar G

omit [CompactSpace G] [MeasurableSpace G] [BorelSpace G] [Nontrivial V] in
/-- The represented inverse character is a finite sum of its own class's
genuine matrix coefficients. -/
private theorem compactIrrepHaarKernel_eq_sum_coefficients
    (ρ : G→*(V→L[ℂ]V)) (hρ : Continuous ρ) :
    let b := finBasis ℂ V
    compactIrrepHaarKernel ρ hρ = (finrank ℂ V : ℂ) •
      ∑ i, compactIrrepHaarCoefficient ρ hρ (b.coord i).toContinuousLinearMap (b i) := by
  classical
  dsimp only
  let b := finBasis ℂ V
  ext g
  change (finrank ℂ V : ℂ)*compactRepresentationCharacter ρ g⁻¹ = _
  rw [ContinuousMap.smul_apply,smul_eq_mul]
  congr 1
  calc
    compactRepresentationCharacter ρ g⁻¹ =
        ∑ i : Fin (finrank ℂ V), b.coord i (ρ g⁻¹ (b i)) := by
      change LinearMap.trace ℂ V (ρ g⁻¹).toLinearMap=_
      rw [LinearMap.trace_eq_matrix_trace ℂ b]
      simp only [Matrix.trace,Matrix.diag,LinearMap.toMatrix_apply,Basis.coord_apply]
      rfl
    _ = _ := by
      rw [ContinuousMap.sum_apply]
      rfl

private theorem compactIrrepHaarKernel_idempotent_convolution
    (ρ : G→*(V→L[ℂ]V)) (hρ : Continuous ρ) (hIrr : compactRepresentationIrreducible ρ) :
    compactHaarContinuousConvolution (compactIrrepHaarKernel ρ hρ) (compactIrrepHaarKernel ρ hρ) =
      compactIrrepHaarKernel ρ hρ := by
  classical
  let χ := compactIrrepHaarKernel ρ hρ
  let P := haarWeightedLeftConvolution χ
  let T : C(G,ℂ)→L[ℂ]HaarL2 ν := ContinuousMap.toLp 2 ν ℂ
  apply ContinuousMap.toLp_injective ν (p:=2) (𝕜:=ℂ)
  change T (compactHaarContinuousConvolution χ χ)=T χ
  rw [←compactHaarWeightedConvolution_toLp χ χ]
  change P (T χ) = T χ
  let b := finBasis ℂ V
  let F (i : Fin (finrank ℂ V)) :=
    compactIrrepHaarCoefficient ρ hρ (b.coord i).toContinuousLinearMap (b i)
  have hF : T χ=(finrank ℂ V : ℂ) • ∑ i, T (F i) := by
    change T (compactIrrepHaarKernel ρ hρ) = _
    rw [compactIrrepHaarKernel_eq_sum_coefficients ρ hρ,map_smul,_root_.map_sum]
  rw [hF,map_smul,_root_.map_sum]
  congr 1
  apply Finset.sum_congr rfl
  intro i _
  exact compactIrrepHaarKernel_fixes_own_coefficients ρ hρ hIrr (b.coord i).toContinuousLinearMap (b i)

/-- Genuine central orthogonal projection onto an irreducible class:
normality follows from actual VN-centrality, and idempotence follows
from the compact character convolution identity on all Haar L².
This does not import or assume a global isotypic decomposition. -/
theorem compactIrrepHaarKernel_isStarProjection
    (ρ : G→*(V→L[ℂ]V)) (hρ : Continuous ρ) (hIrr : compactRepresentationIrreducible ρ) :
    IsStarProjection (haarWeightedLeftConvolution (compactIrrepHaarKernel ρ hρ)) := by
  let χ := compactIrrepHaarKernel ρ hρ
  let P := haarWeightedLeftConvolution χ
  have hC := compactIrrepHaarKernel_mem_center ρ hρ
  change IsStarProjection P
  apply ContinuousLinearMap.isStarProjection_iff_isIdempotentElem_and_isStarNormal.mpr
  constructor
  · change P*P=P
    exact (compactHaarWeightedConvolution_mul χ χ).trans
      (congrArg haarWeightedLeftConvolution (compactIrrepHaarKernel_idempotent_convolution ρ hρ hIrr))
  · exact ⟨VonNeumannAlgebra.mem_commutant_iff.mp hC.2 _ (star_mem hC.1)⟩

end CompactCharacterOrthoprojector

end CompactFourierKD


namespace CompactFourierKD
open MeasureTheory Measure Module
open scoped BigOperators
section OrthogonalCharacterKernels

variable {G V W : Type*} [Group G] [TopologicalSpace G] [IsTopologicalGroup G]
  [CompactSpace G] [MeasurableSpace G] [BorelSpace G]
  [NormedAddCommGroup V] [NormedSpace ℂ V] [FiniteDimensional ℂ V]
  [NormedAddCommGroup W] [NormedSpace ℂ W] [FiniteDimensional ℂ W]
local notation "ν" => compactKDhaar G

/-- Actual orthogonality of the two compact Haar spectral projections,
without an assumption of isotypic completeness. -/
theorem compactIrrepHaarKernels_mul_eq_zero_of_inequivalent
    (ρ : G→*(V→L[ℂ]V)) (σ : G→*(W→L[ℂ]W))
    (hρ : Continuous ρ) (hσ : Continuous σ)
    (hρi : compactRepresentationIrreducible ρ) (hσi : compactRepresentationIrreducible σ)
    (hNE : ¬∃ T : V≃L[ℂ]W, ∀ g v, T (ρ g v)=σ g (T v)) :
    haarWeightedLeftConvolution (compactIrrepHaarKernel ρ hρ) *
      haarWeightedLeftConvolution (compactIrrepHaarKernel σ hσ)=0 := by
  classical
  let χ := compactIrrepHaarKernel ρ hρ
  let ψ := compactIrrepHaarKernel σ hσ
  let P := haarWeightedLeftConvolution χ
  let T : C(G,ℂ)→L[ℂ]HaarL2 ν := ContinuousMap.toLp 2 ν ℂ
  have hKernel : compactHaarContinuousConvolution χ ψ=0 := by
    apply ContinuousMap.toLp_injective ν (p:=2) (𝕜:=ℂ)
    change T (compactHaarContinuousConvolution χ ψ)=T 0
    rw [←compactHaarWeightedConvolution_toLp χ ψ,map_zero]
    change P (T ψ)=0
    let b := finBasis ℂ W
    let F (i : Fin (finrank ℂ W)) :=
      compactIrrepHaarCoefficient σ hσ (b.coord i).toContinuousLinearMap (b i)
    have hF : T ψ=(finrank ℂ W : ℂ) • ∑ i, T (F i) := by
      change T (compactIrrepHaarKernel σ hσ) = _
      rw [compactIrrepHaarKernel_eq_sum_coefficients σ hσ,map_smul,_root_.map_sum]
    rw [hF,map_smul,_root_.map_sum]
    have hZ : ∑ i, P (T (F i))=0 := by
      apply Finset.sum_eq_zero
      intro i _
      exact compactIrrepHaarKernel_kills_inequivalent_coefficients ρ σ hρ hσ hρi hσi hNE
        (b.coord i).toContinuousLinearMap (b i)
    rw [hZ,smul_zero]
  change haarWeightedLeftConvolution χ * haarWeightedLeftConvolution ψ=0
  rw [compactHaarWeightedConvolution_mul,hKernel]
  apply ContinuousLinearMap.ext
  intro v
  rw [haarWeightedLeftConvolution_apply]
  simp

end OrthogonalCharacterKernels

end CompactFourierKD


namespace CompactFourierKD
open MeasureTheory Measure Module
open scoped BigOperators

section CompactMatrixReconstruction

variable {G V : Type*} [Group G] [TopologicalSpace G] [IsTopologicalGroup G]
  [CompactSpace G] [MeasurableSpace G] [BorelSpace G]
  [NormedAddCommGroup V] [NormedSpace ℂ V] [FiniteDimensional ℂ V] [Nontrivial V]

/-- Reconstruction of a genuine irreducible matrix from its full coefficient
function. This is matrix-coefficient orthogonality in operator form, not
an assumed Peter–Weyl completeness statement. -/
theorem compactHaar_trace_weight_extract_operator
    (μ : Measure G) [IsProbabilityMeasure μ] [IsMulLeftInvariant μ]
    (ρ : G→*(V→L[ℂ]V)) (hρ : Continuous ρ) (hIrr : compactRepresentationIrreducible ρ)
    (D : V→L[ℂ]V) (v : V) :
    (∫ g, compactContinuousTrace (D.comp (ρ g⁻¹)) • ρ g v ∂μ) =
      (finrank ℂ V : ℂ)⁻¹ • D v := by
  classical
  let : CompleteSpace V := FiniteDimensional.complete ℂ V
  let b := finBasis ℂ V
  let E (i : Fin (finrank ℂ V)) : V→L[ℂ]ℂ := (b.coord i).toContinuousLinearMap.comp D
  let F (i : Fin (finrank ℂ V)) (g : G) :=
    ρ g (((E i).smulRight v) (ρ g⁻¹ (b i)))
  have hF (i : Fin (finrank ℂ V)) : Integrable (F i) μ :=
    (ContinuousLinearMap.apply ℂ V (b i)).integrable_comp
      (compactHaar_conjugatedOperator_integrable μ ρ ρ hρ hρ ((E i).smulRight v))
  have hSum :
      (∫ g, compactContinuousTrace (D.comp (ρ g⁻¹)) • ρ g v ∂μ) =
        ∑ i : Fin (finrank ℂ V), compactHaarAverageIntertwiner μ ρ ρ ((E i).smulRight v) (b i) := by
    simp_rw [compactHaarAverageIntertwiner_apply μ ρ ρ hρ hρ]
    rw [←integral_finsetSum Finset.univ (fun i _ => hF i)]
    apply integral_congr_ae
    apply Filter.Eventually.of_forall
    intro g
    change _ = ∑ i : Fin (finrank ℂ V), F i g
    simp only [F,ContinuousLinearMap.smulRight_apply,map_smul,←Finset.sum_smul]
    congr 1
    change LinearMap.trace ℂ V (D.comp (ρ g⁻¹)).toLinearMap =
      ∑ i : Fin (finrank ℂ V), b.coord i (D (ρ g⁻¹ (b i)))
    rw [LinearMap.trace_eq_matrix_trace ℂ b]
    simp only [Matrix.trace,Matrix.diag,LinearMap.toMatrix_apply,Basis.coord_apply]
    rfl
  rw [hSum]
  simp only [compactHaarAverageIntertwiner_eq_trace_smul μ ρ hρ hIrr,_root_.smul_apply,one_apply_eq_self]
  have h (i : Fin (finrank ℂ V)) :
      compactContinuousTrace ((E i).smulRight v) = b.coord i (D v) := by
    change LinearMap.trace ℂ V ((E i).toLinearMap.smulRight v)= (E i).toLinearMap v
    exact LinearMap.trace_smulRight (E i).toLinearMap v
  simp_rw [h,div_eq_mul_inv,mul_comm _ ((finrank ℂ V : ℂ)⁻¹),mul_smul,←Finset.smul_sum]
  simpa only [Basis.coord_apply] using
    congrArg (fun u : V => (finrank ℂ V : ℂ)⁻¹ • u) (Basis.sum_repr b (D v))

/-- In particular the full inverse-character coefficient of one
irreducible is injective as a map from endomorphisms. -/
theorem compactHaar_matrixCoefficient_endomorphism_injective
    (μ : Measure G) [IsProbabilityMeasure μ] [IsMulLeftInvariant μ]
    (ρ : G→*(V→L[ℂ]V)) (hρ : Continuous ρ) (hIrr : compactRepresentationIrreducible ρ) :
    Function.Injective (fun D : V→L[ℂ]V => fun g => compactContinuousTrace (D.comp (ρ g⁻¹))) := by
  intro D E h
  have hn : (finrank ℂ V : ℂ) ≠ 0 := by exact_mod_cast finrank_pos.ne'
  apply ContinuousLinearMap.ext
  intro v
  have hd := compactHaar_trace_weight_extract_operator μ ρ hρ hIrr D v
  have he := compactHaar_trace_weight_extract_operator μ ρ hρ hIrr E v
  have hm : (∫ g, compactContinuousTrace (D.comp (ρ g⁻¹)) • ρ g v ∂μ) =
      ∫ g, compactContinuousTrace (E.comp (ρ g⁻¹)) • ρ g v ∂μ := by
    apply integral_congr_ae
    exact Filter.Eventually.of_forall fun g =>
      congrArg (fun z : ℂ => z • ρ g v) (congrFun h g)
  have hh := congrArg (fun x : V => (finrank ℂ V : ℂ) • x) (hd.symm.trans (hm.trans he))
  simpa only [←mul_smul,mul_inv_cancel₀ hn,one_smul] using hh

end CompactMatrixReconstruction

end CompactFourierKD


namespace CompactFourierKD
open MeasureTheory Measure Module
open scoped BigOperators

section ActualMatrixCoefficientBlock

variable {G V : Type*} [Group G] [TopologicalSpace G] [IsTopologicalGroup G]
  [CompactSpace G] [MeasurableSpace G] [BorelSpace G]
  [NormedAddCommGroup V] [NormedSpace ℂ V] [FiniteDimensional ℂ V] [Nontrivial V]
local notation "ν" => compactKDhaar G

/-- The genuine matrix coefficient map from complex endomorphisms
to continuous functions on the compact group. -/
noncomputable def compactMatrixCoefficientContinuous (ρ : G→*(V→L[ℂ]V))
    (hρ : Continuous ρ) (D : V→L[ℂ]V) : C(G,ℂ) :=
  ⟨fun g => compactContinuousTrace (D.comp (ρ g⁻¹)),
    compactContinuousTrace.continuous.comp ((hρ.comp continuous_inv).const_clm_comp D)⟩

noncomputable def compactMatrixCoefficientCLM (ρ : G→*(V→L[ℂ]V))
    (hρ : Continuous ρ) : (V→L[ℂ]V)→L[ℂ]HaarL2 ν := by
  let R : (V→L[ℂ]V)→ₗ[ℂ]C(G,ℂ) :=
    { toFun := compactMatrixCoefficientContinuous ρ hρ
      map_add' := by
        intro D E
        ext g
        change compactContinuousTrace ((D+E).comp (ρ g⁻¹))=_
        rw [ContinuousLinearMap.add_comp,map_add]
        rfl
      map_smul' := by
        intro a D
        ext g
        change compactContinuousTrace ((a • D).comp (ρ g⁻¹))=_
        rw [ContinuousLinearMap.smul_comp,map_smul]
        rfl }
  let T : C(G,ℂ)→L[ℂ]HaarL2 ν := ContinuousMap.toLp 2 ν ℂ
  exact T.comp R.toContinuousLinearMap

theorem compactMatrixCoefficientCLM_injective (ρ : G→*(V→L[ℂ]V))
    (hρ : Continuous ρ) (hIrr : compactRepresentationIrreducible ρ) :
    Function.Injective (compactMatrixCoefficientCLM ρ hρ) := by
  intro D E h
  apply compactHaar_matrixCoefficient_endomorphism_injective ν ρ hρ hIrr
  funext g
  exact DFunLike.congr_fun ((ContinuousMap.toLp_injective ν) h) g

omit [CompactSpace G] [MeasurableSpace G] [BorelSpace G] [Nontrivial V] in
private theorem compactMatrixCoefficientContinuous_eq_sum (ρ : G→*(V→L[ℂ]V))
    (hρ : Continuous ρ) (D : V→L[ℂ]V) :
    let b := finBasis ℂ V
    compactMatrixCoefficientContinuous ρ hρ D =
      ∑ i, compactIrrepHaarCoefficient ρ hρ ((b.coord i).toContinuousLinearMap.comp D) (b i) := by
  classical
  dsimp only
  let b := finBasis ℂ V
  ext g
  rw [ContinuousMap.sum_apply]
  change LinearMap.trace ℂ V (D.comp (ρ g⁻¹)).toLinearMap =
      ∑ i : Fin (finrank ℂ V), b.coord i (D (ρ g⁻¹ (b i)))
  rw [LinearMap.trace_eq_matrix_trace ℂ b]
  simp only [Matrix.trace,Matrix.diag,LinearMap.toMatrix_apply,Basis.coord_apply]
  rfl

/-- The explicit class convolution fixes the full matrix coefficient
image, including trace combinations of mixed rank-one coefficients. -/
theorem compactIrrepHaarKernel_fixes_matrixCoefficient (ρ : G→*(V→L[ℂ]V))
    (hρ : Continuous ρ) (hIrr : compactRepresentationIrreducible ρ) (D : V→L[ℂ]V) :
    haarWeightedLeftConvolution (compactIrrepHaarKernel ρ hρ) (compactMatrixCoefficientCLM ρ hρ D) =
      compactMatrixCoefficientCLM ρ hρ D := by
  classical
  let T : C(G,ℂ)→L[ℂ]HaarL2 ν := ContinuousMap.toLp 2 ν ℂ
  change haarWeightedLeftConvolution (compactIrrepHaarKernel ρ hρ)
    (T (compactMatrixCoefficientContinuous ρ hρ D))=T (compactMatrixCoefficientContinuous ρ hρ D)
  rw [compactMatrixCoefficientContinuous_eq_sum ρ hρ D,_root_.map_sum,_root_.map_sum]
  apply Finset.sum_congr rfl
  intro i _
  exact compactIrrepHaarKernel_fixes_own_coefficients ρ hρ hIrr _ _

omit [Nontrivial V] in
private theorem compactIrrepHaarKernel_maps_continuous_to_matrixCoefficient
    (ρ : G→*(V→L[ℂ]V)) (hρ : Continuous ρ) (f : C(G,ℂ)) :
    ∃ D : V→L[ℂ]V,
      haarWeightedLeftConvolution (compactIrrepHaarKernel ρ hρ) (ContinuousMap.toLp 2 ν ℂ f) =
        compactMatrixCoefficientCLM ρ hρ D := by
  let : CompleteSpace V := FiniteDimensional.complete ℂ V
  let F (y : G) := f y⁻¹ • ρ y⁻¹
  have hF : Integrable F ν :=
    ((f.continuous.comp continuous_inv).smul (hρ.comp continuous_inv)).integrable_of_hasCompactSupport
      (HasCompactSupport.of_compactSpace _)
  let d : ℂ := finrank ℂ V
  refine ⟨d • (∫ y, F y ∂ν),?_⟩
  rw [compactHaarWeightedConvolution_toLp]
  let T : C(G,ℂ)→L[ℂ]HaarL2 ν := ContinuousMap.toLp 2 ν ℂ
  change T (compactHaarContinuousConvolution (compactIrrepHaarKernel ρ hρ) f) =
    T (compactMatrixCoefficientContinuous ρ hρ (d • (∫ y, F y ∂ν)))
  congr 1
  ext x
  rw [compactHaarContinuousConvolution_apply]
  let L : (V→L[ℂ]V)→L[ℂ]ℂ :=
    compactContinuousTrace.comp ((ContinuousLinearMap.compL ℂ V V V).flip (ρ x⁻¹))
  change (∫ g, (d*compactContinuousTrace (ρ g⁻¹))*f (g⁻¹*x) ∂ν) =
      L (d • ∫ y, F y ∂ν)
  rw [map_smul,←L.integral_comp_comm hF,←integral_smul]
  let A (g : G) := (d*compactContinuousTrace (ρ g⁻¹))*f (g⁻¹*x)
  let M := MeasurableEquiv.mulLeft x
  have hM : MeasurePreserving M ν ν := measurePreserving_mul_left ν x
  change (∫ g, A g ∂ν)=_
  rw [←hM.integral_comp' A]
  apply integral_congr_ae
  apply Filter.Eventually.of_forall
  intro y
  change (d*compactContinuousTrace (ρ (x*y)⁻¹))*f ((x*y)⁻¹*x)=
    d • L (f y⁻¹ • ρ y⁻¹)
  rw [mul_inv_rev,show y⁻¹*x⁻¹*x=y⁻¹ by group,map_mul,map_smul,smul_eq_mul,smul_eq_mul]
  change (d*compactContinuousTrace ((ρ y⁻¹).comp (ρ x⁻¹)))*f y⁻¹ =
    d*(f y⁻¹*compactContinuousTrace ((ρ y⁻¹).comp (ρ x⁻¹)))
  ring

/-- The actual range of the named Haar orthoprojector is exactly its
finite-dimensional matrix coefficient space; this proves the local
isotypic assertion without assuming full Peter–Weyl completeness. -/
theorem compactIrrepHaarKernel_range_eq_matrixCoefficient
    (ρ : G→*(V→L[ℂ]V)) (hρ : Continuous ρ) (hIrr : compactRepresentationIrreducible ρ) :
    (haarWeightedLeftConvolution (compactIrrepHaarKernel ρ hρ)).range =
      (compactMatrixCoefficientCLM ρ hρ).range := by
  let P := haarWeightedLeftConvolution (compactIrrepHaarKernel ρ hρ)
  let C := compactMatrixCoefficientCLM ρ hρ
  let T : C(G,ℂ)→L[ℂ]HaarL2 ν := ContinuousMap.toLp 2 ν ℂ
  let S := P ⁻¹' (C.range : Set (HaarL2 ν))
  have hS : IsClosed S := C.range.closed_of_finiteDimensional.preimage P.continuous
  have hD : DenseRange T := by
    let : Measure.Regular ν := by unfold compactKDhaar; infer_instance
    exact ContinuousMap.toLp_denseRange ℂ ν ℂ (p:=2) (by norm_num)
  have hZ : closure (Set.range T)⊆S := closure_minimal (by
    rintro _ ⟨f,rfl⟩
    obtain ⟨D,hD⟩ := compactIrrepHaarKernel_maps_continuous_to_matrixCoefficient ρ hρ f
    exact ⟨D,hD.symm⟩) hS
  rw [hD.closure_range] at hZ
  ext x
  constructor
  · rintro ⟨f,rfl⟩
    exact hZ (Set.mem_univ f)
  · rintro ⟨D,rfl⟩
    exact ⟨C D,compactIrrepHaarKernel_fixes_matrixCoefficient ρ hρ hIrr D⟩

end ActualMatrixCoefficientBlock

end CompactFourierKD


namespace CompactFourierKD
open MeasureTheory Measure Module

section CompactRepresentationFullSpan

variable {G V : Type*} [Group G] [TopologicalSpace G] [IsTopologicalGroup G]
  [CompactSpace G] [MeasurableSpace G] [BorelSpace G]
  [NormedAddCommGroup V] [NormedSpace ℂ V] [FiniteDimensional ℂ V] [Nontrivial V]

/-- Compact Haar reconstruction yields the full matrix span of an
irreducible without importing Burnside's density theorem. -/
theorem compactIrreducibleRepresentation_span_full
    (μ : Measure G) [IsProbabilityMeasure μ] [IsMulLeftInvariant μ]
    (ρ : G→*(V→L[ℂ]V)) (hρ : Continuous ρ) (hIrr : compactRepresentationIrreducible ρ) :
    Submodule.span ℂ (Set.range ρ)=⊤ := by
  let : CompleteSpace V := FiniteDimensional.complete ℂ V
  apply top_unique
  intro D _
  let S := Submodule.span ℂ (Set.range ρ)
  let F (g : G) := compactContinuousTrace (D.comp (ρ g⁻¹)) • ρ g
  have hCont : Continuous F :=
    (compactContinuousTrace.continuous.comp ((hρ.comp continuous_inv).const_clm_comp D)).smul hρ
  have hF : Integrable F μ := hCont.integrable_of_hasCompactSupport (HasCompactSupport.of_compactSpace _)
  have he : D=(finrank ℂ V : ℂ) • (∫ g, F g ∂μ) := by
    apply ContinuousLinearMap.ext
    intro v
    have h := (ContinuousLinearMap.apply ℂ V v).integral_comp_comm hF
    change (∫ g, compactContinuousTrace (D.comp (ρ g⁻¹)) • ρ g v ∂μ) =
      (∫ g, F g ∂μ) v at h
    rw [compactHaar_trace_weight_extract_operator μ ρ hρ hIrr D v] at h
    change D v = (finrank ℂ V : ℂ) • (∫ g, F g ∂μ) v
    have hn : (finrank ℂ V : ℂ)≠0 := by exact_mod_cast finrank_pos.ne'
    rw [←h,←mul_smul,mul_inv_cancel₀ hn,one_smul]
  by_contra hn
  obtain ⟨φ,hφ,hKer⟩ := Submodule.exists_le_ker_of_notMem hn
  let L : (V→L[ℂ]V)→L[ℂ]ℂ := φ.toContinuousLinearMap
  apply hφ
  have hZero : L (∫ g, F g ∂μ)=0 := by
    rw [←L.integral_comp_comm hF]
    have hf : (∫ g, L (F g) ∂μ)=∫ _ : G, (0:ℂ) ∂μ := by
      apply integral_congr_ae
      apply Filter.Eventually.of_forall
      intro g
      change φ (F g)=0
      exact hKer (S.smul_mem _ (Submodule.subset_span ⟨g,rfl⟩))
    rw [hf,integral_zero]
  change L D=0
  rw [he,map_smul,hZero,smul_zero]

end CompactRepresentationFullSpan

end CompactFourierKD


namespace CompactFourierKD
open MeasureTheory Measure Module

section CompactFullCentralAction

variable {G V : Type*} [Group G] [TopologicalSpace G] [IsTopologicalGroup G]
  [CompactSpace G] [MeasurableSpace G] [BorelSpace G]
  [NormedAddCommGroup V] [NormedSpace ℂ V] [FiniteDimensional ℂ V] [Nontrivial V]
local notation "ν" => compactKDhaar G

omit [Nontrivial V] in
private theorem compactMatrixCoefficientCLM_ae (ρ : G→*(V→L[ℂ]V))
    (hρ : Continuous ρ) (D : V→L[ℂ]V) :
    compactMatrixCoefficientCLM ρ hρ D =ᵐ[ν] fun x => compactContinuousTrace (D.comp (ρ x⁻¹)) :=
  (compactMatrixCoefficientContinuous ρ hρ D).coeFn_toLp ν (𝕜:=ℂ) (p:=2)

omit [Nontrivial V] in
theorem compactMatrixCoefficientCLM_left_action (ρ : G→*(V→L[ℂ]V))
    (hρ : Continuous ρ) (D : V→L[ℂ]V) (g : G) :
    haarLeftReg ν g (compactMatrixCoefficientCLM ρ hρ D)
      =compactMatrixCoefficientCLM ρ hρ (ρ g * D) := by
  apply Lp.ext
  let C := compactMatrixCoefficientCLM ρ hρ
  filter_upwards [haarLeftReg_ae ν g (C D),compactMatrixCoefficientCLM_ae ρ hρ (ρ g * D),
    (measurePreserving_mul_left ν g⁻¹).quasiMeasurePreserving.ae_eq_comp
      (compactMatrixCoefficientCLM_ae ρ hρ D)] with x h1 h2 h3
  dsimp only [Function.comp_apply] at h3
  rw [h1,h2,h3,mul_inv_rev,inv_inv,map_mul]
  change LinearMap.trace ℂ V (D.toLinearMap*((ρ x⁻¹).toLinearMap*(ρ g).toLinearMap)) =
    LinearMap.trace ℂ V (((ρ g).toLinearMap*D.toLinearMap)*(ρ x⁻¹).toLinearMap)
  rw [←mul_assoc,LinearMap.trace_mul_comm,mul_assoc]

omit [Nontrivial V] in
theorem compactMatrixCoefficientCLM_right_action (ρ : G→*(V→L[ℂ]V))
    (hρ : Continuous ρ) (D : V→L[ℂ]V) (g : G) :
    haarRightReg ν g (compactMatrixCoefficientCLM ρ hρ D)
      =compactMatrixCoefficientCLM ρ hρ (D * ρ g⁻¹) := by
  apply Lp.ext
  let C := compactMatrixCoefficientCLM ρ hρ
  filter_upwards [haarRightReg_ae ν g (C D),compactMatrixCoefficientCLM_ae ρ hρ (D*ρ g⁻¹),
    (measurePreserving_mul_right ν g).quasiMeasurePreserving.ae_eq_comp
      (compactMatrixCoefficientCLM_ae ρ hρ D)] with x h1 h2 h3
  dsimp only [Function.comp_apply] at h3
  rw [h1,h2,h3,mul_inv_rev,map_mul]
  change compactContinuousTrace (D*(ρ g⁻¹*ρ x⁻¹)) =
    compactContinuousTrace ((D*ρ g⁻¹)*ρ x⁻¹)
  rw [mul_assoc]

private theorem compactIrreducible_matrix_bimodule_scalar
    (ρ : G→*(V→L[ℂ]V)) (hρ : Continuous ρ) (hIrr : compactRepresentationIrreducible ρ)
    (S : (V→L[ℂ]V)→ₗ[ℂ](V→L[ℂ]V))
    (hL : ∀ g D, S (ρ g*D)=ρ g*S D)
    (hR : ∀ g D, S (D*ρ g⁻¹)=S D*ρ g⁻¹) :
    ∃ c : ℂ, ∀ D, S D=c • D := by
  have hSL (g : G) : S (ρ g)=ρ g*S 1 := by simpa only [mul_one] using hL g 1
  have hSR (g : G) : S (ρ g)=S 1*ρ g := by simpa only [inv_inv,one_mul] using hR g⁻¹ 1
  obtain ⟨c,hc⟩ := compactSchur_scalar_of_intertwines ρ hIrr (S 1) (fun g v =>
    DFunLike.congr_fun ((hSR g).symm.trans (hSL g)) v)
  let L := LinearMap.mulRight ℂ (S 1)
  have hs : Submodule.span ℂ (Set.range ρ)≤LinearMap.eqLocus S L := by
    apply Submodule.span_le.mpr
    rintro _ ⟨g,rfl⟩
    exact hSL g
  rw [compactIrreducibleRepresentation_span_full ν ρ hρ hIrr] at hs
  refine ⟨c,fun D => ?_⟩
  have hEq : S D=D*S 1 := hs Submodule.mem_top
  rw [hEq,hc,mul_smul_comm,mul_one]

/-- Any actual central bounded observable acts by a scalar on the
entire genuine irreducible matrix-coefficient block. -/
theorem compactHaar_central_matrixCoefficient_scalar
    (ρ : G→*(V→L[ℂ]V)) (hρ : Continuous ρ) (hIrr : compactRepresentationIrreducible ρ)
    (Q : HaarOp ν) (hQ : InHaarFourierCenter ν Q) :
    ∃ a : ℂ, ∀ D, Q (compactMatrixCoefficientCLM ρ hρ D) =
      a • compactMatrixCoefficientCLM ρ hρ D := by
  let C := compactMatrixCoefficientCLM ρ hρ
  let P := haarWeightedLeftConvolution (compactIrrepHaarKernel ρ hρ)
  have hc : Function.Injective C := compactMatrixCoefficientCLM_injective ρ hρ hIrr
  have hRange : P.range=C.range := compactIrrepHaarKernel_range_eq_matrixCoefficient ρ hρ hIrr
  have hPQ : P*Q=Q*P := VonNeumannAlgebra.mem_commutant_iff.mp hQ.2 P
    (compactIrrepHaarKernel_mem_center ρ hρ).1
  have hIn (v : HaarL2 ν) (hv : v∈C.range) : Q v∈C.range := by
    rw [←hRange] at hv ⊢
    obtain ⟨w,rfl⟩ := hv
    exact ⟨Q w,DFunLike.congr_fun hPQ w⟩
  let B : C.range→ₗ[ℂ]C.range := Q.toLinearMap.restrict hIn
  let E : (V→L[ℂ]V)≃ₗ[ℂ]C.range := LinearEquiv.ofInjective C.toLinearMap hc
  let S : (V→L[ℂ]V)→ₗ[ℂ](V→L[ℂ]V) := E.symm.toLinearMap.comp (B.comp E.toLinearMap)
  have hS (D : V→L[ℂ]V) : C (S D)=Q (C D) := by
    exact congrArg Subtype.val (E.apply_symm_apply (B (E D)))
  have hL (g : G) (D : V→L[ℂ]V) : S (ρ g*D)=ρ g*S D := by
    apply hc
    rw [hS,←compactMatrixCoefficientCLM_left_action ρ hρ D g,
      ←compactMatrixCoefficientCLM_left_action ρ hρ (S D) g,hS]
    exact DFunLike.congr_fun (haarFourierCenter_commutes_left_right ν Q hQ g).1.eq (C D)
  have hR (g : G) (D : V→L[ℂ]V) : S (D*ρ g⁻¹)=S D*ρ g⁻¹ := by
    apply hc
    rw [hS,←compactMatrixCoefficientCLM_right_action ρ hρ D g,
      ←compactMatrixCoefficientCLM_right_action ρ hρ (S D) g,hS]
    exact DFunLike.congr_fun (haarFourierCenter_commutes_left_right ν Q hQ g).2.eq (C D)
  obtain ⟨a,ha⟩ := compactIrreducible_matrix_bimodule_scalar ρ hρ hIrr S hL hR
  refine ⟨a,fun D => ?_⟩
  change Q (C D)=a • C D
  rw [←hS,ha,map_smul]

/-- Original compact positivity needs all central orthoprojectors.
On each occupied irreducible a genuine central orthoprojector is
now proved to select the ENTIRE block either with 0 or with 1. -/
theorem compactHaar_central_projection_matrixCoefficient_selects
    (ρ : G→*(V→L[ℂ]V)) (hρ : Continuous ρ) (hIrr : compactRepresentationIrreducible ρ)
    (Q : HaarOp ν) (hQ : InHaarFourierCenter ν Q) (hProj : IsStarProjection Q) :
    (∀ D, Q (compactMatrixCoefficientCLM ρ hρ D)=0) ∨
    (∀ D, Q (compactMatrixCoefficientCLM ρ hρ D)=compactMatrixCoefficientCLM ρ hρ D) := by
  let C := compactMatrixCoefficientCLM ρ hρ
  obtain ⟨a,ha⟩ := compactHaar_central_matrixCoefficient_scalar ρ hρ hIrr Q hQ
  have hx : C 1≠0 := by
    intro hz
    apply (one_ne_zero : (1:V→L[ℂ]V)≠0)
    apply compactMatrixCoefficientCLM_injective ρ hρ hIrr
    change C 1=C 0
    rw [map_zero,hz]
  have hh : Q (Q (C 1))=Q (C 1) := DFunLike.congr_fun hProj.isIdempotentElem (C 1)
  change ∀ D, Q (C D)=a • C D at ha
  rw [ha 1,map_smul,ha 1,smul_smul] at hh
  have hZ : (a*a-a) • C 1=0 := by rw [sub_smul,hh,sub_self]
  have hb : a*(a-1)=0 := by
    rw [mul_sub,mul_one]
    exact (smul_eq_zero.mp hZ).resolve_right hx
  rcases mul_eq_zero.mp hb with h|h
  · left; intro D; rw [ha,h,zero_smul]
  · right; intro D; rw [ha,sub_eq_zero.mp h,one_smul]

end CompactFullCentralAction

end CompactFourierKD

namespace CompactFourierKD
open MeasureTheory Measure Filter Set
open scoped ComplexInnerProductSpace ENNReal MeasureTheory Topology

section ComplexPositiveDensity
variable {X : Type*} [MeasurableSpace X] {μ : Measure X}

/-
Local reuse: exact proof text of Mathlib's ae_nonneg_of_forall_setIntegral_nonneg
at revision 0df444a360eaa60ab8c11dca51a86af692955474, from AEEqOfIntegral.lean.
Copyright (c) 2021 Rémy Degenne. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Rémy Degenne. The local private name avoids conflict.
-/
private theorem kd3_ae_nonneg_of_forall_setIntegral_nonneg {f : X→ℝ} (hf : Integrable f μ)
    (hf_zero : ∀ s, MeasurableSet s → μ s < ∞ → 0 ≤ ∫ x in s, f x ∂μ) : 0 ≤ᵐ[μ] f := by
  simp_rw [EventuallyLE, Pi.zero_apply]
  rw [ae_const_le_iff_forall_lt_measure_zero]
  intro b hb_neg
  let s := {x | f x ≤ b}
  have hs : NullMeasurableSet s μ := nullMeasurableSet_le hf.1.aemeasurable aemeasurable_const
  have mus : μ s < ∞ := Integrable.measure_le_lt_top hf hb_neg
  have h_int_gt : (∫ x in s, f x ∂μ) ≤ b * μ.real s := by
    have h_const_le : (∫ x in s, f x ∂μ) ≤ ∫ _ in s, b ∂μ := by
      refine setIntegral_mono_ae_restrict hf.integrableOn (integrableOn_const mus.ne) ?_
      rw [EventuallyLE, ae_restrict_iff₀ (hs.mono μ.restrict_le_self)]
      exact Eventually.of_forall fun x hxs => hxs
    rwa [setIntegral_const, smul_eq_mul, mul_comm] at h_const_le
  contrapose! h_int_gt with H
  calc
    b * μ.real s < 0 := mul_neg_of_neg_of_pos hb_neg <| ENNReal.toReal_pos H mus.ne
    _ ≤ ∫ x in s, f x ∂μ := by
      rw [← μ.restrict_toMeasurable mus.ne]
      exact hf_zero _ (measurableSet_toMeasurable ..) (by rwa [measure_toMeasurable])


theorem compactKD_complex_density_nonnegative_ae {f : X→ℂ} (hf : Integrable f μ)
    (h : ∀ E, MeasurableSet E →
     0 ≤ (∫ x in E, f x ∂μ).re ∧ (∫ x in E, f x ∂μ).im=0) :
    ∀ᵐ x ∂μ, 0 ≤ (f x).re ∧ (f x).im=0 := by
  have hr := Complex.reCLM.integrable_comp hf
  have hi := Complex.imCLM.integrable_comp hf
  have ha : ∀ᵐ x ∂μ, 0≤(f x).re := by
    apply kd3_ae_nonneg_of_forall_setIntegral_nonneg hr
    intro E hE _
    rw [Complex.reCLM.integral_comp_comm hf.integrableOn]
    exact (h E hE).1
  have hb : ∀ᵐ x ∂μ, 0≤(f x).im := by
    apply kd3_ae_nonneg_of_forall_setIntegral_nonneg hi
    intro E hE _
    rw [Complex.imCLM.integral_comp_comm hf.integrableOn]
    exact (h E hE).2.ge
  have hc : ∀ᵐ x ∂μ, 0≤-(f x).im := by
    apply kd3_ae_nonneg_of_forall_setIntegral_nonneg hi.neg
    intro E hE _
    change 0≤∫ x in E, -Complex.imCLM (f x) ∂μ
    rw [integral_neg,Complex.imCLM.integral_comp_comm hf.integrableOn]
    exact neg_nonneg.mpr (h E hE).2.le
  filter_upwards [ha,hb,hc] with x hx hy hz
  exact ⟨hx,le_antisymm (neg_nonneg.mp hz) hy⟩

theorem compactKD_complex_density_positive_integral_domination {f : X→ℂ} (hf : Integrable f μ)
    (h : ∀ E, MeasurableSet E →
     0 ≤ (∫ x in E, f x ∂μ).re ∧ (∫ x in E, f x ∂μ).im=0)
    {ν : Measure X} (hν : ν≤μ) :
    0≤(∫ x, f x ∂ν).re ∧ (∫ x, f x ∂ν).im=0 := by
  have hA : ∀ᵐ x ∂ν, 0≤(f x).re ∧ (f x).im=0 :=
    hν.absolutelyContinuous.ae_le (compactKD_complex_density_nonnegative_ae hf h)
  have hI : Integrable f ν := hf.mono_measure hν
  constructor
  · change 0≤Complex.reCLM (∫ x, f x ∂ν)
    rw [←Complex.reCLM.integral_comp_comm hI]
    exact integral_nonneg_of_ae (hA.mono fun x hx => hx.1)
  · change Complex.imCLM (∫ x, f x ∂ν) = 0
    rw [←Complex.imCLM.integral_comp_comm hI]
    calc
      _ = ∫ _ : X, (0:ℝ) ∂ν := integral_congr_ae (hA.mono fun x hx => hx.2)
      _ = 0 := integral_zero _ _

end ComplexPositiveDensity

end CompactFourierKD

namespace CompactFourierKD
open ContinuousLinearMap InnerProductSpace
open scoped ComplexInnerProductSpace BigOperators

section RankOneTrace

variable {I J V : Type*} [NormedAddCommGroup V] [InnerProductSpace ℂ V] [CompleteSpace V]

noncomputable def compactRankOneDensity (v : I→V) : V→L[ℂ]V :=
  ∑' i, rankOne ℂ (v i) (v i)

theorem compactRankOneDensity_summable (v : I→V) (hv : Summable fun i => ‖v i‖^2) :
    Summable fun i => rankOne ℂ (v i) (v i) := by
  apply Summable.of_norm
  simpa only [norm_rankOne,pow_two] using hv

private theorem compactRankOneDensity_isClosed_positive :
    IsClosed {T : V→L[ℂ]V | T.IsPositive} := by
  have heq : {T : V→L[ℂ]V | T.IsPositive} =
      {T : V→L[ℂ]V | star T=T} ∩
        ⋂ x : V, {T : V→L[ℂ]V | 0≤(⟪T x,x⟫ : ℂ).re} := by
    ext T
    simp only [Set.mem_ofPred_eq,Set.mem_inter_iff,Set.mem_iInter,ContinuousLinearMap.isPositive_def']
    rfl
  rw [heq]
  refine (isClosed_eq continuous_star continuous_id).inter (isClosed_iInter fun x => ?_)
  have hc : Continuous fun T : V→L[ℂ]V => (⟪T x,x⟫ : ℂ).re :=
    Complex.continuous_re.comp (continuous_inner.comp
      (((ContinuousLinearMap.apply ℂ V x).continuous).prodMk continuous_const))
  exact isClosed_le continuous_const hc

theorem compactRankOneDensity_positive (v : I→V) (hv : Summable fun i => ‖v i‖^2) :
    (compactRankOneDensity v).IsPositive := by
  apply compactRankOneDensity_isClosed_positive.mem_of_tendsto
    (compactRankOneDensity_summable v hv).hasSum
  apply Filter.Eventually.of_forall
  intro s
  exact ContinuousLinearMap.isPositive_sum s (fun i _ => isPositive_rankOne_self _)

private theorem compactRankOneDensity_eval_inner (v : I→V) (hv : Summable fun i => ‖v i‖^2)
    (A : V→L[ℂ]V) (x : V) :
    ⟪x,compactRankOneDensity v (A x)⟫ =
      ∑' i, ⟪A.adjoint (v i),x⟫ * ⟪x,v i⟫ := by
  let T : (V→L[ℂ]V)→L[ℂ]ℂ := (innerSL ℂ x).comp (ContinuousLinearMap.apply ℂ V (A x))
  have h := ((compactRankOneDensity_summable v hv).hasSum.mapL T).tsum_eq.symm
  change T (compactRankOneDensity v) = _ at h
  change T (compactRankOneDensity v)=_
  rw [h]
  apply tsum_congr
  intro i
  change ⟪x,rankOne ℂ (v i) (v i) (A x)⟫=_
  rw [rankOne_apply,inner_smul_right,ContinuousLinearMap.adjoint_inner_left]

theorem compactRankOneDensity_basis_trace_pairing
    (v : I→V) (hv : Summable fun i => ‖v i‖^2)
    (A : V→L[ℂ]V) (b : HilbertBasis J ℂ V) :
    Summable (fun j => ‖⟪b j,compactRankOneDensity v (A (b j))⟫‖) ∧
      (∑' j, ⟪b j,compactRankOneDensity v (A (b j))⟫)=∑' i, ⟪v i,A (v i)⟫ := by
  let f (i : I) (j : J) := ⟪A.adjoint (v i),b j⟫*⟪b j,v i⟫
  let m (i : I) (j : J) := ‖⟪b j,A.adjoint (v i)⟫‖^2+‖⟪b j,v i⟫‖^2
  have hm (i : I) : Summable (m i) :=
    (b.orthonormal.inner_products_summable (A.adjoint (v i))).add
      (b.orthonormal.inner_products_summable (v i))
  have hBound (i : I) (j : J) : ‖f i j‖≤m i j := by
    have he : ‖⟪A.adjoint (v i),b j⟫‖=‖⟪b j,A.adjoint (v i)⟫‖ := norm_inner_symm _ _
    change ‖⟪A.adjoint (v i),b j⟫*⟪b j,v i⟫‖≤_
    rw [norm_mul,he]
    change _ ≤ ‖⟪b j,A.adjoint (v i)⟫‖^2+‖⟪b j,v i⟫‖^2
    nlinarith [sq_nonneg (‖⟪b j,A.adjoint (v i)⟫‖-‖⟪b j,v i⟫‖)]
  have hOuter (i : I) :
      (∑' j, m i j)≤(‖A.adjoint‖^2+1)*‖v i‖^2 := by
    change (∑' j, (‖⟪b j,A.adjoint (v i)⟫‖^2+‖⟪b j,v i⟫‖^2)) ≤ _
    rw [Summable.tsum_add (b.orthonormal.inner_products_summable (A.adjoint (v i)))
      (b.orthonormal.inner_products_summable (v i))]
    calc
      _ ≤ ‖A.adjoint (v i)‖^2+‖v i‖^2 :=
        add_le_add (b.orthonormal.tsum_inner_products_le (A.adjoint (v i)))
          (b.orthonormal.tsum_inner_products_le (v i))
      _ ≤ (‖A.adjoint‖^2+1)*‖v i‖^2 := by
        have hh := pow_le_pow_left₀ (norm_nonneg _) (A.adjoint.le_opNorm (v i)) 2
        rw [mul_pow] at hh
        nlinarith
  have hMS : Summable (fun p : I×J => m p.1 p.2) := by
    apply (summable_prod_of_nonneg (fun _ => by dsimp [m]; positivity)).mpr
    refine ⟨hm,?_⟩
    exact (hv.mul_left _).of_nonneg_of_le (fun _ => tsum_nonneg fun _ => by dsimp [m]; positivity) hOuter
  have hNS : Summable (fun p : I×J => ‖f p.1 p.2‖) :=
    hMS.of_nonneg_of_le (fun _ => norm_nonneg _) (fun p => hBound p.1 p.2)
  have hS : Summable (Function.uncurry f) := Summable.of_norm hNS
  have hD (j : J) : ⟪b j,compactRankOneDensity v (A (b j))⟫=∑' i, f i j :=
    compactRankOneDensity_eval_inner v hv A (b j)
  constructor
  · simp_rw [hD]
    apply hNS.prod_symm.prod.of_nonneg_of_le (fun _ => norm_nonneg _)
    intro j
    exact norm_tsum_le_tsum_norm (hNS.prod_symm.prod_factor j)
  · simp_rw [hD]
    rw [hS.tsum_comm]
    apply tsum_congr
    intro i
    change (∑' j, ⟪A.adjoint (v i),b j⟫ * ⟪b j,v i⟫)=_
    rw [b.tsum_inner_mul_inner,ContinuousLinearMap.adjoint_inner_left]

end RankOneTrace

end CompactFourierKD

namespace CompactFourierKD
open MeasureTheory Measure
open scoped ComplexInnerProductSpace

section ActualRankOneHaarMoments

variable {X I J : Type*} [MeasurableSpace X] {μ : Measure X}

private theorem kd3_l2_norm_sq_integral (f : HaarL2 μ) :
    Integrable (fun x => ‖f x‖^2) μ ∧
      (∫ x, ‖f x‖^2 ∂μ)=‖f‖^2 := by
  have h0 := L2.integrable_inner (𝕜:=ℂ) f f
  have h1 := Complex.reCLM.integrable_comp h0
  have he (x : X) : Complex.reCLM ⟪f x,f x⟫ = ‖f x‖^2 :=
    inner_self_eq_norm_sq (𝕜:=ℂ) (f x)
  constructor
  · simpa only [he] using h1
  · simp_rw [←he]
    rw [Complex.reCLM.integral_comp_comm h0,←L2.inner_def]
    exact inner_self_eq_norm_sq (𝕜:=ℂ) f

noncomputable def compactKD_l2_pair_row (f g : HaarL2 μ) : Lp ℂ 1 μ :=
  (L2.integrable_inner (𝕜:=ℂ) f g).toL1 (fun x => ⟪f x,g x⟫)

theorem compactKD_l2_pair_row_ae (f g : HaarL2 μ) :
    compactKD_l2_pair_row f g =ᵐ[μ] fun x => ⟪f x,g x⟫ :=
  (L2.integrable_inner (𝕜:=ℂ) f g).coeFn_toL1

private theorem compactKD_l2_pair_row_norm_le (f g : HaarL2 μ) :
    ‖compactKD_l2_pair_row f g‖≤‖f‖^2+‖g‖^2 := by
  rw [L1.norm_eq_integral_norm]
  have hA : (compactKD_l2_pair_row f g : X→ℂ) =ᵐ[μ] fun x => ⟪f x,g x⟫ :=
    compactKD_l2_pair_row_ae f g
  have hb : (fun x => ‖compactKD_l2_pair_row f g x‖) =ᵐ[μ] (fun x => ‖⟪f x,g x⟫‖) :=
    hA.mono (fun _ h => congrArg norm h)
  rw [integral_congr_ae hb]
  obtain ⟨hf,hfEq⟩ := kd3_l2_norm_sq_integral f
  obtain ⟨hg,hgEq⟩ := kd3_l2_norm_sq_integral g
  have hBound (x : X) : ‖⟪f x,g x⟫‖≤‖f x‖^2+‖g x‖^2 := by
    refine (norm_inner_le_norm (𝕜:=ℂ) _ _).trans ?_
    nlinarith [sq_nonneg (‖f x‖-‖g x‖)]
  calc
    _ ≤ ∫ x, (‖f x‖^2+‖g x‖^2) ∂μ :=
      integral_mono (L2.integrable_inner (𝕜:=ℂ) f g).norm (hf.add hg) hBound
    _ = _ := by rw [integral_add hf hg,hfEq,hgEq]

noncomputable def compactKD_rankOne_density_row (Q : HaarOp μ) (v : I→HaarL2 μ) : Lp ℂ 1 μ :=
  ∑' i, compactKD_l2_pair_row (Q (v i)) (v i)

theorem compactKD_rankOne_density_row_summable (Q : HaarOp μ) (v : I→HaarL2 μ)
    (hv : Summable fun i => ‖v i‖^2) :
    Summable (fun i => compactKD_l2_pair_row (Q (v i)) (v i)) := by
  refine Summable.of_norm_bounded (g:=fun i => (‖Q‖^2+1)*‖v i‖^2) (hv.mul_left _) ?_
  intro i
  refine (compactKD_l2_pair_row_norm_le _ _).trans ?_
  have hB := pow_le_pow_left₀ (norm_nonneg _) (Q.le_opNorm (v i)) 2
  rw [mul_pow] at hB
  nlinarith

noncomputable def compactKD_l1_integral_dominated (ν : Measure X) (hν : ν≤μ) :
    Lp ℂ 1 μ →L[ℂ] ℂ :=
  let h (f : Lp ℂ 1 μ) : Integrable f ν := (L1.integrable_coeFn f).mono_measure hν
  LinearMap.mkContinuous
    { toFun := fun f => ∫ x, f x ∂ν
      map_add' := fun f g => by
        rw [←integral_add (h f) (h g)]
        apply integral_congr_ae
        exact hν.absolutelyContinuous.ae_eq (Lp.coeFn_add f g)
      map_smul' := fun a f => by
        simp only [RingHom.id_apply]
        rw [←integral_smul]
        apply integral_congr_ae
        exact hν.absolutelyContinuous.ae_eq (Lp.coeFn_smul a f) }
    1 (fun f => by
      rw [one_mul,L1.norm_eq_integral_norm]
      refine (norm_integral_le_integral_norm _).trans ?_
      exact integral_mono_measure hν (Filter.Eventually.of_forall fun _ => norm_nonneg _)
        (L1.integrable_coeFn f).norm)

theorem compactKD_rankOne_density_row_integral (Q : HaarOp μ) (v : I→HaarL2 μ)
    (hv : Summable fun i => ‖v i‖^2) (ν : Measure X) (hν : ν≤μ) :
    (∫ x, (compactKD_rankOne_density_row Q v) x ∂ν)=
      ∑' i, ∫ x, ⟪(Q (v i)) x,(v i) x⟫ ∂ν := by
  let L := compactKD_l1_integral_dominated ν hν
  have h := ((compactKD_rankOne_density_row_summable Q v hv).hasSum.mapL L).tsum_eq.symm
  change L (compactKD_rankOne_density_row Q v)=_ at h
  change L (compactKD_rankOne_density_row Q v)=_
  rw [h]
  apply tsum_congr
  intro i
  exact integral_congr_ae (hν.absolutelyContinuous.ae_eq (compactKD_l2_pair_row_ae _ _))

theorem compactKD_rankOne_trace_eq_position_row
    (Q : HaarOp μ) (hQ : IsSelfAdjoint Q)
    (v : I→HaarL2 μ) (hv : Summable fun i => ‖v i‖^2)
    (b : HilbertBasis J ℂ (HaarL2 μ)) (E : Set X) (hE : MeasurableSet E) :
    (∑' j, ⟪b j,compactRankOneDensity v ((Q * positionIndicator μ E hE) (b j))⟫) =
      ∫ x in E, (compactKD_rankOne_density_row Q v) x ∂μ := by
  rw [(compactRankOneDensity_basis_trace_pairing v hv _ b).2,
    compactKD_rankOne_density_row_integral Q v hv _ Measure.restrict_le_self]
  apply tsum_congr
  intro i
  change ⟪v i,Q (positionIndicator μ E hE (v i))⟫=_
  rw [←ContinuousLinearMap.adjoint_inner_left,show Q.adjoint=Q from hQ.star_eq,
    L2.inner_def,←integral_indicator hE]
  apply integral_congr_ae
  filter_upwards [positionIndicator_apply_ae μ E hE (v i)] with x hx
  rw [hx]
  by_cases he : x∈E
  · rw [Set.indicator_of_mem he,Set.indicator_of_mem he]
  · rw [Set.indicator_of_notMem he,Set.indicator_of_notMem he,inner_zero_right]

end ActualRankOneHaarMoments

end CompactFourierKD

namespace CompactFourierKD
open MeasureTheory Measure ContinuousLinearMap InnerProductSpace
open scoped ComplexInnerProductSpace BigOperators

section ActualHaarFeatureGram

variable {G V I : Type*} [Group G] [TopologicalSpace G] [IsTopologicalGroup G]
  [CompactSpace G] [MeasurableSpace G] [BorelSpace G]
  [NormedAddCommGroup V] [InnerProductSpace ℂ V] [CompleteSpace V]
local notation "μ" => compactKDhaar G

noncomputable def compactKD_featureCoefficient (F : C(G,V)) (v : V) : C(G,ℂ) :=
  ⟨fun x => ⟪F x,v⟫,F.continuous.inner continuous_const⟩

noncomputable def compactKD_featureAnalysis (F : C(G,V)) : V→L[ℂ]HaarL2 μ := by
  let R : V→ₗ[ℂ]C(G,ℂ) :=
    { toFun := compactKD_featureCoefficient F
      map_add' := by
        intro u v; ext x
        exact inner_add_right (F x) u v
      map_smul' := by
        intro a u; ext x
        exact inner_smul_right (F x) u a }
  let T : C(G,ℂ)→L[ℂ]HaarL2 μ := ContinuousMap.toLp 2 μ ℂ
  let U : V→L[ℂ]C(G,ℂ) := R.mkContinuous ‖F‖ (fun v => by
    apply (ContinuousMap.norm_le _ (mul_nonneg (norm_nonneg _) (norm_nonneg _))).mpr
    intro g
    exact (norm_inner_le_norm (𝕜:=ℂ) (F g) v).trans <|
      mul_le_mul_of_nonneg_right (F.norm_coe_le_norm g) (norm_nonneg v))
  exact T.comp U

omit [CompleteSpace V] in
private theorem compactKD_featureAnalysis_ae (F : C(G,V)) (v : V) :
    compactKD_featureAnalysis F v =ᵐ[μ] (fun x => ⟪F x,v⟫) :=
  (compactKD_featureCoefficient F v).coeFn_toLp μ (𝕜:=ℂ) (p:=2)

omit [CompleteSpace V] in
private theorem compactKD_featureAnalysis_sq_norm (F : C(G,V)) (v : V) :
    ‖compactKD_featureAnalysis F v‖^2 = ∫ x, ‖⟪F x,v⟫‖^2 ∂μ := by
  have h := (kd3_l2_norm_sq_integral (compactKD_featureAnalysis F v)).2
  have hAE := (compactKD_featureAnalysis_ae F v).mono fun x hx => congrArg (fun z : ℂ => ‖z‖^2) hx
  exact h.symm.trans (integral_congr_ae hAE)

omit [CompleteSpace V] in
theorem compactKD_featureAnalysis_HilbertSchmidt (F : C(G,V)) (b : HilbertBasis I ℂ V) :
    Summable (fun i => ‖compactKD_featureAnalysis F (b i)‖^2) := by
  classical
  apply summable_of_sum_le (fun _ => sq_nonneg _) (c:=‖F‖^2)
  intro s
  simp_rw [compactKD_featureAnalysis_sq_norm]
  have hi (i : I) : Integrable (fun x => ‖⟪F x,b i⟫‖^2) μ := by
    apply Continuous.integrable_of_hasCompactSupport
    · exact (F.continuous.inner continuous_const).norm.pow _
    · exact HasCompactSupport.of_compactSpace _
  rw [←integral_finsetSum s (fun i _ => hi i)]
  have hPt (x : G) : (∑ i ∈ s, ‖⟪F x,b i⟫‖^2)≤‖F‖^2 := by
    simp_rw [norm_inner_symm (F x)]
    exact (b.orthonormal.sum_inner_products_le (F x)).trans
      (pow_le_pow_left₀ (norm_nonneg _) (F.norm_coe_le_norm x) _)
  calc
    _ ≤ ∫ _ : G, ‖F‖^2 ∂μ := integral_mono (integrable_finsetSum s (fun i _ => hi i))
      (integrable_const _) hPt
    _ = _ := by simp [integral_const,Measure.real]

theorem compactKD_featureGram_eq_rankOne (F : C(G,V)) (b : HilbertBasis I ℂ V) :
    let A := compactKD_featureAnalysis F
    compactRankOneDensity (fun i => A (b i))=A.comp A.adjoint := by
  let A := compactKD_featureAnalysis F
  let v (i : I) := A (b i)
  have hv : Summable fun i => ‖v i‖^2 := compactKD_featureAnalysis_HilbertSchmidt F b
  apply ContinuousLinearMap.ext
  intro x
  have hv' : HasSum (fun i => rankOne ℂ (v i) (v i) x) (compactRankOneDensity v x) :=
    (compactRankOneDensity_summable v hv).hasSum.mapL (ContinuousLinearMap.apply ℂ (HaarL2 μ) x)
  have hx := (b.hasSum_repr (A.adjoint x)).mapL A
  have hh : (fun i => A (b.repr (A.adjoint x) i • b i)) =
      (fun i => rankOne ℂ (v i) (v i) x) := by
    funext i
    rw [map_smul,HilbertBasis.repr_apply_apply,rankOne_apply]
    change ⟪b i,A.adjoint x⟫ • v i=⟪A (b i),x⟫ • v i
    rw [ContinuousLinearMap.adjoint_inner_right]
  rw [hh] at hx
  exact hv'.unique hx

omit [CompleteSpace V] in
theorem compactKD_featureAnalysis_injective (F : C(G,V))
    (hSpan : Submodule.span ℂ (Set.range F)=⊤) :
    Function.Injective (compactKD_featureAnalysis F) := by
  apply LinearMap.ker_eq_bot.mp
  apply eq_bot_iff.mpr
  intro v hv
  change compactKD_featureAnalysis F v=0 at hv
  let T : C(G,ℂ)→L[ℂ]HaarL2 μ := ContinuousMap.toLp 2 μ ℂ
  have hT : T (compactKD_featureCoefficient F v) = T 0 := by
    rw [map_zero]
    exact hv
  have hV : compactKD_featureCoefficient F v=0 := ContinuousMap.toLp_injective μ hT
  let K := Submodule.span ℂ ({v} : Set V)
  have hOrth : Submodule.span ℂ (Set.range F)≤Kᗮ := by
    apply Submodule.span_le.mpr
    rintro _ ⟨g,rfl⟩
    apply Submodule.mem_orthogonal_singleton_iff_inner_left.mpr
    exact DFunLike.congr_fun hV g
  rw [hSpan] at hOrth
  have hv' : v ∈ Kᗮ := hOrth Submodule.mem_top
  have hzero : ⟪v,v⟫=0 := Submodule.mem_orthogonal_singleton_iff_inner_left.mp hv'
  exact (Submodule.mem_bot ℂ).mpr (inner_self_eq_zero.mp hzero)

theorem compactKD_featureSynthesis_dense (F : C(G,V))
    (hSpan : Submodule.span ℂ (Set.range F)=⊤) :
    DenseRange (compactKD_featureAnalysis F).adjoint := by
  let A := compactKD_featureAnalysis F
  have hker : A.ker=⊥ := LinearMap.ker_eq_bot.mpr (compactKD_featureAnalysis_injective F hSpan)
  have hd : A.adjoint.range.topologicalClosure=⊤ := by
    apply Submodule.topologicalClosure_eq_top_iff.mpr
    rw [ContinuousLinearMap.orthogonal_range,adjoint_adjoint,hker]
  rw [denseRange_iff_closure_range,←show (A.adjoint.range : Set V)=Set.range A.adjoint from rfl,
    ←Submodule.topologicalClosure_coe,hd]
  rfl

end ActualHaarFeatureGram

end CompactFourierKD

namespace CompactFourierKD
open MeasureTheory Measure ContinuousLinearMap
open scoped ComplexInnerProductSpace

section InfiniteActualFeatureGram

variable {G V : Type*} [Group G] [TopologicalSpace G] [IsTopologicalGroup G]
  [CompactSpace G] [MeasurableSpace G] [BorelSpace G]
  [NormedAddCommGroup V] [InnerProductSpace ℂ V] [CompleteSpace V]

theorem compactKD_featureGram_infiniteRank (F : C(G,V))
    (hSpan : Submodule.span ℂ (Set.range F)=⊤)
    (hInf : ¬FiniteDimensional ℂ V) :
    let A := compactKD_featureAnalysis F
    ¬FiniteDimensional ℂ (A.comp A.adjoint).range := by
  let A := compactKD_featureAnalysis F
  change ¬FiniteDimensional ℂ (A.comp A.adjoint).range
  intro hR
  have hInj : Function.Injective A := compactKD_featureAnalysis_injective F hSpan
  have hRange : (A.comp A.adjoint).range=A.adjoint.range.map A.toLinearMap := by
    ext x
    constructor
    · rintro ⟨y,rfl⟩
      exact ⟨A.adjoint y,⟨y,rfl⟩,rfl⟩
    · rintro ⟨_,⟨z,rfl⟩,rfl⟩
      exact ⟨z,rfl⟩
  rw [hRange] at hR
  let : FiniteDimensional ℂ A.adjoint.range :=
    (Module.Finite.equiv_iff (Submodule.equivMapOfInjective A.toLinearMap hInj _).symm).mp hR
  have hClosed : IsClosed (A.adjoint.range : Set V) := A.adjoint.range.closed_of_finiteDimensional
  have hTop : A.adjoint.range=⊤ := by
    apply SetLike.coe_injective
    change (A.adjoint.range : Set V)=Set.univ
    rw [←hClosed.closure_eq]
    exact (compactKD_featureSynthesis_dense F hSpan).closure_range
  let : FiniteDimensional ℂ (⊤ : Submodule ℂ V) := hTop ▸ inferInstanceAs (FiniteDimensional ℂ A.adjoint.range)
  exact hInf (Module.Finite.equiv (Submodule.topEquiv (R:=ℂ) (M:=V)))

end InfiniteActualFeatureGram

end CompactFourierKD

namespace CompactFourierKD
open MeasureTheory Measure ContinuousLinearMap
open scoped ComplexInnerProductSpace

section PointwiseFeatureKDMoments

variable {G V I J : Type*} [Group G] [TopologicalSpace G] [IsTopologicalGroup G]
  [CompactSpace G] [MeasurableSpace G] [BorelSpace G]
  [NormedAddCommGroup V] [InnerProductSpace ℂ V] [CompleteSpace V] [Countable I]
local notation "μ" => compactKDhaar G

omit [CompleteSpace V] in
theorem compactKD_feature_trace_eq_pointwise_row
    (F Y : C(G,V)) (Q : HaarOp μ) (hQ : IsSelfAdjoint Q)
    (hA : ∀ v, Q (compactKD_featureAnalysis F v)=compactKD_featureAnalysis Y v)
    (b : HilbertBasis I ℂ V) (c : HilbertBasis J ℂ (HaarL2 μ))
    (E : Set G) (hE : MeasurableSet E) :
    let v := fun i => compactKD_featureAnalysis F (b i)
    (∑' j, ⟪c j,compactRankOneDensity v ((Q * positionIndicator μ E hE) (c j))⟫) =
      ∫ x in E, ⟪F x,Y x⟫ ∂μ := by
  let v := fun i => compactKD_featureAnalysis F (b i)
  let w := fun i => compactKD_featureAnalysis Y (b i)
  let d (i : I) (x : G) := ⟪⟪Y x,b i⟫,⟪F x,b i⟫⟫
  have hv : Summable (fun i => ‖v i‖^2) := compactKD_featureAnalysis_HilbertSchmidt F b
  have hw : Summable (fun i => ‖w i‖^2) := compactKD_featureAnalysis_HilbertSchmidt Y b
  have hAE (i : I) :
       (fun x => ⟪w i x,v i x⟫) =ᵐ[μ] d i := by
    filter_upwards [compactKD_featureAnalysis_ae Y (b i),
      compactKD_featureAnalysis_ae F (b i)] with x hy hf
    rw [show w i x=⟪Y x,b i⟫ from hy,show v i x=⟪F x,b i⟫ from hf]
  have hd (i : I) : Integrable (d i) μ :=
    (L2.integrable_inner (𝕜:=ℂ) (w i) (v i)).congr (hAE i)
  have ht : Summable (fun i => ∫ x in E, ‖d i x‖ ∂μ) := by
    apply (hw.add hv).of_nonneg_of_le (fun _ => integral_nonneg (fun _ => norm_nonneg _))
    intro i
    calc
      _ ≤ ∫ x, ‖d i x‖ ∂μ :=
        integral_mono_measure Measure.restrict_le_self
          (Filter.Eventually.of_forall fun _ => norm_nonneg _) (hd i).norm
      _ = ‖compactKD_l2_pair_row (w i) (v i)‖ := by
        rw [L1.norm_eq_integral_norm]
        apply integral_congr_ae
        have hrow := compactKD_l2_pair_row_ae (w i) (v i)
        filter_upwards [hAE i,hrow] with x hx hy
        rw [hy,hx]
      _ ≤ ‖w i‖^2+‖v i‖^2 := compactKD_l2_pair_row_norm_le _ _
  change (∑' j, ⟪c j,compactRankOneDensity v ((Q * positionIndicator μ E hE) (c j))⟫) = _
  rw [compactKD_rankOne_trace_eq_position_row Q hQ v hv c E hE,
    compactKD_rankOne_density_row_integral Q v hv _ Measure.restrict_le_self]
  have hOne (i : I) : Q (v i)=w i := hA (b i)
  simp_rw [hOne]
  have hIdent : (∑' i, ∫ x in E, ⟪w i x,v i x⟫ ∂μ) = ∑' i, ∫ x in E, d i x ∂μ := by
    apply tsum_congr
    intro i
    exact integral_congr_ae (ae_restrict_of_ae (hAE i))
  rw [hIdent,integral_tsum_of_summable_integral_norm (fun i => (hd i).integrableOn) ht]
  apply integral_congr_ae
  apply Filter.Eventually.of_forall
  intro x
  simp only [d,RCLike.inner_apply,inner_conj_symm]
  exact b.tsum_inner_mul_inner (F x) (Y x)

end PointwiseFeatureKDMoments

end CompactFourierKD

namespace CompactFourierKD
open MeasureTheory Measure ContinuousLinearMap
open scoped ComplexInnerProductSpace

section FeatureEndpointRows

variable {G V I J : Type*} [Group G] [TopologicalSpace G] [IsTopologicalGroup G]
  [CompactSpace G] [MeasurableSpace G] [BorelSpace G]
  [NormedAddCommGroup V] [InnerProductSpace ℂ V] [CompleteSpace V] [Countable I]
local notation "μ" => compactKDhaar G

noncomputable def compactKD_mapFeature (S : V→L[ℂ]V) (F : C(G,V)) : C(G,V) :=
  ⟨fun x => S (F x),S.continuous.comp F.continuous⟩

theorem compactKD_featureAnalysis_comp (F : C(G,V)) (S : V→L[ℂ]V) :
    (compactKD_featureAnalysis F).comp S =
      compactKD_featureAnalysis (compactKD_mapFeature S.adjoint F) := by
  apply ContinuousLinearMap.ext
  intro v
  apply Lp.ext
  filter_upwards [compactKD_featureAnalysis_ae F (S v),
    compactKD_featureAnalysis_ae (compactKD_mapFeature S.adjoint F) v] with x hx hy
  change compactKD_featureAnalysis F (S v) x =
    compactKD_featureAnalysis (compactKD_mapFeature S.adjoint F) v x
  rw [hx,hy]
  exact (S.adjoint_inner_left v (F x)).symm

theorem compactKD_middleGram_trace_eq_endpoint_row
    (F Y : C(G,V)) (Q : HaarOp μ) (hQ : IsSelfAdjoint Q)
    (hQY : ∀ v, Q (compactKD_featureAnalysis F v)=compactKD_featureAnalysis Y v)
    (B : V→L[ℂ]V) (hB : B.IsPositive)
    (b : HilbertBasis I ℂ V) (c : HilbertBasis J ℂ (HaarL2 μ))
    (E : Set G) (hE : MeasurableSet E) :
    let A := compactKD_featureAnalysis F
    (∑' j, ⟪c j,(A.comp (B.comp A.adjoint)) ((Q * positionIndicator μ E hE) (c j))⟫) =
      ∫ x in E, ⟪F x,B (Y x)⟫ ∂μ := by
  let A := compactKD_featureAnalysis F
  let S : V→L[ℂ]V := CFC.sqrt B
  have hB0 : 0≤B := (ContinuousLinearMap.nonneg_iff_isPositive B).mpr hB
  have hSym : S.IsSymmetric := ((ContinuousLinearMap.nonneg_iff_isPositive S).mp
    (CFC.sqrt_nonneg B)).isSymmetric
  have hS : S.adjoint=S := hSym.isSelfAdjoint.star_eq
  have hSquare (x : V) : S (S x)=B x := DFunLike.congr_fun (CFC.sqrt_mul_sqrt_self B hB0) x
  let FS := compactKD_mapFeature S F
  let YS := compactKD_mapFeature S Y
  have hAF : A.comp S=compactKD_featureAnalysis FS := by
    simpa only [hS] using compactKD_featureAnalysis_comp F S
  have hAY : (compactKD_featureAnalysis Y).comp S=compactKD_featureAnalysis YS := by
    simpa only [hS] using compactKD_featureAnalysis_comp Y S
  have hQYS (v : V) :
      Q (compactKD_featureAnalysis FS v)=compactKD_featureAnalysis YS v := by
    rw [←hAF,←hAY]
    exact hQY (S v)
  have hGram :
      compactRankOneDensity (fun i => compactKD_featureAnalysis FS (b i)) =
        A.comp (B.comp A.adjoint) := by
    rw [compactKD_featureGram_eq_rankOne FS b,←hAF,ContinuousLinearMap.adjoint_comp,hS]
    apply ContinuousLinearMap.ext
    intro x
    change A (S (S (A.adjoint x)))=A (B (A.adjoint x))
    rw [hSquare]
  change (∑' j, ⟪c j,(A.comp (B.comp A.adjoint)) ((Q * positionIndicator μ E hE) (c j))⟫) = _
  rw [←hGram,compactKD_feature_trace_eq_pointwise_row FS YS Q hQ hQYS b c E hE]
  apply integral_congr_ae
  apply Filter.Eventually.of_forall
  intro x
  change ⟪S (F x),S (Y x)⟫=⟪F x,B (Y x)⟫
  exact (hSym (F x) (S (Y x))).trans (congrArg (fun z : V => ⟪F x,z⟫) (hSquare (Y x)))

end FeatureEndpointRows

end CompactFourierKD

namespace CompactFourierKD
open MeasureTheory Measure ContinuousLinearMap
open scoped ComplexInnerProductSpace

section EndpointsArePointwiseReal

variable {G V I J : Type*} [Group G] [TopologicalSpace G] [IsTopologicalGroup G]
  [CompactSpace G] [MeasurableSpace G] [BorelSpace G]
  [NormedAddCommGroup V] [InnerProductSpace ℂ V] [CompleteSpace V] [Countable I]
local notation "μ" => compactKDhaar G

private theorem compactKD_continuous_row_nonnegative_everywhere (d : C(G,ℂ))
    (h : ∀ E, MeasurableSet E →
      0≤(∫ x in E, d x ∂μ).re ∧ (∫ x in E, d x ∂μ).im=0) :
    ∀ x, 0≤(d x).re ∧ (d x).im=0 := by
  have hInt : Integrable d μ := d.continuous.integrable_of_hasCompactSupport
    (HasCompactSupport.of_compactSpace _)
  have hAll := compactKD_complex_density_nonnegative_ae hInt h
  let S := {x : G | 0≤(d x).re ∧ (d x).im=0}
  have hS : IsClosed S :=
    (isClosed_le continuous_const (Complex.continuous_re.comp d.continuous)).inter
      (isClosed_eq (Complex.continuous_im.comp d.continuous) continuous_const)
  intro x
  by_contra hx
  have hZero : μ Sᶜ=0 := ae_iff.mp hAll
  exact (hS.isOpen_compl.measure_pos μ ⟨x,hx⟩).ne' hZero

theorem compactKD_middleGram_endpoint_row_nonnegative_everywhere
    (F Y : C(G,V)) (Q : HaarOp μ) (hQ : IsSelfAdjoint Q)
    (hQY : ∀ v, Q (compactKD_featureAnalysis F v)=compactKD_featureAnalysis Y v)
    (B : V→L[ℂ]V) (hB : B.IsPositive)
    (b : HilbertBasis I ℂ V) (c : HilbertBasis J ℂ (HaarL2 μ))
    (h : ∀ E, ∀ hE : MeasurableSet E,
      let A := compactKD_featureAnalysis F
      let z := ∑' j, ⟪c j,(A.comp (B.comp A.adjoint)) ((Q * positionIndicator μ E hE) (c j))⟫
      0≤z.re ∧ z.im=0) :
    ∀ x, 0≤(⟪F x,B (Y x)⟫ : ℂ).re ∧ (⟪F x,B (Y x)⟫ : ℂ).im=0 := by
  let d : C(G,ℂ) := ⟨fun x => ⟪F x,B (Y x)⟫,F.continuous.inner (B.continuous.comp Y.continuous)⟩
  change ∀ x, 0≤(d x).re ∧ (d x).im=0
  apply compactKD_continuous_row_nonnegative_everywhere d
  intro E hE
  have he := compactKD_middleGram_trace_eq_endpoint_row F Y Q hQ hQY B hB b c E hE
  change _ = ∫ x in E, d x ∂μ at he
  rw [←he]
  exact h E hE

end EndpointsArePointwiseReal

end CompactFourierKD

namespace CompactFourierKD
open MeasureTheory Measure ContinuousLinearMap
open scoped ComplexInnerProductSpace

section CompactOrthogonalFeatureSeries

variable {G V I J : Type*} [Group G] [TopologicalSpace G] [IsTopologicalGroup G]
  [CompactSpace G] [MeasurableSpace G] [BorelSpace G]
  [NormedAddCommGroup V] [InnerProductSpace ℂ V] [CompleteSpace V] [Countable I]
local notation "ν" => compactKDhaar G

noncomputable def compactKD_featureAtRealCLM (v : V) : C(G,V)→L[ℝ]HaarL2 ν := by
  let R : C(G,V)→ₗ[ℝ]C(G,ℂ) :=
    { toFun := fun F => compactKD_featureCoefficient F v
      map_add' := by
        intro F Y
        ext x
        exact inner_add_left (F x) (Y x) v
      map_smul' := by
        intro a F
        ext x
        exact inner_smul_real_left (F x) v a }
  let X : C(G,V)→L[ℝ]C(G,ℂ) := R.mkContinuous ‖v‖ (fun F => by
    apply (ContinuousMap.norm_le _ (mul_nonneg (norm_nonneg _) (norm_nonneg _))).mpr
    intro g
    refine (norm_inner_le_norm (𝕜:=ℂ) (F g) v).trans ?_
    rw [mul_comm ‖v‖]
    exact mul_le_mul_of_nonneg_right (F.norm_coe_le_norm g) (norm_nonneg v))
  let T : C(G,ℂ)→L[ℂ]HaarL2 ν := ContinuousMap.toLp 2 ν ℂ
  exact (T.restrictScalars ℝ).comp X

omit [CompleteSpace V] in
private theorem compactKD_featureAtRealCLM_apply (v : V) (F : C(G,V)) :
    compactKD_featureAtRealCLM v F=compactKD_featureAnalysis F v := rfl

theorem compactKD_orthogonal_feature_series_positive_for_Q
    (F : ℕ→C(G,V)) (hF : Summable fun n => ‖F n‖)
    (hOrth : ∀ n m, n≠m → ∀ x, ⟪F n x,F m x⟫=0)
    (Q : HaarOp ν) (hQ : IsSelfAdjoint Q)
    (hSpec : ∀ n, (∀ v, Q (compactKD_featureAnalysis (F n) v)=0) ∨
          (∀ v, Q (compactKD_featureAnalysis (F n) v)=compactKD_featureAnalysis (F n) v))
    (b : HilbertBasis I ℂ V) (c : HilbertBasis J ℂ (HaarL2 ν))
    (E : Set G) (hE : MeasurableSet E) :
    let V₀ := fun i => compactKD_featureAnalysis (∑' n,F n) (b i)
    let z := ∑' j, ⟪c j,compactRankOneDensity V₀ ((Q * positionIndicator ν E hE) (c j))⟫
    0≤z.re ∧ z.im=0 := by
  classical
  let T : C(G,V) := ∑' n,F n
  have hs : Summable F := Summable.of_norm hF
  have hex (n : ℕ) : ∃ p : Bool, ∀ v,
      Q (compactKD_featureAnalysis (F n) v) =
        compactKD_featureAnalysis (if p then F n else 0) v := by
    rcases hSpec n with h|h
    · refine ⟨false,fun v => ?_⟩
      rw [h]
      simp only [Bool.false_eq_true, if_false, ←compactKD_featureAtRealCLM_apply,map_zero]
    · exact ⟨true,by simpa only [if_true] using h⟩
  let sel (n : ℕ) := (hex n).choose
  let U (n : ℕ) : C(G,V) := if sel n then F n else 0
  let Y : C(G,V) := ∑' n,U n
  have hUS : Summable U := Summable.of_norm_bounded hF (fun n => by
    dsimp only [U]
    split_ifs <;> simp [norm_nonneg])
  have hQY (v : V) : Q (compactKD_featureAnalysis T v)=compactKD_featureAnalysis Y v := by
    let P := compactKD_featureAtRealCLM (G:=G) v
    have h := ((hs.hasSum.mapL P).mapL (Q.restrictScalars ℝ)).tsum_eq
    have h' := (hUS.hasSum.mapL P).tsum_eq
    change (∑' n, Q (compactKD_featureAnalysis (F n) v))=Q (compactKD_featureAnalysis T v) at h
    change (∑' n, compactKD_featureAnalysis (U n) v)=compactKD_featureAnalysis Y v at h'
    refine h.symm.trans ((tsum_congr fun n => (hex n).choose_spec v).trans h')
  have hDiag (x : G) (n : ℕ) : ⟪T x,F n x⟫=(‖F n x‖:ℂ)^2 := by
    let ev : C(G,V)→L[ℂ]V := ContinuousMap.evalCLM ℂ x
    let p := (innerSL ℂ (F n x)).comp ev
    have hh := (hs.hasSum.mapL p).tsum_eq
    change (∑' k, ⟪F n x,F k x⟫)=⟪F n x,T x⟫ at hh
    rw [tsum_eq_single n (fun k hk => hOrth n k (Ne.symm hk) x),inner_self_eq_norm_sq_to_K] at hh
    rw [←inner_conj_symm,←hh, map_pow]
    simp
  have hrow (x : G) :
      ⟪T x,Y x⟫ = ((∑' n, if sel n then ‖F n x‖^2 else 0 : ℝ):ℂ) := by
    let ev : C(G,V)→L[ℂ]V := ContinuousMap.evalCLM ℂ x
    let p := (innerSL ℂ (T x)).comp ev
    have hh := (hUS.hasSum.mapL p).tsum_eq
    change (∑' n, ⟪T x,U n x⟫)=⟪T x,Y x⟫ at hh
    rw [←hh,Complex.ofReal_tsum]
    apply tsum_congr
    intro n
    dsimp only [U]
    split_ifs with hs
    · rw [hDiag,Complex.ofReal_pow]
    · simp [inner_zero_right]
  have hreal (x : G) : 0≤(⟪T x,Y x⟫ : ℂ).re ∧ (⟪T x,Y x⟫ : ℂ).im=0 := by
    rw [hrow,Complex.ofReal_re,Complex.ofReal_im]
    exact ⟨tsum_nonneg (fun _ => by split_ifs <;> positivity),rfl⟩
  let d : C(G,ℂ) := ⟨fun x => ⟪T x,Y x⟫,T.continuous.inner Y.continuous⟩
  have hI : Integrable d ((ν).restrict E) :=
    (d.continuous.integrable_of_hasCompactSupport (HasCompactSupport.of_compactSpace _)).integrableOn
  have hTr := compactKD_feature_trace_eq_pointwise_row T Y Q hQ hQY b c E hE
  dsimp only
  rw [hTr]
  constructor
  · change 0≤Complex.reCLM (∫ x in E, d x ∂ν)
    rw [←Complex.reCLM.integral_comp_comm hI]
    exact integral_nonneg (fun x => (hreal x).1)
  · change Complex.imCLM (∫ x in E, d x ∂ν)=0
    rw [←Complex.imCLM.integral_comp_comm hI]
    calc
      _ = ∫ _ : G in E, (0:ℝ) ∂ν := integral_congr_ae (Filter.Eventually.of_forall fun x => (hreal x).2)
      _ = _ := integral_zero _ _

end CompactOrthogonalFeatureSeries

end CompactFourierKD


namespace CompactFourierKD
open MeasureTheory Measure ContinuousLinearMap
open scoped ComplexInnerProductSpace

section CompactIrrepFeatureSeries

variable {G X I J : Type*} [Group G] [TopologicalSpace G] [IsTopologicalGroup G]
  [CompactSpace G] [MeasurableSpace G] [BorelSpace G]
  [NormedAddCommGroup X] [InnerProductSpace ℂ X]
  {V : ℕ→Type*} [∀ n, NormedAddCommGroup (V n)] [∀ n, NormedSpace ℂ (V n)]
  [∀ n, FiniteDimensional ℂ (V n)] [∀ n, Nontrivial (V n)]
local notation "ν" => compactKDhaar G
variable (ρ : ∀ n,G→*(V n→L[ℂ]V n)) (hρ : ∀ n, Continuous (ρ n))
  (hIrr : ∀ n, compactRepresentationIrreducible (ρ n))
  (F : ℕ→C(G,X))
  (hFrep : ∀ n x, ∃ D, compactKD_featureAnalysis (F n) x=compactMatrixCoefficientCLM (ρ n) (hρ n) D)

omit [∀ n, Nontrivial (V n)] in
/-- The actual inverse-character Fourier operator for a named type. -/
noncomputable def compactKD_irrepFeatureProjection (n : ℕ) : HaarOp ν :=
  haarWeightedLeftConvolution (compactIrrepHaarKernel (ρ n) (hρ n))

variable [CompleteSpace X]

include hIrr hFrep in
/-- The named central projection picks precisely its own continuous feature row
from the entire uniform series, with no assumption on unoccupied types. -/
theorem compactKD_irrep_feature_selects_own_row
    (hNE : ∀ n m, n≠m → ¬∃ T : V n≃L[ℂ]V m, ∀ g v, T (ρ n g v)=ρ m g (T v))
    (hF : Summable fun n => ‖F n‖) (n : ℕ) (x : X) :
    compactKD_irrepFeatureProjection ρ hρ n (compactKD_featureAnalysis (∑' k,F k) x) =
      compactKD_featureAnalysis (F n) x := by
  let P := compactKD_irrepFeatureProjection ρ hρ n
  let Q (m : ℕ) := compactKD_irrepFeatureProjection ρ hρ m
  let U := compactKD_featureAtRealCLM (G:=G) x
  have hFix (m : ℕ) : Q m (compactKD_featureAnalysis (F m) x)=compactKD_featureAnalysis (F m) x := by
    obtain ⟨D,hD⟩ := hFrep m x
    rw [hD]
    exact compactIrrepHaarKernel_fixes_matrixCoefficient (ρ m) (hρ m) (hIrr m) D
  have hZ (m : ℕ) (hm : m≠n) : P (compactKD_featureAnalysis (F m) x)=0 := by
    have hPQ : P*Q m=0 :=
      compactIrrepHaarKernels_mul_eq_zero_of_inequivalent
        (ρ n) (ρ m) (hρ n) (hρ m) (hIrr n) (hIrr m) (hNE n m hm.symm)
    have hz := DFunLike.congr_fun hPQ (compactKD_featureAnalysis (F m) x)
    change P (Q m (compactKD_featureAnalysis (F m) x))=0 at hz
    rwa [hFix] at hz
  have hh := (((Summable.of_norm hF).hasSum.mapL U).mapL (P.restrictScalars ℝ)).tsum_eq
  change (∑' k, P (compactKD_featureAnalysis (F k) x))=
    P (compactKD_featureAnalysis (∑' k,F k) x) at hh
  rw [tsum_eq_single n hZ] at hh
  exact hh.symm.trans (hFix n)

variable [Countable I]

include hIrr hFrep in
/-- For the full feature state, positivity holds for every actual central
star projection, because an occupied irreducible block cannot split in Q. -/
theorem compactKD_irrep_feature_series_positive
    (hF : Summable fun n => ‖F n‖)
    (hOrth : ∀ n m, n≠m → ∀ g, ⟪F n g,F m g⟫=0)
    (Q : HaarOp ν) (hQC : InHaarFourierCenter ν Q) (hQP : IsStarProjection Q)
    (b : HilbertBasis I ℂ X) (c : HilbertBasis J ℂ (HaarL2 ν))
    (E : Set G) (hE : MeasurableSet E) :
    let V₀ := fun i => compactKD_featureAnalysis (∑' n,F n) (b i)
    let z := ∑' j, ⟪c j,compactRankOneDensity V₀ ((Q * positionIndicator ν E hE) (c j))⟫
    0≤z.re ∧ z.im=0 := by
  apply compactKD_orthogonal_feature_series_positive_for_Q F hF hOrth Q hQP.isSelfAdjoint
      _ b c E hE
  intro n
  rcases compactHaar_central_projection_matrixCoefficient_selects (ρ n) (hρ n) (hIrr n) Q hQC hQP with h|h
  · left
    intro x
    obtain ⟨D,hD⟩ := hFrep n x
    rw [hD,h]
  · right
    intro x
    obtain ⟨D,hD⟩ := hFrep n x
    rw [hD,h]

include hIrr hFrep in
/-- Every named row of a genuine positive Gram endpoint is nonnegative real
pointwise. The hypothesis quantifies over the actual center and positions. -/
theorem compactKD_irrep_feature_endpoint_rows
    (hNE : ∀ n m, n≠m → ¬∃ T : V n≃L[ℂ]V m, ∀ g v, T (ρ n g v)=ρ m g (T v))
    (hF : Summable fun n => ‖F n‖)
    (B : X→L[ℂ]X) (hB : B.IsPositive)
    (b : HilbertBasis I ℂ X) (c : HilbertBasis J ℂ (HaarL2 ν))
    (h : ∀ Q : HaarOp ν, InHaarFourierCenter ν Q → IsStarProjection Q →
      ∀ E, ∀ hE : MeasurableSet E,
      let A := compactKD_featureAnalysis (∑' n,F n)
      let z := ∑' j, ⟪c j,(A.comp (B.comp A.adjoint)) ((Q * positionIndicator ν E hE) (c j))⟫
      0≤z.re ∧ z.im=0) :
    ∀ n g, 0≤(⟪(∑' k,F k) g,B (F n g)⟫ : ℂ).re ∧
      (⟪(∑' k,F k) g,B (F n g)⟫ : ℂ).im=0 := by
  intro n
  let P := compactKD_irrepFeatureProjection ρ hρ n
  have hPC : InHaarFourierCenter ν P := compactIrrepHaarKernel_mem_center (ρ n) (hρ n)
  have hPP : IsStarProjection P := compactIrrepHaarKernel_isStarProjection (ρ n) (hρ n) (hIrr n)
  exact compactKD_middleGram_endpoint_row_nonnegative_everywhere (∑' k,F k) (F n) P
    hPP.isSelfAdjoint (compactKD_irrep_feature_selects_own_row ρ hρ hIrr F hFrep hNE hF n)
    B hB b c (h P hPC hPP)

end CompactIrrepFeatureSeries

end CompactFourierKD


namespace CompactFourierKD
open MeasureTheory Measure ContinuousLinearMap
open scoped ComplexInnerProductSpace

section IrrepFeatureRank

variable {G X : Type*} [Group G] [TopologicalSpace G] [IsTopologicalGroup G]
  [CompactSpace G] [MeasurableSpace G] [BorelSpace G]
  [NormedAddCommGroup X] [InnerProductSpace ℂ X] [CompleteSpace X]
  {V : ℕ→Type*} [∀ n, NormedAddCommGroup (V n)] [∀ n, NormedSpace ℂ (V n)]
  [∀ n, FiniteDimensional ℂ (V n)] [∀ n, Nontrivial (V n)]
local notation "ν" => compactKDhaar G

/-- Dense synthesis for the sum of genuine inequivalent irreducible feature
rows follows from the collective span of their values. No claim that the
algebraic span of the values of the summed field is already closed. -/
theorem compactKD_irrep_feature_synthesis_dense_and_gram_infinite
    (ρ : ∀ n,G→*(V n→L[ℂ]V n)) (hρ : ∀ n, Continuous (ρ n))
    (hIrr : ∀ n, compactRepresentationIrreducible (ρ n))
    (F : ℕ→C(G,X))
    (hRep : ∀ n x, ∃ D, compactKD_featureAnalysis (F n) x=compactMatrixCoefficientCLM (ρ n) (hρ n) D)
    (hNE : ∀ n m, n≠m → ¬∃ T : V n≃L[ℂ]V m, ∀ g v, T (ρ n g v)=ρ m g (T v))
    (hF : Summable fun n => ‖F n‖)
    (hSpan : (Submodule.span ℂ (⋃ n, Set.range (F n))).topologicalClosure=⊤)
    (hInf : ¬FiniteDimensional ℂ X) :
    let A := compactKD_featureAnalysis (∑' n,F n)
    DenseRange A.adjoint ∧ ¬FiniteDimensional ℂ (A.comp A.adjoint).range := by
  let A := compactKD_featureAnalysis (∑' n,F n)
  have hker : A.ker=⊥ := by
    apply eq_bot_iff.mpr
    intro v hv
    change A v=0 at hv
    have hZero (n : ℕ) : compactKD_featureAnalysis (F n) v=0 := by
      rw [←compactKD_irrep_feature_selects_own_row ρ hρ hIrr F hRep hNE hF n v]
      change compactKD_irrepFeatureProjection ρ hρ n (A v)=0
      rw [hv,map_zero]
    have hCoeff (n : ℕ) : compactKD_featureCoefficient (F n) v=0 := by
      let M : C(G,ℂ)→L[ℂ]HaarL2 ν := ContinuousMap.toLp 2 ν ℂ
      apply ContinuousMap.toLp_injective ν (p:=2) (𝕜:=ℂ)
      change M (compactKD_featureCoefficient (F n) v)=M 0
      rw [map_zero]
      exact hZero n
    let K := (ℂ∙v)ᗮ
    have hO : Submodule.span ℂ (⋃ n, Set.range (F n))≤K := Submodule.span_le.mpr (by
      intro y hy
      obtain ⟨n,hy⟩ := Set.mem_iUnion.mp hy
      obtain ⟨g,rfl⟩ := hy
      exact Submodule.mem_orthogonal_singleton_iff_inner_left.mpr (DFunLike.congr_fun (hCoeff n) g))
    have hOTop := Submodule.topologicalClosure_minimal _ hO ((ℂ∙v) : Submodule ℂ X).isClosed_orthogonal
    rw [hSpan] at hOTop
    have hvO : v∈K := hOTop (Submodule.mem_top : v∈⊤)
    rw [Submodule.mem_bot]
    exact inner_self_eq_zero.mp (Submodule.mem_orthogonal_singleton_iff_inner_left.mp hvO)
  have hd : A.adjoint.range.topologicalClosure=⊤ := by
    apply Submodule.topologicalClosure_eq_top_iff.mpr
    rw [ContinuousLinearMap.orthogonal_range,adjoint_adjoint,hker]
  have hD : DenseRange A.adjoint := by
    rw [denseRange_iff_closure_range,←show (A.adjoint.range : Set X)=Set.range A.adjoint from rfl,
      ←Submodule.topologicalClosure_coe,hd]
    rfl
  refine ⟨hD, ?_⟩
  intro hR
  have hInj : Function.Injective A := LinearMap.ker_eq_bot.mp hker
  have hRange : (A.comp A.adjoint).range=A.adjoint.range.map A.toLinearMap := by
    ext x
    constructor
    · rintro ⟨y,rfl⟩
      exact ⟨A.adjoint y,⟨y,rfl⟩,rfl⟩
    · rintro ⟨_,⟨z,rfl⟩,rfl⟩
      exact ⟨z,rfl⟩
  rw [hRange] at hR
  let : FiniteDimensional ℂ A.adjoint.range :=
    (Module.Finite.equiv_iff (Submodule.equivMapOfInjective A.toLinearMap hInj _).symm).mp hR
  have hClosed : IsClosed (A.adjoint.range : Set X) := A.adjoint.range.closed_of_finiteDimensional
  have hTop : A.adjoint.range=⊤ := by
    apply SetLike.coe_injective
    change (A.adjoint.range : Set X)=Set.univ
    rw [←hClosed.closure_eq]
    exact hD.closure_range
  let : FiniteDimensional ℂ (⊤ : Submodule ℂ X) := hTop ▸ inferInstanceAs (FiniteDimensional ℂ A.adjoint.range)
  exact hInf (Module.Finite.equiv (Submodule.topEquiv (R:=ℂ) (M:=X)))

end IrrepFeatureRank
end CompactFourierKD

/-! A bounded Gram endpoint descends along the dense feature map. -/

namespace KD3Discrete

noncomputable section
open ContinuousLinearMap

variable {H K J : Type*} [NormedAddCommGroup H] [InnerProductSpace ℂ H] [CompleteSpace H]
  [NormedAddCommGroup K] [InnerProductSpace ℂ K] [CompleteSpace K]
  [NormedAddCommGroup J] [InnerProductSpace ℂ J] [CompleteSpace J]

/-- Core Gram-domination step: extend a factor on the dense feature range and take its Gram.
The endpoint is supplied as the Gram of S; asking for that factor is not an axiom of this theorem. -/
theorem gram_factor_of_norm_domination
    (W : H →L[ℂ] K) (S : H →L[ℂ] J) (hW : DenseRange W)
    (C : ℝ) (hC : 0 ≤ C) (hdom : ∀ x, ‖S x‖ ≤ C * ‖W x‖) :
    ∃ T : K →L[ℂ] K,
      T.IsPositive ∧ ‖T‖ ≤ C^2 ∧
      S.adjoint.comp S = W.adjoint.comp (T.comp W) := by
  let R := S.toLinearMap.extendOfNorm W.toLinearMap
  have hRapply (x : H) : R (W x) = S x :=
    LinearMap.extendOfNorm_eq hW ⟨C, hdom⟩ x
  have hR : S = R.comp W := by
    apply ContinuousLinearMap.ext
    exact fun x => (hRapply x).symm
  have hnorm (y : K) : ‖R y‖ ≤ C * ‖y‖ :=
    LinearMap.norm_extendOfNorm_apply_le hW C hdom y
  have hRn : ‖R‖ ≤ C := (ContinuousLinearMap.opNorm_le_iff hC).2 hnorm
  refine ⟨R.adjoint.comp R, ContinuousLinearMap.isPositive_adjoint_comp_self R, ?_, ?_⟩
  · rw [ContinuousLinearMap.norm_adjoint_comp_self, ← pow_two]
    exact pow_le_pow_left₀ (norm_nonneg _) hRn _
  · conv_lhs => rw [hR]
    rw [ContinuousLinearMap.adjoint_comp, ContinuousLinearMap.comp_assoc,
      ContinuousLinearMap.comp_assoc]


/-- A positive bounded endpoint dominated by the Gram of W on quadratic forms descends with
the same upper form constant. This is the actual endpoint step used in extremality. -/
theorem positive_gram_endpoint
    (W : H →L[ℂ] K) (B : H →L[ℂ] H) (hW : DenseRange W)
    (hB : B.IsPositive) (C : ℝ) (hC : 0 ≤ C)
    (hdom : ∀ x, B.reApplyInnerSelf x ≤ C * ‖W x‖^2) :
    ∃ T : K →L[ℂ] K,
      T.IsPositive ∧ ‖T‖ ≤ C ∧ B = W.adjoint.comp (T.comp W) := by
  obtain ⟨S, hS⟩ := CStarAlgebra.nonneg_iff_eq_star_mul_self.mp
    ((ContinuousLinearMap.nonneg_iff_isPositive B).2 hB)
  have hS' : B = S.adjoint.comp S := hS
  have hbound (x : H) : ‖S x‖ ≤ Real.sqrt C * ‖W x‖ := by
    apply (sq_le_sq₀ (norm_nonneg _) (mul_nonneg (Real.sqrt_nonneg _) (norm_nonneg _))).mp
    rw [mul_pow, Real.sq_sqrt hC, ContinuousLinearMap.apply_norm_sq_eq_inner_adjoint_left, ← hS']
    exact hdom x
  obtain ⟨T, hT, hTnorm, hTB⟩ :=
    gram_factor_of_norm_domination W S hW (Real.sqrt C) (Real.sqrt_nonneg _) hbound
  exact ⟨T, hT, by simpa [Real.sq_sqrt hC] using hTnorm, hS'.trans hTB⟩


end
end KD3Discrete
namespace CompactFourierKD
open MeasureTheory Measure ContinuousLinearMap
open scoped ComplexInnerProductSpace

section ActualKDPositivity

variable {X J : Type*} [Group X] [MeasurableSpace X] [MeasurableMul X]
  (μ : Measure X) [IsMulLeftInvariant μ]

/-- Central Fourier KD positivity with the original trace order ρ Q M_E,
evaluated by an actual Hilbert-basis trace. The separately checked
trace-class theorem guarantees basis independence for normal states. -/
def compactKDPositiveAt (b : HilbertBasis J ℂ (HaarL2 μ)) (A : HaarOp μ) : Prop :=
  ∀ (Q : HaarOp μ), InHaarFourierCenter μ Q → IsStarProjection Q →
    ∀ (E : Set X) (hE : MeasurableSet E),
      let z := ∑' j, ⟪b j,A ((Q * positionIndicator μ E hE) (b j))⟫
      0≤z.re ∧ z.im=0

end ActualKDPositivity
section HaarNormalStateDefinition

variable {G I J : Type*} [Group G] [MeasurableSpace G] [MeasurableMul G]
  (ν : Measure G) [IsMulLeftInvariant ν]

/-- The exact operator normal-state class used in Paper 3: positive,
trace class with trace one, and all central Fourier/position tests.
Trace-classness is the usual summability of the diagonal of a positive
operator. Previously checked rank-one completeness makes this independent of b. -/
structure CompactKDNormalStateAt (b : HilbertBasis J ℂ (HaarL2 ν)) (A : HaarOp ν) : Prop where
  positive : A.IsPositive
  traceClass : Summable fun j => (⟪b j,A (b j)⟫ : ℂ).re
  traceOne : (∑' j, ⟪b j,A (b j)⟫)=1
  kd : compactKDPositiveAt ν b A

/-- The midpoint characterization of an extreme point in this convex
class of normal states, as used verbatim in the manuscript. -/
def CompactKDExtremeAt (b : HilbertBasis J ℂ (HaarL2 ν)) (A : HaarOp ν) : Prop :=
  CompactKDNormalStateAt ν b A ∧
    ∀ B C, CompactKDNormalStateAt ν b B → CompactKDNormalStateAt ν b C →
      B+C=2 • A → B=A ∧ C=A

end HaarNormalStateDefinition
end CompactFourierKD


namespace CompactFourierKD
open MeasureTheory Measure ContinuousLinearMap
open scoped ComplexInnerProductSpace

section DenseFeatureExtreme

variable {G X J : Type*} [Group G] [MeasurableSpace G] [MeasurableMul G]
  (μ : Measure G) [IsMulLeftInvariant μ]
  [NormedAddCommGroup X] [InnerProductSpace ℂ X] [CompleteSpace X]

/-- A genuine normal KD Gram is midpoint extreme when its measured
endpoint rows lock every positive bounded middle operator to a scalar.
All positive normal midpoint endpoints, not only prescribed Gram states,
are included, using the actual dense-range Gram domination theorem. -/
theorem compactKD_extreme_of_dense_gram_endpoint_lock
    (b : HilbertBasis J ℂ (HaarL2 μ)) (W : HaarL2 μ→L[ℂ]X)
    (hW : DenseRange W) (hA : CompactKDNormalStateAt μ b (W.adjoint.comp W))
    (hLock : ∀ T : X→L[ℂ]X, T.IsPositive →
      compactKDPositiveAt μ b (W.adjoint.comp (T.comp W)) → ∃ a : ℂ, ∀ x, T x=a • x) :
    CompactKDExtremeAt μ b (W.adjoint.comp W) := by
  let A := W.adjoint.comp W
  refine ⟨hA,?_⟩
  have oneEnd (B C : HaarOp μ) (hB : CompactKDNormalStateAt μ b B)
      (hC : CompactKDNormalStateAt μ b C) (hBC : B+C=2 • A) : B=A := by
    have hdom (x : HaarL2 μ) : B.reApplyInnerSelf x≤2*‖W x‖^2 := by
      have hp : 0≤C.reApplyInnerSelf x := hC.positive.re_inner_nonneg_left x
      have hh : B+C=A+A := by rwa [two_nsmul] at hBC
      have hp' : B x+C x=A x+A x := DFunLike.congr_fun hh x
      have he := congrArg (fun v : HaarL2 μ => (⟪v,x⟫ : ℂ).re) hp'
      rw [inner_add_left,inner_add_left,Complex.add_re,Complex.add_re] at he
      have he' : B.reApplyInnerSelf x+C.reApplyInnerSelf x=2*‖W x‖^2 := by
        rw [W.apply_norm_sq_eq_inner_adjoint_left,two_mul]
        exact he
      linarith
    obtain ⟨T,hT,_,hBT⟩ := KD3Discrete.positive_gram_endpoint W B hW hB.positive 2 (by norm_num) hdom
    obtain ⟨z,hz⟩ := hLock T hT (hBT ▸ hB.kd)
    have hBa : B=z • A := by
      rw [hBT]
      apply ContinuousLinearMap.ext
      intro x
      change W.adjoint (T (W x))=z • W.adjoint (W x)
      rw [hz,map_smul]
    have hTrace : (∑' j, ⟪b j,B (b j)⟫)=1 := hB.traceOne
    rw [hBa] at hTrace
    have hAtrace : (∑' j, ⟪b j,A (b j)⟫)=1 := hA.traceOne
    simp only [_root_.smul_apply,inner_smul_right,tsum_mul_left,hAtrace,mul_one] at hTrace
    simpa only [hTrace,one_smul] using hBa
  intro B C hB hC hBC
  exact ⟨oneEnd B C hB hC hBC,oneEnd C B hC hB (by rwa [add_comm])⟩

/-- A positively rescaled genuine normal KD Gram is midpoint extreme when its measured
endpoint rows lock every positive bounded middle operator to a scalar.
All positive normal midpoint endpoints, not only prescribed Gram states,
are included, using the actual dense-range Gram domination theorem. -/
theorem compactKD_extreme_of_scaled_dense_gram_endpoint_lock
    (b : HilbertBasis J ℂ (HaarL2 μ)) (W : HaarL2 μ→L[ℂ]X)
    (hW : DenseRange W) (r : ℝ) (hr : 0<r)
    (hA : CompactKDNormalStateAt μ b ((r:ℂ) • W.adjoint.comp W))
    (hLock : ∀ T : X→L[ℂ]X, T.IsPositive →
      compactKDPositiveAt μ b (W.adjoint.comp (T.comp W)) → ∃ a : ℂ, ∀ x, T x=a • x) :
    CompactKDExtremeAt μ b ((r:ℂ) • W.adjoint.comp W) := by
  let A := (r:ℂ) • W.adjoint.comp W
  refine ⟨hA,?_⟩
  have oneEnd (B C : HaarOp μ) (hB : CompactKDNormalStateAt μ b B)
      (hC : CompactKDNormalStateAt μ b C) (hBC : B+C=2 • A) : B=A := by
    have hdom (x : HaarL2 μ) : B.reApplyInnerSelf x≤(2*r)*‖W x‖^2 := by
      have hp : 0≤C.reApplyInnerSelf x := hC.positive.re_inner_nonneg_left x
      have hh : B+C=A+A := by rwa [two_nsmul] at hBC
      have hp' : B x+C x=A x+A x := DFunLike.congr_fun hh x
      have he := congrArg (fun v : HaarL2 μ => (⟪v,x⟫ : ℂ).re) hp'
      rw [inner_add_left,inner_add_left,Complex.add_re,Complex.add_re] at he
      have hGram : (⟪A x,x⟫ : ℂ).re = r*‖W x‖^2 := by
        change (⟪(r:ℂ) • W.adjoint (W x),x⟫ : ℂ).re = _
        have hh := W.apply_norm_sq_eq_inner_adjoint_left x
        change ‖W x‖^2=(⟪W.adjoint (W x),x⟫ : ℂ).re at hh
        rw [inner_smul_left,Complex.conj_ofReal,Complex.mul_re,Complex.ofReal_re,
          Complex.ofReal_im,zero_mul,sub_zero,←hh]
      rw [hGram] at he
      change B.reApplyInnerSelf x+C.reApplyInnerSelf x=r*‖W x‖^2+r*‖W x‖^2 at he
      rw [mul_assoc,two_mul]
      linarith
    obtain ⟨T,hT,_,hBT⟩ := KD3Discrete.positive_gram_endpoint W B hW hB.positive (2*r) (by positivity) hdom
    obtain ⟨z,hz⟩ := hLock T hT (hBT ▸ hB.kd)
    have hr' : (r:ℂ)≠0 := by exact_mod_cast hr.ne'
    have hBa : B=(z/(r:ℂ)) • A := by
      rw [hBT]
      apply ContinuousLinearMap.ext
      intro x
      change W.adjoint (T (W x))=(z/(r:ℂ)) • ((r:ℂ) • W.adjoint (W x))
      rw [hz,map_smul,smul_smul,div_mul_cancel₀ _ hr']
    have hTrace : (∑' j, ⟪b j,B (b j)⟫)=1 := hB.traceOne
    rw [hBa] at hTrace
    have hAtrace : (∑' j, ⟪b j,A (b j)⟫)=1 := hA.traceOne
    simp only [_root_.smul_apply,inner_smul_right,tsum_mul_left,hAtrace,mul_one] at hTrace
    simpa only [hTrace,one_smul] using hBa
  intro B C hB hC hBC
  exact ⟨oneEnd B C hB hC hBC,oneEnd C B hC hB (by rwa [add_comm])⟩


end DenseFeatureExtreme
end CompactFourierKD


namespace CompactFourierKD
open MeasureTheory Measure ContinuousLinearMap
open scoped ComplexInnerProductSpace ComplexOrder

section CompactGramNormalize
variable {G I J : Type*} [Group G] [MeasurableSpace G] [MeasurableMul G]
  (μ : Measure G) [IsMulLeftInvariant μ]

/-- Every positive real scaling preserves and reflects the actual
ordered Haar Fourier/position inequalities. -/
theorem compactKDPositive_realScale_iff
    (b : HilbertBasis J ℂ (HaarL2 μ)) (A : HaarOp μ) (r : ℝ) (hr : 0<r) :
    compactKDPositiveAt μ b ((r:ℂ) • A) ↔ compactKDPositiveAt μ b A := by
  constructor <;> intro h Q hQC hQP E hE
  · have H := h Q hQC hQP E hE
    simp only [_root_.smul_apply,inner_smul_right,tsum_mul_left,Complex.mul_re,Complex.mul_im,
      Complex.ofReal_re,Complex.ofReal_im,zero_mul,sub_zero,add_zero] at H
    exact ⟨(mul_nonneg_iff_of_pos_left hr).mp H.1,(mul_eq_zero.mp H.2).resolve_left hr.ne'⟩
  · have H := h Q hQC hQP E hE
    simp only [_root_.smul_apply,inner_smul_right,tsum_mul_left,Complex.mul_re,Complex.mul_im,
      Complex.ofReal_re,Complex.ofReal_im,zero_mul,sub_zero,add_zero]
    exact ⟨mul_nonneg hr.le H.1,mul_eq_zero.mpr (Or.inr H.2)⟩

/-- Normalize the genuine trace of a nonzero summable rank-one Gram by
one global positive scalar, preserving the exact KD inequalities. -/
theorem compactKD_normalize_rankOne_density
    (b : HilbertBasis J ℂ (HaarL2 μ)) (v : I→HaarL2 μ)
    (hv : Summable fun i => ‖v i‖^2) (hNZ : ∃ i, v i≠0)
    (h : compactKDPositiveAt μ b (compactRankOneDensity v)) :
    ∃ r : ℝ, 0<r ∧ CompactKDNormalStateAt μ b ((r:ℂ) • compactRankOneDensity v) := by
  let m : ℝ := ∑' i, ‖v i‖^2
  obtain ⟨i,hi⟩ := hNZ
  have hm : 0<m := hv.tsum_pos (fun _ => sq_nonneg _) i (pow_pos (norm_pos_iff.mpr hi) _)
  let r : ℝ := m⁻¹
  have hr : 0<r := inv_pos.mpr hm
  refine ⟨r,hr,⟨(compactRankOneDensity_positive v hv).smul_of_nonneg
    (Complex.zero_le_real.mpr hr.le),?_,?_,(compactKDPositive_realScale_iff μ b _ r hr).mpr h⟩⟩
  · have habs := (compactRankOneDensity_basis_trace_pairing v hv (1 : HaarOp μ) b).1
    simp only [one_apply_eq_self] at habs
    have hre : Summable fun j => (⟪b j,compactRankOneDensity v (b j)⟫ : ℂ).re :=
      ((Summable.of_norm habs).hasSum.mapL Complex.reCLM).summable
    simp only [_root_.smul_apply,inner_smul_right,Complex.mul_re,Complex.ofReal_re,
      Complex.ofReal_im,zero_mul,sub_zero]
    exact hre.mul_left r
  · have hBase := (compactRankOneDensity_basis_trace_pairing v hv (1 : HaarOp μ) b).2
    simp only [one_apply_eq_self,inner_self_eq_norm_sq_to_K] at hBase
    have hMass : (∑' i, (‖v i‖:ℂ)^2)=(m:ℂ) := by
      rw [Complex.ofReal_tsum]
      simp only [Complex.ofReal_pow]
    simp only [_root_.smul_apply,inner_smul_right,tsum_mul_left,hBase]
    change (r:ℂ)*(∑' i, (‖v i‖:ℂ)^2)=1
    rw [hMass]
    change ((m⁻¹:ℝ):ℂ)*(m:ℂ)=1
    rw [Complex.ofReal_inv,inv_mul_cancel₀ (by exact_mod_cast hm.ne')]

omit [Group G] [MeasurableMul G] [μ.IsMulLeftInvariant] in
/-- Actual infinite rank is unaffected by a nonzero global scaling. -/
theorem compactKD_realScale_range
    (A : HaarOp μ) (r : ℝ) (hr : r≠0) : (((r:ℂ) • A) : HaarOp μ).range=A.range := by
  have hc : (r:ℂ)≠0 := by exact_mod_cast hr
  ext y
  constructor
  · rintro ⟨x,rfl⟩
    refine ⟨(r:ℂ) • x,?_⟩
    change A ((r:ℂ) • x)=(r:ℂ) • A x
    exact map_smul A _ _
  · rintro ⟨x,rfl⟩
    refine ⟨(r:ℂ)⁻¹ • x,?_⟩
    change (r:ℂ) • A ((r:ℂ)⁻¹ • x)=A x
    rw [map_smul,smul_smul,mul_inv_cancel₀ hc,one_smul]

end CompactGramNormalize
end CompactFourierKD



namespace CompactFourierKD
open scoped ComplexInnerProductSpace

section ConnectedHilbertFibres

variable {V : Type*} [NormedAddCommGroup V] [InnerProductSpace ℂ V]

noncomputable abbrev ConnectedLabelSpace := lp (fun _ : ℕ => ℂ) 2
abbrev ConnectedFibreSpace (V : Type*) [NormedAddCommGroup V] := lp (fun _ : ℕ => V) 2

/-- Hilbert tensor along a single label, realized in ℓ²(ℕ,V). -/
noncomputable def connectedTensorLabel (v : V) : ConnectedLabelSpace→L[ℂ]ConnectedFibreSpace V := by
  let S : ConnectedLabelSpace→ₗ[ℂ]ConnectedFibreSpace V :=
    { toFun := fun h => ⟨fun i => h i • v, by
        apply Memℓp.of_norm
        simp only [norm_smul, mul_comm _ ‖v‖]
        exact (lp.memℓp h).norm.const_mul ‖v‖⟩
      map_add' := fun h k => by apply lp.ext; funext i; exact add_smul (h i) (k i) v
      map_smul' := fun a h => by apply lp.ext; funext i; exact mul_smul a (h i) v }
  exact S.mkContinuous ‖v‖ (fun h => by
    have hNorm : lp.toNorm (S h)=‖v‖ • lp.toNorm h := by
      apply lp.ext
      funext i
      exact (norm_smul (h i) v).trans (mul_comm _ _)
    rw [←lp.norm_toNorm (x:=S h),hNorm,norm_smul,lp.norm_toNorm,Real.norm_eq_abs,
      abs_of_nonneg (norm_nonneg v)])

theorem connectedTensorLabel_coord (h : ConnectedLabelSpace) (v : V) (i : ℕ) :
    connectedTensorLabel v h i=h i • v := rfl

theorem connectedTensorLabel_inner (h k : ConnectedLabelSpace) (v w : V) :
    ⟪connectedTensorLabel v h,connectedTensorLabel w k⟫=⟪h,k⟫*⟪v,w⟫ := by
  rw [lp.inner_eq_tsum,lp.inner_eq_tsum,←tsum_mul_right]
  refine tsum_congr fun i => ?_
  simp only [connectedTensorLabel_coord,inner_smul_left,inner_smul_right,
    RCLike.inner_apply]
  ac_rfl

noncomputable def connectedCoordinateEmb (i : ℕ) : V→L[ℂ]ConnectedFibreSpace V :=
  lp.singleContinuousLinearMap ℂ (fun _ : ℕ => V) 2 i

theorem connectedCoordinateEmb_apply (i : ℕ) (v : V) :
    connectedCoordinateEmb i v=lp.single 2 i v := rfl

theorem connectedTensorLabel_single (i : ℕ) (v : V) :
    connectedTensorLabel v (lp.single 2 i 1)=connectedCoordinateEmb i v := by
  apply lp.ext
  funext j
  simp only [connectedTensorLabel_coord,connectedCoordinateEmb_apply,lp.coeFn_single]
  by_cases h : j=i
  · subst j
    simp
  · simp [Pi.single_eq_of_ne h]

theorem connectedCoordinateEmb_inner_left (i : ℕ) (v : V) (x : ConnectedFibreSpace V) :
    ⟪connectedCoordinateEmb i v,x⟫=⟪v,x i⟫ :=
  lp.inner_single_left i v x

theorem connectedCoordinateEmb_inner_right (i : ℕ) (v : V) (x : ConnectedFibreSpace V) :
    ⟪x,connectedCoordinateEmb i v⟫=⟪x i,v⟫ :=
  lp.inner_single_right i v x

end ConnectedHilbertFibres


end CompactFourierKD


section ConnectedTopologyInline

/-
Copyright (c) 2017 Johannes Hölzl. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Johannes Hölzl, Mario Carneiro
-/


/-!
# Interaction of separation properties with connectedness properties
-/


variable {X : Type*} [TopologicalSpace X]

open Filter Set
open scoped Topology

-- see Note [lower instance priority]
instance (priority := 100) TotallyDisconnectedSpace.t1Space [h : TotallyDisconnectedSpace X] :
    T1Space X := by
  rw [((t1Space_TFAE X).out 0 1 :)]
  intro x
  rw [← totallyDisconnectedSpace_iff_connectedComponent_singleton.mp h x]
  exact isClosed_connectedComponent

theorem PreconnectedSpace.trivial_of_discrete [PreconnectedSpace X] [DiscreteTopology X] :
    Subsingleton X := by
  by_contra! ⟨x, y, hxy⟩
  rw [Ne, ← mem_singleton_iff, (isClopen_discrete _).eq_univ <| singleton_nonempty y] at hxy
  exact hxy (mem_univ x)

theorem IsPreconnected.infinite_of_nontrivial [T1Space X] {s : Set X} (h : IsPreconnected s)
    (hs : s.Nontrivial) : s.Infinite := by
  refine mt (fun hf => (subsingleton_coe s).mp ?_) (not_subsingleton_iff.mpr hs)
  have := @Finite.instDiscreteTopology s _ _ hf.to_subtype
  exact @PreconnectedSpace.trivial_of_discrete _ _ (Subtype.preconnectedSpace h) _

theorem PreconnectedSpace.infinite [PreconnectedSpace X] [Nontrivial X] [T1Space X] : Infinite X :=
  infinite_univ_iff.mp <| isPreconnected_univ.infinite_of_nontrivial nontrivial_univ

theorem subsingleton_iff_discrete_and_indiscrete :
    Subsingleton X ↔ DiscreteTopology X ∧ IndiscreteTopology X :=
  ⟨fun _ ↦ ⟨inferInstance, inferInstance⟩, fun ⟨_, _⟩ ↦ PreconnectedSpace.trivial_of_discrete⟩

/-- A non-trivial connected T1 space has no isolated points. -/
instance (priority := 100) ConnectedSpace.neBot_nhdsWithin_compl_of_nontrivial_of_t1space
    [ConnectedSpace X] [Nontrivial X] [T1Space X] (x : X) :
    NeBot (𝓝[≠] x) := by
  by_contra contra
  rw [not_neBot, ← isOpen_singleton_iff_punctured_nhds] at contra
  replace contra := nonempty_inter isOpen_compl_singleton
    contra (compl_union_self _) (Set.nonempty_compl_of_nontrivial _) (singleton_nonempty _)
  simp [compl_inter_self {x}] at contra


end ConnectedTopologyInline


namespace CompactFourierKD
open scoped ComplexInnerProductSpace

/-- In the connected compact branch, the scalar with which a block
acts on a unit coherent line is continuous in the group point and
belongs to a finite spectrum. Connectedness makes that scalar
constant, and the actual spanning hypothesis then makes the entire
block scalar. This is not an assumption of scalarity. -/
theorem connected_spanning_eigenlines_force_scalar
    {X V : Type*} [TopologicalSpace X] [ConnectedSpace X]
    [NormedAddCommGroup V] [InnerProductSpace ℂ V] [FiniteDimensional ℂ V]
    (u : X→V) (hu : Continuous u) (hUnit : ∀ x, ‖u x‖=1)
    (hSpan : Submodule.span ℂ (Set.range u)=⊤)
    (T : V→L[ℂ]V) (hEig : ∀ x, ∃ a : ℂ, T (u x)=a • u x) :
    ∃ a : ℂ, ∀ v, T v=a • v := by
  let z : X→ℂ := fun x => ⟪u x,T (u x)⟫
  have hzC : Continuous z := hu.inner (T.continuous.comp hu)
  have hzEq (x : X) : T (u x)=z x • u x := by
    obtain ⟨a,ha⟩ := hEig x
    have hh : z x=a := by
      change ⟪u x,T (u x)⟫=a
      simp [ha,inner_smul_right,inner_self_eq_norm_sq_to_K,hUnit]
    rwa [hh]
  have hFin : (Set.range z).Finite :=
    (Module.End.finite_hasEigenvalue T.toLinearMap).subset (by
      rintro _ ⟨x,rfl⟩
      apply Module.End.hasEigenvalue_of_hasEigenvector (x:=u x)
      exact ⟨(Module.End.mem_eigenspace_iff).mpr (hzEq x),
        fun h => by simpa [h] using hUnit x⟩)
  have hC : IsPreconnected (Set.range z) := isPreconnected_range hzC
  obtain ⟨x₀⟩ := (inferInstance : Nonempty X)
  let a := z x₀
  have hConst (x : X) : z x=a := by
    by_contra hn
    exact hFin.not_infinite (hC.infinite_of_nontrivial
      ⟨z x,⟨x,rfl⟩,a,⟨x₀,rfl⟩,hn⟩)
  have hSub : Submodule.span ℂ (Set.range u)≤Module.End.eigenspace T.toLinearMap a := by
    apply Submodule.span_le.mpr
    rintro _ ⟨x,rfl⟩
    apply Module.End.mem_eigenspace_iff.mpr
    change T (u x) = a • u x
    exact (hzEq x).trans (congrArg (fun s : ℂ => s • u x) (hConst x))
  rw [hSpan] at hSub
  exact ⟨a,fun v => (Module.End.mem_eigenspace_iff).mp (hSub (Submodule.mem_top : v∈⊤))⟩

end CompactFourierKD

namespace CompactFourierKD
open ContinuousLinearMap
open scoped ComplexInnerProductSpace

section ConnectedFibreBlocks

variable {V X : Type*} [NormedAddCommGroup V] [InnerProductSpace ℂ V]
  [CompleteSpace V] [FiniteDimensional ℂ V]
  [TopologicalSpace X] [ConnectedSpace X]

/-- The actual (i,k) matrix block of a bounded operator on ℓ²(ℕ,V). -/
noncomputable def connectedKD_fibreBlock (B : ConnectedFibreSpace V→L[ℂ]ConnectedFibreSpace V)
    (i k : ℕ) : V→L[ℂ]V :=
  (lp.evalCLM ℂ (fun _ : ℕ => V) 2 i).comp (B.comp (connectedCoordinateEmb k))

omit [CompleteSpace V] [FiniteDimensional ℂ V] in
theorem connectedKD_fibreBlock_apply (B : ConnectedFibreSpace V→L[ℂ]ConnectedFibreSpace V)
    (i k : ℕ) (v : V) : connectedKD_fibreBlock B i k v=B (connectedCoordinateEmb k v) i := rfl

omit [CompleteSpace V] [FiniteDimensional ℂ V] in
/-- Vanishing off-diagonal blocks genuinely forces a pointwise diagonal
operator on the complete, infinite-dimensional Hilbert sum. -/
theorem connectedKD_fibreBlock_diagonal
    (B : ConnectedFibreSpace V→L[ℂ]ConnectedFibreSpace V)
    (hB : ∀ i k, i≠k → connectedKD_fibreBlock B i k=0) (x : ConnectedFibreSpace V) (i : ℕ) :
    B x i=connectedKD_fibreBlock B i i (x i) := by
  let J := lp.evalCLM ℂ (fun _ : ℕ => V) 2 i
  change J.comp B x=((connectedKD_fibreBlock B i i).comp J) x
  suffices h : J.comp B=(connectedKD_fibreBlock B i i).comp J from DFunLike.congr_fun h x
  apply lp.ext_continuousLinearMap (by norm_num)
  intro k
  apply ContinuousLinearMap.ext
  intro v
  change connectedKD_fibreBlock B i k v=connectedKD_fibreBlock B i i (lp.single (E:=fun _ : ℕ => V) 2 k v i)
  rw [lp.coeFn_single]
  by_cases h : i=k
  · subst k
    rw [Pi.single_eq_same]
  · rw [Pi.single_eq_of_ne h,hB i k h,zero_apply,map_zero]

/-- The first two checks in the connected proof: the distinguished coherent
diagonal separates all off-diagonal blocks, and the transported orthogonal
coherent frame plus connectedness makes each diagonal block scalar. -/
theorem connectedKD_coherent_fibre_blocks_scalar
    (e : X→V) (heC : Continuous e) (heU : ∀ g, ‖e g‖=1)
    (heSpan : Submodule.span ℂ (Set.range e)=⊤)
    (heSep : ∀ S : V→L[ℂ]V, (∀ g, ⟪e g,S (e g)⟫=0) → S=0)
    (w : ℕ→X→V) (hFrame : ∀ g, Submodule.span ℂ (Set.range fun j => w j g)=(ℂ∙e g)ᗮ)
    (h : ℕ→ConnectedLabelSpace) (hH : ∀ i j, h j i≠0)
    (B : ConnectedFibreSpace V→L[ℂ]ConnectedFibreSpace V) (hB : IsSelfAdjoint B)
    (hUU : ∀ i k, i≠k → ∀ g, ⟪connectedCoordinateEmb i (e g),B (connectedCoordinateEmb k (e g))⟫=0)
    (hUV : ∀ i j g, ⟪connectedCoordinateEmb i (e g),B (connectedTensorLabel (w j g) (h j))⟫=0) :
    ∃ s : ℕ→ℂ, ∀ x : ConnectedFibreSpace V, ∀ i, B x i=s i • x i := by
  have hOff (i k : ℕ) (hik : i≠k) : connectedKD_fibreBlock B i k=0 := by
    apply heSep
    intro g
    rw [connectedKD_fibreBlock_apply,←connectedCoordinateEmb_inner_left]
    exact hUU i k hik g
  let S (i : ℕ) := connectedKD_fibreBlock B i i
  have hAdj : B.adjoint=B := isSelfAdjoint_iff'.mp hB
  have hSingle (i : ℕ) (v : V) : B (connectedCoordinateEmb i v)=connectedCoordinateEmb i (S i v) := by
    apply lp.ext
    funext k
    rw [connectedKD_fibreBlock_diagonal B hOff]
    change S k ((lp.single (E:=fun _ : ℕ => V) 2 i v) k)=(lp.single (E:=fun _ : ℕ => V) 2 i (S i v)) k
    rw [lp.coeFn_single,lp.coeFn_single]
    by_cases hh : k=i
    · subst k
      simp only [Pi.single_eq_same]
    · simp only [Pi.single_eq_of_ne hh,map_zero]
  have hEig (i : ℕ) (g : X) : ∃ a : ℂ, S i (e g)=a • e g := by
    have hh (j : ℕ) : ⟪S i (e g),w j g⟫=0 := by
      have hz := hUV i j g
      rw [←hAdj,adjoint_inner_right,hSingle,connectedCoordinateEmb_inner_left,connectedTensorLabel_coord,
        inner_smul_right] at hz
      exact (mul_eq_zero.mp hz).resolve_left (hH i j)
    have hsub : Submodule.span ℂ (Set.range fun j => w j g)≤(ℂ∙S i (e g))ᗮ :=
      Submodule.span_le.mpr (by
        rintro x ⟨j,rfl⟩
        exact Submodule.mem_orthogonal_singleton_iff_inner_right.mpr (hh j))
    rw [hFrame] at hsub
    have hy : S i (e g)∈(ℂ∙e g)ᗮᗮ := (Submodule.orthogonal_le hsub)
      (Submodule.le_orthogonal_orthogonal (ℂ∙S i (e g)) (Submodule.mem_span_singleton_self _))
    rw [Submodule.orthogonal_orthogonal] at hy
    obtain ⟨a,ha⟩ := Submodule.mem_span_singleton.mp hy
    exact ⟨a,ha.symm⟩
  have H (i : ℕ) : ∃ a : ℂ, ∀ v, S i v=a • v :=
    connected_spanning_eigenlines_force_scalar e heC heU heSpan (S i) (hEig i)
  choose s hs using H
  exact ⟨s,fun x i => (connectedKD_fibreBlock_diagonal B hOff x i).trans (hs i (x i))⟩

end ConnectedFibreBlocks
end CompactFourierKD


namespace CompactFourierKD
open ContinuousLinearMap
open scoped ComplexInnerProductSpace

section ConnectedSecondBasisLock

variable {V : Type*} [NormedAddCommGroup V] [InnerProductSpace ℂ V] [CompleteSpace V]

/-- The second-basis anchor removes the remaining diagonal freedom in the
actual infinite Hilbert sum. Every canonical coordinate of the anchor is
nonzero; the other test fibres merely have to pair nontrivially with its own. -/
theorem connectedKD_second_basis_locks_diagonal
    (h : HilbertBasis ℕ ℂ ConnectedLabelSpace) (hH : ∀ i, h 0 i≠0)
    (w : ℕ→V) (hUnit : ‖w 0‖=1) (hW : ∀ j, j≠0 → ⟪w 0,w j⟫≠0)
    (B : ConnectedFibreSpace V→L[ℂ]ConnectedFibreSpace V) (hB : IsSelfAdjoint B)
    (s : ℕ→ℂ) (hD : ∀ x : ConnectedFibreSpace V, ∀ i, B x i=s i • x i)
    (hVV : ∀ j, j≠0 → ⟪connectedTensorLabel (w 0) (h 0),
      B (connectedTensorLabel (w j) (h j))⟫=0) :
    ∃ a : ℂ, ∀ x, B x=a • x := by
  let J := connectedTensorLabel (w 0)
  let d : ConnectedLabelSpace := J.adjoint (B (J (h 0)))
  have hdi (i : ℕ) : d i=s i*h 0 i := by
    calc
      d i=⟪lp.single 2 i (1:ℂ),d⟫ := by
        rw [lp.inner_single_left]
        simp [RCLike.inner_apply]
      _=⟪connectedCoordinateEmb i (w 0),B (J (h 0))⟫ := by
        change ⟪lp.single 2 i (1:ℂ),J.adjoint (B (J (h 0)))⟫=_
        rw [adjoint_inner_right]
        change ⟪connectedTensorLabel (w 0) (lp.single 2 i 1),B (J (h 0))⟫=_
        rw [connectedTensorLabel_single]
      _=_ := by
        rw [connectedCoordinateEmb_inner_left,hD]
        change ⟪w 0,s i • connectedTensorLabel (w 0) (h 0) i⟫=_
        rw [connectedTensorLabel_coord,inner_smul_right,inner_smul_right,
          inner_self_eq_norm_sq_to_K,hUnit]
        norm_num
  have hBJ : B (J (h 0))=J d := by
    apply lp.ext
    funext i
    rw [hD]
    change s i • connectedTensorLabel (w 0) (h 0) i=connectedTensorLabel (w 0) d i
    rw [connectedTensorLabel_coord,connectedTensorLabel_coord,hdi,mul_smul]
  have hAdj : B.adjoint=B := isSelfAdjoint_iff'.mp hB
  have ho (j : ℕ) (hj : j≠0) : ⟪h j,d⟫=0 := by
    have hz := hVV j hj
    rw [←hAdj,adjoint_inner_right] at hz
    change ⟪B (J (h 0)),connectedTensorLabel (w j) (h j)⟫=0 at hz
    rw [hBJ] at hz
    change ⟪connectedTensorLabel (w 0) d,connectedTensorLabel (w j) (h j)⟫=0 at hz
    rw [connectedTensorLabel_inner] at hz
    exact inner_eq_zero_symm.mpr ((mul_eq_zero.mp hz).resolve_right (hW j hj))
  let a : ℂ := ⟪h 0,d⟫
  have hd : d=a • h 0 := by
    apply h.repr.injective
    apply lp.ext
    funext j
    rw [HilbertBasis.repr_apply_apply,HilbertBasis.repr_apply_apply,inner_smul_right]
    by_cases hj : j=0
    · subst j
      simp [inner_self_eq_norm_sq_to_K,h.orthonormal.norm_eq_one,a]
    · rw [ho j hj,h.orthonormal.inner_eq_zero hj,mul_zero]
  have hsi (i : ℕ) : s i=a := by
    have hz := congrArg (fun x : ConnectedLabelSpace => x i) hd
    change d i=a*h 0 i at hz
    rw [hdi] at hz
    exact mul_right_cancel₀ (hH i) hz
  refine ⟨a,fun x => ?_⟩
  apply lp.ext
  funext i
  change B x i=a • x i
  rw [hD,hsi]

end ConnectedSecondBasisLock
end CompactFourierKD


namespace CompactFourierKD
open scoped ComplexInnerProductSpace

/-- The complete two-channel operator lock on the actual ℓ² Hilbert sum,
once the off-diagonal row summands have been separated. -/
theorem connectedKD_coherent_two_basis_operator_lock
    {V X : Type*} [NormedAddCommGroup V] [InnerProductSpace ℂ V]
    [CompleteSpace V] [FiniteDimensional ℂ V] [TopologicalSpace X] [ConnectedSpace X]
    (g₀ : X) (e : X→V) (heC : Continuous e) (heU : ∀ g, ‖e g‖=1)
    (heSpan : Submodule.span ℂ (Set.range e)=⊤)
    (heSep : ∀ S : V→L[ℂ]V, (∀ g, ⟪e g,S (e g)⟫=0) → S=0)
    (w : ℕ→X→V) (hFrame : ∀ g, Submodule.span ℂ (Set.range fun j => w j g)=(ℂ∙e g)ᗮ)
    (hwU : ‖w 0 g₀‖=1) (hwOver : ∀ j, j≠0 → ⟪w 0 g₀,w j g₀⟫≠0)
    (h : HilbertBasis ℕ ℂ ConnectedLabelSpace) (hH : ∀ i j, h j i≠0)
    (B : ConnectedFibreSpace V→L[ℂ]ConnectedFibreSpace V) (hB : IsSelfAdjoint B)
    (hUU : ∀ i k, i≠k → ∀ g, ⟪connectedCoordinateEmb i (e g),B (connectedCoordinateEmb k (e g))⟫=0)
    (hUV : ∀ i j g, ⟪connectedCoordinateEmb i (e g),B (connectedTensorLabel (w j g) (h j))⟫=0)
    (hVV : ∀ j, j≠0 → ⟪connectedTensorLabel (w 0 g₀) (h 0),
      B (connectedTensorLabel (w j g₀) (h j))⟫=0) :
    ∃ a : ℂ, ∀ x, B x=a • x := by
  obtain ⟨s, hs⟩ := connectedKD_coherent_fibre_blocks_scalar e heC heU heSpan heSep w hFrame h hH B hB hUU hUV
  exact connectedKD_second_basis_locks_diagonal h (fun i => hH i 0)
    (fun j => w j g₀) hwU hwOver B hB s hs hVV

end CompactFourierKD


namespace CompactFourierKD
open scoped ComplexInnerProductSpace
open ContinuousLinearMap

section ConnectedSeedSpan
variable {G V : Type*} [TopologicalSpace G]
  [NormedAddCommGroup V] [InnerProductSpace ℂ V]

/-- The same Hilbert tensor, continuous linear in its fibre coordinate
with the label fixed. -/
noncomputable def connectedTensorFibre (h : ConnectedLabelSpace) : V→L[ℂ]ConnectedFibreSpace V := by
  let S : V→ₗ[ℂ]ConnectedFibreSpace V :=
    { toFun := fun v => connectedTensorLabel v h
      map_add' := by
        intro v w
        apply lp.ext
        funext i
        change connectedTensorLabel (v+w) h i =
          connectedTensorLabel v h i+connectedTensorLabel w h i
        simp only [connectedTensorLabel_coord,smul_add]
      map_smul' := by
        intro a v
        apply lp.ext
        funext i
        change connectedTensorLabel (a • v) h i=a • connectedTensorLabel v h i
        simp only [connectedTensorLabel_coord,smul_smul,mul_comm] }
  exact S.mkContinuous ‖h‖ (fun v => by
    have hNorm : lp.toNorm (S v)=‖v‖ • lp.toNorm h := by
      apply lp.ext
      funext i
      change ‖connectedTensorLabel v h i‖=‖v‖*‖h i‖
      rw [connectedTensorLabel_coord,norm_smul,mul_comm]
    rw [←lp.norm_toNorm (x:=S v),hNorm,norm_smul,lp.norm_toNorm,
      Real.norm_eq_abs,abs_of_nonneg (norm_nonneg v),mul_comm])

theorem connectedTensorFibre_apply (h : ConnectedLabelSpace) (v : V) :
    connectedTensorFibre h v=connectedTensorLabel v h := rfl

/-- The first channel alone spans densely in ℓ²(ℕ,V), even though each
coherent row has a varying prefactor with zeros. -/
theorem connectedKD_first_channel_collective_closed_span
    (e : C(G,V)) (he : Submodule.span ℂ (Set.range e)=⊤)
    (F : ℕ→C(G,ConnectedFibreSpace V)) (f : ℕ→C(G,ℂ))
    (hf : ∀ i, Dense {g | f (2*i) g≠0})
    (hFirst : ∀ i g, F (2*i) g=f (2*i) g • connectedCoordinateEmb i (e g)) :
    (Submodule.span ℂ (⋃ n, Set.range (F n))).topologicalClosure=⊤ := by
  let A := Submodule.span ℂ (⋃ n, Set.range (F n))
  let L := A.topologicalClosure
  have hLC : IsClosed (L : Set (ConnectedFibreSpace V)) := Submodule.isClosed_topologicalClosure A
  have hLines (i : ℕ) (g : G) : connectedCoordinateEmb i (e g)∈L := by
    apply (hf i).induction (P:=fun g => connectedCoordinateEmb i (e g)∈L)
      _ (hLC.preimage ((connectedCoordinateEmb i).continuous.comp e.continuous))
    intro x hx
    have hx' : F (2*i) x∈L := Submodule.le_topologicalClosure _ (Submodule.subset_span
      (Set.mem_iUnion.mpr ⟨2*i,x,rfl⟩))
    rw [hFirst] at hx'
    have hs := L.smul_mem (f (2*i) x)⁻¹ hx'
    rw [smul_smul,inv_mul_cancel₀ hx,one_smul] at hs
    exact hs
  have hFibre (i : ℕ) (x : V) : connectedCoordinateEmb i x∈L := by
    have ha : Submodule.span ℂ (Set.range e)≤L.comap (connectedCoordinateEmb i).toLinearMap := by
      apply Submodule.span_le.mpr
      rintro _ ⟨g,rfl⟩
      exact hLines i g
    rw [he] at ha
    exact ha (Submodule.mem_top : x∈⊤)
  apply top_unique
  intro x _
  apply hLC.mem_of_tendsto (lp.hasSum_single (by norm_num) x)
  apply Filter.Eventually.of_forall
  intro s
  exact L.sum_mem fun i _ => hFibre i (x i)

end ConnectedSeedSpan
end CompactFourierKD


namespace CompactFourierKD
open scoped ComplexInnerProductSpace

/-- An actual nonzero Hilbert fibre makes the infinite Hilbert sum
infinite-dimensional, witnessed by the coordinate unit vectors. -/
theorem connectedKD_fibreSpace_infiniteDimensional
    {V : Type*} [NormedAddCommGroup V] [InnerProductSpace ℂ V] (v : V) (hv : ‖v‖=1) :
    ¬FiniteDimensional ℂ (ConnectedFibreSpace V) := by
  intro hFin
  let : FiniteDimensional ℂ (ConnectedFibreSpace V) := hFin
  let u (i : ℕ) := connectedCoordinateEmb i v
  have hOr : Orthonormal ℂ u := by
    constructor
    · intro i
      change ‖connectedCoordinateEmb i v‖=1
      rw [connectedCoordinateEmb_apply,lp.norm_single (by norm_num),hv]
    · intro i j hij
      change ⟪connectedCoordinateEmb i v,connectedCoordinateEmb j v⟫=0
      rw [connectedCoordinateEmb_inner_left,connectedCoordinateEmb_apply,lp.coeFn_single,
        Pi.single_eq_of_ne hij,inner_zero_right]
  let : Finite ℕ := hOr.linearIndependent.finite
  exact not_finite ℕ

end CompactFourierKD


namespace CompactFourierKD

def rowFrequencyCenter (qL : ℤ) (n m : ℕ) : ℤ :=
  qL*((4:ℤ)^n-(4:ℤ)^m)

def rowFrequencyWindow (qL R : ℤ) (n m : ℕ) : Set ℤ :=
  {k | |k-rowFrequencyCenter qL n m|≤R}

/-- The exact progression obstruction for the paper's powers of 4.
Unlike an asymptotic spacing argument, the proof includes all
coincidences among the three indices. -/
theorem powersFour_center_double_only_trivial (n m k : ℕ)
    (h : 2*(4:ℤ)^n=(4:ℤ)^m+(4:ℤ)^k) : m=n ∧ k=n := by
  have pos (i : ℕ) : 0 < (4:ℤ)^i := pow_pos (by decide) _
  have gap (i : ℕ) (hi : n < i) : 4*(4:ℤ)^n≤(4:ℤ)^i := by
    rw [←pow_succ']
    exact pow_le_pow_right₀ (by decide) (by omega)
  have hm : m≤n := by
    by_contra! hlt
    linarith [gap m hlt,pos n,pos k]
  have hk : k≤n := by
    by_contra! hlt
    linarith [gap k hlt,pos n,pos m]
  have hM : m=n := by
    by_contra hn
    have hlt : (4:ℤ)^m<(4:ℤ)^n := pow_lt_pow_right₀ (by decide) (lt_of_le_of_ne hm hn)
    have hle : (4:ℤ)^k≤(4:ℤ)^n := pow_le_pow_right₀ (by decide) hk
    linarith
  have hK : k=n := by
    by_contra hn
    have hlt : (4:ℤ)^k<(4:ℤ)^n := pow_lt_pow_right₀ (by decide) (lt_of_le_of_ne hk hn)
    rw [hM] at h
    linarith
  exact ⟨hM,hK⟩

private theorem abs_mul_ge_left_of_int_ne_zero (a b : ℤ) (hb : b≠0) :
    |a|≤|a*b| := by
  have hb' : 1≤|b| := by
    have h := abs_pos.mpr hb
    omega
  calc
    |a| = |a| * 1 := (mul_one _).symm
    _ ≤ |a| * |b| := mul_le_mul_of_nonneg_left hb' (abs_nonneg _)
    _ = |a*b| := (abs_mul _ _).symm

/-- At a fixed row number, the distinct summands have disjoint
Fourier windows for the exact frequencies in the manuscript. -/
theorem rowFrequencyWindow_disjoint (qL R : ℤ) (n m k : ℕ)
    (hspace : 2*R < |qL|) (hmk : m≠k) (l : ℤ)
    (hm : l∈rowFrequencyWindow qL R n m)
    (hk : l∈rowFrequencyWindow qL R n k) : False := by
  have hDist : ((4:ℤ)^k-(4:ℤ)^m)≠0 := by
    apply sub_ne_zero.mpr
    exact fun h => hmk ((pow_right_injective₀ (a:=(4:ℤ)) (by decide) (by decide)) h.symm)
  have hD : rowFrequencyCenter qL n m-rowFrequencyCenter qL n k=
      qL*((4:ℤ)^k-(4:ℤ)^m) := by
    unfold rowFrequencyCenter
    ring
  change |l-rowFrequencyCenter qL n m|≤R at hm
  change |l-rowFrequencyCenter qL n k|≤R at hk
  have hm' := abs_le.mp hm
  have hk' := abs_le.mp hk
  have hL : |rowFrequencyCenter qL n m-rowFrequencyCenter qL n k|≤2*R :=
    abs_le.mpr ⟨by omega,by omega⟩
  rw [hD] at hL
  exact (not_le_of_gt hspace) ((abs_mul_ge_left_of_int_ne_zero _ _ hDist).trans hL)

/-- An off-diagonal frequency has no negative partner in any summand
in its row, including the self-window at zero. -/
theorem rowFrequencyWindow_reflection_missing (qL R : ℤ) (n m k : ℕ)
    (hspace : 2*R < |qL|) (hmn : m≠n) (l : ℤ)
    (hm : l∈rowFrequencyWindow qL R n m)
    (hk : -l∈rowFrequencyWindow qL R n k) : False := by
  have hDist : (2*(4:ℤ)^n-(4:ℤ)^m-(4:ℤ)^k)≠0 := by
    intro h
    have hp : 2*(4:ℤ)^n=(4:ℤ)^m+(4:ℤ)^k := by omega
    exact hmn (powersFour_center_double_only_trivial n m k hp).1
  have hD : rowFrequencyCenter qL n m+rowFrequencyCenter qL n k=
      qL*(2*(4:ℤ)^n-(4:ℤ)^m-(4:ℤ)^k) := by
    unfold rowFrequencyCenter
    ring
  change |l-rowFrequencyCenter qL n m|≤R at hm
  change |-l-rowFrequencyCenter qL n k|≤R at hk
  have hm' := abs_le.mp hm
  have hk' := abs_le.mp hk
  have hL : |rowFrequencyCenter qL n m+rowFrequencyCenter qL n k|≤2*R :=
    abs_le.mpr ⟨by omega,by omega⟩
  rw [hD] at hL
  exact (not_le_of_gt hspace) ((abs_mul_ge_left_of_int_ne_zero _ _ hDist).trans hL)

end CompactFourierKD

namespace CompactFourierKD
open MeasureTheory AddCircle
open scoped ComplexConjugate

noncomputable def circleCoefficientCLM (T : ℝ) [Fact (0<T)] (l : ℤ) :
    C(AddCircle T,ℂ) →L[ℂ] ℂ :=
  LinearMap.mkContinuous
    { toFun := fun f => fourierCoeff f l
      map_add' := fun f g => congrFun (fourierCoeff.add
        (f.continuous.integrable_of_hasCompactSupport (HasCompactSupport.of_compactSpace _))
        (g.continuous.integrable_of_hasCompactSupport (HasCompactSupport.of_compactSpace _))) l
      map_smul' := fun c f => fourierCoeff.const_smul f c l }
    1 (fun f => by
      change ‖fourierCoeff (⇑f) l‖≤1*‖f‖
      rw [one_mul,fourierCoeff]
      have hNorm (x : AddCircle T) : ‖fourier (-l) x • f x‖≤‖f‖ := by
        rw [norm_smul,fourier_apply,Circle.norm_coe,one_mul]
        exact f.norm_coe_le_norm x
      simpa [Measure.real] using
        norm_integral_le_of_norm_le_const (μ:=haarAddCircle)
          (Filter.Eventually.of_forall hNorm))

@[simp] theorem circleCoefficientCLM_apply (T : ℝ) [Fact (0<T)] (l : ℤ)
    (f : C(AddCircle T,ℂ)) :
    circleCoefficientCLM T l f=fourierCoeff f l := rfl

/-- Haar Fourier coefficients of actual real-valued circular
functions satisfy conjugacy of opposite frequencies. -/
theorem circleCoefficient_real_conjugate {T : ℝ} [Fact (0<T)]
    (f : C(AddCircle T,ℂ)) (hf : ∀ x, conj (f x)=f x) (l : ℤ) :
    fourierCoeff f (-l)=conj (fourierCoeff f l) := by
  rw [fourierCoeff,fourierCoeff,←integral_conj]
  apply integral_congr_ae
  apply Filter.Eventually.of_forall
  intro x
  simp only [neg_neg,smul_eq_mul,map_mul,fourier_neg,starRingEnd_apply,star_star,hf]

/-- Uniform sums of the actual continuous circular functions admit
termwise Haar coefficients by the bounded coefficient map. -/
theorem fourierCoeff_hasSum_of_uniform_sum {T : ℝ} [Fact (0<T)]
    (f : ℕ→C(AddCircle T,ℂ)) (s : C(AddCircle T,ℂ)) (h : HasSum f s)
    (l : ℤ) : HasSum (fun n => fourierCoeff (f n) l) (fourierCoeff s l) := by
  simpa only [circleCoefficientCLM_apply] using (circleCoefficientCLM T l).hasSum h

theorem circleFourier_zero_of_all_coefficients_zero {T : ℝ} [Fact (0<T)]
    (f : C(AddCircle T,ℂ)) (h : ∀ l, fourierCoeff f l=0) : f=0 := by
  have hs : Summable (fourierCoeff f) := by
    rw [show fourierCoeff f=(fun _ : ℤ => (0:ℂ)) from funext h]
    exact summable_zero
  have hsum := hasSum_fourier_series_of_summable hs
  have hzero : HasSum (fun _ : ℤ => (0:C(AddCircle T,ℂ))) 0 := hasSum_zero
  apply HasSum.unique _ hzero
  simpa only [h,zero_smul] using hsum

end CompactFourierKD

namespace CompactFourierKD
open AddCircle
open scoped ComplexConjugate

/-- Exact analytic separation of the connected compact proof:
a uniformly convergent real row with the manuscript's lacunary
Fourier windows has every off-diagonal summand identically zero.
Both coefficient extraction and uniqueness use normalized Haar
Fourier coefficients on the actual circle. -/
theorem connected_real_row_forces_offDiagonal_zero
    {T : ℝ} [Fact (0<T)] (qL R : ℤ) (n : ℕ)
    (hspace : 2*R < |qL|)
    (F : ℕ→C(AddCircle T,ℂ)) (f : C(AddCircle T,ℂ))
    (hSum : HasSum F f) (hReal : ∀ t, conj (f t)=f t)
    (hSupport : ∀ m l, l∉rowFrequencyWindow qL R n m → fourierCoeff (F m) l=0)
    (m : ℕ) (hm : m≠n) : F m=0 := by
  apply circleFourier_zero_of_all_coefficients_zero
  intro l
  by_cases h : l∈rowFrequencyWindow qL R n m
  · have hNegative (k : ℕ) : fourierCoeff (F k) (-l)=0 :=
      hSupport k (-l) (fun hk => rowFrequencyWindow_reflection_missing qL R n m k hspace hm l h hk)
    have hN := fourierCoeff_hasSum_of_uniform_sum F f hSum (-l)
    have hN0 : fourierCoeff f (-l)=0 := by
      apply hN.unique
      simpa only [hNegative] using (hasSum_zero : HasSum (fun _ : ℕ => (0:ℂ)) 0)
    have hPos := circleCoefficient_real_conjugate f hReal l
    rw [hN0] at hPos
    have hP0 : fourierCoeff f l=0 := by
      simpa only [map_zero,starRingEnd_apply,star_star] using
        (congrArg (fun z : ℂ => conj z) hPos).symm
    have hSole (k : ℕ) (hk : k≠m) : fourierCoeff (F k) l=0 :=
      hSupport k l (fun hn => rowFrequencyWindow_disjoint qL R n k m hspace hk l hn h)
    have hP := fourierCoeff_hasSum_of_uniform_sum F f hSum l
    calc
      fourierCoeff (F m) l = ∑' k : ℕ, fourierCoeff (F k) l := (tsum_eq_single m hSole).symm
      _ = fourierCoeff f l := hP.tsum_eq
      _ = 0 := hP0
  · exact hSupport m l h

end CompactFourierKD

namespace CompactFourierKD
open AddCircle
open scoped ComplexConjugate ComplexInnerProductSpace

section FiniteWeightRows
variable {T : ℝ} [Fact (0<T)]
variable {I X : Type*} [Fintype I] [NormedAddCommGroup X] [InnerProductSpace ℂ X]

noncomputable def connectedKD_weightedRow
    (qL : ℤ) (a : I→ℤ) (n : ℕ) (u : I→X) : C(AddCircle T,X) :=
  ∑ i, ⟨fun t => fourier (qL*(4:ℤ)^n+a i) t • u i,
    (fourier (qL*(4:ℤ)^n+a i)).continuous.smul continuous_const⟩

noncomputable def connectedKD_weightedRowPair
    (qL : ℤ) (a : I→ℤ) (m n : ℕ) (u v : I→X) (B : X→L[ℂ]X) : C(AddCircle T,ℂ) :=
  ⟨fun t => ⟪connectedKD_weightedRow qL a m u t,B (connectedKD_weightedRow qL a n v t)⟫,
   (connectedKD_weightedRow qL a m u).continuous.inner
     (B.continuous.comp (connectedKD_weightedRow qL a n v).continuous)⟩

/-- The row pair's exact Fourier support follows from the finite circle
weight expansion. Both the sign and the absolute difference of weights
are checked by the genuine normalized circle Fourier transform. -/
theorem connectedKD_weightedRowPair_fourier_support
    (qL R : ℤ) (a : I→ℤ) (hR : ∀ i j, |a j-a i|≤R)
    (m n : ℕ) (u v : I→X) (B : X→L[ℂ]X) (l : ℤ)
    (hl : l∉rowFrequencyWindow qL R n m) :
    fourierCoeff (connectedKD_weightedRowPair (T:=T) qL a m n u v B) l=0 := by
  let f (i j : I) : C(AddCircle T,ℂ) :=
    ⟪u i,B (v j)⟫ • fourier (rowFrequencyCenter qL n m+a j-a i)
  have hPair : connectedKD_weightedRowPair (T:=T) qL a m n u v B = ∑ i,∑ j,f i j := by
    ext t
    change ⟪connectedKD_weightedRow qL a m u t,B (connectedKD_weightedRow qL a n v t)⟫=_
    simp only [connectedKD_weightedRow,ContinuousMap.sum_apply,ContinuousMap.coe_mk,
      map_sum,map_smul,ContinuousMap.smul_apply,f,smul_eq_mul]
    simp_rw [sum_inner,inner_sum,inner_smul_left,inner_smul_right]
    apply Finset.sum_congr rfl
    intro i _
    apply Finset.sum_congr rfl
    intro j _
    have hz :
      -(qL * (4:ℤ)^m + a i)+(qL * (4:ℤ)^n+a j)
        =rowFrequencyCenter qL n m+a j-a i := by unfold rowFrequencyCenter; ring
    rw [←fourier_neg,←hz,fourier_add (m:=-(qL*(4:ℤ)^m+a i)) (n:=qL*(4:ℤ)^n+a j)]
    ac_rfl
  have hZero (i j : I) : circleCoefficientCLM T l (f i j)=0 := by
    have hn : l≠rowFrequencyCenter qL n m+a j-a i := fun h => hl (by
      change |l-rowFrequencyCenter qL n m|≤R
      rw [h,show rowFrequencyCenter qL n m+a j-a i-rowFrequencyCenter qL n m=a j-a i by ring]
      exact hR i j)
    rw [show f i j=⟪u i,B (v j)⟫ • fourier (rowFrequencyCenter qL n m+a j-a i) by rfl,map_smul,
      circleCoefficientCLM_apply,fourierCoeff_fourier,Pi.single_eq_of_ne hn,smul_zero]
  rw [←circleCoefficientCLM_apply,hPair,map_sum]
  simp only [map_sum,hZero,Finset.sum_const_zero]

end FiniteWeightRows
end CompactFourierKD


namespace CompactFourierKD
open AddCircle
open scoped ComplexConjugate ComplexInnerProductSpace

section RestrictConnectedUniformRows
variable {T : ℝ} [Fact (0<T)]
variable {I G X : Type*} [Fintype I] [TopologicalSpace G] [CompactSpace G]
  [NormedAddCommGroup X] [InnerProductSpace ℂ X] [CompleteSpace X]

private noncomputable def connectedKD_rowInnerRealCLM
    (Y : C(AddCircle T,X)) : C(AddCircle T,X)→L[ℝ]C(AddCircle T,ℂ) :=
  let L : C(AddCircle T,X)→ₗ[ℝ]C(AddCircle T,ℂ) :=
    { toFun := fun F => ⟨fun t => ⟪F t,Y t⟫,F.continuous.inner Y.continuous⟩
      map_add' := by
        intro F W
        ext t
        exact inner_add_left (F t) (W t) (Y t)
      map_smul' := by
        intro a F
        ext t
        exact inner_smul_real_left (F t) (Y t) a }
  L.mkContinuous ‖Y‖ (fun F => by
    apply (ContinuousMap.norm_le _ (mul_nonneg (norm_nonneg _) (norm_nonneg _))).mpr
    intro t
    exact (norm_inner_le_norm (𝕜:=ℂ) (F t) (Y t)).trans (by
      rw [mul_comm ‖Y‖]
      exact mul_le_mul (F.norm_coe_le_norm t) (Y.norm_coe_le_norm t)
        (norm_nonneg _) (norm_nonneg _)))

/-- The actual uniform Hilbert-valued Fourier rows restricted to a torus
circle have exactly the separated off-diagonal equations in the paper,
as soon as the finite circle weights and reality of the full row are known. -/
theorem connectedKD_weighted_uniform_rows_force_offDiagonal
    (qL R : ℤ) (a : I→ℤ) (hR : ∀ i j, |a j-a i|≤R) (hspace : 2*R < |qL|)
    (F : ℕ→C(G,X)) (hF : Summable fun n => ‖F n‖)
    (c : C(AddCircle T,G)) (u : ℕ→I→X)
    (hWeight : ∀ n, (F n).comp c=connectedKD_weightedRow qL a n (u n))
    (B : X→L[ℂ]X) (n : ℕ)
    (hReal : ∀ g : G, (⟪(∑' k,F k) g,B (F n g)⟫ : ℂ).im=0)
    (m : ℕ) (hm : m≠n) (t : AddCircle T) :
    ⟪F m (c t),B (F n (c t))⟫=0 := by
  let Rmap : C(G,X)→L[ℝ]C(AddCircle T,X) :=
    (ContinuousMap.compCLM ℂ X c).restrictScalars ℝ
  let Y : C(AddCircle T,X) := ⟨fun t => B (F n (c t)),B.continuous.comp ((F n).continuous.comp c.continuous)⟩
  let L := (connectedKD_rowInnerRealCLM Y).comp Rmap
  have hSum : HasSum (fun k => L (F k)) (L (∑' k,F k)) := ((Summable.of_norm hF).hasSum.mapL L)
  have hf : ∀ t, conj (L (∑' k,F k) t)=L (∑' k,F k) t := by
    intro t
    change conj ⟪(∑' k,F k) (c t),B (F n (c t))⟫=⟪(∑' k,F k) (c t),B (F n (c t))⟫
    apply Complex.ext
    · exact Complex.conj_re _
    · rw [Complex.conj_im,hReal,neg_zero]
  have hEq (k : ℕ) : L (F k)=connectedKD_weightedRowPair qL a k n (u k) (u n) B := by
    ext t
    have hm := DFunLike.congr_fun (hWeight k) t
    have hn := DFunLike.congr_fun (hWeight n) t
    change ⟪F k (c t),B (F n (c t))⟫=_
    change F k (c t)=connectedKD_weightedRow qL a k (u k) t at hm
    change F n (c t)=connectedKD_weightedRow qL a n (u n) t at hn
    rw [hm,hn]
    rfl
  have hZ := connected_real_row_forces_offDiagonal_zero qL R n hspace
    (fun k => L (F k)) _ hSum hf (fun k l hl => by
      rw [hEq k]
      exact connectedKD_weightedRowPair_fourier_support (T:=T) qL R a hR k n (u k) (u n) B l hl) m hm
  exact DFunLike.congr_fun hZ t

end RestrictConnectedUniformRows
end CompactFourierKD


namespace CompactFourierKD
open scoped ComplexInnerProductSpace

/-- The paper's scalar prefactors can be removed globally from a separated
equation, because their common nonzero locus is dense and the raw row
pair is continuous. No division is performed at a zero of either factor. -/
theorem connectedKD_strip_dense_nonzero_row_factors
    {G X : Type*} [TopologicalSpace G] [NormedAddCommGroup X] [InnerProductSpace ℂ X]
    (f q : C(G,ℂ)) (hf : Dense {g | f g≠0}) (hq : Dense {g | q g≠0})
    (x y : C(G,X)) (B : X→L[ℂ]X)
    (h : ∀ g, ⟪f g • x g,B (q g • y g)⟫=0) :
    ∀ g, ⟪x g,B (y g)⟫=0 := by
  let u (g : G) := ⟪x g,B (y g)⟫
  have hu : Continuous u := x.continuous.inner (B.continuous.comp y.continuous)
  have hd := hf.inter_of_isOpen_left hq (isOpen_ne_fun f.continuous continuous_const)
  intro g
  apply hd.induction (P:=fun g => u g=0) _ (isClosed_eq hu continuous_const)
  intro z hz
  have hn := h z
  rw [map_smul,inner_smul_left,inner_smul_right] at hn
  exact (mul_eq_zero.mp ((mul_eq_zero.mp hn).resolve_left
    ((map_ne_zero (starRingEnd ℂ)).mpr hz.1))).resolve_left hz.2

end CompactFourierKD



namespace CompactFourierKD
open scoped ComplexInnerProductSpace

/-- The two coherent channels give pointwise orthogonality automatically:
coordinate orthogonality within a channel and the coherent hyperplane
condition across channels. -/
theorem connectedKD_actualTwoChannel_rows_orthogonal
    {G V : Type*} [TopologicalSpace G] [NormedAddCommGroup V] [InnerProductSpace ℂ V]
    (e : C(G,V)) (w : ℕ→C(G,V))
    (hFrame : ∀ g, Submodule.span ℂ (Set.range fun j => w j g)=(ℂ∙e g)ᗮ)
    (h : HilbertBasis ℕ ℂ ConnectedLabelSpace)
    (F : ℕ→C(G,ConnectedFibreSpace V)) (f : ℕ→C(G,ℂ))
    (hFirst : ∀ i g, F (2*i) g=f (2*i) g • connectedCoordinateEmb i (e g))
    (hSecond : ∀ j g, F (2*j+1) g=f (2*j+1) g • connectedTensorLabel (w j g) (h j)) :
    ∀ n m, n≠m→∀ g, ⟪F n g,F m g⟫=0 := by
  have hu (i k : ℕ) (hik : i≠k) (g : G) :
      ⟪F (2*i) g,F (2*k) g⟫=0 := by
    rw [hFirst,hFirst,inner_smul_left,inner_smul_right,connectedCoordinateEmb_inner_left,
      connectedCoordinateEmb_apply,lp.coeFn_single,Pi.single_eq_of_ne hik,inner_zero_right,mul_zero,mul_zero]
  have hv (i k : ℕ) (hik : i≠k) (g : G) :
      ⟪F (2*i+1) g,F (2*k+1) g⟫=0 := by
    rw [hSecond,hSecond,inner_smul_left,inner_smul_right,connectedTensorLabel_inner,
      h.orthonormal.inner_eq_zero hik,zero_mul,mul_zero,mul_zero]
  have hm (i j : ℕ) (g : G) : ⟪F (2*i) g,F (2*j+1) g⟫=0 := by
    have hh : w j g∈(ℂ∙e g)ᗮ := by
      rw [←hFrame]
      exact Submodule.subset_span ⟨j,rfl⟩
    have hW : ⟪e g,w j g⟫=0 := Submodule.mem_orthogonal_singleton_iff_inner_right.mp hh
    rw [hFirst,hSecond,inner_smul_left,inner_smul_right,connectedCoordinateEmb_inner_left,
      connectedTensorLabel_coord,inner_smul_right,hW,mul_zero,mul_zero,mul_zero]
  intro n m hnm g
  have H (t : ℕ) : ∃ i : ℕ, t=2*i ∨ t=2*i+1 := ⟨t/2,by omega⟩
  obtain ⟨i,rfl|rfl⟩ := H n <;> obtain ⟨j,rfl|rfl⟩ := H m
  · exact hu i j (by omega) g
  · exact hm i j g
  · exact inner_eq_zero_symm.mpr (hm j i g)
  · exact hv i j (by omega) g

end CompactFourierKD


namespace CompactFourierKD
open MeasureTheory Measure ContinuousLinearMap AddCircle
open scoped ComplexInnerProductSpace

section FullConnectedConditionalSeed
variable {G V I J K : Type*} [Group G] [TopologicalSpace G] [IsTopologicalGroup G]
  [CompactSpace G] [ConnectedSpace G] [MeasurableSpace G] [BorelSpace G]
  [NormedAddCommGroup V] [InnerProductSpace ℂ V] [CompleteSpace V] [FiniteDimensional ℂ V]
  [Countable I] [Fintype K]
variable {Y : ℕ → Type*} [∀ n, NormedAddCommGroup (Y n)] [∀ n, NormedSpace ℂ (Y n)]
  [∀ n, FiniteDimensional ℂ (Y n)] [∀ n, Nontrivial (Y n)]
variable {T₀ : ℝ} [Fact (0<T₀)]
local notation "μ" => compactKDhaar G
local notation "X" => ConnectedFibreSpace V

set_option maxHeartbeats 1400000 in
/-- The connected proof from its exact representation-theoretic input:
once coherent rays, their transported frame, the actual inequivalent
Cartan coefficient spaces and their circle weight expansions are supplied,
the genuine compact Haar KD set has a trace-one extreme of infinite rank.
This theorem does not assert existence of those Lie-theoretic inputs. -/
theorem compactKD_connected_infiniteRank_extreme_from_coherent_rows
    (g₀ : G) (e : C(G,V)) (w : ℕ→C(G,V))
    (heU : ∀ g, ‖e g‖=1)
    (heSpan : Submodule.span ℂ (Set.range e)=⊤)
    (heSep : ∀ S : V→L[ℂ]V, (∀ g, ⟪e g,S (e g)⟫=0) → S=0)
    (hFrame : ∀ g, Submodule.span ℂ (Set.range fun j => w j g)=(ℂ∙e g)ᗮ)
    (hwU : ‖w 0 g₀‖=1) (hwOver : ∀ j, j≠0→⟪w 0 g₀,w j g₀⟫≠0)
    (h : HilbertBasis ℕ ℂ ConnectedLabelSpace) (hH : ∀ i j, h j i≠0)
    (F : ℕ→C(G,X)) (f : ℕ→C(G,ℂ))
    (hF : Summable fun n=>‖F n‖)
    (hf : ∀ n, Dense {g | f n g≠0})
    (hFirst : ∀ i g, F (2*i) g=f (2*i) g • connectedCoordinateEmb i (e g))
    (hSecond : ∀ j g, F (2*j+1) g=f (2*j+1) g • connectedTensorLabel (w j g) (h j))
    (ρ : ∀ n, G→*(Y n→L[ℂ]Y n)) (hρ : ∀ n, Continuous (ρ n))
    (hIrr : ∀ n, compactRepresentationIrreducible (ρ n))
    (hRep : ∀ n x, ∃ D, compactKD_featureAnalysis (F n) x=compactMatrixCoefficientCLM (ρ n) (hρ n) D)
    (hNE : ∀ n m, n≠m→¬∃ A : Y n≃L[ℂ]Y m, ∀ g v, A (ρ n g v)=ρ m g (A v))
    (qL R : ℤ) (a : K→ℤ) (hR : ∀ k j, |a j-a k|≤R) (hspace : 2*R < |qL|)
    (hCircle : ∀ g:G, ∃ c : C(AddCircle T₀,G), ∃ u : ℕ→K→X,
      c 0=g ∧ (∀ n, (F n).comp c=connectedKD_weightedRow qL a n (u n)))
    (b : HilbertBasis I ℂ X) (i₀ : I) (d : HilbertBasis J ℂ (HaarL2 μ)) :
    ∃ P : HaarOp μ, CompactKDExtremeAt μ d P ∧ ¬FiniteDimensional ℂ P.range := by
  let S : C(G,X) := ∑' n,F n
  let A := compactKD_featureAnalysis S
  let W := A.adjoint
  let Z := A.comp A.adjoint
  let v (i : I) := A (b i)
  have hV : Summable fun i => ‖v i‖^2 := compactKD_featureAnalysis_HilbertSchmidt S b
  have hGram : compactRankOneDensity v=Z := compactKD_featureGram_eq_rankOne S b
  have hFspan := connectedKD_first_channel_collective_closed_span e heSpan F f (fun i => hf (2*i)) hFirst
  have hXinf := connectedKD_fibreSpace_infiniteDimensional (e g₀) (heU g₀)
  obtain ⟨hD,hRank⟩ := compactKD_irrep_feature_synthesis_dense_and_gram_infinite
    ρ hρ hIrr F hRep hNE hF hFspan hXinf
  change DenseRange W at hD
  change ¬FiniteDimensional ℂ Z.range at hRank
  have hOrth := connectedKD_actualTwoChannel_rows_orthogonal e w hFrame h F f hFirst hSecond
  have hKD : compactKDPositiveAt μ d Z := by
    rw [←hGram]
    intro Q hQC hQP E hE
    exact compactKD_irrep_feature_series_positive ρ hρ hIrr F hRep hF hOrth Q hQC hQP b d E hE
  have hBasisNZ : v i₀≠0 := by
    intro hz
    let x := b i₀
    change A x=0 at hz
    let L := (ℂ∙x)ᗮ
    have hWspan : Set.range W⊆(L:Set X) := by
      rintro _ ⟨y,rfl⟩
      apply Submodule.mem_orthogonal_singleton_iff_inner_left.mpr
      change ⟪A.adjoint y,x⟫=0
      rw [adjoint_inner_left,hz,inner_zero_right]
    have hh := closure_minimal hWspan ((ℂ∙x) : Submodule ℂ X).isClosed_orthogonal (hD x)
    have hx := inner_self_eq_zero.mp (Submodule.mem_orthogonal_singleton_iff_inner_left.mp hh)
    change b i₀=0 at hx
    have h := b.orthonormal.norm_eq_one i₀
    rw [hx,norm_zero] at h
    exact zero_ne_one h
  obtain ⟨r,hr,hNormal⟩ := compactKD_normalize_rankOne_density μ d v hV ⟨i₀,hBasisNZ⟩ (by rwa [hGram])
  rw [hGram] at hNormal
  have hNormW : CompactKDNormalStateAt μ d ((r:ℂ) • W.adjoint.comp W) := by
    simpa only [W,Z,adjoint_adjoint] using hNormal
  have hLock (B : X→L[ℂ]X) (hB : B.IsPositive)
      (hEnd : compactKDPositiveAt μ d (W.adjoint.comp (B.comp W))) :
      ∃ s : ℂ, ∀ x, B x=s • x := by
    have hReal (n : ℕ) (g : G) : (⟪S g,B (F n g)⟫ : ℂ).im=0 := by
      apply (compactKD_irrep_feature_endpoint_rows ρ hρ hIrr F hRep hNE hF B hB b d _ n g).2
      intro Q hQC hQP E hE
      have he := hEnd Q hQC hQP E hE
      simpa only [W,A,S,adjoint_adjoint] using he
    have hSep (m n : ℕ) (hmn : m≠n) (g : G) : ⟪F m g,B (F n g)⟫=0 := by
      obtain ⟨c,u,hc,hu⟩ := hCircle g
      simpa only [hc] using connectedKD_weighted_uniform_rows_force_offDiagonal
        qL R a hR hspace F hF c u hu B n (hReal n) m hmn 0
    let u (i : ℕ) : C(G,X) :=
      ⟨fun g=>connectedCoordinateEmb i (e g),(connectedCoordinateEmb i).continuous.comp e.continuous⟩
    let t (j : ℕ) : C(G,X) :=
      ⟨fun g=>connectedTensorLabel (w j g) (h j),(connectedTensorFibre (h j)).continuous.comp (w j).continuous⟩
    have hUU (i k : ℕ) (hik : i≠k) (g : G) :
        ⟪connectedCoordinateEmb i (e g),B (connectedCoordinateEmb k (e g))⟫=0 := by
      exact connectedKD_strip_dense_nonzero_row_factors
        (f (2*i)) (f (2*k)) (hf _) (hf _) (u i) (u k) B (fun g => by
          change ⟪f (2*i) g • connectedCoordinateEmb i (e g),B (f (2*k) g • connectedCoordinateEmb k (e g))⟫=0
          rw [←hFirst,←hFirst]
          exact hSep _ _ (by omega) g) g
    have hUV (i j : ℕ) (g : G) :
        ⟪connectedCoordinateEmb i (e g),B (connectedTensorLabel (w j g) (h j))⟫=0 := by
      exact connectedKD_strip_dense_nonzero_row_factors
        (f (2*i)) (f (2*j+1)) (hf _) (hf _) (u i) (t j) B (fun g => by
          change ⟪f (2*i) g • connectedCoordinateEmb i (e g),B (f (2*j+1) g • connectedTensorLabel (w j g) (h j))⟫=0
          rw [←hFirst,←hSecond]
          exact hSep _ _ (by omega) g) g
    have hVV (j : ℕ) (hj : j≠0) :
        ⟪connectedTensorLabel (w 0 g₀) (h 0),B (connectedTensorLabel (w j g₀) (h j))⟫=0 := by
      exact connectedKD_strip_dense_nonzero_row_factors
        (f (2*0+1)) (f (2*j+1)) (hf _) (hf _) (t 0) (t j) B (fun g => by
          change ⟪f (2*0+1) g • connectedTensorLabel (w 0 g) (h 0),
            B (f (2*j+1) g • connectedTensorLabel (w j g) (h j))⟫=0
          rw [←hSecond,←hSecond]
          exact hSep _ _ (by omega) g) g₀
    exact connectedKD_coherent_two_basis_operator_lock g₀ e e.continuous heU heSpan heSep
      (fun j g=>w j g) hFrame hwU hwOver h hH B hB.isSelfAdjoint hUU hUV hVV
  let P := (r:ℂ) • Z
  have hE' := compactKD_extreme_of_scaled_dense_gram_endpoint_lock μ d W hD r hr hNormW hLock
  have hE : CompactKDExtremeAt μ d P := by simpa only [W,adjoint_adjoint] using hE'
  have hPR : P.range=Z.range := compactKD_realScale_range μ Z r hr.ne'
  exact ⟨P,hE,fun h => hRank (by rw [←hPR]; exact h)⟩

end FullConnectedConditionalSeed
end CompactFourierKD


namespace CompactFourierKD
open scoped BigOperators ComplexInnerProductSpace
open Matrix ContinuousLinearMap

section ActualMatrixTensor
variable {ι κ : Type*} [Fintype ι] [Fintype κ] [DecidableEq κ]

/-- Exact indexed Kronecker tensor power on all coordinate words. No abstract
tensor-product existence or canonical representation is assumed. -/
noncomputable def kd3TensorMatrix (A : Matrix ι ι ℂ) : Matrix (κ→ι) (κ→ι) ℂ :=
  fun u v => ∏ t, A (u t) (v t)

theorem kd3TensorMatrix_mul (A B : Matrix ι ι ℂ) :
    kd3TensorMatrix (κ:=κ) (A*B)=kd3TensorMatrix (κ:=κ) A*kd3TensorMatrix (κ:=κ) B := by
  classical
  ext u v
  change (∏ t, (A*B) (u t) (v t))=(kd3TensorMatrix (κ:=κ) A*kd3TensorMatrix (κ:=κ) B) u v
  rw [Matrix.mul_apply]
  simp only [Matrix.mul_apply,kd3TensorMatrix,←Finset.prod_mul_distrib]
  exact Fintype.prod_sum (ι:=κ) (κ:=fun _ => ι) (R:=ℂ) _

omit [Fintype ι] [DecidableEq κ] in
theorem kd3TensorMatrix_conjTranspose (A : Matrix ι ι ℂ) :
    kd3TensorMatrix (κ:=κ) A.conjTranspose=(kd3TensorMatrix A).conjTranspose := by
  ext u v
  simp only [kd3TensorMatrix,conjTranspose_apply,star_prod]

variable [DecidableEq ι]

omit [Fintype ι] [DecidableEq κ] in
theorem kd3TensorMatrix_diagonal (a : ι→ℂ) :
    kd3TensorMatrix (κ:=κ) (Matrix.diagonal a)=Matrix.diagonal (fun u : κ→ι => ∏ t, a (u t)) := by
  classical
  ext u v
  by_cases h : u=v
  · subst v
    simp only [kd3TensorMatrix,Matrix.diagonal_apply_eq]
  · obtain ⟨t,ht⟩ : ∃ t, u t≠v t := by
      by_contra! H
      exact h (funext H)
    rw [Matrix.diagonal_apply_ne _ h]
    exact Finset.prod_eq_zero (Finset.mem_univ t) (Matrix.diagonal_apply_ne _ ht)

omit [Fintype ι] [DecidableEq κ] in
theorem kd3TensorMatrix_one :
    kd3TensorMatrix (κ:=κ) (1 : Matrix ι ι ℂ)=1 := by
  rw [←Matrix.diagonal_one, kd3TensorMatrix_diagonal]
  simp

/-- A genuine monoid hom to the indexed tensor matrices. -/
noncomputable def kd3TensorMatrixMonoidHom : Matrix ι ι ℂ →* Matrix (κ→ι) (κ→ι) ℂ where
  toFun := kd3TensorMatrix
  map_one' := kd3TensorMatrix_one
  map_mul' := kd3TensorMatrix_mul

/-- Pure tensor as an actual vector of the finite Euclidean space indexed by
tensor words. -/
noncomputable def kd3TensorPure (x : κ→EuclideanSpace ℂ ι) : EuclideanSpace ℂ (κ→ι) :=
  WithLp.toLp 2 (fun u => ∏ t, x t (u t))

omit [Fintype ι] [DecidableEq ι] [DecidableEq κ] in
theorem kd3TensorPure_apply (x : κ→EuclideanSpace ℂ ι) (u : κ→ι) :
    kd3TensorPure x u=∏ t, x t (u t) := rfl

omit [DecidableEq ι] in
/-- The genuine Hilbert-space pairing of pure tensors factors exactly into
the coordinate pairings; this is not a separately chosen phase rule. -/
theorem kd3TensorPure_inner (x y : κ→EuclideanSpace ℂ ι) :
    ⟪kd3TensorPure x,kd3TensorPure y⟫=∏ t, ⟪x t,y t⟫ := by
  classical
  simp only [EuclideanSpace.inner_eq_star_dotProduct,dotProduct,kd3TensorPure_apply,
    Pi.star_apply,star_prod,←Finset.prod_mul_distrib]
  exact (Fintype.prod_sum (fun (t:κ) (i:ι) => (y t).ofLp i * star ((x t).ofLp i))).symm

/-- Matrix tensor powers send actual pure tensors to the pure tensor of
the transformed entries. -/
theorem kd3TensorMatrix_apply_pure (A : Matrix ι ι ℂ) (x : κ→EuclideanSpace ℂ ι) :
    Matrix.toEuclideanLin (kd3TensorMatrix A) (kd3TensorPure x)=
      kd3TensorPure (fun t => Matrix.toEuclideanLin A (x t)) := by
  classical
  apply PiLp.ext
  intro u
  change (kd3TensorMatrix A *ᵥ (fun v => ∏ t, x t (v t))) u =
    ∏ t, (A *ᵥ WithLp.ofLp (x t)) (u t)
  simp only [Matrix.mulVec,dotProduct,kd3TensorMatrix,←Finset.prod_mul_distrib]
  exact (Fintype.prod_sum (fun (t:κ) (i:ι) => A (u t) i * (x t).ofLp i)).symm

end ActualMatrixTensor
end CompactFourierKD


namespace CompactFourierKD
open Matrix ContinuousLinearMap
open scoped ComplexInnerProductSpace

section ActualTensorRep
variable {ι κ : Type*} [Fintype ι] [Fintype κ] [DecidableEq ι] [DecidableEq κ]

/-- Matrix entries produce an actual continuous operator on Euclidean space. -/
noncomputable def kd3EuclideanMatrixOpLinear :
    Matrix ι ι ℂ →ₗ[ℂ] (EuclideanSpace ℂ ι→L[ℂ]EuclideanSpace ℂ ι) :=
  (LinearMap.toContinuousLinearMap : _ ≃ₗ[ℂ] _).toLinearMap.comp Matrix.toEuclideanLin.toLinearMap

theorem kd3EuclideanMatrixOpLinear_apply (A : Matrix ι ι ℂ) (v : EuclideanSpace ℂ ι) :
    kd3EuclideanMatrixOpLinear A v=Matrix.toEuclideanLin A v := rfl

noncomputable def kd3EuclideanMatrixOp :
    Matrix ι ι ℂ →* (EuclideanSpace ℂ ι→L[ℂ]EuclideanSpace ℂ ι) where
  toFun := kd3EuclideanMatrixOpLinear
  map_one' := by
    apply ContinuousLinearMap.ext
    intro v
    change WithLp.toLp 2 ((1:Matrix ι ι ℂ) *ᵥ WithLp.ofLp v)=v
    rw [Matrix.one_mulVec,WithLp.toLp_ofLp]
  map_mul' A B := by
    apply ContinuousLinearMap.ext
    intro v
    change kd3EuclideanMatrixOpLinear (A*B) v=kd3EuclideanMatrixOpLinear A (kd3EuclideanMatrixOpLinear B v)
    change WithLp.toLp 2 ((A*B) *ᵥ WithLp.ofLp v)=WithLp.toLp 2 (A *ᵥ (B *ᵥ WithLp.ofLp v))
    rw [Matrix.mulVec_mulVec]

theorem kd3EuclideanMatrixOp_adjoint (A : Matrix ι ι ℂ) :
    (kd3EuclideanMatrixOp A).adjoint=kd3EuclideanMatrixOp A.conjTranspose := by
  apply ContinuousLinearMap.ext
  intro v
  have h := DFunLike.congr_fun (Matrix.toEuclideanLin_conjTranspose_eq_adjoint A).symm v
  exact h

theorem kd3EuclideanMatrixOp_continuous : Continuous (kd3EuclideanMatrixOp (ι:=ι)) := by
  change Continuous (kd3EuclideanMatrixOpLinear (ι:=ι) : Matrix ι ι ℂ→(EuclideanSpace ℂ ι→L[ℂ]EuclideanSpace ℂ ι))
  exact LinearMap.continuous_of_finiteDimensional (𝕜:=ℂ) (kd3EuclideanMatrixOpLinear (ι:=ι))

variable {G : Type*} [Group G]

/-- The genuine bounded representation on the indexed Euclidean tensor
power. Its underlying matrices are the exact computed tensor matrices. -/
noncomputable def kd3ActualTensorRep (π : G→*Matrix ι ι ℂ) :
    G→*(EuclideanSpace ℂ (κ→ι)→L[ℂ]EuclideanSpace ℂ (κ→ι)) :=
  kd3EuclideanMatrixOp.comp (kd3TensorMatrixMonoidHom.comp π)

theorem kd3ActualTensorRep_continuous [TopologicalSpace G] (π : G→*Matrix ι ι ℂ)
    (hπ : Continuous π) : Continuous (kd3ActualTensorRep (κ:=κ) π) := by
  apply kd3EuclideanMatrixOp_continuous.comp
  change Continuous (fun g => kd3TensorMatrix (κ:=κ) (π g))
  apply continuous_pi
  intro u
  apply continuous_pi
  intro v
  change Continuous (fun g => ∏ t, π g (u t) (v t))
  exact continuous_finsetProd _ (fun t _ =>
    (continuous_apply (v t)).comp ((continuous_apply (u t)).comp hπ))

theorem kd3ActualTensorRep_unitary (π : G→*Matrix ι ι ℂ)
    (hπ : ∀ g, (π g).conjTranspose=π g⁻¹) (g : G) :
    (kd3ActualTensorRep (κ:=κ) π g).adjoint=kd3ActualTensorRep π g⁻¹ := by
  change (kd3EuclideanMatrixOp (kd3TensorMatrix (κ:=κ) (π g))).adjoint=
    kd3EuclideanMatrixOp (kd3TensorMatrix (κ:=κ) (π g⁻¹))
  rw [kd3EuclideanMatrixOp_adjoint,←kd3TensorMatrix_conjTranspose,hπ]

theorem kd3ActualTensorRep_pure (π : G→*Matrix ι ι ℂ) (g : G)
    (x : κ→EuclideanSpace ℂ ι) :
    kd3ActualTensorRep π g (kd3TensorPure x)=
      kd3TensorPure (fun t => kd3EuclideanMatrixOp (π g) (x t)) :=
  kd3TensorMatrix_apply_pure (π g) x

end ActualTensorRep
end CompactFourierKD



namespace CompactFourierKD
open scoped ComplexInnerProductSpace
open ContinuousLinearMap

section ActualCyclicUnitary
variable {G V : Type*} [Group G] [NormedAddCommGroup V] [InnerProductSpace ℂ V]
  [CompleteSpace V] [FiniteDimensional ℂ V]

/-- The actual Euclidean cyclic orbit subspace, with inherited norm and inner
product. This does not assume a Cartan component or an irreducible subspace. -/
noncomputable def kd3CyclicUnitarySpace (ρ : G→*(V→L[ℂ]V)) (e : V) : Submodule ℂ V :=
  Submodule.span ℂ (Set.range fun g => ρ g e)

omit [CompleteSpace V] [FiniteDimensional ℂ V] in
theorem kd3CyclicUnitarySpace_invariant (ρ : G→*(V→L[ℂ]V)) (e : V) (g : G) :
    ∀ x∈kd3CyclicUnitarySpace ρ e, ρ g x∈kd3CyclicUnitarySpace ρ e := by
  have h : kd3CyclicUnitarySpace ρ e≤(kd3CyclicUnitarySpace ρ e).comap (ρ g).toLinearMap :=
    Submodule.span_le.mpr (by
      rintro _ ⟨t,rfl⟩
      change ρ g (ρ t e)∈kd3CyclicUnitarySpace ρ e
      exact Submodule.subset_span ⟨g*t,by change ρ (g*t) e=ρ g (ρ t e); rw [map_mul]; rfl⟩)
  exact fun x hx => h hx

noncomputable def kd3CyclicUnitaryRep (ρ : G→*(V→L[ℂ]V)) (e : V) :
    G→*(kd3CyclicUnitarySpace ρ e→L[ℂ]kd3CyclicUnitarySpace ρ e) where
  toFun g := (ρ g).restrict (kd3CyclicUnitarySpace_invariant ρ e g)
  map_one' := by
    apply ContinuousLinearMap.ext
    intro x
    apply Subtype.ext
    change ρ 1 x=x
    rw [map_one]
    rfl
  map_mul' g t := by
    apply ContinuousLinearMap.ext
    intro x
    apply Subtype.ext
    change ρ (g*t) x=ρ g (ρ t x)
    rw [map_mul]
    rfl

omit [CompleteSpace V] [FiniteDimensional ℂ V] in
theorem kd3CyclicUnitaryRep_apply_coe (ρ : G→*(V→L[ℂ]V)) (e : V) (g : G)
    (x : kd3CyclicUnitarySpace ρ e) : (kd3CyclicUnitaryRep ρ e g x : V)=ρ g x := rfl

omit [CompleteSpace V] in
theorem kd3CyclicUnitaryRep_continuous [TopologicalSpace G]
    (ρ : G→*(V→L[ℂ]V)) (hρ : Continuous ρ) (e : V) :
    Continuous (kd3CyclicUnitaryRep ρ e) := by
  let S := kd3CyclicUnitarySpace ρ e
  have h : Continuous (fun g => S.orthogonalProjectionOnto.comp ((ρ g).comp S.subtypeL)) :=
    (hρ.clm_comp_const S.subtypeL).const_clm_comp S.orthogonalProjectionOnto
  apply h.congr
  intro g
  apply ContinuousLinearMap.ext
  intro x
  apply Subtype.ext
  change S.starProjection (ρ g (x : V))=ρ g (x : V)
  exact Submodule.starProjection_eq_self_iff.mpr (kd3CyclicUnitarySpace_invariant ρ e g x x.property)

theorem kd3CyclicUnitaryRep_unitary
    (ρ : G→*(V→L[ℂ]V)) (hρ : ∀ g, (ρ g).adjoint=ρ g⁻¹) (e : V) (g : G) :
    (kd3CyclicUnitaryRep ρ e g).adjoint=kd3CyclicUnitaryRep ρ e g⁻¹ := by
  apply ContinuousLinearMap.ext
  intro x
  apply ext_inner_right ℂ
  intro y
  rw [adjoint_inner_left]
  change ⟪(x : V),ρ g (y : V)⟫=⟪ρ g⁻¹ (x : V),(y : V)⟫
  rw [←adjoint_inner_left,hρ]

noncomputable def kd3CyclicUnitaryVector (ρ : G→*(V→L[ℂ]V)) (e : V) : kd3CyclicUnitarySpace ρ e :=
  ⟨e, Submodule.subset_span ⟨1,by change ρ 1 e=e; rw [map_one]; rfl⟩⟩

omit [CompleteSpace V] [FiniteDimensional ℂ V] in
theorem kd3CyclicUnitaryVector_spans (ρ : G→*(V→L[ℂ]V)) (e : V) :
    Submodule.span ℂ (Set.range fun g => kd3CyclicUnitaryRep ρ e g (kd3CyclicUnitaryVector ρ e))=⊤ := by
  let S := kd3CyclicUnitarySpace ρ e
  let L := Submodule.span ℂ (Set.range fun g => kd3CyclicUnitaryRep ρ e g (kd3CyclicUnitaryVector ρ e))
  have hL : L.map S.subtype=S := by
    change (Submodule.span ℂ (Set.range fun g => kd3CyclicUnitaryRep ρ e g (kd3CyclicUnitaryVector ρ e))).map S.subtype=S
    rw [Submodule.map_span]
    congr 1
    ext x
    constructor
    · rintro ⟨_,⟨g,rfl⟩,rfl⟩
      exact ⟨g,rfl⟩
    · rintro ⟨g,rfl⟩
      exact ⟨_,⟨g,rfl⟩,rfl⟩
  apply top_unique
  intro x _
  have hx : (x : V)∈L.map S.subtype := by rw [hL]; exact x.property
  obtain ⟨z,hz,hEq⟩ := hx
  exact (Subtype.ext hEq : z=x) ▸ hz

/-- A cyclic unitary representation is irreducible when one eigenvalue
is already simple on the cyclic vector. This is the elementary step needed
to obtain the Cartan component from the literal tensor power. -/
theorem kd3Unitary_cyclic_simple_eigenspace_irreducible
    (ρ : G→*(V→L[ℂ]V)) (hUnit : ∀ g, (ρ g).adjoint=ρ g⁻¹)
    (e : V) (hSpan : Submodule.span ℂ (Set.range fun g => ρ g e)=⊤)
    (a : G) (c : ℂ) (he : ρ a e=c • e)
    (hSimple : ∀ v : V, ρ a v=c • v → ∃ z : ℂ, v=z • e) :
    ∀ S : Submodule ℂ V, (∀ g v, v∈S → ρ g v∈S) → S=⊥ ∨ S=⊤ := by
  intro S hS
  have hOrth (g : G) (v : V) (hv : v∈Sᗮ) : ρ g v∈Sᗮ := by
    apply (S.mem_orthogonal _).mpr
    intro u hu
    rw [←adjoint_inner_left,hUnit]
    exact Submodule.inner_right_of_mem_orthogonal (hS g⁻¹ u hu) hv
  let P := S.starProjection
  have hComm (g : G) (v : V) : P (ρ g v)=ρ g (P v) := by
    apply Submodule.eq_starProjection_of_mem_orthogonal (hS g _ (S.starProjection_apply_mem v))
    rw [←map_sub]
    exact hOrth g _ (S.sub_starProjection_mem_orthogonal v)
  have hEigP : ρ a (P e)=c • P e := by rw [←hComm,he,map_smul]
  obtain ⟨z,hz⟩ := hSimple (P e) hEigP
  by_cases hz0 : z=0
  · left
    have heO : e∈Sᗮ := by
      have h := S.sub_starProjection_mem_orthogonal e
      change e-P e∈Sᗮ at h
      simpa only [hz,hz0,zero_smul,sub_zero] using h
    have hTop : Submodule.span ℂ (Set.range fun g => ρ g e)≤Sᗮ :=
      Submodule.span_le.mpr (by rintro _ ⟨g,rfl⟩; exact hOrth g e heO)
    rw [hSpan] at hTop
    apply eq_bot_iff.mpr
    intro x hx
    have hh := Submodule.inner_right_of_mem_orthogonal hx (hTop (Submodule.mem_top : x∈⊤))
    rw [Submodule.mem_bot]
    exact inner_self_eq_zero.mp hh
  · right
    have hP : P e∈S := S.starProjection_apply_mem e
    have hE : e∈S := by
      have h := S.smul_mem z⁻¹ hP
      rwa [hz,smul_smul,inv_mul_cancel₀ hz0,one_smul] at h
    have hTop : Submodule.span ℂ (Set.range fun g => ρ g e)≤S :=
      Submodule.span_le.mpr (by rintro _ ⟨g,rfl⟩; exact hS g e hE)
    rw [hSpan] at hTop
    exact top_unique hTop

end ActualCyclicUnitary
end CompactFourierKD


namespace CompactFourierKD
open Matrix ContinuousLinearMap
open scoped ComplexInnerProductSpace

section ActualTensorCartan
variable {ι κ : Type*} [Fintype ι] [Fintype κ] [DecidableEq ι] [DecidableEq κ]
variable {G : Type*} [Group G]

omit [Fintype ι] [DecidableEq κ] in
/-- A literal pure coordinate word, equal to the Euclidean coordinate
unit of the constant word. -/
theorem kd3TensorPure_coordinateUnit (j : ι) :
    kd3TensorPure (fun _ : κ => EuclideanSpace.single j (1:ℂ)) =
      EuclideanSpace.single (fun _ : κ => j) (1:ℂ) := by
  classical
  apply PiLp.ext
  intro u
  rw [kd3TensorPure_apply,PiLp.single_apply]
  by_cases h : u=(fun _ : κ => j)
  · subst u
    simp
  · obtain ⟨t,ht⟩ : ∃ t, u t≠j := by
      by_contra! hn
      exact h (funext hn)
    rw [if_neg h]
    exact Finset.prod_eq_zero (Finset.mem_univ t) (by simp [ht])

theorem kd3EuclideanMatrixOp_diagonal_apply (z : ι→ℂ)
    (v : EuclideanSpace ℂ ι) (i : ι) :
    (kd3EuclideanMatrixOp (Matrix.diagonal z) v) i = z i * v i := by
  change (((Matrix.diagonal z) *ᵥ WithLp.ofLp v) i)=z i*v i
  exact Matrix.mulVec_diagonal z _ i

/-- A diagonal matrix with one isolated coordinate at a specified value
has exactly that one-dimensional eigenspace. -/
theorem kd3EuclideanDiagonal_simple (z : ι→ℂ) (j : ι)
    (hIsol : ∀ i, i≠j → z i≠z j) :
    kd3EuclideanMatrixOp (Matrix.diagonal z) (EuclideanSpace.single j 1) =
      z j • (EuclideanSpace.single j 1 : EuclideanSpace ℂ ι) ∧
    ∀ v : EuclideanSpace ℂ ι,
      kd3EuclideanMatrixOp (Matrix.diagonal z) v=z j • v →
      ∃ c : ℂ, v=c • (EuclideanSpace.single j 1 : EuclideanSpace ℂ ι) := by
  constructor
  · apply PiLp.ext
    intro i
    change (kd3EuclideanMatrixOp (Matrix.diagonal z) (EuclideanSpace.single j 1)) i=
      z j*(EuclideanSpace.single j (1:ℂ)) i
    rw [kd3EuclideanMatrixOp_diagonal_apply,PiLp.single_apply]
    by_cases h : i=j
    · subst i
      simp
    · simp [h]
  · intro v hv
    refine ⟨v j,?_⟩
    apply PiLp.ext
    intro i
    change v i=v j*(EuclideanSpace.single j (1:ℂ)) i
    rw [PiLp.single_apply]
    by_cases h : i=j
    · subst i
      simp
    · have hh := congrArg (fun v : EuclideanSpace ℂ ι => v i) hv
      change (kd3EuclideanMatrixOp (Matrix.diagonal z) v) i=z j*v i at hh
      rw [kd3EuclideanMatrixOp_diagonal_apply,←sub_eq_zero,←sub_mul] at hh
      have hi : v i=0 := (mul_eq_zero.mp hh).resolve_left (sub_ne_zero.mpr (hIsol i h))
      simp [h,hi]

noncomputable def kd3TensorTopVector (j : ι) : EuclideanSpace ℂ (κ→ι) :=
  EuclideanSpace.single (fun _ : κ => j) (1:ℂ)

noncomputable def kd3TensorCartanSpace (π : G→*Matrix ι ι ℂ) (j : ι) :
    Submodule ℂ (EuclideanSpace ℂ (κ→ι)) :=
  kd3CyclicUnitarySpace (kd3ActualTensorRep π) (kd3TensorTopVector j)

noncomputable def kd3TensorCartanRep (π : G→*Matrix ι ι ℂ) (j : ι) :
    G→*(kd3TensorCartanSpace (κ:=κ) π j→L[ℂ]kd3TensorCartanSpace (κ:=κ) π j) :=
  kd3CyclicUnitaryRep (kd3ActualTensorRep (κ:=κ) π) (kd3TensorTopVector (κ:=κ) j)

/-- The actual cyclic subrepresentation of the Euclidean tensor power is
irreducible whenever the extremal product weight is isolated at one
group element. No Cartan existence or complete reducibility theorem is used. -/
theorem kd3TensorCartanRep_irreducible_of_isolated_top
    (π : G→*Matrix ι ι ℂ) (hU : ∀ g, (π g).conjTranspose=π g⁻¹)
    (j : ι) (g₀ : G) (z : ι→ℂ) (hD : π g₀=Matrix.diagonal z)
    (hIsol : ∀ u : κ→ι, u≠(fun _ : κ => j) → (∏ t, z (u t))≠∏ _ : κ, z j) :
    ∀ S : Submodule ℂ (kd3TensorCartanSpace (κ:=κ) π j),
      (∀ g v, v∈S → kd3TensorCartanRep (κ:=κ) π j g v∈S) → S=⊥ ∨ S=⊤ := by
  let R := kd3ActualTensorRep (κ:=κ) π
  let e := kd3TensorTopVector (κ:=κ) j
  let E := kd3CyclicUnitaryVector R e
  let z' (u : κ→ι) := ∏ t, z (u t)
  let c := z' (fun _ : κ => j)
  have H : R g₀=kd3EuclideanMatrixOp (Matrix.diagonal z') := by
    change kd3EuclideanMatrixOp (kd3TensorMatrix (κ:=κ) (π g₀))=_
    rw [hD,kd3TensorMatrix_diagonal]
  obtain ⟨he,hSimple⟩ := kd3EuclideanDiagonal_simple z' (fun _ : κ => j) hIsol
  have hEig : kd3CyclicUnitaryRep R e g₀ E=c • E := by
    apply Subtype.ext
    change R g₀ e=c • e
    rw [H]
    exact he
  have hUnique (v : kd3CyclicUnitarySpace R e)
      (hv : kd3CyclicUnitaryRep R e g₀ v=c • v) :
      ∃ a : ℂ, v=a • E := by
    have hv' := congrArg (fun v : kd3CyclicUnitarySpace R e => v.val) hv
    change R g₀ (v : EuclideanSpace ℂ (κ→ι))=c • (v : EuclideanSpace ℂ (κ→ι)) at hv'
    rw [H] at hv'
    obtain ⟨a,ha⟩ := hSimple v hv'
    exact ⟨a,Subtype.ext ha⟩
  exact kd3Unitary_cyclic_simple_eigenspace_irreducible (kd3CyclicUnitaryRep R e)
    (kd3CyclicUnitaryRep_unitary R (kd3ActualTensorRep_unitary (κ:=κ) π hU) e)
    E (kd3CyclicUnitaryVector_spans R e) g₀ c hEig hUnique

end ActualTensorCartan
end CompactFourierKD



namespace CompactFourierKD
open AddCircle
open scoped BigOperators

private theorem kd3Circle_small_sample_eq_zpow {T : ℝ} (hT : 0<T)
    (M : ℕ) (hM : M≠0) (k : ℤ) :
    fourier k (((T/(M:ℝ)):ℝ) : AddCircle T)=
      Complex.exp (2 * (Real.pi:ℂ) * Complex.I / (M:ℂ)) ^ k := by
  rw [fourier_coe_apply,←Complex.exp_int_mul]
  congr 1
  have hTc : (T:ℂ)≠0 := by exact_mod_cast hT.ne'
  have hMc : (M:ℂ)≠0 := by exact_mod_cast hM
  push_cast
  field_simp

/-- A single exact point of the torus circle distinguishes any prescribed
finite set of integral weights, via a primitive root of sufficiently large
order. This is not an assumption of genericity of the selected parameter. -/
theorem kd3Circle_finite_frequencies_separated (T : ℝ) (hT : 0<T)
    (s : Finset ℤ) : ∃ t : AddCircle T, Set.InjOn (fun k => fourier k t) (s:Set ℤ) := by
  let m : ℕ := s.sup (fun i => s.sup (fun j => (i-j).natAbs))
  let M : ℕ := m+1
  have hM : M≠0 := Nat.succ_ne_zero m
  let t : AddCircle T := (((T/(M:ℝ)):ℝ) : AddCircle T)
  let z : ℂ := Complex.exp (2*(Real.pi:ℂ)*Complex.I/(M:ℂ))
  have hPrim : IsPrimitiveRoot z M := Complex.isPrimitiveRoot_exp M hM
  have hz : z≠0 := Complex.exp_ne_zero _
  refine ⟨t,?_⟩
  intro i hi j hj he
  change fourier i t=fourier j t at he
  have he' : z^i=z^j := (kd3Circle_small_sample_eq_zpow hT M hM i).symm.trans
    (he.trans (kd3Circle_small_sample_eq_zpow hT M hM j))
  have hOne : z^(i-j)=1 := by
    rw [zpow_sub₀ hz,he',div_self (zpow_ne_zero j hz)]
  have hDVD : (M:ℤ)∣i-j := (hPrim.zpow_eq_one_iff_dvd _).mp hOne
  have hBound : (i-j).natAbs≤m := by
    have hi' : i∈s := hi
    have hj' : j∈s := hj
    exact (Finset.le_sup (f:=fun j => (i-j).natAbs) hj').trans
      (Finset.le_sup (f:=fun i => s.sup (fun j => (i-j).natAbs)) hi')
  have hLt : (i-j).natAbs<(M:ℤ).natAbs := by
    rw [Int.natAbs_natCast]
    exact Nat.lt_succ_of_le hBound
  exact sub_eq_zero.mp (Int.eq_zero_of_dvd_of_natAbs_lt_natAbs hDVD hLt)

theorem kd3Circle_prod_characters {T : ℝ} (t : AddCircle T) {I : Type*}
    (s : Finset I) (b : I→ℤ) :
    (∏ i∈s, fourier (b i) t)=fourier (∑ i∈s,b i) t := by
  classical
  induction s using Finset.induction_on with
  | empty => simp only [Finset.prod_empty,Finset.sum_empty,fourier_zero]
  | insert i s hi ih => rw [Finset.prod_insert hi,Finset.sum_insert hi,ih,fourier_add]

end CompactFourierKD



namespace CompactFourierKD
open scoped Matrix ComplexInnerProductSpace
open Matrix

/-- The actual standard compact special unitary group in complex dimension two. -/
abbrev KD3SU2 := Matrix.specialUnitaryGroup (Fin 2) ℂ
noncomputable abbrev KD3SU2Fiber := EuclideanSpace ℂ (Fin 2)

/-- Exact SU(2) parametrization by the first column. -/
noncomputable def kd3SU2Mate (v : KD3SU2Fiber) : Matrix (Fin 2) (Fin 2) ℂ :=
  !![v 0, -star (v 1); v 1, star (v 0)]

private theorem kd3SU2Fiber_norm_one_sum (v : KD3SU2Fiber) (hv : ‖v‖=1) :
    v 0*star (v 0)+v 1*star (v 1)=1 := by
  have hh := EuclideanSpace.norm_sq_eq v
  rw [Fin.sum_univ_two,hv,one_pow] at hh
  change v 0*(starRingEnd ℂ) (v 0)+v 1*(starRingEnd ℂ) (v 1)=1
  rw [Complex.mul_conj',Complex.mul_conj']
  rw [←Complex.ofReal_pow,←Complex.ofReal_pow,←Complex.ofReal_add,←Complex.ofReal_one,hh]

/-- Any actual unit vector in the defining fibre is the first column of
a genuine determinant-one unitary matrix. -/
noncomputable def kd3SU2_fromUnit (v : KD3SU2Fiber) (hv : ‖v‖=1) : KD3SU2 := by
  let A := kd3SU2Mate v
  have he := kd3SU2Fiber_norm_one_sum v hv
  refine ⟨A,Matrix.mem_specialUnitaryGroup_iff.mpr ⟨?_,?_⟩⟩
  · rw [Matrix.mem_unitaryGroup_iff]
    ext i j
    fin_cases i <;> fin_cases j <;>
      simp [A,kd3SU2Mate,Matrix.mul_apply,Fin.sum_univ_two]
    · simpa [mul_comm] using he
    · ring
    · ring
    · simpa [add_comm,mul_comm] using he
  · simp only [A,kd3SU2Mate,Matrix.det_fin_two_of]
    rw [neg_mul,sub_neg_eq_add,mul_comm (star (v 1))]
    exact he

noncomputable def kd3SU2_firstColumn (A : KD3SU2) : KD3SU2Fiber :=
  WithLp.toLp 2 (fun i => (A:Matrix (Fin 2) (Fin 2) ℂ) i 0)

theorem kd3SU2_firstColumn_fromUnit (v : KD3SU2Fiber) (hv : ‖v‖=1) :
    kd3SU2_firstColumn (kd3SU2_fromUnit v hv)=v := by
  apply PiLp.ext
  intro i
  fin_cases i <;> rfl

theorem kd3SU2_firstColumn_norm_one (A : KD3SU2) :
    ‖kd3SU2_firstColumn A‖=1 := by
  let B : Matrix (Fin 2) (Fin 2) ℂ := A
  have hU : star B*B=1 := Matrix.mem_unitaryGroup_iff'.mp A.property.1
  have h := congrArg (fun M : Matrix (Fin 2) (Fin 2) ℂ => M 0 0) hU
  change (star B*B) 0 0=(1 : Matrix (Fin 2) (Fin 2) ℂ) 0 0 at h
  simp only [Matrix.mul_apply,Fin.sum_univ_two,Matrix.star_apply,Matrix.one_apply_eq] at h
  change (starRingEnd ℂ) (B 0 0)*B 0 0+(starRingEnd ℂ) (B 1 0)*B 1 0=1 at h
  rw [Complex.conj_mul',Complex.conj_mul'] at h
  have hR : ‖B 0 0‖^2+‖B 1 0‖^2=1 := by exact_mod_cast h
  have hj := EuclideanSpace.norm_sq_eq (kd3SU2_firstColumn A)
  rw [Fin.sum_univ_two] at hj
  change ‖kd3SU2_firstColumn A‖^2=‖B 0 0‖^2+‖B 1 0‖^2 at hj
  rw [hR] at hj
  nlinarith [norm_nonneg (kd3SU2_firstColumn A)]

private theorem kd3SU2_star_eq_adjugate (A : KD3SU2) :
    star (A:Matrix (Fin 2) (Fin 2) ℂ) = Matrix.adjugate (A:Matrix (Fin 2) (Fin 2) ℂ) := by
  let B : Matrix (Fin 2) (Fin 2) ℂ := A
  have hB : B*star B=1 := Matrix.mem_unitaryGroup_iff.mp A.property.1
  have hDet : B.det=1 := A.property.2
  have hAdj : B.adjugate*B=1 := by rw [Matrix.adjugate_mul,hDet,one_smul]
  calc
    star B=(B.adjugate*B)*star B := by rw [hAdj,Matrix.one_mul]
    _=B.adjugate := by rw [Matrix.mul_assoc,hB,Matrix.mul_one]

/-- The column parametrization is exhaustive on the actual matrix group,
not just an exhibited closed subgroup. -/
theorem kd3SU2_fromUnit_firstColumn (A : KD3SU2) :
    kd3SU2_fromUnit (kd3SU2_firstColumn A) (kd3SU2_firstColumn_norm_one A)=A := by
  apply Subtype.ext
  let B : Matrix (Fin 2) (Fin 2) ℂ := A
  have h := kd3SU2_star_eq_adjugate A
  change star B=B.adjugate at h
  rw [Matrix.adjugate_fin_two] at h
  have h01 := congrArg (fun M : Matrix (Fin 2) (Fin 2) ℂ => M 0 1) h
  have h00 := congrArg (fun M : Matrix (Fin 2) (Fin 2) ℂ => M 0 0) h
  change star (B 1 0)=-(B 0 1) at h01
  change star (B 0 0)=B 1 1 at h00
  change kd3SU2Mate (kd3SU2_firstColumn A)=B
  ext i j
  fin_cases i <;> fin_cases j
  · rfl
  · change -star (B 1 0)=B 0 1
    rw [h01,neg_neg]
  · rfl
  · exact h00

end CompactFourierKD


namespace CompactFourierKD
open Matrix
open scoped Matrix ComplexInnerProductSpace

private theorem kd3SU2_coord_continuous (i j : Fin 2) :
    Continuous (fun A : KD3SU2 => (A:Matrix (Fin 2) (Fin 2) ℂ) i j) :=
  (continuous_apply j).comp ((continuous_apply i).comp continuous_subtype_val)

/-- The explicit first-column parametrization is continuous in both
directions and keeps the actual matrix group topology. -/
theorem kd3SU2_firstColumn_continuous : Continuous kd3SU2_firstColumn := by
  apply (PiLp.continuous_toLp 2 (fun _ : Fin 2 => ℂ)).comp
  exact continuous_pi (fun i => kd3SU2_coord_continuous i 0)

theorem kd3SU2Mate_continuous : Continuous kd3SU2Mate := by
  apply continuous_pi
  intro i
  apply continuous_pi
  intro j
  fin_cases i <;> fin_cases j
  · exact PiLp.continuous_apply 2 (fun _ : Fin 2 => ℂ) 0
  · exact (PiLp.continuous_apply 2 (fun _ : Fin 2 => ℂ) 1).star.neg
  · exact PiLp.continuous_apply 2 (fun _ : Fin 2 => ℂ) 1
  · exact (PiLp.continuous_apply 2 (fun _ : Fin 2 => ℂ) 0).star

theorem kd3SU2_point_norm_one {x : KD3SU2Fiber}
    (h : x∈Metric.sphere (0:KD3SU2Fiber) 1) : ‖x‖=1 := by
  simpa only [Metric.mem_sphere,dist_zero_right] using h

noncomputable def kd3SU2SphereHomeo :
    Metric.sphere (0:KD3SU2Fiber) 1 ≃ₜ KD3SU2 where
  toFun v := kd3SU2_fromUnit v (kd3SU2_point_norm_one v.property)
  invFun A := ⟨kd3SU2_firstColumn A,by
    simpa only [Metric.mem_sphere,dist_zero_right] using kd3SU2_firstColumn_norm_one A⟩
  left_inv v := Subtype.ext (kd3SU2_firstColumn_fromUnit v (kd3SU2_point_norm_one v.property))
  right_inv _ := kd3SU2_fromUnit_firstColumn _
  continuous_toFun := (kd3SU2Mate_continuous.comp continuous_subtype_val).subtype_mk _
  continuous_invFun := kd3SU2_firstColumn_continuous.subtype_mk (fun A => by
    simpa only [Metric.mem_sphere,dist_zero_right] using kd3SU2_firstColumn_norm_one A)

theorem kd3SU2Fiber_finrank_real : Module.finrank ℝ KD3SU2Fiber=4 := by
  rw [←Module.finrank_mul_finrank ℝ ℂ KD3SU2Fiber,Complex.finrank_real_complex,
    finrank_euclideanSpace]
  norm_num

instance kd3SU2_isTopologicalGroup : IsTopologicalGroup KD3SU2 where
  continuous_mul :=
    ((continuous_subtype_val.comp continuous_fst).mul
      (continuous_subtype_val.comp continuous_snd)).subtype_mk _
  continuous_inv := (continuous_id.matrix_conjTranspose.comp continuous_subtype_val).subtype_mk _

instance kd3SU2_compactSpace : CompactSpace KD3SU2 := by
  let T := Metric.sphere (0:KD3SU2Fiber) 1
  let : CompactSpace T := isCompact_iff_compactSpace.mp (isCompact_sphere _ _)
  exact kd3SU2SphereHomeo.surjective.compactSpace kd3SU2SphereHomeo.continuous

instance kd3SU2_connectedSpace : ConnectedSpace KD3SU2 := by
  have hr : (1:Cardinal) < Module.rank ℝ KD3SU2Fiber := by
    rw [←Module.finrank_eq_rank,kd3SU2Fiber_finrank_real]
    norm_num
  let T := Metric.sphere (0:KD3SU2Fiber) 1
  let : ConnectedSpace T := isConnected_iff_connectedSpace.mp (isConnected_sphere hr _ (by norm_num))
  exact kd3SU2SphereHomeo.surjective.connectedSpace kd3SU2SphereHomeo.continuous

end CompactFourierKD


namespace CompactFourierKD
open Matrix AddCircle
open scoped Matrix ComplexInnerProductSpace BigOperators ComplexConjugate

/-- Defining representation of the actual SU(2) matrix group. -/
noncomputable def kd3SU2_definingMatrix : KD3SU2→*Matrix (Fin 2) (Fin 2) ℂ :=
  (Matrix.specialUnitaryGroup (Fin 2) ℂ).subtype

theorem kd3SU2_definingMatrix_continuous : Continuous kd3SU2_definingMatrix :=
  continuous_subtype_val

theorem kd3SU2_definingMatrix_unitary (g : KD3SU2) :
    (kd3SU2_definingMatrix g).conjTranspose=kd3SU2_definingMatrix g⁻¹ := rfl

noncomputable def kd3SU2Weight (i : Fin 2) : ℤ := if i=0 then 1 else -1

noncomputable def kd3SU2_leftCircle (t : AddCircle (1:ℝ)) : KD3SU2 :=
  kd3SU2_fromUnit (EuclideanSpace.single 0 (fourier 1 t)) (by
    rw [PiLp.norm_single,fourier_apply]
    exact Circle.norm_coe _)

theorem kd3SU2_leftCircle_continuous : Continuous kd3SU2_leftCircle := by
  have h : Continuous (fun t : AddCircle (1:ℝ) => EuclideanSpace.single (0:Fin 2) (fourier 1 t)) := by
    apply (PiLp.continuous_toLp 2 (fun _ : Fin 2 => ℂ)).comp
    apply continuous_pi
    intro i
    by_cases hi : i=0
    · subst i
      simpa only [Pi.single_eq_same] using (fourier (T:=1) 1).continuous
    · simpa only [Pi.single_eq_of_ne hi] using (continuous_const : Continuous (fun _ : AddCircle (1:ℝ) => (0:ℂ)))
  exact (kd3SU2Mate_continuous.comp h).subtype_mk _

theorem kd3SU2_leftCircle_matrix (t : AddCircle (1:ℝ)) :
    kd3SU2_definingMatrix (kd3SU2_leftCircle t) =
      Matrix.diagonal (fun i : Fin 2 => fourier (kd3SU2Weight i) t) := by
  change kd3SU2Mate (EuclideanSpace.single 0 (fourier 1 t))=_
  ext i j
  fin_cases i <;> fin_cases j
  · simp [kd3SU2Mate, kd3SU2Weight]
  · simp [kd3SU2Mate]
  · simp [kd3SU2Mate]
  · simpa [kd3SU2Mate,kd3SU2Weight] using (fourier_neg (n:=1) (x:=t)).symm

noncomputable def kd3SU2WordWeight {n : ℕ} (u : Fin n→Fin 2) : ℤ :=
  ∑ i, kd3SU2Weight (u i)

theorem kd3SU2WordWeight_le {n : ℕ} (u : Fin n→Fin 2) :
    kd3SU2WordWeight u≤n := by
  calc
    _ ≤ ∑ _ : Fin n, (1:ℤ) := Finset.sum_le_sum (fun i _ => by
      unfold kd3SU2Weight
      split_ifs <;> norm_num)
    _ = _ := by simp

theorem kd3SU2WordWeight_const_zero (n : ℕ) :
    kd3SU2WordWeight (fun _ : Fin n => (0:Fin 2))=n := by
  simp [kd3SU2WordWeight,kd3SU2Weight]

theorem kd3SU2WordWeight_lt_of_nonconst {n : ℕ} (u : Fin n→Fin 2)
    (h : u≠fun _ => 0) : kd3SU2WordWeight u<n := by
  obtain ⟨i,hi⟩ : ∃ i, u i≠0 := by
    by_contra! H
    exact h (funext H)
  calc
    _ < ∑ _ : Fin n, (1:ℤ) := Finset.sum_lt_sum (fun j _ => by
      unfold kd3SU2Weight
      split_ifs <;> norm_num) ⟨i,Finset.mem_univ i,by simp [kd3SU2Weight,hi]⟩
    _ = _ := by simp

theorem kd3SU2Tensor_leftCircle_diag (n : ℕ) (t : AddCircle (1:ℝ)) :
    kd3ActualTensorRep (κ:=Fin n) kd3SU2_definingMatrix (kd3SU2_leftCircle t)=
      kd3EuclideanMatrixOp (Matrix.diagonal (fun u : Fin n→Fin 2 => fourier (kd3SU2WordWeight u) t)) := by
  change kd3EuclideanMatrixOp (kd3TensorMatrix (κ:=Fin n)
    (kd3SU2_definingMatrix (kd3SU2_leftCircle t)))=_
  rw [kd3SU2_leftCircle_matrix,kd3TensorMatrix_diagonal]
  congr 2
  funext u
  exact kd3Circle_prod_characters t Finset.univ (fun i => kd3SU2Weight (u i))

noncomputable abbrev KD3SU2CartanSpace (n : ℕ) :=
  kd3TensorCartanSpace (κ:=Fin n) kd3SU2_definingMatrix (0:Fin 2)

noncomputable def kd3SU2Cartan (n : ℕ) :
    KD3SU2→*(KD3SU2CartanSpace n→L[ℂ]KD3SU2CartanSpace n) :=
  kd3TensorCartanRep (κ:=Fin n) kd3SU2_definingMatrix (0:Fin 2)

/-- Every actual degree of the SU(2) Cartan tensor construction is
irreducible, by the explicit ±1 circle weights and a rigorously chosen
parameter. -/
theorem kd3SU2Cartan_irreducible (n : ℕ) :
    ∀ S : Submodule ℂ (KD3SU2CartanSpace n),
      (∀ g v, v∈S → kd3SU2Cartan n g v∈S) → S=⊥ ∨ S=⊤ := by
  classical
  let w : (Fin n→Fin 2)→ℤ := kd3SU2WordWeight
  let A : Finset ℤ := Finset.univ.image w
  obtain ⟨t,hT⟩ := kd3Circle_finite_frequencies_separated (1:ℝ) (by norm_num) A
  apply kd3TensorCartanRep_irreducible_of_isolated_top kd3SU2_definingMatrix
    kd3SU2_definingMatrix_unitary 0 (kd3SU2_leftCircle t) (fun i => fourier (kd3SU2Weight i) t)
    (kd3SU2_leftCircle_matrix t)
  intro u hu he
  rw [kd3Circle_prod_characters t Finset.univ
    (fun i : Fin n => kd3SU2Weight (u i)),
    kd3Circle_prod_characters t Finset.univ
      (fun _ : Fin n => kd3SU2Weight (0:Fin 2))] at he
  have h1 : w u∈(A:Set ℤ) := Finset.mem_image.mpr ⟨u,Finset.mem_univ _,rfl⟩
  have h2 : w (fun _ => 0)∈(A:Set ℤ) := Finset.mem_image.mpr ⟨_,Finset.mem_univ _,rfl⟩
  exact ((kd3SU2WordWeight_lt_of_nonconst u hu).ne) ((hT h1 h2 he).trans (kd3SU2WordWeight_const_zero n))

end CompactFourierKD


namespace CompactFourierKD
open scoped ComplexInnerProductSpace
open Matrix ContinuousLinearMap

section UnitSphereSeparation
variable {V : Type*} [NormedAddCommGroup V] [InnerProductSpace ℂ V]

private theorem kd3_inverse_norm_smul_unit (x : V) (hx : x≠0) :
    ‖(‖x‖:ℂ)⁻¹ • x‖=1 := by
  rw [norm_smul,norm_inv,Complex.norm_real,Real.norm_eq_abs,abs_of_nonneg (norm_nonneg _)]
  exact inv_mul_cancel₀ (norm_ne_zero_iff.mpr hx)

/-- Complex operator diagonal separation on the whole unit sphere, no
holomorphic-chart axiom or self-adjointness hypothesis. -/
theorem kd3UnitSphere_diagonal_separates (S : V→L[ℂ]V)
    (h : ∀ x : V, ‖x‖=1 → ⟪x,S x⟫=0) : S=0 := by
  have hDiag (x : V) : ⟪x,S x⟫=0 := by
    by_cases hx : x=0
    · simp [hx]
    · let c : ℂ := (‖x‖:ℂ)⁻¹
      have hc : c≠0 := inv_ne_zero (by exact_mod_cast norm_ne_zero_iff.mpr hx)
      have hcx := h (c • x) (kd3_inverse_norm_smul_unit x hx)
      rw [map_smul,inner_smul_left,inner_smul_right] at hcx
      exact (mul_eq_zero.mp ((mul_eq_zero.mp hcx).resolve_left
        ((map_ne_zero (starRingEnd ℂ)).mpr hc))).resolve_left hc
  have hS := (inner_map_self_eq_zero S.toLinearMap).mp (fun x => inner_eq_zero_symm.mp (hDiag x))
  apply ContinuousLinearMap.ext
  intro x
  exact DFunLike.congr_fun hS x

theorem kd3_span_of_contains_entire_unitSphere {G : Type*} (F : G→V)
    (h : ∀ x : V, ‖x‖=1 → ∃ g, F g=x) :
    Submodule.span ℂ (Set.range F)=⊤ := by
  apply top_unique
  intro x _
  by_cases hx : x=0
  · simp [hx]
  obtain ⟨g,hg⟩ := h ((‖x‖:ℂ)⁻¹ • x) (kd3_inverse_norm_smul_unit x hx)
  have hnorm : (‖x‖:ℂ)≠0 := by exact_mod_cast norm_ne_zero_iff.mpr hx
  have hz := (Submodule.span ℂ (Set.range F)).smul_mem (‖x‖:ℂ)
    (Submodule.subset_span ⟨g,rfl⟩ : F g∈Submodule.span ℂ (Set.range F))
  rwa [hg,smul_smul,mul_inv_cancel₀ hnorm,one_smul] at hz

end UnitSphereSeparation

noncomputable def kd3SU2_definingAction :
    KD3SU2→*(KD3SU2Fiber→L[ℂ]KD3SU2Fiber) :=
  kd3EuclideanMatrixOp.comp ((Matrix.specialUnitaryGroup (Fin 2) ℂ).subtype)

theorem kd3SU2_definingAction_continuous : Continuous kd3SU2_definingAction :=
  kd3EuclideanMatrixOp_continuous.comp continuous_subtype_val

theorem kd3SU2_definingAction_adjoint (g : KD3SU2) :
    (kd3SU2_definingAction g).adjoint=kd3SU2_definingAction g⁻¹ :=
  kd3EuclideanMatrixOp_adjoint (g : Matrix (Fin 2) (Fin 2) ℂ)

theorem kd3SU2_definingAction_inner (g : KD3SU2) (u v : KD3SU2Fiber) :
    ⟪kd3SU2_definingAction g u,kd3SU2_definingAction g v⟫=⟪u,v⟫ := by
  rw [←adjoint_inner_right,kd3SU2_definingAction_adjoint]
  have h := DFunLike.congr_fun (map_mul kd3SU2_definingAction g⁻¹ g) v
  change kd3SU2_definingAction (g⁻¹*g) v=kd3SU2_definingAction g⁻¹ (kd3SU2_definingAction g v) at h
  rw [inv_mul_cancel,map_one] at h
  rw [←h]
  rfl

noncomputable def kd3SU2_e0 : KD3SU2Fiber := EuclideanSpace.single (0:Fin 2) 1
noncomputable def kd3SU2_e1 : KD3SU2Fiber := EuclideanSpace.single (1:Fin 2) 1
noncomputable def kd3SU2_coherentE (g : KD3SU2) := kd3SU2_definingAction g kd3SU2_e0
noncomputable def kd3SU2_coherentW (g : KD3SU2) := kd3SU2_definingAction g kd3SU2_e1

theorem kd3SU2_coherentE_firstColumn (g : KD3SU2) :
    kd3SU2_coherentE g=kd3SU2_firstColumn g := by
  apply PiLp.ext
  intro i
  change ((g : Matrix (Fin 2) (Fin 2) ℂ) *ᵥ (Pi.single 0 1 : Fin 2→ℂ)) i=g.val i 0
  simp [Matrix.mulVec,dotProduct,Fin.sum_univ_two]

theorem kd3SU2_coherentE_spans :
    Submodule.span ℂ (Set.range kd3SU2_coherentE)=⊤ := by
  apply kd3_span_of_contains_entire_unitSphere
  intro x hx
  exact ⟨kd3SU2_fromUnit x hx,
    (kd3SU2_coherentE_firstColumn _).trans (kd3SU2_firstColumn_fromUnit x hx)⟩

theorem kd3SU2_coherentE_diagonal_separates (S : KD3SU2Fiber→L[ℂ]KD3SU2Fiber)
    (h : ∀ g : KD3SU2, ⟪kd3SU2_coherentE g,S (kd3SU2_coherentE g)⟫=0) : S=0 := by
  apply kd3UnitSphere_diagonal_separates
  intro x hx
  have he : kd3SU2_coherentE (kd3SU2_fromUnit x hx)=x :=
    (kd3SU2_coherentE_firstColumn _).trans (kd3SU2_firstColumn_fromUnit x hx)
  simpa only [he] using h (kd3SU2_fromUnit x hx)

theorem kd3SU2_coherentE_norm_one (g : KD3SU2) : ‖kd3SU2_coherentE g‖=1 := by
  rw [kd3SU2_coherentE_firstColumn]
  exact kd3SU2_firstColumn_norm_one g

theorem kd3SU2_coherentW_norm_one (g : KD3SU2) : ‖kd3SU2_coherentW g‖=1 := by
  have h := kd3SU2_definingAction_inner g kd3SU2_e1 kd3SU2_e1
  change ⟪kd3SU2_coherentW g,kd3SU2_coherentW g⟫=⟪kd3SU2_e1,kd3SU2_e1⟫ at h
  have hR : ‖kd3SU2_coherentW g‖^2=‖kd3SU2_e1‖^2 := by
    rw [norm_sq_eq_re_inner (𝕜:=ℂ),norm_sq_eq_re_inner (𝕜:=ℂ)]
    exact congrArg Complex.re h
  have hN : ‖kd3SU2_e1‖=1 := by simp [kd3SU2_e1]
  rw [hN] at hR
  nlinarith [norm_nonneg (kd3SU2_coherentW g)]

end CompactFourierKD


namespace CompactFourierKD
open scoped ComplexInnerProductSpace
open ContinuousLinearMap

theorem kd3SU2_coherentE_continuous : Continuous kd3SU2_coherentE :=
  (ContinuousLinearMap.apply ℂ KD3SU2Fiber kd3SU2_e0).continuous.comp kd3SU2_definingAction_continuous

theorem kd3SU2_coherentW_continuous : Continuous kd3SU2_coherentW :=
  (ContinuousLinearMap.apply ℂ KD3SU2Fiber kd3SU2_e1).continuous.comp kd3SU2_definingAction_continuous

/-- In the actual SU(2) case the second coherent vector, repeated at all
second-channel labels, gives the entire orthogonal hyperplane. -/
theorem kd3SU2_coherentW_spans_hyperplane (g : KD3SU2) :
    (ℂ∙kd3SU2_coherentW g)=(ℂ∙kd3SU2_coherentE g)ᗮ := by
  apply le_antisymm
  · apply Submodule.span_le.mpr
    intro w hw
    have hw' : w=kd3SU2_coherentW g := Set.mem_singleton_iff.mp hw
    rw [hw']
    apply Submodule.mem_orthogonal_singleton_iff_inner_right.mpr
    change ⟪kd3SU2_definingAction g kd3SU2_e0,kd3SU2_definingAction g kd3SU2_e1⟫=0
    rw [kd3SU2_definingAction_inner]
    simp [kd3SU2_e0,kd3SU2_e1,EuclideanSpace.inner_single_left]
  · intro y hy
    let x := kd3SU2_definingAction g⁻¹ y
    have hxy : kd3SU2_definingAction g x=y := by
      have h := DFunLike.congr_fun (map_mul kd3SU2_definingAction g g⁻¹) y
      change kd3SU2_definingAction (g*g⁻¹) y=kd3SU2_definingAction g x at h
      rw [mul_inv_cancel,map_one] at h
      exact h.symm
    have hzero : ⟪kd3SU2_e0,x⟫=0 := by
      calc
        _ = ⟪kd3SU2_definingAction g kd3SU2_e0,kd3SU2_definingAction g x⟫ :=
          (kd3SU2_definingAction_inner g _ _).symm
        _ = 0 := by
          rw [hxy]
          exact Submodule.mem_orthogonal_singleton_iff_inner_right.mp hy
    have hx0 : x 0=0 := by
      simpa [kd3SU2_e0,EuclideanSpace.inner_single_left] using hzero
    have hx : x=(x 1) • kd3SU2_e1 := by
      apply PiLp.ext
      intro i
      fin_cases i
      · simpa [kd3SU2_e1] using hx0
      · simp [kd3SU2_e1]
    have h := congrArg (fun x => kd3SU2_definingAction g x) hx
    rw [hxy,map_smul] at h
    exact Submodule.mem_span_singleton.mpr ⟨x 1,h.symm⟩

theorem kd3SU2_coherentW_repeated_frame (g : KD3SU2) :
    Submodule.span ℂ (Set.range fun _ : ℕ => kd3SU2_coherentW g) = (ℂ∙kd3SU2_coherentE g)ᗮ := by
  rw [Set.range_const,kd3SU2_coherentW_spans_hyperplane]

theorem kd3SU2_coherentW_self_nonzero (g : KD3SU2) :
    ⟪kd3SU2_coherentW g,kd3SU2_coherentW g⟫≠0 := by
  rw [inner_self_eq_norm_sq_to_K,kd3SU2_coherentW_norm_one]
  norm_num

end CompactFourierKD


namespace CompactFourierKD
open AddCircle Matrix ContinuousLinearMap
open scoped ComplexInnerProductSpace

noncomputable def kd3SU2CartanTop (n : ℕ) : KD3SU2CartanSpace n :=
  kd3CyclicUnitaryVector (kd3ActualTensorRep (κ:=Fin n) kd3SU2_definingMatrix)
    (kd3TensorTopVector (κ:=Fin n) (0:Fin 2))

theorem kd3SU2CartanTop_ne_zero (n : ℕ) : kd3SU2CartanTop n≠0 := by
  intro h
  have he := congrArg (fun x : KD3SU2CartanSpace n => x.val (fun _ => 0)) h
  change (EuclideanSpace.single (fun _ : Fin n => (0:Fin 2)) (1:ℂ)) (fun _ => 0)=0 at he
  simp at he

theorem kd3SU2CartanTop_leftCircle (n : ℕ) (t : AddCircle (1:ℝ)) :
    kd3SU2Cartan n (kd3SU2_leftCircle t) (kd3SU2CartanTop n) =
      fourier (n:ℤ) t • kd3SU2CartanTop n := by
  apply Subtype.ext
  change kd3ActualTensorRep (κ:=Fin n) kd3SU2_definingMatrix (kd3SU2_leftCircle t)
      (EuclideanSpace.single (fun _ : Fin n => (0:Fin 2)) 1) =
    fourier (n:ℤ) t • EuclideanSpace.single (fun _ : Fin n => (0:Fin 2)) 1
  rw [kd3SU2Tensor_leftCircle_diag]
  apply PiLp.ext
  intro u
  rw [kd3EuclideanMatrixOp_diagonal_apply]
  change fourier (kd3SU2WordWeight u) t*(EuclideanSpace.single (fun _ : Fin n => (0:Fin 2)) (1:ℂ)) u=
    fourier (n:ℤ) t*(EuclideanSpace.single (fun _ : Fin n => (0:Fin 2)) (1:ℂ)) u
  by_cases h : u=fun _ => 0
  · subst u
    rw [kd3SU2WordWeight_const_zero]
  · simp [h]

/-- The actual highest circle eigenvalue of degree n cannot occur at
lower degree m. Hence the cyclic Cartan representations genuinely belong
to distinct Fourier types, independently of any character table. -/
theorem kd3SU2Cartan_no_intertwining_equiv_of_lt {n m : ℕ} (h : m<n) :
    ¬∃ E : KD3SU2CartanSpace n≃L[ℂ]KD3SU2CartanSpace m,
        ∀ g v, E (kd3SU2Cartan n g v)=kd3SU2Cartan m g (E v) := by
  classical
  rintro ⟨E,hE⟩
  let A : Finset ℤ := insert (n:ℤ) (Finset.univ.image (kd3SU2WordWeight (n:=m)))
  obtain ⟨t,hT⟩ := kd3Circle_finite_frequencies_separated (1:ℝ) (by norm_num) A
  let x := E (kd3SU2CartanTop n)
  have hEig : kd3SU2Cartan m (kd3SU2_leftCircle t) x = fourier (n:ℤ) t • x := by
    have he := hE (kd3SU2_leftCircle t) (kd3SU2CartanTop n)
    rw [kd3SU2CartanTop_leftCircle,map_smul] at he
    exact he.symm
  have hc := congrArg (fun x : KD3SU2CartanSpace m => x.val) hEig
  change kd3ActualTensorRep (κ:=Fin m) kd3SU2_definingMatrix (kd3SU2_leftCircle t) x.val=
    fourier (n:ℤ) t • x.val at hc
  rw [kd3SU2Tensor_leftCircle_diag] at hc
  have hx : x=0 := by
    apply Subtype.ext
    apply PiLp.ext
    intro u
    have he := congrArg (fun v : EuclideanSpace ℂ (Fin m→Fin 2) => v u) hc
    rw [kd3EuclideanMatrixOp_diagonal_apply] at he
    change fourier (kd3SU2WordWeight u) t*(x.val u)=fourier (n:ℤ) t*(x.val u) at he
    rw [←sub_eq_zero,←sub_mul] at he
    have hWord : kd3SU2WordWeight u∈(A:Set ℤ) := Finset.mem_insert_of_mem
      (Finset.mem_image.mpr ⟨u,Finset.mem_univ _,rfl⟩)
    have hTop : (n:ℤ)∈(A:Set ℤ) := Finset.mem_insert_self _ _
    have hne : fourier (kd3SU2WordWeight u) t≠fourier (n:ℤ) t := fun hn => by
      have hBad := (hT hWord hTop hn)
      have hL : kd3SU2WordWeight u < (n:ℤ) :=
        (kd3SU2WordWeight_le u).trans_lt (by exact_mod_cast h)
      exact hL.ne hBad
    have hz := (mul_eq_zero.mp he).resolve_left (sub_ne_zero.mpr hne)
    exact hz
  have hy : E (kd3SU2CartanTop n)=E 0 := by simpa only [map_zero] using hx
  exact (kd3SU2CartanTop_ne_zero n) (E.injective hy)

theorem kd3SU2Cartan_pairwise_inequivalent (n m : ℕ) (hnm : n≠m) :
    ¬∃ E : KD3SU2CartanSpace n≃L[ℂ]KD3SU2CartanSpace m,
        ∀ g v, E (kd3SU2Cartan n g v)=kd3SU2Cartan m g (E v) := by
  rcases lt_or_gt_of_ne hnm with hl | hl
  · rintro ⟨E,hE⟩
    apply kd3SU2Cartan_no_intertwining_equiv_of_lt hl
    refine ⟨E.symm,?_⟩
    intro g v
    apply E.injective
    rw [ContinuousLinearEquiv.apply_symm_apply,hE,ContinuousLinearEquiv.apply_symm_apply]
  · exact kd3SU2Cartan_no_intertwining_equiv_of_lt hl

end CompactFourierKD



namespace CompactFourierKD
open Matrix ContinuousLinearMap
open scoped ComplexInnerProductSpace

theorem kd3SU2Cartan_continuous (n : ℕ) : Continuous (kd3SU2Cartan n) :=
  kd3CyclicUnitaryRep_continuous (kd3ActualTensorRep (κ:=Fin n) kd3SU2_definingMatrix)
    (kd3ActualTensorRep_continuous kd3SU2_definingMatrix kd3SU2_definingMatrix_continuous)
    (kd3TensorTopVector (κ:=Fin n) (0:Fin 2))

theorem kd3SU2Cartan_unitary (n : ℕ) (g : KD3SU2) :
    ContinuousLinearMap.adjoint (𝕜:=ℂ) (E:=KD3SU2CartanSpace n) (F:=KD3SU2CartanSpace n)
      (kd3SU2Cartan n g)=kd3SU2Cartan n g⁻¹ :=
  kd3CyclicUnitaryRep_unitary (kd3ActualTensorRep (κ:=Fin n) kd3SU2_definingMatrix)
    (kd3ActualTensorRep_unitary (κ:=Fin n) kd3SU2_definingMatrix kd3SU2_definingMatrix_unitary)
    (kd3TensorTopVector (κ:=Fin n) (0:Fin 2)) g

instance kd3SU2CartanSpace_nontrivial (n : ℕ) : Nontrivial (KD3SU2CartanSpace n) :=
  nontrivial_of_ne (kd3SU2CartanTop n) 0 (kd3SU2CartanTop_ne_zero n)

/-- The conjugate power-times-coordinate in the actual KD row is a single
inverse matrix coefficient of the correct cyclic Cartan representation.
The mixed vector can be projected onto the actual cyclic subspace without
changing the coefficient. -/
theorem kd3SU2_inverseTrace_power_times_coherent_coefficient
    (N : ℕ) (k : KD3SU2) (v : KD3SU2Fiber) :
    ∃ D : KD3SU2CartanSpace (N+1)→L[ℂ]KD3SU2CartanSpace (N+1),
      ∀ g : KD3SU2,
      LinearMap.trace ℂ (KD3SU2CartanSpace (N+1)) (D.comp (kd3SU2Cartan (N+1) g⁻¹)).toLinearMap =
        ⟪kd3SU2_definingAction g (kd3SU2_coherentE k),kd3SU2_e0⟫^N *
          ⟪kd3SU2_definingAction g (kd3SU2_coherentE k),v⟫ := by
  let S := KD3SU2CartanSpace (N+1)
  let R := kd3ActualTensorRep (κ:=Fin (N+1)) kd3SU2_definingMatrix
  let ρ := kd3SU2Cartan (N+1)
  let e := kd3TensorTopVector (κ:=Fin (N+1)) (0:Fin 2)
  let η : S := ρ k (kd3SU2CartanTop (N+1))
  let ψ := kd3TensorPure (Fin.cons v (fun _ : Fin N => kd3SU2_e0))
  let w : S := S.orthogonalProjectionOnto ψ
  let D : S→L[ℂ]S := (innerSL ℂ η).smulRight w
  refine ⟨D,?_⟩
  intro g
  change LinearMap.trace ℂ S (D.comp (ρ g⁻¹)).toLinearMap=_
  have hTrace : LinearMap.trace ℂ S (D.comp (ρ g⁻¹)).toLinearMap=⟪η,ρ g⁻¹ w⟫ := by
    change LinearMap.trace ℂ S (((innerSL ℂ η).comp (ρ g⁻¹)).toLinearMap.smulRight w)=_
    rw [LinearMap.trace_smulRight]
    rfl
  have hU : ContinuousLinearMap.adjoint (𝕜:=ℂ) (E:=S) (F:=S) (ρ g)=ρ g⁻¹ :=
    kd3SU2Cartan_unitary (N+1) g
  rw [hTrace,←hU,adjoint_inner_right]
  have hp : ⟪ρ g η,w⟫ = ⟪((ρ g η : S): EuclideanSpace ℂ (Fin (N+1)→Fin 2)),ψ⟫ :=
    Submodule.inner_orthogonalProjectionOnto_eq_of_mem_left _ _
  rw [hp]
  have ht : ((ρ g η : S):EuclideanSpace ℂ (Fin (N+1)→Fin 2)) =
      kd3TensorPure (fun _ : Fin (N+1) => kd3SU2_definingAction g (kd3SU2_coherentE k)) := by
    change R g (R k e)=_
    have he : e=kd3TensorPure (fun _ : Fin (N+1) => kd3SU2_e0) :=
      (kd3TensorPure_coordinateUnit (κ:=Fin (N+1)) (0:Fin 2)).symm
    rw [he,kd3ActualTensorRep_pure,kd3ActualTensorRep_pure]
    rfl
  rw [ht]
  change ⟪kd3TensorPure (fun _ : Fin (N+1) => kd3SU2_definingAction g (kd3SU2_coherentE k)),
    kd3TensorPure (Fin.cons v (fun _ : Fin N => kd3SU2_e0))⟫=_
  rw [kd3TensorPure_inner,Fin.prod_univ_succ]
  simp only [Fin.cons_zero,Fin.cons_succ,Finset.prod_const,Finset.card_univ,Fintype.card_fin]
  exact mul_comm _ _

end CompactFourierKD



namespace CompactFourierKD
open Filter Set Module
open scoped Topology Pointwise ComplexInnerProductSpace

section ConnectedLocalOrbit

variable {G V : Type*} [Group G] [TopologicalSpace G] [IsTopologicalGroup G] [ConnectedSpace G]
  [NormedAddCommGroup V] [InnerProductSpace ℂ V] [FiniteDimensional ℂ V]

variable (ρ : G→*(V→L[ℂ]V))
  (hI : ∀ S : Submodule ℂ V, (∀ g v, v∈S → ρ g v∈S) → S=⊥ ∨ S=⊤)

include hI
/-- The orbit from any neighborhood of the identity already spans an
irreducible finite-dimensional representation of a connected group.
This elementary argument avoids real analyticity or any Lie quotient. -/
theorem connectedKD_irreducible_orbit_nhds_span (v : V) (hv : v≠0)
    (W : Set G) (hW : W∈𝓝 (1:G)) :
    Submodule.span ℂ ((fun g => ρ g v) '' W)=⊤ := by
  classical
  let Uspan (U : Set G) := Submodule.span ℂ ((fun g => ρ g v) '' U)
  let dims (m : ℕ) := ∃ U : Set G, U∈𝓝 (1:G) ∧ U⊆W ∧ finrank ℂ (Uspan U)=m
  have hDim : ∃ m, dims m := ⟨_,W,hW,subset_rfl,rfl⟩
  obtain ⟨U,hU,hUW,hUmin⟩ := Nat.find_spec hDim
  obtain ⟨J,hJ,_,hJinv,hJU⟩ := exists_closed_nhds_one_inv_eq_mul_subset hU
  have hJU' : J⊆U := fun g hg => hJU (by
    simpa only [mul_one] using Set.mul_mem_mul hg (mem_of_mem_nhds hJ))
  have hInc {U V' : Set G} (h : U⊆V') : Uspan U≤Uspan V' :=
    Submodule.span_mono (Set.image_mono h)
  have hJrank : finrank ℂ (Uspan U)≤finrank ℂ (Uspan J) := by
    rw [hUmin]
    exact Nat.find_min' hDim ⟨J,hJ,hJU'.trans hUW,rfl⟩
  have hE : Uspan J=Uspan U := Submodule.eq_of_le_of_finrank_le (hInc hJU') hJrank
  let L := Uspan J
  have hacts (g : G) (hg : g∈J) (y : V) (hy : y∈L) : ρ g y∈L := by
    have h : L≤L.comap (ρ g).toLinearMap := Submodule.span_le.mpr (by
      rintro _ ⟨k,hk,rfl⟩
      change ρ g (ρ k v)∈Uspan J
      rw [←mul_apply_eq_comp,←map_mul,hE]
      exact Submodule.subset_span ⟨g*k,hJU (Set.mul_mem_mul hg hk),rfl⟩)
    exact h hy
  let K : Subgroup G :=
    { carrier := {g | (∀ y∈L, ρ g y∈L) ∧ ∀ y∈L, ρ g⁻¹ y∈L}
      one_mem' := by
        constructor <;> intro y hy <;> simpa using hy
      mul_mem' := by
        intro g k hg hk
        refine ⟨?_,?_⟩
        · intro y hy
          rw [map_mul,mul_apply_eq_comp]
          exact hg.1 (ρ k y) (hk.1 y hy)
        · intro y hy
          rw [mul_inv_rev,map_mul,mul_apply_eq_comp]
          exact hk.2 (ρ g⁻¹ y) (hg.2 y hy)
      inv_mem' := fun {g} hg => ⟨hg.2,fun y hy => by simpa only [inv_inv] using hg.1 y hy⟩ }
  have hJK : J⊆(K:Set G) := fun g hg =>
    ⟨hacts g hg,hacts g⁻¹ (by rw [←hJinv]; simpa only [Set.mem_inv,inv_inv] using hg)⟩
  have hKopen : IsOpen (K:Set G) := K.isOpen_of_mem_nhds (Filter.mem_of_superset hJ hJK)
  have hKall : (K:Set G)=Set.univ :=
    IsClopen.eq_univ ⟨K.isClosed_of_isOpen hKopen,hKopen⟩ ⟨1,K.one_mem⟩
  have hAll (g : G) : g∈K := by
    change g∈(K:Set G)
    rw [hKall]
    exact Set.mem_univ g
  have hV : v∈L := Submodule.subset_span ⟨1,mem_of_mem_nhds hJ,by simp⟩
  obtain hbot | htop := hI L (fun g => (hAll g).1)
  · exact (hv (by simpa [hbot] using hV)).elim
  · apply top_unique
    rw [←htop]
    exact hInc (hJU'.trans hUW)

/-- A nonzero matrix coefficient of a connected finite-dimensional
irreducible is nonzero on a dense set, with no analytic package. -/
theorem connectedKD_irreducible_matrix_coefficient_dense_nonzero
    (u v : V) (hu : u≠0) (hv : v≠0) :
    Dense {g : G | ⟪u,ρ g v⟫≠0} := by
  apply dense_iff_inter_open.mpr
  intro U hU hUN
  obtain ⟨g₀,hg₀⟩ := hUN
  by_contra h
  let W : Set G := (fun g => g₀*g) ⁻¹' U
  have hW : W∈𝓝 (1:G) := (hU.preimage (continuous_const.mul continuous_id)).mem_nhds
    (by simpa [W] using hg₀)
  have hSpan := connectedKD_irreducible_orbit_nhds_span ρ hI v hv W hW
  let φ : V→L[ℂ]ℂ := (innerSL ℂ u).comp (ρ g₀)
  have hKer : Submodule.span ℂ ((fun g => ρ g v) '' W)≤φ.ker := Submodule.span_le.mpr (by
    rintro _ ⟨g,hg,rfl⟩
    change ⟪u,ρ g₀ (ρ g v)⟫=0
    rw [←mul_apply_eq_comp,←map_mul]
    by_contra hNZ
    exact h ⟨g₀*g,hg,hNZ⟩)
  rw [hSpan] at hKer
  have hu0 : φ (ρ g₀⁻¹ u)=0 := hKer (Submodule.mem_top : ρ g₀⁻¹ u∈⊤)
  change ⟪u,ρ g₀ (ρ g₀⁻¹ u)⟫=0 at hu0
  rw [←mul_apply_eq_comp,←map_mul,mul_inv_cancel,map_one] at hu0
  change ⟪u,u⟫=0 at hu0
  exact hu (inner_self_eq_zero.mp hu0)

end ConnectedLocalOrbit
end CompactFourierKD


namespace CompactFourierKD
open AddCircle
open scoped ComplexInnerProductSpace

section ShiftedRawCircleWeights

variable {T : ℝ} [Fact (0<T)]
variable {I X : Type*} [Fintype I] [NormedAddCommGroup X] [InnerProductSpace ℂ X]

omit [Fact (0<T)] in
private theorem connectedKD_fourier_pow (k : ℤ) (t : AddCircle T) (n : ℕ) :
    (fourier k t)^n=fourier ((n:ℤ)*k) t := by
  induction n with
  | zero => simp
  | succ n ih => rw [pow_succ,ih,Nat.cast_succ,add_mul,one_mul,fourier_add]

omit [Fact (0<T)] in
/-- The \((N-1)\)-power of a \(q\)-weight scalar shift turns raw circle
weights \(a_i\) into the exact shifted positions \(qL4^n+(a_i-q)\).
This checks that the finite frequency-window theorem uses the original
manuscript's same normalization and sign convention. -/
theorem connectedKD_power_row_has_exact_shifted_weights
    (L : ℕ) (hL : 0<L) (q : ℤ) (a : I→ℤ) (n : ℕ)
    (z d : ℂ) (u : I→X) (t : AddCircle T) :
    (d*(fourier q t*z)^(L*4^n-1)) •
      (∑ i, fourier (a i) t • u i) =
    connectedKD_weightedRow (T:=T) (q*(L:ℤ)) (fun i => a i-q) n
      (fun i => (d*z^(L*4^n-1)) • u i) t := by
  let N : ℕ := L*4^n
  have hN : 0<N := Nat.mul_pos hL (pow_pos (by decide) _)
  have hNint : ((N-1:ℕ):ℤ)=(L:ℤ)*(4:ℤ)^n-1 := by
    rw [Nat.cast_sub (by omega),Nat.cast_one]
    simp [N]
  have hshift (i : I) :
      (((N-1:ℕ):ℤ)*q)+a i=(q*(L:ℤ))*(4:ℤ)^n+(a i-q) := by
    rw [hNint]
    ring
  change (d*(fourier q t*z)^(N-1)) • _ = _
  simp only [connectedKD_weightedRow,ContinuousMap.sum_apply,ContinuousMap.coe_mk,
    Finset.smul_sum,mul_pow,connectedKD_fourier_pow]
  apply Finset.sum_congr rfl
  intro i _
  rw [←hshift,fourier_add,smul_smul,smul_smul]
  congr 1
  ac_rfl

end ShiftedRawCircleWeights
end CompactFourierKD


namespace CompactFourierKD
open Matrix ContinuousLinearMap AddCircle MeasureTheory
open scoped ComplexInnerProductSpace BigOperators

noncomputable def kd3SU2RowSource (n : ℕ) : KD3SU2Fiber :=
  if n%2=0 then kd3SU2_e0 else kd3SU2_e1

theorem kd3SU2RowSource_norm (n : ℕ) : ‖kd3SU2RowSource n‖=1 := by
  unfold kd3SU2RowSource
  split_ifs <;> simp [kd3SU2_e0,kd3SU2_e1]

noncomputable def kd3SU2RowEmbedding (h : HilbertBasis ℕ ℂ ConnectedLabelSpace) (n : ℕ) :
    KD3SU2Fiber→L[ℂ]ConnectedFibreSpace KD3SU2Fiber :=
  if n%2=0 then connectedCoordinateEmb (n/2) else connectedTensorFibre (h (n/2))

theorem kd3SU2RowEmbedding_norm (h : HilbertBasis ℕ ℂ ConnectedLabelSpace) (n : ℕ) (v : KD3SU2Fiber) :
    ‖kd3SU2RowEmbedding h n v‖=‖v‖ := by
  unfold kd3SU2RowEmbedding
  split_ifs
  · rw [connectedCoordinateEmb_apply,lp.norm_single (by norm_num)]
  · rw [connectedTensorFibre_apply]
    have hN : lp.toNorm (connectedTensorLabel v (h (n/2)))=‖v‖ • lp.toNorm (h (n/2)) := by
      apply lp.ext
      funext i
      change ‖connectedTensorLabel v (h (n/2)) i‖=‖v‖*‖h (n/2) i‖
      rw [connectedTensorLabel_coord,norm_smul,mul_comm]
    rw [←lp.norm_toNorm,hN,norm_smul,lp.norm_toNorm,Real.norm_eq_abs,
      abs_of_nonneg (norm_nonneg _),h.orthonormal.norm_eq_one,mul_one]

theorem kd3SU2_definingAction_norm (g : KD3SU2) (v : KD3SU2Fiber) :
    ‖kd3SU2_definingAction g v‖=‖v‖ := by
  have hE : ‖kd3SU2_definingAction g v‖^2=‖v‖^2 := by
    rw [norm_sq_eq_re_inner (𝕜:=ℂ),norm_sq_eq_re_inner (𝕜:=ℂ)]
    exact congrArg Complex.re (kd3SU2_definingAction_inner g v v)
  exact (sq_eq_sq₀ (norm_nonneg _) (norm_nonneg _)).mp hE

def kd3SU2RowExponent (n : ℕ) : ℕ := 8*4^n-1
def kd3SU2RowDegree (n : ℕ) : ℕ := kd3SU2RowExponent n+1

theorem kd3SU2RowDegree_value (n : ℕ) : kd3SU2RowDegree n=8*4^n := by
  unfold kd3SU2RowDegree kd3SU2RowExponent
  exact Nat.sub_add_cancel (Nat.succ_le_of_lt (Nat.mul_pos (by decide) (pow_pos (by decide) _)))

theorem kd3SU2RowDegree_injective : Function.Injective kd3SU2RowDegree := by
  intro n m h
  rw [kd3SU2RowDegree_value,kd3SU2RowDegree_value] at h
  exact (pow_right_injective₀ (a:=(4:ℕ)) (by decide) (by decide)) (Nat.eq_of_mul_eq_mul_left (by decide) h)

noncomputable def kd3SU2RawScalar (n : ℕ) : C(KD3SU2,ℂ) :=
  ⟨fun g => ⟪kd3SU2_e0,kd3SU2_definingAction g (kd3SU2RowSource n)⟫,
    continuous_const.inner ((ContinuousLinearMap.apply ℂ KD3SU2Fiber (kd3SU2RowSource n)).continuous.comp
      kd3SU2_definingAction_continuous)⟩

noncomputable def kd3SU2Prefactor (n : ℕ) : C(KD3SU2,ℂ) :=
  ⟨fun g => (((1/2:ℝ)^n:ℝ):ℂ)*(kd3SU2RawScalar n g)^kd3SU2RowExponent n,
    continuous_const.mul ((kd3SU2RawScalar n).continuous.pow _)⟩

noncomputable def kd3SU2ConnectedField (h : HilbertBasis ℕ ℂ ConnectedLabelSpace)
    (n : ℕ) : C(KD3SU2,ConnectedFibreSpace KD3SU2Fiber) :=
  ⟨fun g => kd3SU2Prefactor n g • (kd3SU2RowEmbedding h n)
      (kd3SU2_definingAction g (kd3SU2RowSource n)),
    (kd3SU2Prefactor n).continuous.smul ((kd3SU2RowEmbedding h n).continuous.comp
      ((ContinuousLinearMap.apply ℂ KD3SU2Fiber (kd3SU2RowSource n)).continuous.comp
        kd3SU2_definingAction_continuous))⟩

/-- The actual SU(2) coherent fields converge in continuous-map norm. -/
theorem kd3SU2ConnectedField_summable (h : HilbertBasis ℕ ℂ ConnectedLabelSpace) :
    Summable fun n=>‖kd3SU2ConnectedField h n‖ := by
  have hs : Summable (fun n : ℕ => (1/2:ℝ)^n) :=
    (summable_geometric_iff_norm_lt_one).2 (by norm_num)
  apply hs.of_nonneg_of_le (fun _ => norm_nonneg _)
  intro n
  apply (ContinuousMap.norm_le _ (by positivity)).mpr
  intro g
  change ‖( (((1/2:ℝ)^n:ℝ):ℂ)*(kd3SU2RawScalar n g)^kd3SU2RowExponent n) •
    kd3SU2RowEmbedding h n (kd3SU2_definingAction g (kd3SU2RowSource n))‖≤(1/2:ℝ)^n
  rw [norm_smul,kd3SU2RowEmbedding_norm,kd3SU2_definingAction_norm,kd3SU2RowSource_norm,mul_one,
    norm_mul,norm_pow,Complex.norm_real,Real.norm_eq_abs,abs_of_nonneg (by positivity)]
  have h1 : ‖kd3SU2RawScalar n g‖≤1 := by
    change ‖⟪kd3SU2_e0,kd3SU2_definingAction g (kd3SU2RowSource n)⟫‖≤1
    refine (norm_inner_le_norm (𝕜:=ℂ) _ _).trans ?_
    rw [kd3SU2_definingAction_norm,kd3SU2RowSource_norm,mul_one]
    simp [kd3SU2_e0]
  exact mul_le_of_le_one_right (by positivity) (pow_le_one₀ (norm_nonneg _) h1)

theorem kd3SU2ConnectedField_even (h : HilbertBasis ℕ ℂ ConnectedLabelSpace) (i : ℕ) (g : KD3SU2) :
    kd3SU2ConnectedField h (2*i) g=kd3SU2Prefactor (2*i) g • connectedCoordinateEmb i (kd3SU2_coherentE g) := by
  have hn : (2*i)%2=0 := by omega
  have hd : (2*i)/2=i := by omega
  change kd3SU2Prefactor (2*i) g • kd3SU2RowEmbedding h (2*i)
    (kd3SU2_definingAction g (kd3SU2RowSource (2*i)))=_
  simp only [kd3SU2RowEmbedding,kd3SU2RowSource,hn,if_true,hd,kd3SU2_coherentE]

theorem kd3SU2ConnectedField_odd (h : HilbertBasis ℕ ℂ ConnectedLabelSpace) (i : ℕ) (g : KD3SU2) :
    kd3SU2ConnectedField h (2*i+1) g=kd3SU2Prefactor (2*i+1) g •
      connectedTensorLabel (kd3SU2_coherentW g) (h i) := by
  have hn : (2*i+1)%2≠0 := by omega
  have hd : (2*i+1)/2=i := by omega
  change kd3SU2Prefactor (2*i+1) g • kd3SU2RowEmbedding h (2*i+1)
    (kd3SU2_definingAction g (kd3SU2RowSource (2*i+1)))=_
  simp only [kd3SU2RowEmbedding,kd3SU2RowSource,hn,if_false,hd,
    connectedTensorFibre_apply,kd3SU2_coherentW]

/-- The defining SU(2) representation is irreducible by the exact full
sphere orbit. -/
theorem kd3SU2_definingAction_irreducible :
    ∀ S : Submodule ℂ KD3SU2Fiber,
      (∀ g v, v∈S → kd3SU2_definingAction g v∈S) → S=⊥ ∨ S=⊤ := by
  intro S hS
  by_cases h : S=⊥
  · exact Or.inl h
  · right
    have he : ∃ x∈S, x≠0 := by
      by_contra! H
      apply h
      apply eq_bot_iff.mpr
      intro x hx
      rw [Submodule.mem_bot]
      exact H x hx
    obtain ⟨x,hx,hne⟩ := he
    let u : KD3SU2Fiber := (‖x‖:ℂ)⁻¹ • x
    have hu : ‖u‖=1 := kd3_inverse_norm_smul_unit x hne
    let g := kd3SU2_fromUnit u hu
    have hg : kd3SU2_definingAction g kd3SU2_e0=u :=
      (kd3SU2_coherentE_firstColumn g).trans (kd3SU2_firstColumn_fromUnit u hu)
    have hIn : kd3SU2_definingAction g⁻¹ u∈S := hS _ _ (S.smul_mem _ hx)
    rw [← hg] at hIn
    have hv := DFunLike.congr_fun (map_mul kd3SU2_definingAction g⁻¹ g) kd3SU2_e0
    change kd3SU2_definingAction (g⁻¹*g) kd3SU2_e0 =
      kd3SU2_definingAction g⁻¹ (kd3SU2_definingAction g kd3SU2_e0) at hv
    rw [inv_mul_cancel,map_one,one_apply_eq_self] at hv
    have hE : kd3SU2_e0∈S := hv.symm ▸ hIn
    apply top_unique
    rw [←kd3SU2_coherentE_spans]
    exact Submodule.span_le.mpr (by rintro _ ⟨g,rfl⟩; exact hS g _ hE)

theorem kd3SU2Prefactor_dense_nonzero (n : ℕ) :
    Dense {g : KD3SU2 | kd3SU2Prefactor n g≠0} := by
  have hE : kd3SU2_e0≠0 := by simp [kd3SU2_e0]
  have hV : kd3SU2RowSource n≠0 := by
    intro hn
    have h := kd3SU2RowSource_norm n
    simp [hn] at h
  apply (connectedKD_irreducible_matrix_coefficient_dense_nonzero
    kd3SU2_definingAction kd3SU2_definingAction_irreducible _ _ hE hV).mono
  intro g hg
  change kd3SU2RawScalar n g≠0 at hg
  change (((1/2:ℝ)^n:ℝ):ℂ)*(kd3SU2RawScalar n g)^kd3SU2RowExponent n≠0
  exact mul_ne_zero (by exact_mod_cast pow_ne_zero n (by norm_num : (1/2:ℝ)≠0)) (pow_ne_zero _ hg)

end CompactFourierKD


namespace CompactFourierKD
open AddCircle Matrix ContinuousLinearMap
open scoped ComplexInnerProductSpace BigOperators

theorem kd3SU2_leftCircle_zero : kd3SU2_leftCircle 0=1 := by
  apply Subtype.ext
  change kd3SU2_definingMatrix (kd3SU2_leftCircle 0)=(1:Matrix (Fin 2) (Fin 2) ℂ)
  rw [kd3SU2_leftCircle_matrix]
  simp [fourier_apply]

theorem kd3SU2_circle_action_coord (t : AddCircle (1:ℝ)) (g : KD3SU2) (z : KD3SU2Fiber) (i : Fin 2) :
    (kd3SU2_definingAction (kd3SU2_leftCircle t*g) z) i =
      fourier (kd3SU2Weight i) t * (kd3SU2_definingAction g z) i := by
  rw [map_mul]
  change (kd3EuclideanMatrixOp (kd3SU2_definingMatrix (kd3SU2_leftCircle t))
      (kd3SU2_definingAction g z)) i=_
  rw [kd3SU2_leftCircle_matrix,kd3EuclideanMatrixOp_diagonal_apply]

theorem kd3SU2_fibre_reconstruct (z : KD3SU2Fiber) :
    z=∑ i : Fin 2,z i • (EuclideanSpace.single i (1:ℂ)) := by
  apply PiLp.ext
  intro k
  fin_cases k <;> simp [Fin.sum_univ_two]

theorem kd3SU2_rawScalar_circle (t : AddCircle (1:ℝ)) (g : KD3SU2) (n : ℕ) :
    kd3SU2RawScalar n (kd3SU2_leftCircle t*g)=fourier 1 t*kd3SU2RawScalar n g := by
  change ⟪kd3SU2_e0,kd3SU2_definingAction (kd3SU2_leftCircle t*g) (kd3SU2RowSource n)⟫=
    fourier 1 t * ⟪kd3SU2_e0,kd3SU2_definingAction g (kd3SU2RowSource n)⟫
  simp only [kd3SU2_e0,EuclideanSpace.inner_single_left,map_one,one_mul,kd3SU2_circle_action_coord,
    kd3SU2Weight,if_true]

noncomputable def kd3SU2RawCircleComponents (h : HilbertBasis ℕ ℂ ConnectedLabelSpace)
    (g : KD3SU2) (n : ℕ) (i : Fin 2) : ConnectedFibreSpace KD3SU2Fiber :=
  (kd3SU2_definingAction g (kd3SU2RowSource n)) i •
    kd3SU2RowEmbedding h n (EuclideanSpace.single i (1:ℂ))

theorem kd3SU2_rawField_circle (h : HilbertBasis ℕ ℂ ConnectedLabelSpace)
    (t : AddCircle (1:ℝ)) (g : KD3SU2) (n : ℕ) :
    kd3SU2RowEmbedding h n (kd3SU2_definingAction (kd3SU2_leftCircle t*g) (kd3SU2RowSource n)) =
      ∑ i : Fin 2, fourier (kd3SU2Weight i) t • kd3SU2RawCircleComponents h g n i := by
  rw [kd3SU2_fibre_reconstruct (kd3SU2_definingAction (kd3SU2_leftCircle t*g) (kd3SU2RowSource n)),map_sum]
  simp only [map_smul,kd3SU2_circle_action_coord,kd3SU2RawCircleComponents,mul_smul]

/-- The circle hypothesis for the real SU(2) connected terminal now
follows from the explicit degree and matrix weights, not a frequency
window assumed on the field. -/
theorem kd3SU2ConnectedField_has_actual_circle_weights
    (h : HilbertBasis ℕ ℂ ConnectedLabelSpace) (g : KD3SU2) :
    ∃ c : C(AddCircle (1:ℝ),KD3SU2), ∃ u : ℕ→Fin 2→ConnectedFibreSpace KD3SU2Fiber,
      c 0=g ∧ (∀ n, (kd3SU2ConnectedField h n).comp c=
        connectedKD_weightedRow 8 (fun i => kd3SU2Weight i-1) n (u n)) := by
  let c : C(AddCircle (1:ℝ),KD3SU2) :=
    ⟨fun t => kd3SU2_leftCircle t*g,kd3SU2_leftCircle_continuous.mul continuous_const⟩
  let u (n : ℕ) (i : Fin 2) :=
    ((((1/2:ℝ)^n:ℝ):ℂ)*(kd3SU2RawScalar n g)^kd3SU2RowExponent n) •
      kd3SU2RawCircleComponents h g n i
  refine ⟨c,u,?_,?_⟩
  · change kd3SU2_leftCircle 0*g=g
    rw [kd3SU2_leftCircle_zero,one_mul]
  · intro n
    apply ContinuousMap.ext
    intro t
    change ((((1/2:ℝ)^n:ℝ):ℂ)*
      (kd3SU2RawScalar n (kd3SU2_leftCircle t*g))^kd3SU2RowExponent n) •
      kd3SU2RowEmbedding h n
        (kd3SU2_definingAction (kd3SU2_leftCircle t*g) (kd3SU2RowSource n))=_
    rw [kd3SU2_rawScalar_circle,kd3SU2_rawField_circle]
    have hS := connectedKD_power_row_has_exact_shifted_weights (T:=1) 8 (by decide)
      1 kd3SU2Weight n (kd3SU2RawScalar n g) ((((1/2:ℝ)^n:ℝ):ℂ))
      (kd3SU2RawCircleComponents h g n) t
    simpa only [kd3SU2RowExponent,u,Int.reduceNeg,one_mul,Nat.cast_ofNat] using hS

end CompactFourierKD


namespace CompactFourierKD
open scoped ComplexInnerProductSpace ComplexConjugate

noncomputable abbrev ChannelHilbert := lp (fun _ : ℕ => ℂ) 2

noncomputable def reflectionCoordinateReal (i : ℕ) : ℝ :=
  Real.sqrt (3/4) * (1/2)^i

theorem reflectionCoordinateReal_pos (i : ℕ) : 0 < reflectionCoordinateReal i := by
  unfold reflectionCoordinateReal
  positivity

theorem reflectionCoordinateReal_sq (i : ℕ) :
    reflectionCoordinateReal i ^ 2 = (3/4)*(1/4)^i := by
  unfold reflectionCoordinateReal
  rw [mul_pow,Real.sq_sqrt (by norm_num),←pow_mul,mul_comm i 2,pow_mul]
  norm_num

theorem reflectionCoordinateReal_double_sq_ne_one (i : ℕ) :
    2*reflectionCoordinateReal i^2≠1 := by
  rw [reflectionCoordinateReal_sq]
  cases i with
  | zero => norm_num
  | succ i =>
    have h0 : (1/4:ℝ)^i≤1 := pow_le_one₀ (by norm_num) (by norm_num)
    have h : (1/4:ℝ)^(i+1)≤1/4 := by rw [pow_succ]; linarith
    intro he
    linarith

noncomputable def reflectionVector : ChannelHilbert :=
  ⟨fun i => (reflectionCoordinateReal i:ℂ),memℓp_gen (by
    have h := ((summable_geometric_iff_norm_lt_one).2 (by norm_num : ‖(1/4:ℝ)‖<1)).mul_left (3/4:ℝ)
    simpa [Complex.norm_real,Real.norm_eq_abs,abs_of_pos (reflectionCoordinateReal_pos _),
      reflectionCoordinateReal_sq] using h)⟩

theorem reflectionVector_norm : ‖reflectionVector‖=1 := by
  have h := lp.norm_rpow_eq_tsum (by norm_num : 0<(2:ENNReal).toReal) reflectionVector
  simp only [ENNReal.toReal_ofNat,Real.rpow_two] at h
  change ‖reflectionVector‖^2 = ∑' i, ‖(reflectionCoordinateReal i:ℂ)‖^2 at h
  simp_rw [Complex.norm_real,Real.norm_eq_abs,abs_of_pos (reflectionCoordinateReal_pos _),
    reflectionCoordinateReal_sq] at h
  rw [tsum_mul_left,tsum_geometric_of_lt_one (by norm_num) (by norm_num)] at h
  norm_num at h
  exact h.resolve_right (fun hn => (not_lt_of_ge (norm_nonneg reflectionVector)) (hn ▸ by norm_num))

/-- The actual two channel Hilbert bases of the connected proof,
not an assumption of a nonzero overlap matrix. -/
theorem channelHilbert_second_basis_all_coordinates_nonzero :
    ∃ v : HilbertBasis ℕ ℂ ChannelHilbert, ∀ i j, (v j) i≠0 := by
  classical
  let w := reflectionVector
  let v : HilbertBasis ℕ ℂ ChannelHilbert := .ofRepr
    (Submodule.reflection (ℂ ∙ w)).symm
  refine ⟨v,fun i j => ?_⟩
  have hV : v j=(Submodule.reflection (ℂ ∙ w)) (lp.single 2 j (1:ℂ)) := by
    rw [←v.repr_symm_single]
    rfl
  have hW : ‖w‖=1 := reflectionVector_norm
  have hVal : (v j) i=2*(conj (w j))*w i-(if i=j then 1 else 0) := by
    have hvec := hV.trans (Submodule.reflection_singleton_apply w (lp.single 2 j (1:ℂ)))
    rw [hW,RCLike.ofReal_one,one_pow,div_one,lp.inner_single_right] at hvec
    have hh := congrArg (fun z : ChannelHilbert => z i) hvec
    change (v j) i=(2:ℕ) • (inner ℂ (w j) 1 • w i)
      -(lp.single (E:=fun _ : ℕ => ℂ) 2 j 1) i at hh
    simpa [RCLike.inner_apply,two_nsmul,smul_eq_mul,Pi.single_apply,eq_comm,two_mul,add_mul] using hh
  have hCoord (k : ℕ) : w k=(reflectionCoordinateReal k:ℂ) := rfl
  have hn (k : ℕ) : w k≠0 := by
    rw [hCoord,Complex.ofReal_ne_zero]
    exact (reflectionCoordinateReal_pos _).ne'
  rw [hVal]
  by_cases h : i=j
  · subst j
    rw [if_pos rfl,mul_assoc]
    have hC : conj (w i)*w i=((reflectionCoordinateReal i^2:ℝ):ℂ) := by
      rw [hCoord,Complex.conj_ofReal,←Complex.ofReal_mul,pow_two]
    rw [hC]
    intro hz
    have hh := congrArg Complex.re (sub_eq_zero.mp hz)
    simp [Complex.mul_re] at hh
    have hpow : ((↑(reflectionCoordinateReal i):ℂ)^2).re=reflectionCoordinateReal i^2 := by
      rw [←Complex.ofReal_pow,Complex.ofReal_re]
    rw [hpow] at hh
    exact reflectionCoordinateReal_double_sq_ne_one i hh
  · rw [if_neg h,sub_zero]
    exact mul_ne_zero (mul_ne_zero (by norm_num) ((map_ne_zero (starRingEnd ℂ)).2 (hn j))) (hn i)

end CompactFourierKD

namespace CompactFourierKD
open scoped ComplexInnerProductSpace

noncomputable def kd3SU2FibreBasisVector (p : ℕ×Fin 2) : ConnectedFibreSpace KD3SU2Fiber :=
  connectedCoordinateEmb p.1 (EuclideanSpace.single p.2 (1:ℂ))

theorem kd3SU2FibreBasisVector_orthonormal :
    Orthonormal ℂ kd3SU2FibreBasisVector := by
  apply orthonormal_iff_ite.mpr
  intro p q
  rw [kd3SU2FibreBasisVector,kd3SU2FibreBasisVector,connectedCoordinateEmb_inner_left,
    connectedCoordinateEmb_apply,lp.coeFn_single,Pi.single_apply]
  by_cases h₁ : p.1=q.1
  · by_cases h₂ : p.2=q.2
    · have H : p=q := Prod.ext h₁ h₂
      subst q
      simp
    · have H : p≠q := fun H => h₂ (congrArg Prod.snd H)
      simp [h₁,h₂,H,EuclideanSpace.inner_single_left]
  · have H : p≠q := fun H => h₁ (congrArg Prod.fst H)
    simp [h₁,H]

/-- A literal countable Hilbert basis of the actual SU(2) feature space. -/
noncomputable def kd3SU2FibreBasis :
    HilbertBasis (ℕ×Fin 2) ℂ (ConnectedFibreSpace KD3SU2Fiber) := by
  apply HilbertBasis.mkOfOrthogonalEqBot kd3SU2FibreBasisVector_orthonormal
  apply eq_bot_iff.mpr
  intro x hx
  rw [Submodule.mem_bot]
  apply lp.ext
  funext i
  apply PiLp.ext
  intro j
  have hz := Submodule.inner_right_of_mem_orthogonal
    (Submodule.subset_span (Set.mem_range_self (f:=kd3SU2FibreBasisVector) (i,j))) hx
  change ⟪connectedCoordinateEmb i (EuclideanSpace.single j (1:ℂ)),x⟫=0 at hz
  rw [connectedCoordinateEmb_inner_left,EuclideanSpace.inner_single_left] at hz
  simpa using hz

end CompactFourierKD

namespace CompactFourierKD
/-- Two concrete standard matrices in SU(2) do not commute. -/
theorem kd3SU2_exists_noncommuting :
    ∃ a b : KD3SU2, a*b≠b*a := by
  let e := EuclideanSpace.single (0:Fin 2) Complex.I
  let a := kd3SU2_fromUnit e (by simp [e])
  let b := kd3SU2_fromUnit kd3SU2_e1 (by simp [kd3SU2_e1])
  refine ⟨a,b,?_⟩
  intro h
  have H := congrArg (fun z : KD3SU2 => Complex.im (kd3SU2_definingMatrix z 0 1)) h
  change ((kd3SU2_definingMatrix (a*b) 0 1)).im=
    ((kd3SU2_definingMatrix (b*a) 0 1)).im at H
  rw [map_mul,map_mul] at H
  change ((kd3SU2Mate e * kd3SU2Mate kd3SU2_e1) 0 1).im =
    ((kd3SU2Mate kd3SU2_e1 * kd3SU2Mate e) 0 1).im at H
  norm_num [Matrix.mul_apply,Fin.sum_univ_two,kd3SU2Mate,e,kd3SU2_e1,
    PiLp.single_apply,Complex.star_def] at H
end CompactFourierKD


namespace CompactFourierKD
open MeasureTheory ContinuousLinearMap AddCircle
open scoped ComplexInnerProductSpace

noncomputable instance : MeasurableSpace KD3SU2 := borel KD3SU2
noncomputable instance : BorelSpace KD3SU2 := ⟨rfl⟩

local notation "μ" => compactKDhaar KD3SU2

/-- The displayed SU(2) field lies in the genuine inverse character
block selected by the conditional connected terminal. This statement is
about actual Haar L² coefficients, not a pointwise surrogate of the row. -/
theorem kd3SU2ConnectedField_actual_fourier_type
    (h : HilbertBasis ℕ ℂ ConnectedLabelSpace) (n : ℕ)
    (x : ConnectedFibreSpace KD3SU2Fiber) :
    ∃ D : KD3SU2CartanSpace (kd3SU2RowDegree n)→L[ℂ]KD3SU2CartanSpace (kd3SU2RowDegree n),
      compactKD_featureAnalysis (kd3SU2ConnectedField h n) x =
        compactMatrixCoefficientCLM (kd3SU2Cartan (kd3SU2RowDegree n))
          (kd3SU2Cartan_continuous (kd3SU2RowDegree n)) D := by
  let a := kd3SU2RowEmbedding h n
  let v := a.adjoint x
  let N := kd3SU2RowExponent n
  let c : ℂ := (((1/2:ℝ)^n:ℝ):ℂ)
  let z := kd3SU2RowSource n
  let k := kd3SU2_fromUnit z (kd3SU2RowSource_norm n)
  have he : kd3SU2_coherentE k=z :=
    (kd3SU2_coherentE_firstColumn k).trans (kd3SU2_firstColumn_fromUnit _ _)
  obtain ⟨D,hD⟩ := kd3SU2_inverseTrace_power_times_coherent_coefficient N k v
  refine ⟨c • D,?_⟩
  let rho := kd3SU2Cartan (N+1)
  let hr := kd3SU2Cartan_continuous (N+1)
  have hF : compactKD_featureCoefficient (kd3SU2ConnectedField h n) x =
      compactMatrixCoefficientContinuous rho hr (c • D) := by
    ext g
    let y := kd3SU2_definingAction g z
    change ⟪(c*⟪kd3SU2_e0,y⟫^N) • a y,x⟫ =
      compactContinuousTrace ((c • D).comp (rho g⁻¹))
    have hTr : compactContinuousTrace (D.comp (rho g⁻¹))=⟪y,kd3SU2_e0⟫^N*⟪y,v⟫ := by
      have hProof := hD g
      rw [he] at hProof
      exact hProof
    have hC : (starRingEnd ℂ) c=c := Complex.conj_ofReal _
    have hAdj : ⟪a y,x⟫=⟪y,v⟫ := (adjoint_inner_right a y x).symm
    rw [inner_smul_left,map_mul,map_pow,hC,inner_conj_symm,hAdj,
      ContinuousLinearMap.smul_comp,map_smul,smul_eq_mul,hTr]
    change c*⟪y,kd3SU2_e0⟫^N*⟪y,v⟫=c*(⟪y,kd3SU2_e0⟫^N*⟪y,v⟫)
    rw [mul_assoc]
  exact congrArg (fun f : C(KD3SU2,ℂ) => ContinuousMap.toLp 2 μ ℂ f) hF

/-- First explicit unconditional connected compact nonabelian case:
the actual standard group SU(2) has an infinite-rank extreme state in
the set defined by all actual Haar KD projections and position cuts. -/
theorem compactKD_actual_SU2_infiniteRank_extreme_at
    {J : Type*} (d : HilbertBasis J ℂ (HaarL2 μ)) :
    ∃ P : HaarOp μ, CompactKDExtremeAt μ d P ∧ ¬FiniteDimensional ℂ P.range := by
  obtain ⟨h,hh⟩ := channelHilbert_second_basis_all_coordinates_nonzero
  let e : C(KD3SU2,KD3SU2Fiber) := ⟨kd3SU2_coherentE,kd3SU2_coherentE_continuous⟩
  let w : ℕ→C(KD3SU2,KD3SU2Fiber) :=
    fun _ => ⟨kd3SU2_coherentW,kd3SU2_coherentW_continuous⟩
  let F := kd3SU2ConnectedField h
  let rho (n : ℕ) := kd3SU2Cartan (kd3SU2RowDegree n)
  have hIrr (n : ℕ) : compactRepresentationIrreducible (rho n) :=
    kd3SU2Cartan_irreducible _
  have hNE (n m : ℕ) (hnm : n≠m) :
      ¬∃ A : KD3SU2CartanSpace (kd3SU2RowDegree n)≃L[ℂ]KD3SU2CartanSpace (kd3SU2RowDegree m),
        ∀ g v, A (rho n g v)=rho m g (A v) :=
    kd3SU2Cartan_pairwise_inequivalent _ _ (fun he => hnm (kd3SU2RowDegree_injective he))
  have hR (i j : Fin 2) : |(kd3SU2Weight j-1)-(kd3SU2Weight i-1)|≤2 := by
    fin_cases i <;> fin_cases j <;> norm_num [kd3SU2Weight]
  exact compactKD_connected_infiniteRank_extreme_from_coherent_rows (T₀:=1)
    1 e w kd3SU2_coherentE_norm_one kd3SU2_coherentE_spans kd3SU2_coherentE_diagonal_separates
    kd3SU2_coherentW_repeated_frame (kd3SU2_coherentW_norm_one 1)
    (fun _ _ => kd3SU2_coherentW_self_nonzero 1)
    h hh F kd3SU2Prefactor (kd3SU2ConnectedField_summable h) kd3SU2Prefactor_dense_nonzero
    (kd3SU2ConnectedField_even h) (kd3SU2ConnectedField_odd h)
    rho (fun _ => kd3SU2Cartan_continuous _) hIrr (kd3SU2ConnectedField_actual_fourier_type h) hNE
    8 2 (fun i => kd3SU2Weight i-1) hR (by norm_num)
    (kd3SU2ConnectedField_has_actual_circle_weights h) kd3SU2FibreBasis (0,0) d

theorem compactKD_actual_SU2_infiniteRank_extreme :
    ∃ (J : Set (HaarL2 μ)) (d : HilbertBasis J ℂ (HaarL2 μ)) (P : HaarOp μ),
      CompactKDExtremeAt μ d P ∧ ¬FiniteDimensional ℂ P.range := by
  obtain ⟨J,d,-⟩ := exists_hilbertBasis ℂ (HaarL2 μ)
  obtain ⟨P,hP,hRank⟩ := compactKD_actual_SU2_infiniteRank_extreme_at d
  exact ⟨J,d,P,hP,hRank⟩

end CompactFourierKD

#print axioms CompactFourierKD.kd3SU2_exists_noncommuting
#print axioms CompactFourierKD.kd3SU2ConnectedField_actual_fourier_type
#print axioms CompactFourierKD.compactKD_actual_SU2_infiniteRank_extreme_at
#print axioms CompactFourierKD.compactKD_actual_SU2_infiniteRank_extreme

