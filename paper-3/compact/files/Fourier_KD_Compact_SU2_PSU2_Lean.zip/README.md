# Strict Lean replay: two compact nonabelian examples

These are the source and compiler receipts for the concrete groups SU(2)
and the literal compact Haar quotient PSU(2) = SU(2) / {I, −I}. They check a
normal trace-one, infinite-rank extreme state for the actual measurable
position cuts and central Fourier projections. No coherent representation
input remains for either example. The general compact classification, and a
separate equivalence to a matrix model of SO(3), are not claimed as formalized.

## Replay

Use Lean 4.33.1 and Mathlib revision
`0df444a360eaa60ab8c11dca51a86af692955474`.
This directory includes a minimal Lake environment pinned to that revision.
From it, with that Lean toolchain installed, run:

```sh
lake update
lake exe cache get
lake env lean -DwarningAsError=true ActualSU2InfiniteRankExtreme.lean
lake env lean -DwarningAsError=true ActualPSU2InfiniteRankExtreme.lean
sha256sum -c SHA256SUMS
```

The second file includes the first construction and its descent through the
central quotient. The original strict checks used this version and a
locally reconstructed Mathlib cache. In that environment only, the rebuild
of `Mathlib.Analysis.Normed.Module.Dual` needed the equivalent proof step
documented in `replay-dependency-Dual-proof-only.patch`; no theorem statement
or axiom was changed. The supplied logs are the original terminal receipts.
The terminal declarations depend on `propext`, `Classical.choice`, and
`Quot.sound` only, without `sorryAx`. Independent human review is not reported.

Mathlib-derived portions retain their in-source notices; the Apache 2.0
license text is provided in LICENSE.
