---
title: "Infinite-rank central Fourier KD extreme states on countable discrete nonabelian groups"
author: hys-ops
subtitle: "Fourier Kirkwood–Dirac positivity · Paper 3"
geometry: margin=25mm
mainfont: DejaVu Serif
fontsize: 10pt
colorlinks: true
---

## Measurement and scope

Let \(L(G)\) be the von Neumann algebra of the left regular representation on \(L^2(G)\). For a measurable position set \(E\), let \(M_E\) multiply by its indicator. A normal state is represented by a positive trace-class operator \(\rho\) of trace one. It is central-Fourier KD-positive if \(\operatorname{Tr}(\rho Q M_E)\) is real and nonnegative for every \(E\) and every projection \(Q\) in the center \(Z(L(G))\). Extremality is taken in that full convex set of normal KD-positive states. Rank is operator rank.

This is a nonabelian classification for the specified central measurement. The abelian classification is [Paper 2](https://hys-ops.github.io/fourier-kd-polytopes/paper-2/). Neither this note nor its companion claims a classification outside its stated class of groups. These are written proofs; no Lean verification or independent human review is reported. Priority has not been assessed.

**Research contributions and AI use.** hys-ops directed the research. AI assisted with developing and presenting the written arguments.

## Theorem

For a countable discrete nonabelian group, an infinite-rank normal extreme state for the central Fourier KD measurement exists if and only if the group is infinite and some nonidentity element has finite conjugacy class. Equivalently, among infinite groups the condition is that the regular von Neumann center is nonscalar. Finite groups cannot have infinite-rank states.

For example, the infinite dihedral and discrete integer Heisenberg groups are affirmative. The free group on two generators is negative: every nonidentity conjugacy class is infinite.

## Proof

### An infinite-index FC-center

For a discrete group \(\Gamma\), put \(F=\operatorname{FC}(\Gamma)\). It is the subgroup of elements with finite conjugacy classes. For \(Q\in Z(L(\Gamma))\), the kernel satisfies \(Q_{y,x}=q(yx^{-1})\) with \(q=Q\delta_e\in\ell^2(\Gamma)\) invariant under conjugation. Therefore \(q\) vanishes outside \(F\), so no central test couples distinct right cosets of \(F\). If \(F=\{e\}\) this makes the center scalar. Every normal state then passes the KD tests, and only pure states are extreme.

Suppose \(F\ne\{e\}\) and \([\Gamma:F]=\infty\). The left-translation sum over a nonidentity finite conjugacy class is central and nonscalar; one of its self-adjoint parts has a nonscalar central spectral projection \(Q_0\). A diagonal central projection is scalar by translation invariance. Thus \(c=(Q_0)_{s,e}\ne 0\) for some \(s\in F\setminus\{e\}\). Pick distinct cosets \(Fr_k\) and points \(x_k=r_k,\ y_k=sr_k\). The coefficient \((Q_0)_{y_k,x_k}=c\) is the same for all \(k\).

In the feature space \(\ell^2(\mathbb N)\) with basis \(e_i\), list the orthonormal pairs \((e_i,e_j)\) for \({i<j}\) and \(((e_i+e_{i+1})/\sqrt 2,(e_i-e_{i+1})/\sqrt 2)\) for every \(i\); list each pair \((u,v)\) and \((u,iv)\). Call the resulting sequence \((u_k,v_k)\). Choose \(a_k>0\) with \(2\sum_k a_k=1\). Define \(W\delta_{x_k}=\sqrt{a_k}\,u_k,\ W\delta_{y_k}=\sqrt{a_k}\,v_k\), zero elsewhere. Its range is dense and it is Hilbert--Schmidt. The state \(\rho=W^*W\) has infinite rank and trace one. On each occupied coset the matrix of \(\rho\) is diagonal, and central projections are blind to cross-coset entries. Thus \((\rho Q)_{xx}=\rho_{xx} Q_{xx}\ge 0\) for every singleton \(x\), which suffices since the diagonal of a trace-class operator is absolutely summable.

In any positive KD midpoint decomposition the endpoint \(B\) satisfies \(0\le B\le 2W^*W\). Cauchy--Schwarz for its positive form gives \(B=W^*TW\) with \(0\le T\le 2I\) on the dense feature range. Reality of \((BQ_0)_{x_k,x_k}\) gives \(\operatorname{Im}(c\langle u_k,Tv_k\rangle)=0\). The two phases force each tested off-diagonal form to vanish. The standard pairs eliminate all off-diagonals; the rotated pairs equate adjacent diagonal entries. Thus \(T\) is scalar, and normalization forces \(B=\rho\). The same proof in a finite-dimensional feature space works for each finite rank at least two; position pure states give rank one.

For context on the central coefficient calculation, see [Bachir Bekka, *The Plancherel formula for countable groups*, §2, Lemma 4](https://arxiv.org/abs/2009.01065).

### Proper FC-center of finite index

### Setting and previous result

Let F = FC(Γ) consist of elements having finite conjugacy class. On ℓ²(Γ), a positive trace-one ρ is KD-positive when Tr(ρ Q M_E) is real and nonnegative for all position sets E and central projections Q of the left group von Neumann algebra. Testing singleton positions suffices. By spectral approximation the same inequalities hold with any bounded positive central operator in place of Q. Every bounded central Q has matrix entries Q(y,x) = q(yx⁻¹), where q = Qδ_e is square summable and conjugation invariant. Consequently no Q connects distinct right cosets of F. If F is trivial the center is scalar and only pure states are extreme. If F is nontrivial of infinite index, the [infinite-index FC-center argument](#an-infinite-index-fc-center) places one tunable two-vector test in each of countably many cosets. The argument below needs just two cosets if F itself is infinite.

### Separating a pair from one end

Give F a proper integer-valued Γ-conjugacy-invariant length L. To construct it, enumerate F and, for the h-th element and its inverse, give their entire conjugacy classes generator cost h+1; use minimum total word cost, with cost zero at the identity. Balls are finite because only finitely many positive-cost generators can enter any bounded-cost word. Length is symmetric, subadditive and invariant under Γ conjugation. Since F is infinite, choose x₀,x₁,… in F with L(x₀)≥1 and L(xₙ₊₁)>5L(xₙ).

For i<j set d=xⱼxᵢ⁻¹, mᵢⱼ=|ClΓ(d)|. At the site xᵢ the conjugacy classes of d and d⁻¹ reach only xⱼ among the chosen sites. Indeed every xₗxᵢ⁻¹ with l<j has length ≤2L(xⱼ₋₁), while L(d)≥L(xⱼ)−L(xᵢ)>4L(xⱼ₋₁). For l>j the reverse bounds place its length above L(d). This assertion is needed at the older endpoint only, not at the newer endpoint. It holds after right translation of all the sites.

The operator Kᵢⱼ equal to the sum of λ(s)+λ(s)⁎ over s∈ClΓ(d), divided by 2mᵢⱼ, is a self-adjoint central contraction. At the older site its only occupied coefficient is at the newer one, of size h≥1/(2mᵢⱼ). There is no diagonal contribution. If B is a KD-positive state supported on the chosen positions in two distinct F cosets, evaluating I±Kᵢⱼ at that site gives Bᵢⱼ real and |Bᵢⱼ|≤2mᵢⱼBᵢᵢ. Contributions from the other coset vanish. The crucial bound uses the smaller endpoint weight at deliberately selected older sites.

### Two bases and a trace class state

On H=L²([0,π],dt/π), use the orthonormal cosine basis c₀=1 and cₙ=√2 cos(nt) for n≥1. A second basis is vₙ=eⁱᵗ⁄²cₙ, meaning vₙ(t)=exp(it/2)cₙ(t). Choose two distinct F cosets Fr₀,Fr₁. With weights aₙ>0 to be specified and 2Σaₙ=1, put Wδ_(xₙr₀)=√aₙ cₙ, Wδ_(xₙr₁)=√aₙ vₙ, W=0 on other sites. The map is Hilbert–Schmidt with dense range. Thus ρ=W⁎W has trace one and infinite rank. Its occupied block *within each coset* is diagonal. All cross-coset entries of Q vanish, so (ρQ)xx=ρxxQxx≥0.

In a KD-positive midpoint, an endpoint 0≤B≤2ρ has B=W⁎TW, 0≤T≤2I. Indeed the positive form of B descends to ran W and is bounded there by 2 by Cauchy–Schwarz; extend by density. Each matrix of T in the c and v bases is real by the one-endpoint central tests. Hence T commutes with the conjugation fixing each basis: J₀f=conj(f) and J₁f=exp(it)conj(f). It commutes with J₁J₀, multiplication by exp(it). This function is injective on [0,π], so its spectral projections are exactly the multiplication projections for Borel subsets, modulo null sets. Therefore T=M_f for a real essentially bounded f. Explicitly, commuting with all indicator multipliers implies T1_E=1_E T1; extend from simple functions and use boundedness to obtain f=T1∈L∞.

### The remaining multiplier is constant

Enumerate all positive gaps k in a sequence k_s in which each occurs infinitely often. Choose i_s≥1 above every earlier used index, j_s=i_s+k_s. Give every n initial weight bₙ=2⁻ⁿ⁻¹ and leave each bⱼₛ unchanged, reducing only the bᵢₛ to positive values satisfying mᵢₛⱼₛ√(bᵢₛ/bⱼₛ)≤1/s. Pairs are disjoint, so this is simultaneous and Σbₙ is finite and positive. Normalize all weights by the same constant. Since Bᵢᵢ≤2aᵢ, the preceding bound gives |⟨cᵢ,Tcⱼ⟩|≤4mᵢⱼ√(aᵢ/aⱼ). For each fixed gap k≥1 these entries tend to zero on the designated subsequence.

For i≥1 the same entry with j=i+k equals the integral of f(t)[cos(kt)+cos((2i+k)t)] against dt/π. The second term tends to zero by the Riemann–Lebesgue lemma since f is integrable. Therefore every nonconstant cosine coefficient of f vanishes. Completeness of the cosine basis yields f constant a.e. Then B is a scalar multiple of ρ; trace one forces B=ρ. This proves extremality. In the remaining finite-F case, F proper in a non-FC group has infinite index, so the previous theorem applies.

### The dihedral transfer check

In D∞ write positions (n,ε)=rⁿsᵋ with n∈ℤ, ε∈{0,1}. The central multipliers are the bounded even Fourier multipliers on the two rotation cosets, acting identically on each; this follows from the vanishing central coefficients on all reflections and invariance under inversion. In each row x the induced central measure has even L² density fₓ(t)=ρₓₓ+Σₖ≥1(ρₓ,ₙ₊ₖ+ρₓ,ₙ₋ₖ)cos(kt), with the fixed coset index suppressed and normalized even-circle measure. L² convergence follows from square-summability of each row. KD positivity is exactly fₓ≥0 real almost everywhere for each x. Reality entails Im ρₙ,ₙ₊ₖ = Im ρₙ₋ₖ,ₙ for k≥1; this quantity is constant along each k-step progression and must vanish by Hilbert–Schmidt summability. Both within-coset blocks are therefore real; positive semidefiniteness and realness alone do not replace the row-density inequalities. The two-basis construction exploits those inequalities, not just realness.

### The FC-group case and compact-kernel transfer

### Finite patterns in a nonabelian FC group

Throughout this part every conjugacy class is finite. Any finitely generated subgroup has center of finite index: intersect the finite-index centralizers of its generators. [Schur’s theorem](https://doi.org/10.1016/j.jalgebra.2018.02.023) then makes its derived group finite. A group generated by finitely many finite-order elements inside Γ is finite, since its abelianization and its derived group are finite. In particular the torsion elements form a locally finite normal subgroup T, and every commutator is torsion.

At least one of the following two finite patterns exists. (I) A finite abelian subgroup A has a character χ and an element r in its normalizer such that χ∘Ad(r)≠χ. (II) A finite cyclic central subgroup A is generated by z≠e and there are h,r with hrh⁻¹=zr; choose χ on A nontrivial on z. If T is abelian but not central, the subgroup generated by the conjugates of a noncentral t∈T is finite, abelian, and normalized with a nontrivial action; characters separate its points. If T is central, take any noncommuting pair h,r: its nonidentity commutator z belongs to T. If T is nonabelian, take a finite nonabelian subgroup and apply the following elementary observation.

Within any finite nonabelian group choose a nonabelian subgroup M minimal by order. Its proper subgroups are abelian. Distinct maximal subgroups intersect exactly in Z(M), since together they generate M and each contains the center. If every maximal H were self-normalizing, its conjugates would cover precisely (|M:Z(M)|−|M:H|) nonidentity elements in M/Z(M). This contributes at least half the order of M/Z(M) per conjugacy family and strictly less than its order minus one. Two families overcount, one undercounts, yet every nonidentity coset belongs to some maximal subgroup (use the subgroup generated by a representative and the center). So some maximal abelian A is properly contained in its normalizer, and r in the difference acts nontrivially: otherwise ⟨A,r⟩=M would be abelian. This yields (I).

### Two packets invisible to each other

We first assume that Γ has infinite center or is residually finite. Use the proper conjugation-invariant length L constructed in the [two-coset proof](#proper-fc-center-of-finite-index). Put R=1+max L over A and r,r⁻¹, and h,h⁻¹ if needed. Choose x₀,x₁,… with L(x₀)>10R and L(xₙ₊₁)>5L(xₙ)+10R. There are two permitted choices. With infinite center take xₙ central and ensure (xⱼxᵢ⁻¹)²∉A∖{e} for i<j. If the doubling image of the center is infinite, choose each new square outside the finite union of A xᵢ² and avoid the finite length ball. If the image is finite, take all xₙ from the infinite kernel of doubling. With residual finiteness choose a finite-index normal N with N∩A={e}; take xₙ in N and in the centralizers of h,r and every conjugate of every element of A, omitting h in (I). This is an infinite finite-index subgroup since A is finite and its conjugacy classes are finite.

Write r₀=e,r₁=r. On A xₙr_b take the normalized packet pₙᵇ(a xₙr_b)=χ(a)/√|A|, extended by zero. These supports are mutually disjoint: r∉A separates the channels at a single site and the length gaps separate distinct n even after multiplying by A and r. Each p has fixed left A-character, which every bounded central Q preserves. Thus Qp restricted to the support of p equals ⟨p,Qp⟩p; for a positive Q the scalar is nonnegative.

More strongly, Qp from one channel vanishes pointwise on all packet supports of the other. In (I) each p in channel b has right character t↦χ(r_b t r_b⁻¹) for t∈A as well as left character χ. Q commutes with both translations and preserves both characters. A function with these two characters must vanish at any site y=a xₘr_c where χ(y t y⁻¹) disagrees with its right character for some t; this holds precisely between our two channels. In (II) write Q(y,x)=q(yx⁻¹) with q conjugation invariant. For y in the opposite packet, the q entries in the convolution against p run over all A-multiples of xₘ r_b r_c⁻¹ xₙ⁻¹. Conjugating by h cycles that A-orbit because h centralizes xₘ,xₙ and sends r to zr and r⁻¹ to z⁻¹r⁻¹. The q values are equal and summing χ over A gives zero.

### Local tests that survive packet compression

For i<j put d=xⱼxᵢ⁻¹ and m=|ClΓ(d)|. The same central contraction K as in the two-coset proof averages λ(s)+λ(s)⁎ over s∈ClΓ(d), divided by 2m. Consider the column of its compression to the packet space from pᵢᵇ. Opposite-channel entries vanish. Every conjugate of d, and its inverse, centralizes A by our choice of x’s. A translation λ(s) therefore contributes to packet l in the same channel only if s∈A xₗxᵢ⁻¹. The gap in lengths makes l=j the only possibility: for l<j one has L(s)≤2L(xⱼ₋₁)+R, below L(d); for l>j one has L(s)≥L(xₗ)−L(xᵢ)−R>L(d). There is no diagonal entry.

At l=j, the shift s=d sends pᵢᵇ to pⱼᵇ exactly. In the residual-finite choice, s,d∈N and N∩A={e}, so s∈Ad forces s=d. In the central choice, only s=d or d⁻¹ can occur, and d⁻¹∈Ad implies d²∈A, hence d²=e by construction. Consequently the surviving coefficient ≥1/(2m) is positive and real; it cannot be lost to a character phase.

### Extremality

Use the packets as input basis vectors for the two-basis map W of the [first proof](#proper-fc-center-of-finite-index): send pₙ⁰ to √aₙ cₙ and pₙ¹ to √aₙ exp(it/2)cₙ, killing the orthogonal complement of the packet span. The cₙ are normalized cosines on [0,π]. The state ρ=W⁎W has infinite rank and trace 1. On each occupied site the only contribution to the KD diagonal is from the same packet: other packets in the same channel have zero Gram entry, and opposite-channel packets have zero measured value there. Its diagonal value is aₙ |pₙᵇ(y)|²⟨pₙᵇ,Qpₙᵇ⟩≥0 for every central projection Q.

An endpoint B in a KD-positive midpoint for ρ has B=W⁎TW with 0≤T≤2I. Test I±K using the entire position set A xᵢr_b. On the packet span the position projection is the rank-one projection onto pᵢᵇ. Since B is supported on that span, the tests give Bᵢⱼ real and |Bᵢⱼ|≤2mBᵢᵢ in packet coordinates, exactly the hypotheses of the two-basis proof. Specifically both real basis matrices force T to multiply by f(t); choose one-endpoint weights with m√(aᵢ/aᵢ₊ₖ)→0 along disjoint subsequences for every k≥1. The limiting matrix coefficients are the nonconstant cosine coefficients of f, all zero. Then T is scalar and the midpoint trivial. This proves the assertion for every infinite nonabelian FC group with infinite center or with residual finiteness.

### Finite center reduction

If the center Z is finite, the infinite FC group Γ/Z is residually finite: for g∉Z choose h not commuting with g. The homomorphism given by conjugation on the finite class ClΓ(h) detects g and annihilates Z. If Γ/Z is nonabelian, the preceding proof applies to that quotient. If Γ/Z is abelian, [Γ,Γ]⊆Z and g^|Z| is central for every g by the central commutator identity. Thus Γ/Z is an infinite torsion abelian group. It cannot be locally cyclic: any two elements generating a cyclic subgroup modulo the center lift to two commuting elements, so a locally cyclic central quotient makes Γ abelian. Its finite subgroups thus include incomparable subgroups (otherwise it is locally cyclic), and their orders are unbounded because the union of finitely generated subgroups is infinite and directed. The [abelian classification, Theorem 1.1 of Paper 2](https://hys-ops.github.io/fourier-kd-polytopes/paper-2/) supplies a normal infinite-rank KD extreme state on Γ/Z.

Finally for any compact normal K in a second-countable locally compact group, pullback from G/K, with Haar probability on K, identifies quotient KD-positive states with a support face of those on G. The averaging projection P=∫_K λ(k)dk is central. On its range the regular action is the quotient left regular representation, so P L(G)P is L(G/K) and its center is P Z(L(G)); every quotient central projection extends by zero. The compression of M_E is multiplication by the conditional Haar average of 1_E, which is a positive contraction; quotient position tests are recovered by taking E to be inverse images. Both directions of positivity follow, and any positive midpoint endpoints for a state supported on P are themselves supported on P. Rank is preserved. Apply with K=Z. This finishes the countable-discrete classification. It also transfers any positive discrete example through any compact normal kernel where the quotient is that discrete group, but does not furnish a converse through the quotient or a general nondiscrete criterion.
